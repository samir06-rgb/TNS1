function NotFoundNotifier(id, appUrl) {
  let pathName = window.location.pathname;
  this.load = function () {
    if (!is404Page()) return;
    let data = { id: id, path_name: pathName };
    post(
      appUrl + "/app/broken-links/track",
      "data=" + JSON.stringify(data),
      function (response) {}
    );
  };
  let is404Page = function () {
    let bodyElem = document.getElementsByTagName("body");
    let titleElem = document.getElementsByTagName("title");
    if (bodyElem.length === 1 && bodyElem[0].className.indexOf("404") > -1)
      return !0;
    if (bodyElem.length === 1 && bodyElem[0].id.indexOf("404-") > -1) return !0;
    if (titleElem.length > 0 && titleElem[0].text.indexOf("404 ") > -1)
      return !0;
    return (
      titleElem.length > 0 && titleElem[0].text.indexOf("404 Not Found") > -1
    );
  };
  function post(url, data, callback) {
    let http = new XMLHttpRequest();
    http.open("POST", url, !0);
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.onreadystatechange = function () {
      if (http.readyState === 4 && http.status === 200)
        callback(http.responseText);
    };
    http.send(data);
  }
}
if (!window.hasOwnProperty("NotFoundNotifier"))
  window.NotFoundNotifier = NotFoundNotifier;
(function () {
  new NotFoundNotifier(
    28216,
    "https://image-optimizer.salessquad.co.uk"
  ).load();
})();
