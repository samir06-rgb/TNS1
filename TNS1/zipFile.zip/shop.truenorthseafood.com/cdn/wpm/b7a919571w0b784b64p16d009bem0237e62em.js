(() => {
  var e = {
      11: (e, t, r) => {
        "use strict";
        var n = r(9058),
          o = String,
          i = TypeError;
        e.exports = function (e) {
          if (n(e)) return e;
          throw new i("Can't set " + o(e) + " as a prototype");
        };
      },
      74: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(5201),
          i = TypeError,
          s = Object.getOwnPropertyDescriptor,
          a =
            n &&
            !(function () {
              if (void 0 !== this) return !0;
              try {
                Object.defineProperty([], "length", {
                  writable: !1,
                }).length = 1;
              } catch (e) {
                return e instanceof TypeError;
              }
            })();
        e.exports = a
          ? function (e, t) {
              if (o(e) && !s(e, "length").writable)
                throw new i("Cannot set read only .length");
              return (e.length = t);
            }
          : function (e, t) {
              return (e.length = t);
            };
      },
      78: (e, t, r) => {
        "use strict";
        var n = r(1834);
        e.exports = function (e, t, r) {
          for (
            var o, i, s = r ? e : e.iterator, a = e.next;
            !(o = n(a, s)).done;

          )
            if (void 0 !== (i = t(o.value))) return i;
        };
      },
      164: (e, t, r) => {
        "use strict";
        var n = r(9544),
          o = r(8078),
          i = n("iterator"),
          s = Array.prototype;
        e.exports = function (e) {
          return void 0 !== e && (o.Array === e || s[i] === e);
        };
      },
      352: (e, t, r) => {
        "use strict";
        var n = r(1834),
          o = r(6895),
          i = r(960),
          s = r(7636),
          a = r(3649),
          c = r(3842),
          u = a(function () {
            var e = this.iterator,
              t = i(n(this.next, e));
            if (!(this.done = !!t.done))
              return c(e, this.mapper, [t.value, this.counter++], !0);
          });
        e.exports = function (e) {
          return i(this), o(e), new u(s(this), { mapper: e });
        };
      },
      380: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(1536),
          i = r(2661),
          s = r(960),
          a = r(3094),
          c = TypeError,
          u = Object.defineProperty,
          l = Object.getOwnPropertyDescriptor,
          d = "enumerable",
          p = "configurable",
          f = "writable";
        t.f = n
          ? i
            ? function (e, t, r) {
                if (
                  (s(e),
                  (t = a(t)),
                  s(r),
                  "function" == typeof e &&
                    "prototype" === t &&
                    "value" in r &&
                    f in r &&
                    !r[f])
                ) {
                  var n = l(e, t);
                  n &&
                    n[f] &&
                    ((e[t] = r.value),
                    (r = {
                      configurable: p in r ? r[p] : n[p],
                      enumerable: d in r ? r[d] : n[d],
                      writable: !1,
                    }));
                }
                return u(e, t, r);
              }
            : u
          : function (e, t, r) {
              if ((s(e), (t = a(t)), s(r), o))
                try {
                  return u(e, t, r);
                } catch (n) {}
              if ("get" in r || "set" in r)
                throw new c("Accessors not supported");
              return "value" in r && (e[t] = r.value), e;
            };
      },
      459: (e, t, r) => {
        "use strict";
        var n = r(3013),
          o = r(8280).concat("length", "prototype");
        t.f =
          Object.getOwnPropertyNames ||
          function (e) {
            return n(e, o);
          };
      },
      482: (e) => {
        "use strict";
        e.exports = {};
      },
      543: (e, t, r) => {
        "use strict";
        var n = r(1105);
        e.exports = function (e) {
          return n(e.length);
        };
      },
      621: (e, t, r) => {
        "use strict";
        var n = r(4202);
        e.exports = function (e) {
          return "object" == typeof e ? null !== e : n(e);
        };
      },
      654: (e, t, r) => {
        "use strict";
        var n = r(8482),
          o = r(6591);
        e.exports = function (e) {
          return n(o(e));
        };
      },
      663: (e, t, r) => {
        "use strict";
        r(6202);
      },
      679: (e, t, r) => {
        "use strict";
        var n = r(4202),
          o = r(380),
          i = r(4952),
          s = r(4980);
        e.exports = function (e, t, r, a) {
          a || (a = {});
          var c = a.enumerable,
            u = void 0 !== a.name ? a.name : t;
          if ((n(r) && i(r, u, a), a.global)) c ? (e[t] = r) : s(t, r);
          else {
            try {
              a.unsafe ? e[t] && (c = !0) : delete e[t];
            } catch (l) {}
            c
              ? (e[t] = r)
              : o.f(e, t, {
                  value: r,
                  enumerable: !1,
                  configurable: !a.nonConfigurable,
                  writable: !a.nonWritable,
                });
          }
          return e;
        };
      },
      728: (e, t, r) => {
        "use strict";
        var n = r(6947);
        e.exports = n({}.isPrototypeOf);
      },
      764: (e, t, r) => {
        "use strict";
        var n = r(1311),
          o = r(4202),
          i = r(7759),
          s = r(9544)("toStringTag"),
          a = Object,
          c =
            "Arguments" ===
            i(
              (function () {
                return arguments;
              })()
            );
        e.exports = n
          ? i
          : function (e) {
              var t, r, n;
              return void 0 === e
                ? "Undefined"
                : null === e
                ? "Null"
                : "string" ==
                  typeof (r = (function (e, t) {
                    try {
                      return e[t];
                    } catch (r) {}
                  })((t = a(e)), s))
                ? r
                : c
                ? i(t)
                : "Object" === (n = i(t)) && o(t.callee)
                ? "Arguments"
                : n;
            };
      },
      960: (e, t, r) => {
        "use strict";
        var n = r(621),
          o = String,
          i = TypeError;
        e.exports = function (e) {
          if (n(e)) return e;
          throw new i(o(e) + " is not an object");
        };
      },
      1105: (e, t, r) => {
        "use strict";
        var n = r(1578),
          o = Math.min;
        e.exports = function (e) {
          var t = n(e);
          return t > 0 ? o(t, 9007199254740991) : 0;
        };
      },
      1120: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = r(5201),
          i = r(4202),
          s = r(7759),
          a = r(8144),
          c = n([].push);
        e.exports = function (e) {
          if (i(e)) return e;
          if (o(e)) {
            for (var t = e.length, r = [], n = 0; n < t; n++) {
              var u = e[n];
              "string" == typeof u
                ? c(r, u)
                : ("number" != typeof u &&
                    "Number" !== s(u) &&
                    "String" !== s(u)) ||
                  c(r, a(u));
            }
            var l = r.length,
              d = !0;
            return function (e, t) {
              if (d) return (d = !1), t;
              if (o(this)) return t;
              for (var n = 0; n < l; n++) if (r[n] === e) return t;
            };
          }
        };
      },
      1249: (e, t, r) => {
        "use strict";
        var n = r(5833),
          o = r(9634),
          i = n.Set,
          s = n.add;
        e.exports = function (e) {
          var t = new i();
          return (
            o(e, function (e) {
              s(t, e);
            }),
            t
          );
        };
      },
      1256: (e, t, r) => {
        "use strict";
        r(5873);
      },
      1311: (e, t, r) => {
        "use strict";
        var n = {};
        (n[r(9544)("toStringTag")] = "z"),
          (e.exports = "[object z]" === String(n));
      },
      1381: (e, t, r) => {
        "use strict";
        var n = r(4862),
          o = function (e) {
            return {
              size: e,
              has: function () {
                return !1;
              },
              keys: function () {
                return {
                  next: function () {
                    return { done: !0 };
                  },
                };
              },
            };
          };
        e.exports = function (e) {
          var t = n("Set");
          try {
            new t()[e](o(0));
            try {
              return new t()[e](o(-1)), !1;
            } catch (r) {
              return !0;
            }
          } catch (i) {
            return !1;
          }
        };
      },
      1399: (e, t, r) => {
        "use strict";
        var n = r(4492);
        e.exports = !n(function () {
          return (
            7 !==
            Object.defineProperty({}, 1, {
              get: function () {
                return 7;
              },
            })[1]
          );
        });
      },
      1536: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(4492),
          i = r(3552);
        e.exports =
          !n &&
          !o(function () {
            return (
              7 !==
              Object.defineProperty(i("div"), "a", {
                get: function () {
                  return 7;
                },
              }).a
            );
          });
      },
      1548: (e, t, r) => {
        "use strict";
        var n = r(728),
          o = TypeError;
        e.exports = function (e, t) {
          if (n(t, e)) return e;
          throw new o("Incorrect invocation");
        };
      },
      1554: function (e, t, r) {
        var n;
        !(function (o, i) {
          "use strict";
          var s = "function",
            a = "undefined",
            c = "object",
            u = "string",
            l = "major",
            d = "model",
            p = "name",
            f = "type",
            h = "vendor",
            m = "version",
            v = "architecture",
            g = "console",
            b = "mobile",
            y = "tablet",
            w = "smarttv",
            _ = "wearable",
            x = "embedded",
            k = "Amazon",
            E = "Apple",
            S = "ASUS",
            A = "BlackBerry",
            I = "Browser",
            P = "Chrome",
            C = "Firefox",
            O = "Google",
            T = "Huawei",
            N = "LG",
            j = "Microsoft",
            R = "Motorola",
            $ = "Opera",
            D = "Samsung",
            M = "Sharp",
            U = "Sony",
            L = "Xiaomi",
            B = "Zebra",
            z = "Facebook",
            q = "Chromium OS",
            H = "Mac OS",
            V = function (e) {
              for (var t = {}, r = 0; r < e.length; r++)
                t[e[r].toUpperCase()] = e[r];
              return t;
            },
            W = function (e, t) {
              return typeof e === u && -1 !== F(t).indexOf(F(e));
            },
            F = function (e) {
              return e.toLowerCase();
            },
            K = function (e, t) {
              if (typeof e === u)
                return (
                  (e = e.replace(/^\s\s*/, "")),
                  typeof t === a ? e : e.substring(0, 500)
                );
            },
            J = function (e, t) {
              for (var r, n, o, a, u, l, d = 0; d < t.length && !u; ) {
                var p = t[d],
                  f = t[d + 1];
                for (r = n = 0; r < p.length && !u && p[r]; )
                  if ((u = p[r++].exec(e)))
                    for (o = 0; o < f.length; o++)
                      (l = u[++n]),
                        typeof (a = f[o]) === c && a.length > 0
                          ? 2 === a.length
                            ? typeof a[1] == s
                              ? (this[a[0]] = a[1].call(this, l))
                              : (this[a[0]] = a[1])
                            : 3 === a.length
                            ? typeof a[1] !== s || (a[1].exec && a[1].test)
                              ? (this[a[0]] = l ? l.replace(a[1], a[2]) : i)
                              : (this[a[0]] = l ? a[1].call(this, l, a[2]) : i)
                            : 4 === a.length &&
                              (this[a[0]] = l
                                ? a[3].call(this, l.replace(a[1], a[2]))
                                : i)
                          : (this[a] = l || i);
                d += 2;
              }
            },
            X = function (e, t) {
              for (var r in t)
                if (typeof t[r] === c && t[r].length > 0) {
                  for (var n = 0; n < t[r].length; n++)
                    if (W(t[r][n], e)) return "?" === r ? i : r;
                } else if (W(t[r], e)) return "?" === r ? i : r;
              return e;
            },
            Y = {
              ME: "4.90",
              "NT 3.11": "NT3.51",
              "NT 4.0": "NT4.0",
              2e3: "NT 5.0",
              XP: ["NT 5.1", "NT 5.2"],
              Vista: "NT 6.0",
              7: "NT 6.1",
              8: "NT 6.2",
              8.1: "NT 6.3",
              10: ["NT 6.4", "NT 10.0"],
              RT: "ARM",
            },
            G = {
              browser: [
                [/\b(?:crmo|crios)\/([\w\.]+)/i],
                [m, [p, "Chrome"]],
                [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                [m, [p, "Edge"]],
                [
                  /(opera mini)\/([-\w\.]+)/i,
                  /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i,
                  /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i,
                ],
                [p, m],
                [/opios[\/ ]+([\w\.]+)/i],
                [m, [p, $ + " Mini"]],
                [/\bopr\/([\w\.]+)/i],
                [m, [p, $]],
                [/\bb[ai]*d(?:uhd|[ub]*[aekoprswx]{5,6})[\/ ]?([\w\.]+)/i],
                [m, [p, "Baidu"]],
                [
                  /(kindle)\/([\w\.]+)/i,
                  /(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i,
                  /(avant|iemobile|slim)\s?(?:browser)?[\/ ]?([\w\.]*)/i,
                  /(?:ms|\()(ie) ([\w\.]+)/i,
                  /(flock|rockmelt|midori|epiphany|silk|skyfire|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|qq|duckduckgo)\/([-\w\.]+)/i,
                  /(heytap|ovi)browser\/([\d\.]+)/i,
                  /(weibo)__([\d\.]+)/i,
                ],
                [p, m],
                [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],
                [m, [p, "UC" + I]],
                [
                  /microm.+\bqbcore\/([\w\.]+)/i,
                  /\bqbcore\/([\w\.]+).+microm/i,
                  /micromessenger\/([\w\.]+)/i,
                ],
                [m, [p, "WeChat"]],
                [/konqueror\/([\w\.]+)/i],
                [m, [p, "Konqueror"]],
                [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],
                [m, [p, "IE"]],
                [/ya(?:search)?browser\/([\w\.]+)/i],
                [m, [p, "Yandex"]],
                [/slbrowser\/([\w\.]+)/i],
                [m, [p, "Smart Lenovo " + I]],
                [/(avast|avg)\/([\w\.]+)/i],
                [[p, /(.+)/, "$1 Secure " + I], m],
                [/\bfocus\/([\w\.]+)/i],
                [m, [p, C + " Focus"]],
                [/\bopt\/([\w\.]+)/i],
                [m, [p, $ + " Touch"]],
                [/coc_coc\w+\/([\w\.]+)/i],
                [m, [p, "Coc Coc"]],
                [/dolfin\/([\w\.]+)/i],
                [m, [p, "Dolphin"]],
                [/coast\/([\w\.]+)/i],
                [m, [p, $ + " Coast"]],
                [/miuibrowser\/([\w\.]+)/i],
                [m, [p, "MIUI " + I]],
                [/fxios\/([-\w\.]+)/i],
                [m, [p, C]],
                [/\bqihu|(qi?ho?o?|360)browser/i],
                [[p, "360 " + I]],
                [/(oculus|sailfish|huawei|vivo)browser\/([\w\.]+)/i],
                [[p, /(.+)/, "$1 " + I], m],
                [/samsungbrowser\/([\w\.]+)/i],
                [m, [p, D + " Internet"]],
                [/(comodo_dragon)\/([\w\.]+)/i],
                [[p, /_/g, " "], m],
                [/metasr[\/ ]?([\d\.]+)/i],
                [m, [p, "Sogou Explorer"]],
                [/(sogou)mo\w+\/([\d\.]+)/i],
                [[p, "Sogou Mobile"], m],
                [
                  /(electron)\/([\w\.]+) safari/i,
                  /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i,
                  /m?(qqbrowser|2345Explorer)[\/ ]?([\w\.]+)/i,
                ],
                [p, m],
                [/(lbbrowser)/i, /\[(linkedin)app\]/i],
                [p],
                [/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],
                [[p, z], m],
                [
                  /(Klarna)\/([\w\.]+)/i,
                  /(kakao(?:talk|story))[\/ ]([\w\.]+)/i,
                  /(naver)\(.*?(\d+\.[\w\.]+).*\)/i,
                  /safari (line)\/([\w\.]+)/i,
                  /\b(line)\/([\w\.]+)\/iab/i,
                  /(alipay)client\/([\w\.]+)/i,
                  /(chromium|instagram|snapchat)[\/ ]([-\w\.]+)/i,
                ],
                [p, m],
                [/\bgsa\/([\w\.]+) .*safari\//i],
                [m, [p, "GSA"]],
                [/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i],
                [m, [p, "TikTok"]],
                [/headlesschrome(?:\/([\w\.]+)| )/i],
                [m, [p, P + " Headless"]],
                [/ wv\).+(chrome)\/([\w\.]+)/i],
                [[p, P + " WebView"], m],
                [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],
                [m, [p, "Android " + I]],
                [/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],
                [p, m],
                [/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],
                [m, [p, "Mobile Safari"]],
                [/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],
                [m, p],
                [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],
                [
                  p,
                  [
                    m,
                    X,
                    {
                      "1.0": "/8",
                      1.2: "/1",
                      1.3: "/3",
                      "2.0": "/412",
                      "2.0.2": "/416",
                      "2.0.3": "/417",
                      "2.0.4": "/419",
                      "?": "/",
                    },
                  ],
                ],
                [/(webkit|khtml)\/([\w\.]+)/i],
                [p, m],
                [/(navigator|netscape\d?)\/([-\w\.]+)/i],
                [[p, "Netscape"], m],
                [/mobile vr; rv:([\w\.]+)\).+firefox/i],
                [m, [p, C + " Reality"]],
                [
                  /ekiohf.+(flow)\/([\w\.]+)/i,
                  /(swiftfox)/i,
                  /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i,
                  /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i,
                  /(firefox)\/([\w\.]+)/i,
                  /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i,
                  /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,
                  /(links) \(([\w\.]+)/i,
                  /panasonic;(viera)/i,
                ],
                [p, m],
                [/(cobalt)\/([\w\.]+)/i],
                [p, [m, /master.|lts./, ""]],
              ],
              cpu: [
                [/(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i],
                [[v, "amd64"]],
                [/(ia32(?=;))/i],
                [[v, F]],
                [/((?:i[346]|x)86)[;\)]/i],
                [[v, "ia32"]],
                [/\b(aarch64|arm(v?8e?l?|_?64))\b/i],
                [[v, "arm64"]],
                [/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i],
                [[v, "armhf"]],
                [/windows (ce|mobile); ppc;/i],
                [[v, "arm"]],
                [/((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i],
                [[v, /ower/, "", F]],
                [/(sun4\w)[;\)]/i],
                [[v, "sparc"]],
                [
                  /((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i,
                ],
                [[v, F]],
              ],
              device: [
                [
                  /\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i,
                ],
                [d, [h, D], [f, y]],
                [
                  /\b((?:s[cgp]h|gt|sm)-\w+|sc[g-]?[\d]+a?|galaxy nexus)/i,
                  /samsung[- ]([-\w]+)/i,
                  /sec-(sgh\w+)/i,
                ],
                [d, [h, D], [f, b]],
                [/(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i],
                [d, [h, E], [f, b]],
                [
                  /\((ipad);[-\w\),; ]+apple/i,
                  /applecoremedia\/[\w\.]+ \((ipad)/i,
                  /\b(ipad)\d\d?,\d\d?[;\]].+ios/i,
                ],
                [d, [h, E], [f, y]],
                [/(macintosh);/i],
                [d, [h, E]],
                [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],
                [d, [h, M], [f, b]],
                [/\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i],
                [d, [h, T], [f, y]],
                [
                  /(?:huawei|honor)([-\w ]+)[;\)]/i,
                  /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i,
                ],
                [d, [h, T], [f, b]],
                [
                  /\b(poco[\w ]+|m2\d{3}j\d\d[a-z]{2})(?: bui|\))/i,
                  /\b; (\w+) build\/hm\1/i,
                  /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i,
                  /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i,
                  /oid[^\)]+; (m?[12][0-389][01]\w{3,6}[c-y])( bui|; wv|\))/i,
                  /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i,
                ],
                [
                  [d, /_/g, " "],
                  [h, L],
                  [f, b],
                ],
                [
                  /oid[^\)]+; (2\d{4}(283|rpbf)[cgl])( bui|\))/i,
                  /\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i,
                ],
                [
                  [d, /_/g, " "],
                  [h, L],
                  [f, y],
                ],
                [
                  /; (\w+) bui.+ oppo/i,
                  /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i,
                ],
                [d, [h, "OPPO"], [f, b]],
                [/vivo (\w+)(?: bui|\))/i, /\b(v[12]\d{3}\w?[at])(?: bui|;)/i],
                [d, [h, "Vivo"], [f, b]],
                [/\b(rmx[1-3]\d{3})(?: bui|;|\))/i],
                [d, [h, "Realme"], [f, b]],
                [
                  /\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i,
                  /\bmot(?:orola)?[- ](\w*)/i,
                  /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i,
                ],
                [d, [h, R], [f, b]],
                [/\b(mz60\d|xoom[2 ]{0,2}) build\//i],
                [d, [h, R], [f, y]],
                [
                  /((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i,
                ],
                [d, [h, N], [f, y]],
                [
                  /(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i,
                  /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i,
                  /\blg-?([\d\w]+) bui/i,
                ],
                [d, [h, N], [f, b]],
                [
                  /(ideatab[-\w ]+)/i,
                  /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i,
                ],
                [d, [h, "Lenovo"], [f, y]],
                [
                  /(?:maemo|nokia).*(n900|lumia \d+)/i,
                  /nokia[-_ ]?([-\w\.]*)/i,
                ],
                [
                  [d, /_/g, " "],
                  [h, "Nokia"],
                  [f, b],
                ],
                [/(pixel c)\b/i],
                [d, [h, O], [f, y]],
                [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],
                [d, [h, O], [f, b]],
                [
                  /droid.+ (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i,
                ],
                [d, [h, U], [f, b]],
                [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i],
                [
                  [d, "Xperia Tablet"],
                  [h, U],
                  [f, y],
                ],
                [
                  / (kb2005|in20[12]5|be20[12][59])\b/i,
                  /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i,
                ],
                [d, [h, "OnePlus"], [f, b]],
                [
                  /(alexa)webm/i,
                  /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i,
                  /(kf[a-z]+)( bui|\)).+silk\//i,
                ],
                [d, [h, k], [f, y]],
                [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],
                [
                  [d, /(.+)/g, "Fire Phone $1"],
                  [h, k],
                  [f, b],
                ],
                [/(playbook);[-\w\),; ]+(rim)/i],
                [d, h, [f, y]],
                [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i],
                [d, [h, A], [f, b]],
                [
                  /(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i,
                ],
                [d, [h, S], [f, y]],
                [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
                [d, [h, S], [f, b]],
                [/(nexus 9)/i],
                [d, [h, "HTC"], [f, y]],
                [
                  /(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i,
                  /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i,
                  /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i,
                ],
                [h, [d, /_/g, " "], [f, b]],
                [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],
                [d, [h, "Acer"], [f, y]],
                [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i],
                [d, [h, "Meizu"], [f, b]],
                [/; ((?:power )?armor(?:[\w ]{0,8}))(?: bui|\))/i],
                [d, [h, "Ulefone"], [f, b]],
                [
                  /(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron|infinix|tecno)[-_ ]?([-\w]*)/i,
                  /(hp) ([\w ]+\w)/i,
                  /(asus)-?(\w+)/i,
                  /(microsoft); (lumia[\w ]+)/i,
                  /(lenovo)[-_ ]?([-\w]+)/i,
                  /(jolla)/i,
                  /(oppo) ?([\w ]+) bui/i,
                ],
                [h, d, [f, b]],
                [
                  /(kobo)\s(ereader|touch)/i,
                  /(archos) (gamepad2?)/i,
                  /(hp).+(touchpad(?!.+tablet)|tablet)/i,
                  /(kindle)\/([\w\.]+)/i,
                  /(nook)[\w ]+build\/(\w+)/i,
                  /(dell) (strea[kpr\d ]*[\dko])/i,
                  /(le[- ]+pan)[- ]+(\w{1,9}) bui/i,
                  /(trinity)[- ]*(t\d{3}) bui/i,
                  /(gigaset)[- ]+(q\w{1,9}) bui/i,
                  /(vodafone) ([\w ]+)(?:\)| bui)/i,
                ],
                [h, d, [f, y]],
                [/(surface duo)/i],
                [d, [h, j], [f, y]],
                [/droid [\d\.]+; (fp\du?)(?: b|\))/i],
                [d, [h, "Fairphone"], [f, b]],
                [/(u304aa)/i],
                [d, [h, "AT&T"], [f, b]],
                [/\bsie-(\w*)/i],
                [d, [h, "Siemens"], [f, b]],
                [/\b(rct\w+) b/i],
                [d, [h, "RCA"], [f, y]],
                [/\b(venue[\d ]{2,7}) b/i],
                [d, [h, "Dell"], [f, y]],
                [/\b(q(?:mv|ta)\w+) b/i],
                [d, [h, "Verizon"], [f, y]],
                [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],
                [d, [h, "Barnes & Noble"], [f, y]],
                [/\b(tm\d{3}\w+) b/i],
                [d, [h, "NuVision"], [f, y]],
                [/\b(k88) b/i],
                [d, [h, "ZTE"], [f, y]],
                [/\b(nx\d{3}j) b/i],
                [d, [h, "ZTE"], [f, b]],
                [/\b(gen\d{3}) b.+49h/i],
                [d, [h, "Swiss"], [f, b]],
                [/\b(zur\d{3}) b/i],
                [d, [h, "Swiss"], [f, y]],
                [/\b((zeki)?tb.*\b) b/i],
                [d, [h, "Zeki"], [f, y]],
                [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i],
                [[h, "Dragon Touch"], d, [f, y]],
                [/\b(ns-?\w{0,9}) b/i],
                [d, [h, "Insignia"], [f, y]],
                [/\b((nxa|next)-?\w{0,9}) b/i],
                [d, [h, "NextBook"], [f, y]],
                [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],
                [[h, "Voice"], d, [f, b]],
                [/\b(lvtel\-)?(v1[12]) b/i],
                [[h, "LvTel"], d, [f, b]],
                [/\b(ph-1) /i],
                [d, [h, "Essential"], [f, b]],
                [/\b(v(100md|700na|7011|917g).*\b) b/i],
                [d, [h, "Envizen"], [f, y]],
                [/\b(trio[-\w\. ]+) b/i],
                [d, [h, "MachSpeed"], [f, y]],
                [/\btu_(1491) b/i],
                [d, [h, "Rotor"], [f, y]],
                [/(shield[\w ]+) b/i],
                [d, [h, "Nvidia"], [f, y]],
                [/(sprint) (\w+)/i],
                [h, d, [f, b]],
                [/(kin\.[onetw]{3})/i],
                [
                  [d, /\./g, " "],
                  [h, j],
                  [f, b],
                ],
                [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                [d, [h, B], [f, y]],
                [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],
                [d, [h, B], [f, b]],
                [/smart-tv.+(samsung)/i],
                [h, [f, w]],
                [/hbbtv.+maple;(\d+)/i],
                [
                  [d, /^/, "SmartTV"],
                  [h, D],
                  [f, w],
                ],
                [/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],
                [
                  [h, N],
                  [f, w],
                ],
                [/(apple) ?tv/i],
                [h, [d, E + " TV"], [f, w]],
                [/crkey/i],
                [
                  [d, P + "cast"],
                  [h, O],
                  [f, w],
                ],
                [/droid.+aft(\w+)( bui|\))/i],
                [d, [h, k], [f, w]],
                [/\(dtv[\);].+(aquos)/i, /(aquos-tv[\w ]+)\)/i],
                [d, [h, M], [f, w]],
                [/(bravia[\w ]+)( bui|\))/i],
                [d, [h, U], [f, w]],
                [/(mitv-\w{5}) bui/i],
                [d, [h, L], [f, w]],
                [/Hbbtv.*(technisat) (.*);/i],
                [h, d, [f, w]],
                [
                  /\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i,
                  /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i,
                ],
                [
                  [h, K],
                  [d, K],
                  [f, w],
                ],
                [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],
                [[f, w]],
                [/(ouya)/i, /(nintendo) ([wids3utch]+)/i],
                [h, d, [f, g]],
                [/droid.+; (shield) bui/i],
                [d, [h, "Nvidia"], [f, g]],
                [/(playstation [345portablevi]+)/i],
                [d, [h, U], [f, g]],
                [/\b(xbox(?: one)?(?!; xbox))[\); ]/i],
                [d, [h, j], [f, g]],
                [/((pebble))app/i],
                [h, d, [f, _]],
                [/(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i],
                [d, [h, E], [f, _]],
                [/droid.+; (glass) \d/i],
                [d, [h, O], [f, _]],
                [/droid.+; (wt63?0{2,3})\)/i],
                [d, [h, B], [f, _]],
                [/(quest( 2| pro)?)/i],
                [d, [h, z], [f, _]],
                [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],
                [h, [f, x]],
                [/(aeobc)\b/i],
                [d, [h, k], [f, x]],
                [
                  /droid .+?; ([^;]+?)(?: bui|; wv\)|\) applew).+? mobile safari/i,
                ],
                [d, [f, b]],
                [/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],
                [d, [f, y]],
                [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],
                [[f, y]],
                [
                  /(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i,
                ],
                [[f, b]],
                [/(android[-\w\. ]{0,9});.+buil/i],
                [d, [h, "Generic"]],
              ],
              engine: [
                [/windows.+ edge\/([\w\.]+)/i],
                [m, [p, "EdgeHTML"]],
                [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                [m, [p, "Blink"]],
                [
                  /(presto)\/([\w\.]+)/i,
                  /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i,
                  /ekioh(flow)\/([\w\.]+)/i,
                  /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i,
                  /(icab)[\/ ]([23]\.[\d\.]+)/i,
                  /\b(libweb)/i,
                ],
                [p, m],
                [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                [m, p],
              ],
              os: [
                [/microsoft (windows) (vista|xp)/i],
                [p, m],
                [/(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i],
                [p, [m, X, Y]],
                [
                  /windows nt 6\.2; (arm)/i,
                  /windows[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i,
                  /(?:win(?=3|9|n)|win 9x )([nt\d\.]+)/i,
                ],
                [
                  [m, X, Y],
                  [p, "Windows"],
                ],
                [
                  /ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i,
                  /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i,
                  /cfnetwork\/.+darwin/i,
                ],
                [
                  [m, /_/g, "."],
                  [p, "iOS"],
                ],
                [
                  /(mac os x) ?([\w\. ]*)/i,
                  /(macintosh|mac_powerpc\b)(?!.+haiku)/i,
                ],
                [
                  [p, H],
                  [m, /_/g, "."],
                ],
                [/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],
                [m, p],
                [
                  /(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i,
                  /(blackberry)\w*\/([\w\.]*)/i,
                  /(tizen|kaios)[\/ ]([\w\.]+)/i,
                  /\((series40);/i,
                ],
                [p, m],
                [/\(bb(10);/i],
                [m, [p, A]],
                [/(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i],
                [m, [p, "Symbian"]],
                [
                  /mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i,
                ],
                [m, [p, C + " OS"]],
                [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                [m, [p, "webOS"]],
                [/watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i],
                [m, [p, "watchOS"]],
                [/crkey\/([\d\.]+)/i],
                [m, [p, P + "cast"]],
                [/(cros) [\w]+(?:\)| ([\w\.]+)\b)/i],
                [[p, q], m],
                [
                  /panasonic;(viera)/i,
                  /(netrange)mmh/i,
                  /(nettv)\/(\d+\.[\w\.]+)/i,
                  /(nintendo|playstation) ([wids345portablevuch]+)/i,
                  /(xbox); +xbox ([^\);]+)/i,
                  /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,
                  /(mint)[\/\(\) ]?(\w*)/i,
                  /(mageia|vectorlinux)[; ]/i,
                  /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i,
                  /(hurd|linux) ?([\w\.]*)/i,
                  /(gnu) ?([\w\.]*)/i,
                  /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i,
                  /(haiku) (\w+)/i,
                ],
                [p, m],
                [/(sunos) ?([\w\.\d]*)/i],
                [[p, "Solaris"], m],
                [
                  /((?:open)?solaris)[-\/ ]?([\w\.]*)/i,
                  /(aix) ((\d)(?=\.|\)| )[\w\.])*/i,
                  /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i,
                  /(unix) ?([\w\.]*)/i,
                ],
                [p, m],
              ],
            },
            Z = function (e, t) {
              if ((typeof e === c && ((t = e), (e = i)), !(this instanceof Z)))
                return new Z(e, t).getResult();
              var r = typeof o !== a && o.navigator ? o.navigator : i,
                n = e || (r && r.userAgent ? r.userAgent : ""),
                g = r && r.userAgentData ? r.userAgentData : i,
                w = t
                  ? (function (e, t) {
                      var r = {};
                      for (var n in e)
                        t[n] && t[n].length % 2 == 0
                          ? (r[n] = t[n].concat(e[n]))
                          : (r[n] = e[n]);
                      return r;
                    })(G, t)
                  : G,
                _ = r && r.userAgent == n;
              return (
                (this.getBrowser = function () {
                  var e,
                    t = {};
                  return (
                    (t[p] = i),
                    (t[m] = i),
                    J.call(t, n, w.browser),
                    (t[l] =
                      typeof (e = t[m]) === u
                        ? e.replace(/[^\d\.]/g, "").split(".")[0]
                        : i),
                    _ &&
                      r &&
                      r.brave &&
                      typeof r.brave.isBrave == s &&
                      (t[p] = "Brave"),
                    t
                  );
                }),
                (this.getCPU = function () {
                  var e = {};
                  return (e[v] = i), J.call(e, n, w.cpu), e;
                }),
                (this.getDevice = function () {
                  var e = {};
                  return (
                    (e[h] = i),
                    (e[d] = i),
                    (e[f] = i),
                    J.call(e, n, w.device),
                    _ && !e[f] && g && g.mobile && (e[f] = b),
                    _ &&
                      "Macintosh" == e[d] &&
                      r &&
                      typeof r.standalone !== a &&
                      r.maxTouchPoints &&
                      r.maxTouchPoints > 2 &&
                      ((e[d] = "iPad"), (e[f] = y)),
                    e
                  );
                }),
                (this.getEngine = function () {
                  var e = {};
                  return (e[p] = i), (e[m] = i), J.call(e, n, w.engine), e;
                }),
                (this.getOS = function () {
                  var e = {};
                  return (
                    (e[p] = i),
                    (e[m] = i),
                    J.call(e, n, w.os),
                    _ &&
                      !e[p] &&
                      g &&
                      "Unknown" != g.platform &&
                      (e[p] = g.platform
                        .replace(/chrome os/i, q)
                        .replace(/macos/i, H)),
                    e
                  );
                }),
                (this.getResult = function () {
                  return {
                    ua: this.getUA(),
                    browser: this.getBrowser(),
                    engine: this.getEngine(),
                    os: this.getOS(),
                    device: this.getDevice(),
                    cpu: this.getCPU(),
                  };
                }),
                (this.getUA = function () {
                  return n;
                }),
                (this.setUA = function (e) {
                  return (
                    (n = typeof e === u && e.length > 500 ? K(e, 500) : e), this
                  );
                }),
                this.setUA(n),
                this
              );
            };
          (Z.VERSION = "1.0.37"),
            (Z.BROWSER = V([p, m, l])),
            (Z.CPU = V([v])),
            (Z.DEVICE = V([d, h, f, g, b, w, y, _, x])),
            (Z.ENGINE = Z.OS = V([p, m])),
            typeof t !== a
              ? (e.exports && (t = e.exports = Z), (t.UAParser = Z))
              : r.amdO
              ? (n = function () {
                  return Z;
                }.call(t, r, t, e)) === i || (e.exports = n)
              : typeof o !== a && (o.UAParser = Z);
          var Q = typeof o !== a && (o.jQuery || o.Zepto);
          if (Q && !Q.ua) {
            var ee = new Z();
            (Q.ua = ee.getResult()),
              (Q.ua.get = function () {
                return ee.getUA();
              }),
              (Q.ua.set = function (e) {
                ee.setUA(e);
                var t = ee.getResult();
                for (var r in t) Q.ua[r] = t[r];
              });
          }
        })("object" == typeof window ? window : this);
      },
      1576: (e) => {
        "use strict";
        var t = TypeError;
        e.exports = function (e) {
          if (e > 9007199254740991) throw t("Maximum allowed index exceeded");
          return e;
        };
      },
      1578: (e, t, r) => {
        "use strict";
        var n = r(5912);
        e.exports = function (e) {
          var t = +e;
          return t != t || 0 === t ? 0 : n(t);
        };
      },
      1613: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(9639);
        n(
          { target: "Set", proto: !0, real: !0, forced: !r(1381)("union") },
          { union: o }
        );
      },
      1639: (e, t, r) => {
        "use strict";
        var n = r(6999),
          o = r(1834),
          i = r(960),
          s = r(2544),
          a = r(164),
          c = r(543),
          u = r(728),
          l = r(9580),
          d = r(7768),
          p = r(8042),
          f = TypeError,
          h = function (e, t) {
            (this.stopped = e), (this.result = t);
          },
          m = h.prototype;
        e.exports = function (e, t, r) {
          var v,
            g,
            b,
            y,
            w,
            _,
            x,
            k = r && r.that,
            E = !(!r || !r.AS_ENTRIES),
            S = !(!r || !r.IS_RECORD),
            A = !(!r || !r.IS_ITERATOR),
            I = !(!r || !r.INTERRUPTED),
            P = n(t, k),
            C = function (e) {
              return v && p(v, "normal", e), new h(!0, e);
            },
            O = function (e) {
              return E
                ? (i(e), I ? P(e[0], e[1], C) : P(e[0], e[1]))
                : I
                ? P(e, C)
                : P(e);
            };
          if (S) v = e.iterator;
          else if (A) v = e;
          else {
            if (!(g = d(e))) throw new f(s(e) + " is not iterable");
            if (a(g)) {
              for (b = 0, y = c(e); y > b; b++)
                if ((w = O(e[b])) && u(m, w)) return w;
              return new h(!1);
            }
            v = l(e, g);
          }
          for (_ = S ? e.next : v.next; !(x = o(_, v)).done; ) {
            try {
              w = O(x.value);
            } catch (T) {
              p(v, "throw", T);
            }
            if ("object" == typeof w && w && u(m, w)) return w;
          }
          return new h(!1);
        };
      },
      1649: (e, t, r) => {
        "use strict";
        var n = r(679),
          o = r(6947),
          i = r(8144),
          s = r(2451),
          a = URLSearchParams,
          c = a.prototype,
          u = o(c.getAll),
          l = o(c.has),
          d = new a("a=1");
        (!d.has("a", 2) && d.has("a", void 0)) ||
          n(
            c,
            "has",
            function (e) {
              var t = arguments.length,
                r = t < 2 ? void 0 : arguments[1];
              if (t && void 0 === r) return l(this, e);
              var n = u(this, e);
              s(t, 1);
              for (var o = i(r), a = 0; a < n.length; )
                if (n[a++] === o) return !0;
              return !1;
            },
            { enumerable: !0, unsafe: !0 }
          );
      },
      1700: (e, t, r) => {
        "use strict";
        var n = r(8575),
          o = r(5833).has,
          i = r(9151),
          s = r(3868),
          a = r(9634),
          c = r(78),
          u = r(8042);
        e.exports = function (e) {
          var t = n(this),
            r = s(e);
          if (i(t) <= r.size)
            return (
              !1 !==
              a(
                t,
                function (e) {
                  if (r.includes(e)) return !1;
                },
                !0
              )
            );
          var l = r.getIterator();
          return (
            !1 !==
            c(l, function (e) {
              if (o(t, e)) return u(l, "normal", !1);
            })
          );
        };
      },
      1777: (e, t, r) => {
        "use strict";
        var n = r(1578),
          o = Math.max,
          i = Math.min;
        e.exports = function (e, t) {
          var r = n(e);
          return r < 0 ? o(r + t, 0) : i(r, t);
        };
      },
      1799: (e, t, r) => {
        "use strict";
        var n = r(4492),
          o = r(4202),
          i = /#|\.prototype\./,
          s = function (e, t) {
            var r = c[a(e)];
            return r === l || (r !== u && (o(t) ? n(t) : !!t));
          },
          a = (s.normalize = function (e) {
            return String(e).replace(i, ".").toLowerCase();
          }),
          c = (s.data = {}),
          u = (s.NATIVE = "N"),
          l = (s.POLYFILL = "P");
        e.exports = s;
      },
      1815: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(380),
          i = r(3929);
        e.exports = function (e, t, r) {
          n ? o.f(e, t, i(0, r)) : (e[t] = r);
        };
      },
      1834: (e, t, r) => {
        "use strict";
        var n = r(5121),
          o = Function.prototype.call;
        e.exports = n
          ? o.bind(o)
          : function () {
              return o.apply(o, arguments);
            };
      },
      1884: (e, t, r) => {
        "use strict";
        r(2561);
      },
      1995: (e, t, r) => {
        "use strict";
        var n = r(6668),
          o = r(4450),
          i = r(6710),
          s = r(380);
        e.exports = function (e, t, r) {
          for (var a = o(t), c = s.f, u = i.f, l = 0; l < a.length; l++) {
            var d = a[l];
            n(e, d) || (r && n(r, d)) || c(e, d, u(t, d));
          }
        };
      },
      2265: (e, t, r) => {
        "use strict";
        var n = r(7759),
          o = r(6947);
        e.exports = function (e) {
          if ("Function" === n(e)) return o(e);
        };
      },
      2275: (e, t, r) => {
        "use strict";
        var n = r(8575),
          o = r(5833),
          i = r(9151),
          s = r(3868),
          a = r(9634),
          c = r(78),
          u = o.Set,
          l = o.add,
          d = o.has;
        e.exports = function (e) {
          var t = n(this),
            r = s(e),
            o = new u();
          return (
            i(t) > r.size
              ? c(r.getIterator(), function (e) {
                  d(t, e) && l(o, e);
                })
              : a(t, function (e) {
                  r.includes(e) && l(o, e);
                }),
            o
          );
        };
      },
      2341: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(1834),
          i = r(6895),
          s = r(960),
          a = r(7636),
          c = r(3649),
          u = r(3842),
          l = r(4192),
          d = c(function () {
            for (
              var e, t, r = this.iterator, n = this.predicate, i = this.next;
              ;

            ) {
              if (((e = s(o(i, r))), (this.done = !!e.done))) return;
              if (((t = e.value), u(r, n, [t, this.counter++], !0))) return t;
            }
          });
        n(
          { target: "Iterator", proto: !0, real: !0, forced: l },
          {
            filter: function (e) {
              return s(this), i(e), new d(a(this), { predicate: e });
            },
          }
        );
      },
      2451: (e) => {
        "use strict";
        var t = TypeError;
        e.exports = function (e, r) {
          if (e < r) throw new t("Not enough arguments");
          return e;
        };
      },
      2513: (e, t, r) => {
        "use strict";
        r(4204);
      },
      2544: (e) => {
        "use strict";
        var t = String;
        e.exports = function (e) {
          try {
            return t(e);
          } catch (r) {
            return "Object";
          }
        };
      },
      2561: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(6115);
        n(
          {
            target: "Set",
            proto: !0,
            real: !0,
            forced: !r(1381)("symmetricDifference"),
          },
          { symmetricDifference: o }
        );
      },
      2578: (e, t, r) => {
        "use strict";
        var n = r(8575),
          o = r(5833).has,
          i = r(9151),
          s = r(3868),
          a = r(78),
          c = r(8042);
        e.exports = function (e) {
          var t = n(this),
            r = s(e);
          if (i(t) < r.size) return !1;
          var u = r.getIterator();
          return (
            !1 !==
            a(u, function (e) {
              if (!o(t, e)) return c(u, "normal", !1);
            })
          );
        };
      },
      2661: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(4492);
        e.exports =
          n &&
          o(function () {
            return (
              42 !==
              Object.defineProperty(function () {}, "prototype", {
                value: 42,
                writable: !1,
              }).prototype
            );
          });
      },
      2690: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = Error,
          i = n("".replace),
          s = String(new o("zxcasd").stack),
          a = /\n\s*at [^:]*:[^\n]*/,
          c = a.test(s);
        e.exports = function (e, t) {
          if (c && "string" == typeof e && !o.prepareStackTrace)
            for (; t--; ) e = i(e, a, "");
          return e;
        };
      },
      2820: (e, t, r) => {
        "use strict";
        var n,
          o,
          i,
          s = r(2903),
          a = r(6002),
          c = r(621),
          u = r(6426),
          l = r(6668),
          d = r(5408),
          p = r(7258),
          f = r(482),
          h = "Object already initialized",
          m = a.TypeError,
          v = a.WeakMap;
        if (s || d.state) {
          var g = d.state || (d.state = new v());
          (g.get = g.get),
            (g.has = g.has),
            (g.set = g.set),
            (n = function (e, t) {
              if (g.has(e)) throw new m(h);
              return (t.facade = e), g.set(e, t), t;
            }),
            (o = function (e) {
              return g.get(e) || {};
            }),
            (i = function (e) {
              return g.has(e);
            });
        } else {
          var b = p("state");
          (f[b] = !0),
            (n = function (e, t) {
              if (l(e, b)) throw new m(h);
              return (t.facade = e), u(e, b, t), t;
            }),
            (o = function (e) {
              return l(e, b) ? e[b] : {};
            }),
            (i = function (e) {
              return l(e, b);
            });
        }
        e.exports = {
          set: n,
          get: o,
          has: i,
          enforce: function (e) {
            return i(e) ? o(e) : n(e, {});
          },
          getterFor: function (e) {
            return function (t) {
              var r;
              if (!c(t) || (r = o(t)).type !== e)
                throw new m("Incompatible receiver, " + e + " required");
              return r;
            };
          },
        };
      },
      2903: (e, t, r) => {
        "use strict";
        var n = r(6002),
          o = r(4202),
          i = n.WeakMap;
        e.exports = o(i) && /native code/.test(String(i));
      },
      3004: (e, t, r) => {
        "use strict";
        var n,
          o,
          i,
          s = r(4492),
          a = r(4202),
          c = r(621),
          u = r(5979),
          l = r(9972),
          d = r(679),
          p = r(9544),
          f = r(4192),
          h = p("iterator"),
          m = !1;
        [].keys &&
          ("next" in (i = [].keys())
            ? (o = l(l(i))) !== Object.prototype && (n = o)
            : (m = !0)),
          !c(n) ||
          s(function () {
            var e = {};
            return n[h].call(e) !== e;
          })
            ? (n = {})
            : f && (n = u(n)),
          a(n[h]) ||
            d(n, h, function () {
              return this;
            }),
          (e.exports = { IteratorPrototype: n, BUGGY_SAFARI_ITERATORS: m });
      },
      3013: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = r(6668),
          i = r(654),
          s = r(5972).indexOf,
          a = r(482),
          c = n([].push);
        e.exports = function (e, t) {
          var r,
            n = i(e),
            u = 0,
            l = [];
          for (r in n) !o(a, r) && o(n, r) && c(l, r);
          for (; t.length > u; ) o(n, (r = t[u++])) && (~s(l, r) || c(l, r));
          return l;
        };
      },
      3094: (e, t, r) => {
        "use strict";
        var n = r(5308),
          o = r(3578);
        e.exports = function (e) {
          var t = n(e, "string");
          return o(t) ? t : t + "";
        };
      },
      3154: (e, t, r) => {
        "use strict";
        var n = r(679),
          o = r(6947),
          i = r(8144),
          s = r(2451),
          a = URLSearchParams,
          c = a.prototype,
          u = o(c.append),
          l = o(c.delete),
          d = o(c.forEach),
          p = o([].push),
          f = new a("a=1&a=2&b=3");
        f.delete("a", 1),
          f.delete("b", void 0),
          f + "" != "a=2" &&
            n(
              c,
              "delete",
              function (e) {
                var t = arguments.length,
                  r = t < 2 ? void 0 : arguments[1];
                if (t && void 0 === r) return l(this, e);
                var n = [];
                d(this, function (e, t) {
                  p(n, { key: t, value: e });
                }),
                  s(t, 1);
                for (
                  var o, a = i(e), c = i(r), f = 0, h = 0, m = !1, v = n.length;
                  f < v;

                )
                  (o = n[f++]),
                    m || o.key === a ? ((m = !0), l(this, o.key)) : h++;
                for (; h < v; )
                  ((o = n[h++]).key === a && o.value === c) ||
                    u(this, o.key, o.value);
              },
              { enumerable: !0, unsafe: !0 }
            );
      },
      3192: (e, t, r) => {
        "use strict";
        var n = r(6671),
          o = r(621),
          i = r(6591),
          s = r(11);
        e.exports =
          Object.setPrototypeOf ||
          ("__proto__" in {}
            ? (function () {
                var e,
                  t = !1,
                  r = {};
                try {
                  (e = n(Object.prototype, "__proto__", "set"))(r, []),
                    (t = r instanceof Array);
                } catch (a) {}
                return function (r, n) {
                  return (
                    i(r), s(n), o(r) ? (t ? e(r, n) : (r.__proto__ = n), r) : r
                  );
                };
              })()
            : void 0);
      },
      3382: (e, t, r) => {
        "use strict";
        var n = r(4492);
        e.exports = !n(function () {
          function e() {}
          return (
            (e.prototype.constructor = null),
            Object.getPrototypeOf(new e()) !== e.prototype
          );
        });
      },
      3506: (e, t) => {
        "use strict";
        t.f = Object.getOwnPropertySymbols;
      },
      3552: (e, t, r) => {
        "use strict";
        var n = r(6002),
          o = r(621),
          i = n.document,
          s = o(i) && o(i.createElement);
        e.exports = function (e) {
          return s ? i.createElement(e) : {};
        };
      },
      3578: (e, t, r) => {
        "use strict";
        var n = r(4862),
          o = r(4202),
          i = r(728),
          s = r(4455),
          a = Object;
        e.exports = s
          ? function (e) {
              return "symbol" == typeof e;
            }
          : function (e) {
              var t = n("Symbol");
              return o(t) && i(t.prototype, a(e));
            };
      },
      3649: (e, t, r) => {
        "use strict";
        var n = r(1834),
          o = r(5979),
          i = r(6426),
          s = r(9746),
          a = r(9544),
          c = r(2820),
          u = r(7751),
          l = r(3004).IteratorPrototype,
          d = r(7214),
          p = r(8042),
          f = a("toStringTag"),
          h = "IteratorHelper",
          m = "WrapForValidIterator",
          v = c.set,
          g = function (e) {
            var t = c.getterFor(e ? m : h);
            return s(o(l), {
              next: function () {
                var r = t(this);
                if (e) return r.nextHandler();
                try {
                  var n = r.done ? void 0 : r.nextHandler();
                  return d(n, r.done);
                } catch (o) {
                  throw ((r.done = !0), o);
                }
              },
              return: function () {
                var r = t(this),
                  o = r.iterator;
                if (((r.done = !0), e)) {
                  var i = u(o, "return");
                  return i ? n(i, o) : d(void 0, !0);
                }
                if (r.inner)
                  try {
                    p(r.inner.iterator, "normal");
                  } catch (s) {
                    return p(o, "throw", s);
                  }
                return p(o, "normal"), d(void 0, !0);
              },
            });
          },
          b = g(!0),
          y = g(!1);
        i(y, f, "Iterator Helper"),
          (e.exports = function (e, t) {
            var r = function (r, n) {
              n ? ((n.iterator = r.iterator), (n.next = r.next)) : (n = r),
                (n.type = t ? m : h),
                (n.nextHandler = e),
                (n.counter = 0),
                (n.done = !1),
                v(this, n);
            };
            return (r.prototype = t ? b : y), r;
          });
      },
      3841: (e, t, r) => {
        "use strict";
        var n = r(8575),
          o = r(5833),
          i = r(1249),
          s = r(9151),
          a = r(3868),
          c = r(9634),
          u = r(78),
          l = o.has,
          d = o.remove;
        e.exports = function (e) {
          var t = n(this),
            r = a(e),
            o = i(t);
          return (
            s(t) <= r.size
              ? c(t, function (e) {
                  r.includes(e) && d(o, e);
                })
              : u(r.getIterator(), function (e) {
                  l(t, e) && d(o, e);
                }),
            o
          );
        };
      },
      3842: (e, t, r) => {
        "use strict";
        var n = r(960),
          o = r(8042);
        e.exports = function (e, t, r, i) {
          try {
            return i ? t(n(r)[0], r[1]) : t(r);
          } catch (s) {
            o(e, "throw", s);
          }
        };
      },
      3868: (e, t, r) => {
        "use strict";
        var n = r(6895),
          o = r(960),
          i = r(1834),
          s = r(1578),
          a = r(7636),
          c = "Invalid size",
          u = RangeError,
          l = TypeError,
          d = Math.max,
          p = function (e, t) {
            (this.set = e),
              (this.size = d(t, 0)),
              (this.has = n(e.has)),
              (this.keys = n(e.keys));
          };
        (p.prototype = {
          getIterator: function () {
            return a(o(i(this.keys, this.set)));
          },
          includes: function (e) {
            return i(this.has, this.set, e);
          },
        }),
          (e.exports = function (e) {
            o(e);
            var t = +e.size;
            if (t != t) throw new l(c);
            var r = s(t);
            if (r < 0) throw new u(c);
            return new p(e, r);
          });
      },
      3875: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = 0,
          i = Math.random(),
          s = n((1).toString);
        e.exports = function (e) {
          return "Symbol(" + (void 0 === e ? "" : e) + ")_" + s(++o + i, 36);
        };
      },
      3912: (e, t, r) => {
        "use strict";
        var n = r(5121),
          o = Function.prototype,
          i = o.apply,
          s = o.call;
        e.exports =
          ("object" == typeof Reflect && Reflect.apply) ||
          (n
            ? s.bind(i)
            : function () {
                return s.apply(i, arguments);
              });
      },
      3929: (e) => {
        "use strict";
        e.exports = function (e, t) {
          return {
            enumerable: !(1 & e),
            configurable: !(2 & e),
            writable: !(4 & e),
            value: t,
          };
        };
      },
      4183: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = r(4202),
          i = r(5408),
          s = n(Function.toString);
        o(i.inspectSource) ||
          (i.inspectSource = function (e) {
            return s(e);
          }),
          (e.exports = i.inspectSource);
      },
      4192: (e) => {
        "use strict";
        e.exports = !1;
      },
      4202: (e) => {
        "use strict";
        var t = "object" == typeof document && document.all;
        e.exports =
          void 0 === t && void 0 !== t
            ? function (e) {
                return "function" == typeof e || e === t;
              }
            : function (e) {
                return "function" == typeof e;
              };
      },
      4204: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(1700);
        n(
          {
            target: "Set",
            proto: !0,
            real: !0,
            forced: !r(1381)("isDisjointFrom"),
          },
          { isDisjointFrom: o }
        );
      },
      4435: (e, t, r) => {
        "use strict";
        var n = r(8575),
          o = r(9151),
          i = r(9634),
          s = r(3868);
        e.exports = function (e) {
          var t = n(this),
            r = s(e);
          return (
            !(o(t) > r.size) &&
            !1 !==
              i(
                t,
                function (e) {
                  if (!r.includes(e)) return !1;
                },
                !0
              )
          );
        };
      },
      4450: (e, t, r) => {
        "use strict";
        var n = r(4862),
          o = r(6947),
          i = r(459),
          s = r(3506),
          a = r(960),
          c = o([].concat);
        e.exports =
          n("Reflect", "ownKeys") ||
          function (e) {
            var t = i.f(a(e)),
              r = s.f;
            return r ? c(t, r(e)) : t;
          };
      },
      4455: (e, t, r) => {
        "use strict";
        var n = r(9750);
        e.exports = n && !Symbol.sham && "symbol" == typeof Symbol.iterator;
      },
      4456: (e, t, r) => {
        "use strict";
        var n = r(5408);
        e.exports = function (e, t) {
          return n[e] || (n[e] = t || {});
        };
      },
      4492: (e) => {
        "use strict";
        e.exports = function (e) {
          try {
            return !!e();
          } catch (t) {
            return !0;
          }
        };
      },
      4555: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = r(6668),
          i = SyntaxError,
          s = parseInt,
          a = String.fromCharCode,
          c = n("".charAt),
          u = n("".slice),
          l = n(/./.exec),
          d = {
            '\\"': '"',
            "\\\\": "\\",
            "\\/": "/",
            "\\b": "\b",
            "\\f": "\f",
            "\\n": "\n",
            "\\r": "\r",
            "\\t": "\t",
          },
          p = /^[\da-f]{4}$/i,
          f = /^[\u0000-\u001F]$/;
        e.exports = function (e, t) {
          for (var r = !0, n = ""; t < e.length; ) {
            var h = c(e, t);
            if ("\\" === h) {
              var m = u(e, t, t + 2);
              if (o(d, m)) (n += d[m]), (t += 2);
              else {
                if ("\\u" !== m)
                  throw new i('Unknown escape sequence: "' + m + '"');
                var v = u(e, (t += 2), t + 4);
                if (!l(p, v)) throw new i("Bad Unicode escape at: " + t);
                (n += a(s(v, 16))), (t += 4);
              }
            } else {
              if ('"' === h) {
                (r = !1), t++;
                break;
              }
              if (l(f, h))
                throw new i("Bad control character in string literal at: " + t);
              (n += h), t++;
            }
          }
          if (r) throw new i("Unterminated string at: " + t);
          return { value: n, end: t };
        };
      },
      4737: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(6668),
          i = Function.prototype,
          s = n && Object.getOwnPropertyDescriptor,
          a = o(i, "name"),
          c = a && "something" === function () {}.name,
          u = a && (!n || (n && s(i, "name").configurable));
        e.exports = { EXISTS: a, PROPER: c, CONFIGURABLE: u };
      },
      4827: (e, t, r) => {
        "use strict";
        var n = r(3013),
          o = r(8280);
        e.exports =
          Object.keys ||
          function (e) {
            return n(e, o);
          };
      },
      4862: (e, t, r) => {
        "use strict";
        var n = r(6002),
          o = r(4202);
        e.exports = function (e, t) {
          return arguments.length < 2
            ? ((r = n[e]), o(r) ? r : void 0)
            : n[e] && n[e][t];
          var r;
        };
      },
      4952: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = r(4492),
          i = r(4202),
          s = r(6668),
          a = r(1399),
          c = r(4737).CONFIGURABLE,
          u = r(4183),
          l = r(2820),
          d = l.enforce,
          p = l.get,
          f = String,
          h = Object.defineProperty,
          m = n("".slice),
          v = n("".replace),
          g = n([].join),
          b =
            a &&
            !o(function () {
              return 8 !== h(function () {}, "length", { value: 8 }).length;
            }),
          y = String(String).split("String"),
          w = (e.exports = function (e, t, r) {
            "Symbol(" === m(f(t), 0, 7) &&
              (t = "[" + v(f(t), /^Symbol\(([^)]*)\).*$/, "$1") + "]"),
              r && r.getter && (t = "get " + t),
              r && r.setter && (t = "set " + t),
              (!s(e, "name") || (c && e.name !== t)) &&
                (a
                  ? h(e, "name", { value: t, configurable: !0 })
                  : (e.name = t)),
              b &&
                r &&
                s(r, "arity") &&
                e.length !== r.arity &&
                h(e, "length", { value: r.arity });
            try {
              r && s(r, "constructor") && r.constructor
                ? a && h(e, "prototype", { writable: !1 })
                : e.prototype && (e.prototype = void 0);
            } catch (o) {}
            var n = d(e);
            return (
              s(n, "source") ||
                (n.source = g(y, "string" == typeof t ? t : "")),
              e
            );
          });
        Function.prototype.toString = w(function () {
          return (i(this) && p(this).source) || u(this);
        }, "toString");
      },
      4980: (e, t, r) => {
        "use strict";
        var n = r(6002),
          o = Object.defineProperty;
        e.exports = function (e, t) {
          try {
            o(n, e, { value: t, configurable: !0, writable: !0 });
          } catch (r) {
            n[e] = t;
          }
          return t;
        };
      },
      5121: (e, t, r) => {
        "use strict";
        var n = r(4492);
        e.exports = !n(function () {
          var e = function () {}.bind();
          return "function" != typeof e || e.hasOwnProperty("prototype");
        });
      },
      5201: (e, t, r) => {
        "use strict";
        var n = r(7759);
        e.exports =
          Array.isArray ||
          function (e) {
            return "Array" === n(e);
          };
      },
      5251: (e, t, r) => {
        "use strict";
        var n = r(4952),
          o = r(380);
        e.exports = function (e, t, r) {
          return (
            r.get && n(r.get, t, { getter: !0 }),
            r.set && n(r.set, t, { setter: !0 }),
            o.f(e, t, r)
          );
        };
      },
      5308: (e, t, r) => {
        "use strict";
        var n = r(1834),
          o = r(621),
          i = r(3578),
          s = r(7751),
          a = r(5621),
          c = r(9544),
          u = TypeError,
          l = c("toPrimitive");
        e.exports = function (e, t) {
          if (!o(e) || i(e)) return e;
          var r,
            c = s(e, l);
          if (c) {
            if (
              (void 0 === t && (t = "default"), (r = n(c, e, t)), !o(r) || i(r))
            )
              return r;
            throw new u("Can't convert object to primitive value");
          }
          return void 0 === t && (t = "number"), a(e, t);
        };
      },
      5379: (e, t, r) => {
        "use strict";
        var n = r(6947);
        e.exports = n([].slice);
      },
      5408: (e, t, r) => {
        "use strict";
        var n = r(4192),
          o = r(6002),
          i = r(4980),
          s = "__core-js_shared__",
          a = (e.exports = o[s] || i(s, {}));
        (a.versions || (a.versions = [])).push({
          version: "3.37.0",
          mode: n ? "pure" : "global",
          copyright: "© 2014-2024 Denis Pushkarev (zloirock.ru)",
          license: "https://github.com/zloirock/core-js/blob/v3.37.0/LICENSE",
          source: "https://github.com/zloirock/core-js",
        });
      },
      5527: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(3841);
        n(
          {
            target: "Set",
            proto: !0,
            real: !0,
            forced: !r(1381)("difference"),
          },
          { difference: o }
        );
      },
      5621: (e, t, r) => {
        "use strict";
        var n = r(1834),
          o = r(4202),
          i = r(621),
          s = TypeError;
        e.exports = function (e, t) {
          var r, a;
          if ("string" === t && o((r = e.toString)) && !i((a = n(r, e))))
            return a;
          if (o((r = e.valueOf)) && !i((a = n(r, e)))) return a;
          if ("string" !== t && o((r = e.toString)) && !i((a = n(r, e))))
            return a;
          throw new s("Can't convert object to primitive value");
        };
      },
      5833: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = Set.prototype;
        e.exports = {
          Set,
          add: n(o.add),
          has: n(o.has),
          remove: n(o.delete),
          proto: o,
        };
      },
      5864: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(1639),
          i = r(6895),
          s = r(960),
          a = r(7636);
        n(
          { target: "Iterator", proto: !0, real: !0 },
          {
            every: function (e) {
              s(this), i(e);
              var t = a(this),
                r = 0;
              return !o(
                t,
                function (t, n) {
                  if (!e(t, r++)) return n();
                },
                { IS_RECORD: !0, INTERRUPTED: !0 }
              ).stopped;
            },
          }
        );
      },
      5873: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(4492),
          i = r(2275);
        n(
          {
            target: "Set",
            proto: !0,
            real: !0,
            forced:
              !r(1381)("intersection") ||
              o(function () {
                return (
                  "3,2" !==
                  String(
                    Array.from(new Set([1, 2, 3]).intersection(new Set([3, 2])))
                  )
                );
              }),
          },
          { intersection: i }
        );
      },
      5912: (e) => {
        "use strict";
        var t = Math.ceil,
          r = Math.floor;
        e.exports =
          Math.trunc ||
          function (e) {
            var n = +e;
            return (n > 0 ? r : t)(n);
          };
      },
      5972: (e, t, r) => {
        "use strict";
        var n = r(654),
          o = r(1777),
          i = r(543),
          s = function (e) {
            return function (t, r, s) {
              var a = n(t),
                c = i(a);
              if (0 === c) return !e && -1;
              var u,
                l = o(s, c);
              if (e && r != r) {
                for (; c > l; ) if ((u = a[l++]) != u) return !0;
              } else
                for (; c > l; l++)
                  if ((e || l in a) && a[l] === r) return e || l || 0;
              return !e && -1;
            };
          };
        e.exports = { includes: s(!0), indexOf: s(!1) };
      },
      5979: (e, t, r) => {
        "use strict";
        var n,
          o = r(960),
          i = r(8220),
          s = r(8280),
          a = r(482),
          c = r(9936),
          u = r(3552),
          l = r(7258),
          d = "prototype",
          p = "script",
          f = l("IE_PROTO"),
          h = function () {},
          m = function (e) {
            return "<" + p + ">" + e + "</" + p + ">";
          },
          v = function (e) {
            e.write(m("")), e.close();
            var t = e.parentWindow.Object;
            return (e = null), t;
          },
          g = function () {
            try {
              n = new ActiveXObject("htmlfile");
            } catch (i) {}
            var e, t, r;
            g =
              "undefined" != typeof document
                ? document.domain && n
                  ? v(n)
                  : ((t = u("iframe")),
                    (r = "java" + p + ":"),
                    (t.style.display = "none"),
                    c.appendChild(t),
                    (t.src = String(r)),
                    (e = t.contentWindow.document).open(),
                    e.write(m("document.F=Object")),
                    e.close(),
                    e.F)
                : v(n);
            for (var o = s.length; o--; ) delete g[d][s[o]];
            return g();
          };
        (a[f] = !0),
          (e.exports =
            Object.create ||
            function (e, t) {
              var r;
              return (
                null !== e
                  ? ((h[d] = o(e)), (r = new h()), (h[d] = null), (r[f] = e))
                  : (r = g()),
                void 0 === t ? r : i.f(r, t)
              );
            });
      },
      5993: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(4862),
          i = r(3912),
          s = r(1834),
          a = r(6947),
          c = r(4492),
          u = r(4202),
          l = r(3578),
          d = r(5379),
          p = r(1120),
          f = r(9750),
          h = String,
          m = o("JSON", "stringify"),
          v = a(/./.exec),
          g = a("".charAt),
          b = a("".charCodeAt),
          y = a("".replace),
          w = a((1).toString),
          _ = /[\uD800-\uDFFF]/g,
          x = /^[\uD800-\uDBFF]$/,
          k = /^[\uDC00-\uDFFF]$/,
          E =
            !f ||
            c(function () {
              var e = o("Symbol")("stringify detection");
              return (
                "[null]" !== m([e]) ||
                "{}" !== m({ a: e }) ||
                "{}" !== m(Object(e))
              );
            }),
          S = c(function () {
            return (
              '"\\udf06\\ud834"' !== m("\udf06\ud834") ||
              '"\\udead"' !== m("\udead")
            );
          }),
          A = function (e, t) {
            var r = d(arguments),
              n = p(t);
            if (u(n) || (void 0 !== e && !l(e)))
              return (
                (r[1] = function (e, t) {
                  if ((u(n) && (t = s(n, this, h(e), t)), !l(t))) return t;
                }),
                i(m, null, r)
              );
          },
          I = function (e, t, r) {
            var n = g(r, t - 1),
              o = g(r, t + 1);
            return (v(x, e) && !v(k, o)) || (v(k, e) && !v(x, n))
              ? "\\u" + w(b(e, 0), 16)
              : e;
          };
        m &&
          n(
            { target: "JSON", stat: !0, arity: 3, forced: E || S },
            {
              stringify: function (e, t, r) {
                var n = d(arguments),
                  o = i(E ? A : m, null, n);
                return S && "string" == typeof o ? y(o, _, I) : o;
              },
            }
          );
      },
      6002: function (e, t, r) {
        "use strict";
        var n = function (e) {
          return e && e.Math === Math && e;
        };
        e.exports =
          n("object" == typeof globalThis && globalThis) ||
          n("object" == typeof window && window) ||
          n("object" == typeof self && self) ||
          n("object" == typeof r.g && r.g) ||
          n("object" == typeof this && this) ||
          (function () {
            return this;
          })() ||
          Function("return this")();
      },
      6115: (e, t, r) => {
        "use strict";
        var n = r(8575),
          o = r(5833),
          i = r(1249),
          s = r(3868),
          a = r(78),
          c = o.add,
          u = o.has,
          l = o.remove;
        e.exports = function (e) {
          var t = n(this),
            r = s(e).getIterator(),
            o = i(t);
          return (
            a(r, function (e) {
              u(t, e) ? l(o, e) : c(o, e);
            }),
            o
          );
        };
      },
      6202: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(2578);
        n(
          {
            target: "Set",
            proto: !0,
            real: !0,
            forced: !r(1381)("isSupersetOf"),
          },
          { isSupersetOf: o }
        );
      },
      6364: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(6002),
          i = r(4862),
          s = r(3929),
          a = r(380).f,
          c = r(6668),
          u = r(1548),
          l = r(8404),
          d = r(9760),
          p = r(8505),
          f = r(2690),
          h = r(1399),
          m = r(4192),
          v = "DOMException",
          g = i("Error"),
          b = i(v),
          y = function () {
            u(this, w);
            var e = arguments.length,
              t = d(e < 1 ? void 0 : arguments[0]),
              r = d(e < 2 ? void 0 : arguments[1], "Error"),
              n = new b(t, r),
              o = new g(t);
            return (
              (o.name = v), a(n, "stack", s(1, f(o.stack, 1))), l(n, this, y), n
            );
          },
          w = (y.prototype = b.prototype),
          _ = "stack" in new g(v),
          x = "stack" in new b(1, 2),
          k = b && h && Object.getOwnPropertyDescriptor(o, v),
          E = !(!k || (k.writable && k.configurable)),
          S = _ && !E && !x;
        n(
          { global: !0, constructor: !0, forced: m || S },
          { DOMException: S ? y : b }
        );
        var A = i(v),
          I = A.prototype;
        if (I.constructor !== A)
          for (var P in (m || a(I, "constructor", s(1, A)), p))
            if (c(p, P)) {
              var C = p[P],
                O = C.s;
              c(A, O) || a(A, O, s(6, C.c));
            }
      },
      6426: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(380),
          i = r(3929);
        e.exports = n
          ? function (e, t, r) {
              return o.f(e, t, i(1, r));
            }
          : function (e, t, r) {
              return (e[t] = r), e;
            };
      },
      6456: (e, t, r) => {
        "use strict";
        r(7777);
      },
      6507: function (e, t) {
        var r, n, o;
        !(function () {
          "use strict";
          (n = []),
            void 0 ===
              (o =
                "function" ==
                typeof (r = function () {
                  function e(e) {
                    return e.charAt(0).toUpperCase() + e.substring(1);
                  }
                  function t(e) {
                    return function () {
                      return this[e];
                    };
                  }
                  var r = ["isConstructor", "isEval", "isNative", "isToplevel"],
                    n = ["columnNumber", "lineNumber"],
                    o = ["fileName", "functionName", "source"],
                    i = r.concat(n, o, ["args"], ["evalOrigin"]);
                  function s(t) {
                    if (t)
                      for (var r = 0; r < i.length; r++)
                        void 0 !== t[i[r]] && this["set" + e(i[r])](t[i[r]]);
                  }
                  (s.prototype = {
                    getArgs: function () {
                      return this.args;
                    },
                    setArgs: function (e) {
                      if (
                        "[object Array]" !== Object.prototype.toString.call(e)
                      )
                        throw new TypeError("Args must be an Array");
                      this.args = e;
                    },
                    getEvalOrigin: function () {
                      return this.evalOrigin;
                    },
                    setEvalOrigin: function (e) {
                      if (e instanceof s) this.evalOrigin = e;
                      else {
                        if (!(e instanceof Object))
                          throw new TypeError(
                            "Eval Origin must be an Object or StackFrame"
                          );
                        this.evalOrigin = new s(e);
                      }
                    },
                    toString: function () {
                      var e = this.getFileName() || "",
                        t = this.getLineNumber() || "",
                        r = this.getColumnNumber() || "",
                        n = this.getFunctionName() || "";
                      return this.getIsEval()
                        ? e
                          ? "[eval] (" + e + ":" + t + ":" + r + ")"
                          : "[eval]:" + t + ":" + r
                        : n
                        ? n + " (" + e + ":" + t + ":" + r + ")"
                        : e + ":" + t + ":" + r;
                    },
                  }),
                    (s.fromString = function (e) {
                      var t = e.indexOf("("),
                        r = e.lastIndexOf(")"),
                        n = e.substring(0, t),
                        o = e.substring(t + 1, r).split(","),
                        i = e.substring(r + 1);
                      if (0 === i.indexOf("@"))
                        var a = /@(.+?)(?::(\d+))?(?::(\d+))?$/.exec(i, ""),
                          c = a[1],
                          u = a[2],
                          l = a[3];
                      return new s({
                        functionName: n,
                        args: o || void 0,
                        fileName: c,
                        lineNumber: u || void 0,
                        columnNumber: l || void 0,
                      });
                    });
                  for (var a = 0; a < r.length; a++)
                    (s.prototype["get" + e(r[a])] = t(r[a])),
                      (s.prototype["set" + e(r[a])] = (function (e) {
                        return function (t) {
                          this[e] = Boolean(t);
                        };
                      })(r[a]));
                  for (var c = 0; c < n.length; c++)
                    (s.prototype["get" + e(n[c])] = t(n[c])),
                      (s.prototype["set" + e(n[c])] = (function (e) {
                        return function (t) {
                          if (((r = t), isNaN(parseFloat(r)) || !isFinite(r)))
                            throw new TypeError(e + " must be a Number");
                          var r;
                          this[e] = Number(t);
                        };
                      })(n[c]));
                  for (var u = 0; u < o.length; u++)
                    (s.prototype["get" + e(o[u])] = t(o[u])),
                      (s.prototype["set" + e(o[u])] = (function (e) {
                        return function (t) {
                          this[e] = String(t);
                        };
                      })(o[u]));
                  return s;
                })
                  ? r.apply(t, n)
                  : r) || (e.exports = o);
        })();
      },
      6591: (e, t, r) => {
        "use strict";
        var n = r(7104),
          o = TypeError;
        e.exports = function (e) {
          if (n(e)) throw new o("Can't call method on " + e);
          return e;
        };
      },
      6668: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = r(7282),
          i = n({}.hasOwnProperty);
        e.exports =
          Object.hasOwn ||
          function (e, t) {
            return i(o(e), t);
          };
      },
      6671: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = r(6895);
        e.exports = function (e, t, r) {
          try {
            return n(o(Object.getOwnPropertyDescriptor(e, t)[r]));
          } catch (i) {}
        };
      },
      6710: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(1834),
          i = r(8590),
          s = r(3929),
          a = r(654),
          c = r(3094),
          u = r(6668),
          l = r(1536),
          d = Object.getOwnPropertyDescriptor;
        t.f = n
          ? d
          : function (e, t) {
              if (((e = a(e)), (t = c(t)), l))
                try {
                  return d(e, t);
                } catch (r) {}
              if (u(e, t)) return s(!o(i.f, e, t), e[t]);
            };
      },
      6718: function (e, t, r) {
        var n, o, i;
        !(function () {
          "use strict";
          (o = [r(6507)]),
            void 0 ===
              (i =
                "function" ==
                typeof (n = function (e) {
                  var t = /(^|@)\S+:\d+/,
                    r = /^\s*at .*(\S+:\d+|\(native\))/m,
                    n = /^(eval@)?(\[native code])?$/;
                  return {
                    parse: function (e) {
                      if (
                        void 0 !== e.stacktrace ||
                        void 0 !== e["opera#sourceloc"]
                      )
                        return this.parseOpera(e);
                      if (e.stack && e.stack.match(r))
                        return this.parseV8OrIE(e);
                      if (e.stack) return this.parseFFOrSafari(e);
                      throw new Error("Cannot parse given Error object");
                    },
                    extractLocation: function (e) {
                      if (-1 === e.indexOf(":")) return [e];
                      var t = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(
                        e.replace(/[()]/g, "")
                      );
                      return [t[1], t[2] || void 0, t[3] || void 0];
                    },
                    parseV8OrIE: function (t) {
                      return t.stack
                        .split("\n")
                        .filter(function (e) {
                          return !!e.match(r);
                        }, this)
                        .map(function (t) {
                          t.indexOf("(eval ") > -1 &&
                            (t = t
                              .replace(/eval code/g, "eval")
                              .replace(/(\(eval at [^()]*)|(,.*$)/g, ""));
                          var r = t
                              .replace(/^\s+/, "")
                              .replace(/\(eval code/g, "(")
                              .replace(/^.*?\s+/, ""),
                            n = r.match(/ (\(.+\)$)/);
                          r = n ? r.replace(n[0], "") : r;
                          var o = this.extractLocation(n ? n[1] : r),
                            i = (n && r) || void 0,
                            s =
                              ["eval", "<anonymous>"].indexOf(o[0]) > -1
                                ? void 0
                                : o[0];
                          return new e({
                            functionName: i,
                            fileName: s,
                            lineNumber: o[1],
                            columnNumber: o[2],
                            source: t,
                          });
                        }, this);
                    },
                    parseFFOrSafari: function (t) {
                      return t.stack
                        .split("\n")
                        .filter(function (e) {
                          return !e.match(n);
                        }, this)
                        .map(function (t) {
                          if (
                            (t.indexOf(" > eval") > -1 &&
                              (t = t.replace(
                                / line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g,
                                ":$1"
                              )),
                            -1 === t.indexOf("@") && -1 === t.indexOf(":"))
                          )
                            return new e({ functionName: t });
                          var r = /((.*".+"[^@]*)?[^@]*)(?:@)/,
                            n = t.match(r),
                            o = n && n[1] ? n[1] : void 0,
                            i = this.extractLocation(t.replace(r, ""));
                          return new e({
                            functionName: o,
                            fileName: i[0],
                            lineNumber: i[1],
                            columnNumber: i[2],
                            source: t,
                          });
                        }, this);
                    },
                    parseOpera: function (e) {
                      return !e.stacktrace ||
                        (e.message.indexOf("\n") > -1 &&
                          e.message.split("\n").length >
                            e.stacktrace.split("\n").length)
                        ? this.parseOpera9(e)
                        : e.stack
                        ? this.parseOpera11(e)
                        : this.parseOpera10(e);
                    },
                    parseOpera9: function (t) {
                      for (
                        var r = /Line (\d+).*script (?:in )?(\S+)/i,
                          n = t.message.split("\n"),
                          o = [],
                          i = 2,
                          s = n.length;
                        i < s;
                        i += 2
                      ) {
                        var a = r.exec(n[i]);
                        a &&
                          o.push(
                            new e({
                              fileName: a[2],
                              lineNumber: a[1],
                              source: n[i],
                            })
                          );
                      }
                      return o;
                    },
                    parseOpera10: function (t) {
                      for (
                        var r =
                            /Line (\d+).*script (?:in )?(\S+)(?:: In function (\S+))?$/i,
                          n = t.stacktrace.split("\n"),
                          o = [],
                          i = 0,
                          s = n.length;
                        i < s;
                        i += 2
                      ) {
                        var a = r.exec(n[i]);
                        a &&
                          o.push(
                            new e({
                              functionName: a[3] || void 0,
                              fileName: a[2],
                              lineNumber: a[1],
                              source: n[i],
                            })
                          );
                      }
                      return o;
                    },
                    parseOpera11: function (r) {
                      return r.stack
                        .split("\n")
                        .filter(function (e) {
                          return !!e.match(t) && !e.match(/^Error created at/);
                        }, this)
                        .map(function (t) {
                          var r,
                            n = t.split("@"),
                            o = this.extractLocation(n.pop()),
                            i = n.shift() || "",
                            s =
                              i
                                .replace(/<anonymous function(: (\w+))?>/, "$2")
                                .replace(/\([^)]*\)/g, "") || void 0;
                          i.match(/\(([^)]*)\)/) &&
                            (r = i.replace(/^[^(]+\(([^)]*)\)$/, "$1"));
                          var a =
                            void 0 === r || "[arguments not available]" === r
                              ? void 0
                              : r.split(",");
                          return new e({
                            functionName: s,
                            args: a,
                            fileName: o[0],
                            lineNumber: o[1],
                            columnNumber: o[2],
                            source: t,
                          });
                        }, this);
                    },
                  };
                })
                  ? n.apply(t, o)
                  : n) || (e.exports = i);
        })();
      },
      6895: (e, t, r) => {
        "use strict";
        var n = r(4202),
          o = r(2544),
          i = TypeError;
        e.exports = function (e) {
          if (n(e)) return e;
          throw new i(o(e) + " is not a function");
        };
      },
      6947: (e, t, r) => {
        "use strict";
        var n = r(5121),
          o = Function.prototype,
          i = o.call,
          s = n && o.bind.bind(i, i);
        e.exports = n
          ? s
          : function (e) {
              return function () {
                return i.apply(e, arguments);
              };
            };
      },
      6999: (e, t, r) => {
        "use strict";
        var n = r(2265),
          o = r(6895),
          i = r(5121),
          s = n(n.bind);
        e.exports = function (e, t) {
          return (
            o(e),
            void 0 === t
              ? e
              : i
              ? s(e, t)
              : function () {
                  return e.apply(t, arguments);
                }
          );
        };
      },
      7104: (e) => {
        "use strict";
        e.exports = function (e) {
          return null == e;
        };
      },
      7214: (e) => {
        "use strict";
        e.exports = function (e, t) {
          return { value: e, done: t };
        };
      },
      7258: (e, t, r) => {
        "use strict";
        var n = r(4456),
          o = r(3875),
          i = n("keys");
        e.exports = function (e) {
          return i[e] || (i[e] = o(e));
        };
      },
      7282: (e, t, r) => {
        "use strict";
        var n = r(6591),
          o = Object;
        e.exports = function (e) {
          return o(n(e));
        };
      },
      7636: (e) => {
        "use strict";
        e.exports = function (e) {
          return { iterator: e, next: e.next, done: !1 };
        };
      },
      7697: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(7282),
          i = r(543),
          s = r(74),
          a = r(1576);
        n(
          {
            target: "Array",
            proto: !0,
            arity: 1,
            forced:
              r(4492)(function () {
                return 4294967297 !== [].push.call({ length: 4294967296 }, 1);
              }) ||
              !(function () {
                try {
                  Object.defineProperty([], "length", { writable: !1 }).push();
                } catch (e) {
                  return e instanceof TypeError;
                }
              })(),
          },
          {
            push: function (e) {
              var t = o(this),
                r = i(t),
                n = arguments.length;
              a(r + n);
              for (var c = 0; c < n; c++) (t[r] = arguments[c]), r++;
              return s(t, r), r;
            },
          }
        );
      },
      7751: (e, t, r) => {
        "use strict";
        var n = r(6895),
          o = r(7104);
        e.exports = function (e, t) {
          var r = e[t];
          return o(r) ? void 0 : n(r);
        };
      },
      7759: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = n({}.toString),
          i = n("".slice);
        e.exports = function (e) {
          return i(o(e), 8, -1);
        };
      },
      7768: (e, t, r) => {
        "use strict";
        var n = r(764),
          o = r(7751),
          i = r(7104),
          s = r(8078),
          a = r(9544)("iterator");
        e.exports = function (e) {
          if (!i(e)) return o(e, a) || o(e, "@@iterator") || s[n(e)];
        };
      },
      7777: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(4435);
        n(
          {
            target: "Set",
            proto: !0,
            real: !0,
            forced: !r(1381)("isSubsetOf"),
          },
          { isSubsetOf: o }
        );
      },
      7872: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(1639),
          i = r(6895),
          s = r(960),
          a = r(7636);
        n(
          { target: "Iterator", proto: !0, real: !0 },
          {
            forEach: function (e) {
              s(this), i(e);
              var t = a(this),
                r = 0;
              o(
                t,
                function (t) {
                  e(t, r++);
                },
                { IS_RECORD: !0 }
              );
            },
          }
        );
      },
      7960: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(1639),
          i = r(6895),
          s = r(960),
          a = r(7636);
        n(
          { target: "Iterator", proto: !0, real: !0 },
          {
            find: function (e) {
              s(this), i(e);
              var t = a(this),
                r = 0;
              return o(
                t,
                function (t, n) {
                  if (e(t, r++)) return n(t);
                },
                { IS_RECORD: !0, INTERRUPTED: !0 }
              ).result;
            },
          }
        );
      },
      8003: (e) => {
        "use strict";
        e.exports =
          ("undefined" != typeof navigator && String(navigator.userAgent)) ||
          "";
      },
      8006: (e, t, r) => {
        "use strict";
        r(1613);
      },
      8042: (e, t, r) => {
        "use strict";
        var n = r(1834),
          o = r(960),
          i = r(7751);
        e.exports = function (e, t, r) {
          var s, a;
          o(e);
          try {
            if (!(s = i(e, "return"))) {
              if ("throw" === t) throw r;
              return r;
            }
            s = n(s, e);
          } catch (c) {
            (a = !0), (s = c);
          }
          if ("throw" === t) throw r;
          if (a) throw s;
          return o(s), r;
        };
      },
      8078: (e) => {
        "use strict";
        e.exports = {};
      },
      8142: (e, t, r) => {
        "use strict";
        r(5527);
      },
      8144: (e, t, r) => {
        "use strict";
        var n = r(764),
          o = String;
        e.exports = function (e) {
          if ("Symbol" === n(e))
            throw new TypeError("Cannot convert a Symbol value to a string");
          return o(e);
        };
      },
      8220: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(2661),
          i = r(380),
          s = r(960),
          a = r(654),
          c = r(4827);
        t.f =
          n && !o
            ? Object.defineProperties
            : function (e, t) {
                s(e);
                for (var r, n = a(t), o = c(t), u = o.length, l = 0; u > l; )
                  i.f(e, (r = o[l++]), n[r]);
                return e;
              };
      },
      8239: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(1639),
          i = r(6895),
          s = r(960),
          a = r(7636);
        n(
          { target: "Iterator", proto: !0, real: !0 },
          {
            some: function (e) {
              s(this), i(e);
              var t = a(this),
                r = 0;
              return o(
                t,
                function (t, n) {
                  if (e(t, r++)) return n();
                },
                { IS_RECORD: !0, INTERRUPTED: !0 }
              ).stopped;
            },
          }
        );
      },
      8280: (e) => {
        "use strict";
        e.exports = [
          "constructor",
          "hasOwnProperty",
          "isPrototypeOf",
          "propertyIsEnumerable",
          "toLocaleString",
          "toString",
          "valueOf",
        ];
      },
      8404: (e, t, r) => {
        "use strict";
        var n = r(4202),
          o = r(621),
          i = r(3192);
        e.exports = function (e, t, r) {
          var s, a;
          return (
            i &&
              n((s = t.constructor)) &&
              s !== r &&
              o((a = s.prototype)) &&
              a !== r.prototype &&
              i(e, a),
            e
          );
        };
      },
      8482: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = r(4492),
          i = r(7759),
          s = Object,
          a = n("".split);
        e.exports = o(function () {
          return !s("z").propertyIsEnumerable(0);
        })
          ? function (e) {
              return "String" === i(e) ? a(e, "") : s(e);
            }
          : s;
      },
      8505: (e) => {
        "use strict";
        e.exports = {
          IndexSizeError: { s: "INDEX_SIZE_ERR", c: 1, m: 1 },
          DOMStringSizeError: { s: "DOMSTRING_SIZE_ERR", c: 2, m: 0 },
          HierarchyRequestError: { s: "HIERARCHY_REQUEST_ERR", c: 3, m: 1 },
          WrongDocumentError: { s: "WRONG_DOCUMENT_ERR", c: 4, m: 1 },
          InvalidCharacterError: { s: "INVALID_CHARACTER_ERR", c: 5, m: 1 },
          NoDataAllowedError: { s: "NO_DATA_ALLOWED_ERR", c: 6, m: 0 },
          NoModificationAllowedError: {
            s: "NO_MODIFICATION_ALLOWED_ERR",
            c: 7,
            m: 1,
          },
          NotFoundError: { s: "NOT_FOUND_ERR", c: 8, m: 1 },
          NotSupportedError: { s: "NOT_SUPPORTED_ERR", c: 9, m: 1 },
          InUseAttributeError: { s: "INUSE_ATTRIBUTE_ERR", c: 10, m: 1 },
          InvalidStateError: { s: "INVALID_STATE_ERR", c: 11, m: 1 },
          SyntaxError: { s: "SYNTAX_ERR", c: 12, m: 1 },
          InvalidModificationError: {
            s: "INVALID_MODIFICATION_ERR",
            c: 13,
            m: 1,
          },
          NamespaceError: { s: "NAMESPACE_ERR", c: 14, m: 1 },
          InvalidAccessError: { s: "INVALID_ACCESS_ERR", c: 15, m: 1 },
          ValidationError: { s: "VALIDATION_ERR", c: 16, m: 0 },
          TypeMismatchError: { s: "TYPE_MISMATCH_ERR", c: 17, m: 1 },
          SecurityError: { s: "SECURITY_ERR", c: 18, m: 1 },
          NetworkError: { s: "NETWORK_ERR", c: 19, m: 1 },
          AbortError: { s: "ABORT_ERR", c: 20, m: 1 },
          URLMismatchError: { s: "URL_MISMATCH_ERR", c: 21, m: 1 },
          QuotaExceededError: { s: "QUOTA_EXCEEDED_ERR", c: 22, m: 1 },
          TimeoutError: { s: "TIMEOUT_ERR", c: 23, m: 1 },
          InvalidNodeTypeError: { s: "INVALID_NODE_TYPE_ERR", c: 24, m: 1 },
          DataCloneError: { s: "DATA_CLONE_ERR", c: 25, m: 1 },
        };
      },
      8575: (e, t, r) => {
        "use strict";
        var n = r(5833).has;
        e.exports = function (e) {
          return n(e), e;
        };
      },
      8590: (e, t) => {
        "use strict";
        var r = {}.propertyIsEnumerable,
          n = Object.getOwnPropertyDescriptor,
          o = n && !r.call({ 1: 2 }, 1);
        t.f = o
          ? function (e) {
              var t = n(this, e);
              return !!t && t.enumerable;
            }
          : r;
      },
      8596: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(1399),
          i = r(6002),
          s = r(4862),
          a = r(6947),
          c = r(1834),
          u = r(4202),
          l = r(621),
          d = r(5201),
          p = r(6668),
          f = r(8144),
          h = r(543),
          m = r(1815),
          v = r(4492),
          g = r(4555),
          b = r(9750),
          y = i.JSON,
          w = i.Number,
          _ = i.SyntaxError,
          x = y && y.parse,
          k = s("Object", "keys"),
          E = Object.getOwnPropertyDescriptor,
          S = a("".charAt),
          A = a("".slice),
          I = a(/./.exec),
          P = a([].push),
          C = /^\d$/,
          O = /^[1-9]$/,
          T = /^(?:-|\d)$/,
          N = /^[\t\n\r ]$/,
          j = function (e, t, r, n) {
            var o,
              i,
              s,
              a,
              u,
              f = e[t],
              m = n && f === n.value,
              v = m && "string" == typeof n.source ? { source: n.source } : {};
            if (l(f)) {
              var g = d(f),
                b = m ? n.nodes : g ? [] : {};
              if (g)
                for (o = b.length, s = h(f), a = 0; a < s; a++)
                  R(f, a, j(f, "" + a, r, a < o ? b[a] : void 0));
              else
                for (i = k(f), s = h(i), a = 0; a < s; a++)
                  (u = i[a]), R(f, u, j(f, u, r, p(b, u) ? b[u] : void 0));
            }
            return c(r, e, t, f, v);
          },
          R = function (e, t, r) {
            if (o) {
              var n = E(e, t);
              if (n && !n.configurable) return;
            }
            void 0 === r ? delete e[t] : m(e, t, r);
          },
          $ = function (e, t, r, n) {
            (this.value = e),
              (this.end = t),
              (this.source = r),
              (this.nodes = n);
          },
          D = function (e, t) {
            (this.source = e), (this.index = t);
          };
        D.prototype = {
          fork: function (e) {
            return new D(this.source, e);
          },
          parse: function () {
            var e = this.source,
              t = this.skip(N, this.index),
              r = this.fork(t),
              n = S(e, t);
            if (I(T, n)) return r.number();
            switch (n) {
              case "{":
                return r.object();
              case "[":
                return r.array();
              case '"':
                return r.string();
              case "t":
                return r.keyword(!0);
              case "f":
                return r.keyword(!1);
              case "n":
                return r.keyword(null);
            }
            throw new _('Unexpected character: "' + n + '" at: ' + t);
          },
          node: function (e, t, r, n, o) {
            return new $(t, n, e ? null : A(this.source, r, n), o);
          },
          object: function () {
            for (
              var e = this.source, t = this.index + 1, r = !1, n = {}, o = {};
              t < e.length;

            ) {
              if (((t = this.until(['"', "}"], t)), "}" === S(e, t) && !r)) {
                t++;
                break;
              }
              var i = this.fork(t).string(),
                s = i.value;
              (t = i.end),
                (t = this.until([":"], t) + 1),
                (t = this.skip(N, t)),
                (i = this.fork(t).parse()),
                m(o, s, i),
                m(n, s, i.value),
                (t = this.until([",", "}"], i.end));
              var a = S(e, t);
              if ("," === a) (r = !0), t++;
              else if ("}" === a) {
                t++;
                break;
              }
            }
            return this.node(1, n, this.index, t, o);
          },
          array: function () {
            for (
              var e = this.source, t = this.index + 1, r = !1, n = [], o = [];
              t < e.length;

            ) {
              if (((t = this.skip(N, t)), "]" === S(e, t) && !r)) {
                t++;
                break;
              }
              var i = this.fork(t).parse();
              if (
                (P(o, i),
                P(n, i.value),
                (t = this.until([",", "]"], i.end)),
                "," === S(e, t))
              )
                (r = !0), t++;
              else if ("]" === S(e, t)) {
                t++;
                break;
              }
            }
            return this.node(1, n, this.index, t, o);
          },
          string: function () {
            var e = this.index,
              t = g(this.source, this.index + 1);
            return this.node(0, t.value, e, t.end);
          },
          number: function () {
            var e = this.source,
              t = this.index,
              r = t;
            if (("-" === S(e, r) && r++, "0" === S(e, r))) r++;
            else {
              if (!I(O, S(e, r)))
                throw new _("Failed to parse number at: " + r);
              r = this.skip(C, ++r);
            }
            if (
              !("." === S(e, r) && (r = this.skip(C, ++r)),
              ("e" !== S(e, r) && "E" !== S(e, r)) ||
                (r++,
                ("+" !== S(e, r) && "-" !== S(e, r)) || r++,
                r !== (r = this.skip(C, r))))
            )
              throw new _("Failed to parse number's exponent value at: " + r);
            return this.node(0, w(A(e, t, r)), t, r);
          },
          keyword: function (e) {
            var t = "" + e,
              r = this.index,
              n = r + t.length;
            if (A(this.source, r, n) !== t)
              throw new _("Failed to parse value at: " + r);
            return this.node(0, e, r, n);
          },
          skip: function (e, t) {
            for (var r = this.source; t < r.length && I(e, S(r, t)); t++);
            return t;
          },
          until: function (e, t) {
            t = this.skip(N, t);
            for (var r = S(this.source, t), n = 0; n < e.length; n++)
              if (e[n] === r) return t;
            throw new _('Unexpected character: "' + r + '" at: ' + t);
          },
        };
        var M = v(function () {
            var e,
              t = "9007199254740993";
            return (
              x(t, function (t, r, n) {
                e = n.source;
              }),
              e !== t
            );
          }),
          U =
            b &&
            !v(function () {
              return 1 / x("-0 \t") != -1 / 0;
            });
        n(
          { target: "JSON", stat: !0, forced: M },
          {
            parse: function (e, t) {
              return U && !u(t)
                ? x(e)
                : (function (e, t) {
                    e = f(e);
                    var r = new D(e, 0, ""),
                      n = r.parse(),
                      o = n.value,
                      i = r.skip(N, n.end);
                    if (i < e.length)
                      throw new _(
                        'Unexpected extra character: "' +
                          S(e, i) +
                          '" after the parsed data at: ' +
                          i
                      );
                    return u(t) ? j({ "": o }, "", t, n) : o;
                  })(e, t);
            },
          }
        );
      },
      8643: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(6002),
          i = r(1548),
          s = r(960),
          a = r(4202),
          c = r(9972),
          u = r(5251),
          l = r(1815),
          d = r(4492),
          p = r(6668),
          f = r(9544),
          h = r(3004).IteratorPrototype,
          m = r(1399),
          v = r(4192),
          g = "constructor",
          b = "Iterator",
          y = f("toStringTag"),
          w = TypeError,
          _ = o[b],
          x =
            v ||
            !a(_) ||
            _.prototype !== h ||
            !d(function () {
              _({});
            }),
          k = function () {
            if ((i(this, h), c(this) === h))
              throw new w("Abstract class Iterator not directly constructable");
          },
          E = function (e, t) {
            m
              ? u(h, e, {
                  configurable: !0,
                  get: function () {
                    return t;
                  },
                  set: function (t) {
                    if ((s(this), this === h))
                      throw new w("You can't redefine this property");
                    p(this, e) ? (this[e] = t) : l(this, e, t);
                  },
                })
              : (h[e] = t);
          };
        p(h, y) || E(y, b),
          (!x && p(h, g) && h[g] !== Object) || E(g, k),
          (k.prototype = h),
          n({ global: !0, constructor: !0, forced: x }, { Iterator: k });
      },
      8963: (e, t, r) => {
        "use strict";
        var n,
          o,
          i = r(6002),
          s = r(8003),
          a = i.process,
          c = i.Deno,
          u = (a && a.versions) || (c && c.version),
          l = u && u.v8;
        l && (o = (n = l.split("."))[0] > 0 && n[0] < 4 ? 1 : +(n[0] + n[1])),
          !o &&
            s &&
            (!(n = s.match(/Edge\/(\d+)/)) || n[1] >= 74) &&
            (n = s.match(/Chrome\/(\d+)/)) &&
            (o = +n[1]),
          (e.exports = o);
      },
      9041: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(352);
        n(
          { target: "Iterator", proto: !0, real: !0, forced: r(4192) },
          { map: o }
        );
      },
      9058: (e, t, r) => {
        "use strict";
        var n = r(621);
        e.exports = function (e) {
          return n(e) || null === e;
        };
      },
      9151: (e, t, r) => {
        "use strict";
        var n = r(6671),
          o = r(5833);
        e.exports =
          n(o.proto, "size", "get") ||
          function (e) {
            return e.size;
          };
      },
      9544: (e, t, r) => {
        "use strict";
        var n = r(6002),
          o = r(4456),
          i = r(6668),
          s = r(3875),
          a = r(9750),
          c = r(4455),
          u = n.Symbol,
          l = o("wks"),
          d = c ? u.for || u : (u && u.withoutSetter) || s;
        e.exports = function (e) {
          return (
            i(l, e) || (l[e] = a && i(u, e) ? u[e] : d("Symbol." + e)), l[e]
          );
        };
      },
      9580: (e, t, r) => {
        "use strict";
        var n = r(1834),
          o = r(6895),
          i = r(960),
          s = r(2544),
          a = r(7768),
          c = TypeError;
        e.exports = function (e, t) {
          var r = arguments.length < 2 ? a(e) : t;
          if (o(r)) return i(n(r, e));
          throw new c(s(e) + " is not iterable");
        };
      },
      9604: (e, t, r) => {
        "use strict";
        var n = r(1399),
          o = r(6947),
          i = r(5251),
          s = URLSearchParams.prototype,
          a = o(s.forEach);
        n &&
          !("size" in s) &&
          i(s, "size", {
            get: function () {
              var e = 0;
              return (
                a(this, function () {
                  e++;
                }),
                e
              );
            },
            configurable: !0,
            enumerable: !0,
          });
      },
      9634: (e, t, r) => {
        "use strict";
        var n = r(6947),
          o = r(78),
          i = r(5833),
          s = i.Set,
          a = i.proto,
          c = n(a.forEach),
          u = n(a.keys),
          l = u(new s()).next;
        e.exports = function (e, t, r) {
          return r ? o({ iterator: u(e), next: l }, t) : c(e, t);
        };
      },
      9639: (e, t, r) => {
        "use strict";
        var n = r(8575),
          o = r(5833).add,
          i = r(1249),
          s = r(3868),
          a = r(78);
        e.exports = function (e) {
          var t = n(this),
            r = s(e).getIterator(),
            c = i(t);
          return (
            a(r, function (e) {
              o(c, e);
            }),
            c
          );
        };
      },
      9641: (e, t, r) => {
        "use strict";
        var n = r(9731),
          o = r(1639),
          i = r(6895),
          s = r(960),
          a = r(7636),
          c = TypeError;
        n(
          { target: "Iterator", proto: !0, real: !0 },
          {
            reduce: function (e) {
              s(this), i(e);
              var t = a(this),
                r = arguments.length < 2,
                n = r ? void 0 : arguments[1],
                u = 0;
              if (
                (o(
                  t,
                  function (t) {
                    r ? ((r = !1), (n = t)) : (n = e(n, t, u)), u++;
                  },
                  { IS_RECORD: !0 }
                ),
                r)
              )
                throw new c("Reduce of empty iterator with no initial value");
              return n;
            },
          }
        );
      },
      9731: (e, t, r) => {
        "use strict";
        var n = r(6002),
          o = r(6710).f,
          i = r(6426),
          s = r(679),
          a = r(4980),
          c = r(1995),
          u = r(1799);
        e.exports = function (e, t) {
          var r,
            l,
            d,
            p,
            f,
            h = e.target,
            m = e.global,
            v = e.stat;
          if ((r = m ? n : v ? n[h] || a(h, {}) : n[h] && n[h].prototype))
            for (l in t) {
              if (
                ((p = t[l]),
                (d = e.dontCallGetSet ? (f = o(r, l)) && f.value : r[l]),
                !u(m ? l : h + (v ? "." : "#") + l, e.forced) && void 0 !== d)
              ) {
                if (typeof p == typeof d) continue;
                c(p, d);
              }
              (e.sham || (d && d.sham)) && i(p, "sham", !0), s(r, l, p, e);
            }
        };
      },
      9746: (e, t, r) => {
        "use strict";
        var n = r(679);
        e.exports = function (e, t, r) {
          for (var o in t) n(e, o, t[o], r);
          return e;
        };
      },
      9750: (e, t, r) => {
        "use strict";
        var n = r(8963),
          o = r(4492),
          i = r(6002).String;
        e.exports =
          !!Object.getOwnPropertySymbols &&
          !o(function () {
            var e = Symbol("symbol detection");
            return (
              !i(e) ||
              !(Object(e) instanceof Symbol) ||
              (!Symbol.sham && n && n < 41)
            );
          });
      },
      9760: (e, t, r) => {
        "use strict";
        var n = r(8144);
        e.exports = function (e, t) {
          return void 0 === e ? (arguments.length < 2 ? "" : t) : n(e);
        };
      },
      9936: (e, t, r) => {
        "use strict";
        var n = r(4862);
        e.exports = n("document", "documentElement");
      },
      9972: (e, t, r) => {
        "use strict";
        var n = r(6668),
          o = r(4202),
          i = r(7282),
          s = r(7258),
          a = r(3382),
          c = s("IE_PROTO"),
          u = Object,
          l = u.prototype;
        e.exports = a
          ? u.getPrototypeOf
          : function (e) {
              var t = i(e);
              if (n(t, c)) return t[c];
              var r = t.constructor;
              return o(r) && t instanceof r
                ? r.prototype
                : t instanceof u
                ? l
                : null;
            };
      },
    },
    t = {};
  function r(n) {
    var o = t[n];
    if (void 0 !== o) return o.exports;
    var i = (t[n] = { exports: {} });
    return e[n].call(i.exports, i, i.exports, r), i.exports;
  }
  (r.amdO = {}),
    (r.n = (e) => {
      var t = e && e.__esModule ? () => e.default : () => e;
      return r.d(t, { a: t }), t;
    }),
    (r.d = (e, t) => {
      for (var n in t)
        r.o(t, n) &&
          !r.o(e, n) &&
          Object.defineProperty(e, n, { enumerable: !0, get: t[n] });
    }),
    (r.g = (function () {
      if ("object" == typeof globalThis) return globalThis;
      try {
        return this || new Function("return this")();
      } catch (e) {
        if ("object" == typeof window) return window;
      }
    })()),
    (r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t)),
    (() => {
      "use strict";
      r(7697), r(5993), r(8643), r(7872), r(9041), r(9641), r(8239);
      var e = ((e) => (
        (e.AdvancedDom = "advanced-dom"),
        (e.Custom = "custom"),
        (e.Dom = "dom"),
        (e.Meta = "meta"),
        (e.Standard = "standard"),
        e
      ))(e || {});
      const t = {
        all_events: e.Meta,
        all_standard_events: e.Meta,
        all_custom_events: e.Meta,
        all_dom_events: e.Meta,
        checkout_address_info_submitted: e.Standard,
        checkout_completed: e.Standard,
        checkout_started: e.Standard,
        payment_info_submitted: e.Standard,
        collection_viewed: e.Standard,
        checkout_contact_info_submitted: e.Standard,
        page_viewed: e.Standard,
        product_added_to_cart: e.Standard,
        product_removed_from_cart: e.Standard,
        product_viewed: e.Standard,
        search_submitted: e.Standard,
        cart_viewed: e.Standard,
        checkout_shipping_info_submitted: e.Standard,
        alert_displayed: e.Standard,
        ui_extension_errored: e.Standard,
        input_changed: e.Dom,
        input_blurred: e.Dom,
        input_focused: e.Dom,
        form_submitted: e.Dom,
        clicked: e.Dom,
        advanced_dom_mouse_moved: e.AdvancedDom,
        advanced_dom_window_resized: e.AdvancedDom,
        advanced_dom_scrolled: e.AdvancedDom,
        advanced_dom_clipboard: e.AdvancedDom,
        advanced_dom_selection_changed: e.AdvancedDom,
        advanced_dom_available: e.AdvancedDom,
        advanced_dom_changed: e.AdvancedDom,
        advanced_dom_clicked: e.AdvancedDom,
        advanced_dom_form_submitted: e.AdvancedDom,
        advanced_dom_input_changed: e.AdvancedDom,
        advanced_dom_input_blurred: e.AdvancedDom,
        advanced_dom_input_focused: e.AdvancedDom,
      };
      function n(r) {
        return (function (e) {
          return e in t;
        })(r)
          ? t[r]
          : e.Custom;
      }
      function o(t) {
        return n(t) === e.Standard;
      }
      function i(t) {
        return n(t) === e.Custom;
      }
      function s(t) {
        return n(t) === e.Dom;
      }
      function a(t) {
        return n(t) === e.AdvancedDom;
      }
      class c extends Error {
        constructor(e, t = {}) {
          super(e),
            (this.severity = t.severity || "error"),
            (this.groupingHash =
              t.groupingHash ?? ("Error" === this.name ? void 0 : this.name));
        }
      }
      var u = ((e) => (
          (e.Shopify = "shopify"),
          (e.StorefrontRenderer = "storefront-renderer"),
          (e.CheckoutOne = "checkout-one"),
          (e.CheckoutOneSdk = "checkout-one-sdk"),
          (e.CheckoutOneShopApp = "checkout-one-shop-app"),
          (e.CustomerAccount = "customer-account"),
          (e.Unknown = "unknown"),
          (e.NotAvailable = "n/a"),
          e
        ))(u || {}),
        l = ((e) => ((e.App = "APP"), (e.Custom = "CUSTOM"), e))(l || {}),
        d = ((e) => (
          (e.Strict = "STRICT"), (e.Lax = "LAX"), (e.Open = "OPEN"), e
        ))(d || {}),
        p = ((e) => ((e.AdvancedDomEvents = "advanced_dom_events"), e))(
          p || {}
        ),
        f = ((e) => (
          (e.Modern = "modern"),
          (e.Legacy = "legacy"),
          (e.Bot = "bot"),
          (e.Unknown = "unknown"),
          (e.NotAvailable = "n/a"),
          e
        ))(f || {});
      const h = "product_added_to_cart",
        m = "Added Product",
        v = "cart_link_id";
      function g(e, t, r) {
        const { jQuery: n } = window;
        if (n && n(e).bind) {
          const o = (e) => {
            e && r(e);
          };
          n(e).bind(t, o);
        } else e.addEventListener && e.addEventListener(t, r);
      }
      function b(e) {
        window.addEventListener("load", () => {
          for (const t of document.forms) e(t);
        });
      }
      function y() {
        return window.ShopifyAnalytics?.meta || {};
      }
      function w(e, t) {
        for (const r of t.variants) if (String(r.id) === String(e)) return r;
        return null;
      }
      function _(e, t) {
        for (const r of t) {
          const t = w(e, r);
          if (t) return { product: r, variant: t };
        }
        return {};
      }
      function x(e, t) {
        const [r] = t.productVariants?.filter((t) => t.id === e) || [];
        return (
          r ||
          (function (e) {
            let t, r;
            const n = y();
            let o = { currency: n.currency, variant_id: e };
            if (n.products) {
              const o = n.products;
              ({ product: t, variant: r } = _(e, o));
            } else n.product && ((t = n.product), (r = w(e, t)));
            return (
              t &&
                ((o = {
                  ...o,
                  product_id: t.id,
                  product_gid: t.gid,
                  product_vendor: t.vendor,
                  collection_title: null,
                  untranslated_product_title: t.untranslated_product_title,
                }),
                r &&
                  (o = {
                    ...o,
                    variant_id: e,
                    variant_price: r.price / 100,
                    product_title: r.name,
                    variant_sku: r.sku,
                    variant_title: r.public_title,
                    untranslated_variant_title: r.untranslated_variant_title,
                  })),
              {
                id: String(o.variant_id),
                image: { src: "" },
                price: { amount: o.variant_price, currencyCode: o.currency },
                product: {
                  id: String(o.product_id),
                  title: o.product_title,
                  vendor: o.product_vendor,
                  type: o.product_type,
                  untranslatedTitle:
                    o.untranslated_product_title || o.product_title,
                  url: o.url,
                },
                sku: o.variant_sku,
                title: o.variant_title,
                untranslatedTitle:
                  o.untranslated_variant_title || o.variant_title,
              }
            );
          })(e)
        );
      }
      function k(e) {
        try {
          return e instanceof FormData
            ? (function (e) {
                const t = {};
                return (
                  e.forEach((e, r) => {
                    E(r, e, t);
                  }),
                  t
                );
              })(e)
            : e instanceof URLSearchParams
            ? (function (e) {
                return Object.fromEntries(e.entries());
              })(e)
            : JSON.parse(e);
        } catch {
          return {};
        }
      }
      function E(e, t, r) {
        const [n, ...o] = e.split(".").filter((e) => e);
        if (n && o.length > 0)
          return (r[n] = r[n] || {}), void E(o.join("."), t, r[n]);
        const i = /(\w+)?\[(\d+)?\](.+)?/.exec(e);
        if (i) {
          const [e, n, o, s = ""] = i;
          if (n) return (r[n] = r[n] || []), void E(e.replace(n, ""), t, r[n]);
          if (o) {
            const e = s && "[" === s[0] ? [] : {};
            return (r[o] = r[o] || e), void E(s, t, r[o]);
          }
          r.push(t);
        } else r[e] = t;
      }
      function S(e) {
        let t = e.toLowerCase();
        return (
          (t = t.replace(/\/+$/, "")),
          (t = t.replace(/\/\/+/g, "/")),
          (t = t.split("?")[0] || t),
          t
        );
      }
      function A(e) {
        if (!e) return 1;
        try {
          return JSON.parse(e).quantity || 1;
        } catch {
          if (e instanceof FormData || e instanceof URLSearchParams) {
            if (e.has("quantity")) return Number(e.get("quantity"));
          } else {
            const t = e.split("&");
            for (const e of t) {
              const t = e.split("=");
              if ("quantity" === t[0]) return Number(t[1]);
            }
          }
        }
        return 1;
      }
      function I(e) {
        return (
          null != e &&
          "object" == typeof e &&
          (("merchandise" in e && null != e.merchandise?.id) ||
            ("variant_id" in e && null != e.variant_id) ||
            ("id" in e && null != e.id))
        );
      }
      function P(e) {
        if (!I(e)) return null;
        if ("remote" in e && "boolean" == typeof e.remote) return e.remote;
        let t = null;
        if (
          ("merchandise" in e
            ? (t = e.merchandise?.id)
            : "variant_id" in e
            ? (t = e.variant_id)
            : "id" in e && (t = e.id),
          t)
        ) {
          const e = (function (e) {
            let t = null,
              r = null;
            const n = y();
            return (
              n.products
                ? ({ product: t, variant: r } = _(e, n.products))
                : n.product && ((r = w(e, n.product)), r && (t = n.product)),
              r ? t ?? null : null
            );
          })(String(t));
          if (e && "remote" in e && "boolean" == typeof e.remote)
            return e.remote;
        }
        return null;
      }
      function C(e, t, r) {
        const n = (function (e) {
          const t = e.merchandise?.product.title || void 0,
            r = e.merchandise?.title || void 0,
            n = t && r ? `${t} - ${r}` : t || r || "",
            o = P(e.merchandise);
          return e
            ? {
                productId: e.merchandise?.product?.id,
                variantId: e.merchandise?.id,
                name: n,
                sku: e.merchandise?.sku,
                category: e.merchandise?.product?.type,
                brand: e.merchandise?.product?.vendor,
                variant: e.merchandise?.title,
                price: e.merchandise?.price?.amount,
                quantity: e.quantity,
                currency: e.merchandise?.price?.currencyCode,
                cartToken: O(document.cookie).cart || void 0,
                remote: o,
              }
            : {};
        })(e);
        window.ShopifyAnalytics &&
          window.ShopifyAnalytics.lib &&
          "function" == typeof window.ShopifyAnalytics.lib.track &&
          window.ShopifyAnalytics.lib.track(m, { ...n }, void 0, void 0, {
            addApiSource: t,
            shopifyEmitted: !0,
          });
      }
      function O(e) {
        const t = {};
        for (const r of e.split(/ *; */)) {
          const [e, n] = r.split("=");
          if (void 0 !== e)
            try {
              t[decodeURIComponent(e)] = decodeURIComponent(n || "");
            } catch {
              continue;
            }
        }
        return t;
      }
      function T(e) {
        if (
          !e.extensions?.cart_changelog ||
          "function" != typeof window.ShopifyAnalytics?.lib?.track
        )
          return;
        const t = (function (e) {
          try {
            return JSON.parse(atob(e));
          } catch {
            return {};
          }
        })(e.extensions.cart_changelog);
        t.items_added &&
          Array.isArray(t.items_added) &&
          (function (e) {
            const t = [];
            return (
              e.forEach((e) => {
                const r = {
                  productId: e.product_id,
                  variantId: e.variant_id,
                  name: e.title,
                  sku: e.sku,
                  category: e.product_type,
                  brand: e.vendor,
                  variant: e.variant_title,
                  price: e.price,
                  quantity: e.quantity,
                  currency: window.ShopifyAnalytics.meta.currency,
                  cartToken: O(document.cookie).cart || void 0,
                };
                t.push(r);
              }),
              t
            );
          })(t.items_added).forEach((e) => {
            window.ShopifyAnalytics.lib.track(m, e, void 0, void 0, {
              addApiSource: "storefrontApi",
              shopifyEmitted: !0,
            });
          });
      }
      function N(e, t, r, n) {
        if (t.length !== r.length)
          throw new c(
            "Payload body and response have different number of items"
          );
        t.forEach((t, o) => {
          let i = 1;
          try {
            const e = r[o]?.quantity;
            i = e ? Number(e) : 1;
          } catch {}
          R(e, t, i, n);
        });
      }
      function j(e, t, r, n, o) {
        let i;
        if (
          (function (e) {
            return (
              e &&
              "object" == typeof e &&
              "merchandise" in e &&
              "cost" in e &&
              "quantity" in e
            );
          })(t)
        )
          i = t;
        else {
          const e = y().currency,
            n = {
              id: o.includes("add") ? String(t.id) : String(t.variant_id),
              image: { src: t.image },
              price: { amount: t.presentment_price, currencyCode: e },
              product: {
                id: String(t.product_id),
                title: t.product_title,
                vendor: t.vendor,
                type: t.product_type,
                untranslatedTitle: t.untranslated_product_title,
                url: t.url,
              },
              sku: t.sku,
              title: t.variant_title,
              untranslatedTitle: t.untranslated_variant_title,
            };
          i = {
            cost: {
              totalAmount: { amount: n.price.amount * r, currencyCode: e },
            },
            merchandise: n,
            quantity: Number(r),
          };
        }
        L(t, "fetch") || e(n, { cartLine: i }),
          n === h &&
            (o.includes("change") ||
              o.includes("update") ||
              o.includes("permalink")) &&
            C(
              {
                ...i,
                merchandise: {
                  ...(i.merchandise || {}),
                  remote: t?.remote ?? null,
                },
              },
              o
            );
      }
      function R(e, t, r, n) {
        j(e, t, r, h, n);
      }
      function $(e, t, r) {
        const n = t.items,
          o = t.items_changelog?.added;
        o &&
          Array.isArray(o) &&
          o
            .map((e) => {
              const t = n.find(
                (t) => String(t.variant_id) === String(e.variant_id)
              );
              return t
                ? {
                    variant_id: t.variant_id,
                    view_key: t.key,
                    image: t.image,
                    presentment_price: t.presentment_price,
                    product_id: t.product_id,
                    vendor: t.vendor,
                    product_type: t.product_type,
                    untranslated_product_title: t.product_title,
                    url: t.url,
                    sku: t.sku,
                    product_title: t.product_title,
                    variant_title: t.variant_title,
                    untranslated_variant_title: t.variant_title,
                    quantity: e.quantity,
                    remote: t.remote,
                  }
                : null;
            })
            .filter((e) => null !== e)
            .forEach((t) => {
              R(e, t, t.quantity, r);
            });
      }
      function D(e, t, r) {
        const n = t.items_added,
          o = t.items_removed;
        n.forEach((t) => {
          R(e, t, t?.quantity, r);
        }),
          o.forEach((t) => {
            !(function (e, t, r, n) {
              j(e, t, r, "product_removed_from_cart", n);
            })(e, t, t?.quantity, r);
          });
      }
      function M(e, t, r, n) {
        try {
          const o = (function (e) {
            const t = [];
            if (e.id) t.push({ id: e.id, quantity: Number(e.quantity) || 1 });
            else if (e.items)
              for (const r of e.items)
                r.id && t.push({ id: r.id, quantity: Number(e.quantity) || 1 });
            return t;
          })(t);
          if (0 === o.length) return !1;
          !(function (e, t, r, n) {
            for (const o of t) {
              const t = o.id.toString(),
                i = o.quantity,
                s = x(t, r),
                a = {
                  cost: {
                    totalAmount: {
                      amount: s.price.amount * i,
                      currencyCode: s.price.currencyCode,
                    },
                  },
                  merchandise: s,
                  quantity: Number(i),
                };
              e(h, { cartLine: a }), C(a, n);
            }
          })(e, o, r, n);
        } catch {
          return !1;
        }
        return !0;
      }
      function U(e) {}
      function L(e, t) {
        if (!y().remoteProductsEnabled) return !1;
        if (!I(e)) return !0;
        const r = P(e);
        switch (t) {
          case "fetch":
          case "form":
            return !0 === r;
          default:
            return t;
        }
      }
      const B =
          /^(?:\/[a-zA-Z]+(?:-[a-zA-Z]+)?)?\/+cart\/+add(?:\.js|\.json)?\/*$/,
        z =
          /^(?:\/[a-zA-Z]+(?:-[a-zA-Z]+)?)?\/+cart\/+change(?:\.js|\.json)?\/*$/,
        q =
          /^(?:\/[a-zA-Z]+(?:-[a-zA-Z]+)?)?\/+cart\/+update(?:\.js|\.json)?\/*$/,
        H =
          /^(?:\/[a-zA-Z]+(?:-[a-zA-Z]+)?)?\/api\/(\d{4}-\d{2}|unstable)\/graphql\.json(\?.*)?$/;
      class V {
        static handleXhrOpen() {}
        static handleXhrDone(e) {
          if (!(e.xhr.status >= 400))
            try {
              const t = document.createElement("a");
              t.href = e.url;
              const r = t.pathname ? t.pathname : e.url;
              t.href = e.xhr.responseURL;
              const n = t.pathname ? t.pathname : e.xhr.responseURL;
              let o = !1;
              if (
                r.match(B) &&
                (function (e, t) {
                  return S(e) !== S(t);
                })(r, n)
              ) {
                const t = k(e.body);
                o = M(e.publish, t, e.initData, "add-xhr-redirect");
              }
              if (o) return;
              r.match(B)
                ? V.parsePayloadResponse(e, (t) => {
                    const r = Object.keys(t).find((e) => "items" === e);
                    if (r) {
                      const n = t[r];
                      let o;
                      try {
                        o = JSON.parse(e.body).items;
                      } catch {
                        o = (function (e, t) {
                          const r = new Array(t);
                          for (let n = 0; n < t; n++) r[n] = {};
                          for (const n of decodeURI(e).split("&")) {
                            const [e = "", t] = n.split("="),
                              o = e.match(/items\[(\d+)\]\[(\w+)\].*/);
                            if (o) {
                              const e = Number(o[1]),
                                n = o[2];
                              "quantity" === n
                                ? (r[e].quantity = t)
                                : "id" === n && (r[e].id = t);
                            }
                          }
                          return r;
                        })(e.body, n.length);
                      }
                      N(e.publish, n, o, "add-xhr-bulk");
                    } else R(e.publish, t, A(e.body), "add-xhr");
                  })
                : r.match(z)
                ? V.parsePayloadResponse(e, (t) => {
                    D(e.publish, t, "change-xhr");
                  })
                : r.match(q)
                ? V.parsePayloadResponse(e, (t) => {
                    $(e.publish, t, "update-xhr");
                  })
                : r.match(H) &&
                  V.parsePayloadResponse(e, (e) => {
                    T(e);
                  });
            } catch {}
        }
        static parseBlobToJson(e, t) {
          const r = new FileReader();
          r.addEventListener("loadend", () => {
            t(JSON.parse(String.fromCharCode(...new Uint8Array(r.result))));
          }),
            r.readAsArrayBuffer(e);
        }
        static parsePayloadResponse(e, t) {
          e.xhr.response instanceof Blob
            ? V.parseBlobToJson(e.xhr.response, t)
            : e.xhr.responseText && t(JSON.parse(e.xhr.responseText));
        }
        constructor(e, t, r, n, o, i) {
          (this.xhr = e),
            (this.url = t),
            (this.method = r),
            (this.body = n),
            (this.publish = o),
            (this.initData = i);
        }
        onReadyStateChange() {
          4 === this.xhr.readyState &&
            V.handleXhrDone({
              method: this.method,
              url: this.url,
              body: this.body,
              xhr: this.xhr,
              publish: this.publish,
              initData: this.initData,
            }),
            this.oldOnReadyStateChange &&
              this.oldOnReadyStateChange.call(
                this.xhr,
                new Event("oldOnReadyStateChange")
              );
        }
      }
      function W(e, t) {
        (function (e, t, r) {
          if (void 0 === e?.prototype?.open) return;
          const n = e.prototype.open,
            o = e.prototype.send;
          Reflect.defineProperty(e.prototype, "open", {
            value(e, t) {
              (this._url = t), (this._method = e), n.apply(this, arguments);
            },
          }),
            Reflect.defineProperty(e.prototype, "send", {
              value(e) {
                if (!(e instanceof Document)) {
                  const n = new V(this, this._url, this._method, e || "", t, r);
                  this.addEventListener
                    ? this.addEventListener(
                        "readystatechange",
                        n.onReadyStateChange.bind(n),
                        !1
                      )
                    : ((n.oldOnReadyStateChange = this.onreadystatechange),
                      (this.onreadystatechange = n.onReadyStateChange));
                }
                o.call(this, e);
              },
            });
        })(window.XMLHttpRequest, e, t),
          (function (e, t, r) {
            const n = e.fetch;
            if ("function" != typeof n) return;
            const o = (function (e, t, r) {
              return function (...n) {
                return e
                  .apply(this, Array.prototype.slice.call(n))
                  .then((e) => {
                    if (!e.ok) return e;
                    const n = document.createElement("a");
                    n.href = e.url;
                    const o = n.pathname ? n.pathname : e.url;
                    let i,
                      s = !1;
                    if (
                      (o.match(B) &&
                        arguments[1]?.body &&
                        e.redirected &&
                        ((i = k(arguments[1].body)),
                        (s = M(t, i, r, "add-fetch-redirect"))),
                      s)
                    )
                      return e;
                    try {
                      if (o.match(B)) {
                        try {
                          if (
                            ((i = i || k(arguments[1].body)),
                            Object.keys(i).includes("items"))
                          )
                            return (
                              (function (e, t, r) {
                                t.clone()
                                  .json()
                                  .then((t) => {
                                    const n = r.items,
                                      o = t.items;
                                    return (
                                      N(e, o, n || [], "add-fetch-bulk"), t
                                    );
                                  })
                                  .catch(U);
                              })(t, e, i),
                              e
                            );
                        } catch (a) {}
                        !(function (e, t, r) {
                          const n = A(r);
                          t.clone()
                            .json()
                            .then((t) => R(e, t, n, "add-fetch"))
                            .catch(U);
                        })(t, e, arguments[1].body);
                      } else
                        o.match(z)
                          ? (function (e, t) {
                              t.clone()
                                .json()
                                .then((t) => {
                                  D(e, t, "change-fetch");
                                })
                                .catch(U);
                            })(t, e)
                          : o.match(q)
                          ? (function (e, t) {
                              t.clone()
                                .json()
                                .then((t) => {
                                  $(e, t, "update-fetch");
                                })
                                .catch(U);
                            })(t, e)
                          : o.match(H) &&
                            (function (e) {
                              e.ok &&
                                e
                                  .clone()
                                  .json()
                                  .then((e) => {
                                    T(e);
                                  })
                                  .catch(U);
                            })(e);
                    } catch {}
                    return e;
                  });
              };
            })(n, t, r);
            Reflect.defineProperty(e, "fetch", { value: o });
          })(window, e, t),
          b((r) => {
            const n = r.getAttribute("action");
            n &&
              n.indexOf("/cart/add") >= 0 &&
              g(r, "submit", (r) => {
                !(function (e, t, r) {
                  const n = t || window.event;
                  if (
                    !n ||
                    n.defaultPrevented ||
                    (n.isDefaultPrevented && n.isDefaultPrevented())
                  )
                    return;
                  const o = n.currentTarget || n.srcElement;
                  if (
                    o &&
                    o instanceof Element &&
                    (o.getAttribute("action") || o.getAttribute("href"))
                  )
                    try {
                      const t = (function (e) {
                        let t;
                        const r =
                          e.querySelector('[name="id"]') ||
                          (e instanceof HTMLFormElement &&
                            e.elements.namedItem("id"));
                        return (
                          r instanceof HTMLSelectElement && r.options
                            ? (t = r.options[r.selectedIndex])
                            : (r instanceof HTMLOptionElement ||
                                r instanceof HTMLInputElement) &&
                              (t = r),
                          t
                        );
                      })(o);
                      if (!t) return;
                      const n = t.value,
                        i = (function (e) {
                          const t = e.querySelector('[name="quantity"]');
                          return t instanceof HTMLInputElement
                            ? Number(t.value)
                            : 1;
                        })(o),
                        s = x(n, r);
                      if (L(s, "form")) return;
                      const a = {
                        cost: {
                          totalAmount: {
                            amount: s.price.amount * i,
                            currencyCode: s.price.currencyCode,
                          },
                        },
                        merchandise: s,
                        quantity: Number(i),
                      };
                      e(h, { cartLine: a });
                    } catch {}
                })(e, r, t);
              });
          });
      }
      class F extends TypeError {
        constructor(e) {
          super(e),
            (this.name = "ConsentValidationError"),
            Object.setPrototypeOf(this, F.prototype);
        }
      }
      const K = "visitorConsentCollected",
        J = "p",
        X = "a",
        Y = "m",
        G = "t",
        Z = "m",
        Q = "a",
        ee = "p",
        te = "s";
      r(8596), r(6364);
      const re = () => "undefined" == typeof window,
        ne = () =>
          "undefined" != typeof __CtaTestEnv__ && "true" === __CtaTestEnv__;
      class oe {}
      (oe.warn = (e) => {
        ne() || console.warn(e);
      }),
        (oe.error = (e) => {
          ne() || console.error(e);
        }),
        (oe.info = (e) => {
          ne() || console.info(e);
        }),
        (oe.debug = (e) => {
          ne() || console.debug(e);
        }),
        (oe.trace = (e) => {
          ne() || console.trace(e);
        });
      const ie = oe;
      function se(e, t) {
        if (null === e) return "null";
        if (Array.isArray(e)) return `[${e.map((e) => se(e, !0)).join(",")}]`;
        if ("object" == typeof e) {
          let r = [];
          for (const t in e)
            e.hasOwnProperty(t) &&
              void 0 !== e[t] &&
              "" !== e[t] &&
              r.push(`${t}:${se(e[t], !0)}`);
          const n = r.join(",");
          return t ? `{${n}}` : n;
        }
        return "string" == typeof e ? JSON.stringify(e) : `${e}`;
      }
      function ae(e) {
        try {
          return decodeURIComponent(e);
        } catch (t) {
          return "";
        }
      }
      const ce = "_tracking_consent";
      function ue(e, t = !1) {
        const r = (function () {
          try {
            return document.cookie;
          } catch {
            return !1;
          }
        })()
          ? document.cookie.split("; ")
          : [];
        for (let n = 0; n < r.length; n++) {
          const [t, o] = r[n].split("=");
          if (e === ae(t)) return ae(o);
        }
        if (
          t &&
          "_tracking_consent" === e &&
          !window.localStorage.getItem("tracking_consent_fetched")
        ) {
          if (ne()) return;
          return (
            console.debug("_tracking_consent missing"),
            (function (e = "/") {
              const t = new XMLHttpRequest();
              t.open("HEAD", e, !1), (t.withCredentials = !0), t.send();
            })(),
            window.localStorage.setItem("tracking_consent_fetched", "true"),
            ue(e, !1)
          );
        }
      }
      function le(e) {
        return e === encodeURIComponent(ae(e));
      }
      function de(e, t, r, n) {
        if (!le(n))
          throw new TypeError("Cookie value is not correctly URI encoded.");
        if (!le(e))
          throw new TypeError("Cookie name is not correctly URI encoded.");
        let o = `${e}=${n}`;
        (o += "; path=/"),
          t && (o += `; domain=${t}`),
          (o += `; expires=${new Date(
            new Date().getTime() + r
          ).toUTCString()}`),
          (document.cookie = o);
      }
      r(7960);
      class pe {
        constructor() {
          if (pe.instance) return pe.instance;
          pe.instance = this;
        }
        produce(e, t) {
          if (!re())
            try {
              const r = {
                  schema_id: "customer_privacy_api_events/2.0",
                  payload: {
                    shop_domain: window.location.host,
                    method_name: e,
                    call_details: t || null,
                  },
                },
                n = {
                  accept: "*/*",
                  "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
                  "content-type": "application/json; charset=utf-8",
                  "x-monorail-edge-event-created-at-ms": String(Date.now()),
                  "x-monorail-edge-event-sent-at-ms": String(Date.now()),
                };
              if (!window.location.host.endsWith("spin.dev"))
                return fetch(
                  "https://monorail-edge.shopifysvc.com/v1/produce",
                  {
                    headers: n,
                    body: JSON.stringify(r),
                    method: "POST",
                    mode: "cors",
                    credentials: "omit",
                  }
                );
              console.log("Monorail event from consent API:", n, r);
            } catch (r) {}
        }
      }
      function fe(e) {
        try {
          return e();
        } catch {
          return;
        }
      }
      function he() {
        var e, t;
        if (
          !we() &&
          !(function () {
            try {
              const e =
                performance.getEntriesByType("navigation")[0].serverTiming;
              return !!e && 0 != e.length;
            } catch {
              return !1;
            }
          })()
        ) {
          const e = new pe();
          let t = "failed_to_fetch";
          try {
            t = navigator.userAgent;
          } catch {}
          e.produce(
            "navigationServerTiming",
            JSON.stringify({ failed: !0, userAgent: t })
          ),
            (function () {
              if (we()) return;
              const e = be();
              e.Shopify || (e.Shopify = {}),
                e.Shopify.customerPrivacy || (e.Shopify.customerPrivacy = {}),
                (e.Shopify.customerPrivacy.serverTimingSupportVerified = !0);
            })();
        }
        const r =
          null === (e = performance) ||
          void 0 === e ||
          null === (t = e.getEntriesByType) ||
          void 0 === t
            ? void 0
            : t.call(e, "navigation");
        if (!r) return;
        const n = r.map(ge).find((e) => e);
        if (n)
          try {
            sessionStorage.setItem("consentHeader", n);
          } catch {}
        return n;
      }
      let me;
      function ve() {
        var e, t;
        const r =
          null === (e = performance) ||
          void 0 === e ||
          null === (t = e.getEntriesByType) ||
          void 0 === t
            ? void 0
            : t.call(e, "resource");
        let n = me;
        for (let o = r.length - 1; o >= 0; o--) {
          let e = ge(r[o]);
          if (e) {
            n = e;
            break;
          }
        }
        return (me = n), n;
      }
      function ge(e) {
        var t, r;
        if (e)
          return null === (t = e.serverTiming) ||
            void 0 === t ||
            null === (r = t.find((e) => "_cmp" == e.name)) ||
            void 0 === r
            ? void 0
            : r.description;
      }
      function be() {
        return window;
      }
      function ye() {
        var e, t;
        const r = be();
        return (
          !0 ===
          (null == r ||
          null === (e = r.Shopify) ||
          void 0 === e ||
          null === (t = e.customerPrivacy) ||
          void 0 === t
            ? void 0
            : t.backendConsentEnabled)
        );
      }
      function we() {
        var e, t;
        const r = be();
        return null == r ||
          null === (e = r.Shopify) ||
          void 0 === e ||
          null === (t = e.customerPrivacy) ||
          void 0 === t
          ? void 0
          : t.serverTimingSupportVerified;
      }
      function _e() {
        if (!re()) {
          var e, t;
          const r =
            null === (e = window.Shopify) ||
            void 0 === e ||
            null === (t = e.customerPrivacy) ||
            void 0 === t
              ? void 0
              : t.injectedConsent;
          return r ? ae(r) : void 0;
        }
      }
      function xe(e, t) {
        if (!re())
          try {
            document.dispatchEvent(new CustomEvent(e, { detail: t || {} }));
          } catch (r) {
            console.error(
              `[Shopify Customer Privacy] Error in event listener for "${e}":`,
              r
            );
          }
      }
      function ke() {
        let e;
        if (
          ((e = re()
            ? _e()
            : (function () {
                var e, t;
                const r =
                  null === (e = window.Shopify) ||
                  void 0 === e ||
                  null === (t = e.customerPrivacy) ||
                  void 0 === t
                    ? void 0
                    : t.cachedConsent;
                return r ? ae(r) : void 0;
              })() ||
              _e() ||
              new URLSearchParams(window.location.search).get("_cs") ||
              ue(ce) ||
              (function () {
                let e;
                if (((e = (ye() && fe(ve)) || fe(he)), !e)) {
                  let e;
                  try {
                    e = sessionStorage.getItem("consentHeader");
                  } catch {}
                  return e || void 0;
                }
                try {
                  e = decodeURIComponent(e);
                } catch {}
                return e;
              })()),
          void 0 !== e)
        )
          return (function (e) {
            if ("%" == e.slice(0, 1))
              try {
                e = decodeURIComponent(e);
              } catch {}
            const t = e.slice(0, 1);
            return "{" == t
              ? (function (e) {
                  var t;
                  let r;
                  try {
                    r = JSON.parse(e);
                  } catch {
                    return;
                  }
                  if (
                    "2.1" === r.v &&
                    null !== (t = r.con) &&
                    void 0 !== t &&
                    t.CMP
                  )
                    return r;
                })(e)
              : "3" == t
              ? (function (e) {
                  const t = e.slice(1).split("_"),
                    [r, n, o, i, s] = t;
                  let a, c;
                  try {
                    a = t[5] ? JSON.parse(t.slice(5).join("_")) : void 0;
                  } catch {}
                  if (s) {
                    const e = s.replace(/\*/g, "/").replace(/-/g, "+"),
                      t = atob(e);
                    let r = "";
                    for (let n = 0; n < t.length; n++) {
                      const e = t.charCodeAt(n).toString(16);
                      r += 1 === e.length ? "0" + e : e;
                    }
                    c = [8, 13, 18, 23].reduce(
                      (e, t) => e.slice(0, t) + "-" + e.slice(t),
                      r
                    );
                  }
                  function u(e) {
                    const t = r.split(".")[0];
                    return t.includes(e.toLowerCase())
                      ? "0"
                      : t.includes(e.toUpperCase())
                      ? "1"
                      : "";
                  }
                  function l(e) {
                    return r.includes(e.replace("t", "s").toUpperCase());
                  }
                  return {
                    v: "3",
                    con: {
                      CMP: {
                        [Q]: u("a"),
                        [ee]: u("p"),
                        [Z]: u("m"),
                        [te]: u("s"),
                      },
                    },
                    region: n || "",
                    cus: a,
                    purposes: { [X]: l(X), [J]: l(J), [Y]: l(Y), [G]: l(G) },
                    sale_of_data_region: "t" == i,
                    display_banner: "t" == o,
                    consent_id: c,
                  };
                })(e)
              : void 0;
          })(e);
      }
      function Ee() {
        try {
          let e = ke();
          if (!e) return;
          return e;
        } catch {
          return;
        }
      }
      function Se(e) {
        const t = Ee();
        if (!t || !t.purposes) return !0;
        const r = t.purposes[e];
        return "boolean" != typeof r || r;
      }
      function Ae() {
        return Se(J);
      }
      function Ie() {
        return Se(X);
      }
      function Pe() {
        return Se(Y);
      }
      function Ce() {
        return Se(G);
      }
      function Oe(e) {
        return `${e.origin}${((t = e.pathname), t.replace(/\/$/, ""))}`;
        var t;
      }
      function Te(e) {
        return e.startsWith("http://") || e.startsWith("https://");
      }
      function Ne(e) {
        const t = e.granular_consent;
        return {
          query: `query { consentManagement { cookies(${se({
            visitorConsent: {
              marketing: t.marketing,
              analytics: t.analytics,
              preferences: t.preferences,
              saleOfData: t.sale_of_data,
              ...(t.metafields && { metafields: t.metafields }),
            },
            ...(t.email && { visitorEmail: t.email }),
            origReferrer: e.referrer,
            landingPage: e.landing_page,
          })}) { trackingConsentCookie cookieDomain landingPageCookie origReferrerCookie } customerAccountUrl } }`,
          variables: {},
        };
      }
      function je(e) {
        return e.granular_consent.headlessStorefront;
      }
      function Re(e, t) {
        const r = t.granular_consent;
        let n = "",
          o = {};
        if (r.customerAccountRequestInfo)
          (n = r.customerAccountRequestInfo.url),
            (o = r.customerAccountRequestInfo.headers);
        else {
          const t =
            r.storefrontAccessToken ||
            (function () {
              try {
                const e =
                    document.documentElement.querySelector("#shopify-features"),
                  t = "Could not find liquid access token";
                if (!e) return void ie.warn(t);
                const r = e.textContent;
                if (!r) return void ie.warn(t);
                let n;
                try {
                  n = JSON.parse(r).accessToken;
                } catch {
                  return void ie.warn(t);
                }
                return n || void ie.warn(t);
              } catch {
                return void ie.warn("Could not find liquid access token");
              }
            })();
          n = `${
            /^(localhost|127\.0\.0\.1)(:|$)/.test(e) ? "http:" : "https:"
          }//${e}/api/unstable/graphql.json`;
          const i = r.isExtensionToken
            ? "Shopify-Storefront-Extension-Token"
            : "x-shopify-storefront-access-token";
          o = { [i]: t };
        }
        const i = {
          headers: {
            "content-type": "application/json",
            ...o,
            ...(ne() ? { "x-test-payload": JSON.stringify(t) } : {}),
          },
          body: JSON.stringify(Ne(t)),
          method: "POST",
        };
        let s;
        try {
          s = fetch(n, i);
        } catch (a) {
          s = Promise.reject(a);
        }
        return s.then((e) => {
          if (e.ok) return e.json();
          {
            const t = new Error("Server error");
            throw ((t.cause = { status: e.status }), t);
          }
        });
      }
      function $e(e, t, r) {
        const n = t.granular_consent.checkoutRootDomain || window.location.host;
        let o = [];
        return (
          o.push(
            Re(n, t).then((e) => {
              var n, o;
              const i = e.data.consentManagement.cookies.cookieDomain,
                s = e.data.consentManagement.cookies.trackingConsentCookie,
                a =
                  null !==
                    (n =
                      null === (o = e.data.consentManagement) || void 0 === o
                        ? void 0
                        : o.customerAccountUrl) && void 0 !== n
                    ? n
                    : "";
              var c, u;
              if (
                (s &&
                  ((c = s),
                  (null !== (u = window.Shopify) &&
                    void 0 !== u &&
                    u.customerPrivacy) ||
                    ((window.Shopify = window.Shopify || {}),
                    (window.Shopify.customerPrivacy = {})),
                  (window.Shopify.customerPrivacy.cachedConsent = c)),
                je(t) && !ye())
              ) {
                const e = 31536e6,
                  r = t.granular_consent,
                  n = i || r.checkoutRootDomain || window.location.hostname,
                  o = r.storefrontRootDomain || i || window.location.hostname;
                de(ce, n, e, s), o !== n && de(ce, o, e, s);
              }
              return (
                void 0 !== t.granular_consent &&
                  (function (e) {
                    const t = e[Y],
                      r = e[G],
                      n = e[X],
                      o = e[J];
                    !0 === t
                      ? xe("firstPartyMarketingConsentAccepted")
                      : !1 === t && xe("firstPartyMarketingConsentDeclined"),
                      !0 === r
                        ? xe("thirdPartyMarketingConsentAccepted")
                        : !1 === r && xe("thirdPartyMarketingConsentDeclined"),
                      !0 === n
                        ? xe("analyticsConsentAccepted")
                        : !1 === n && xe("analyticsConsentDeclined"),
                      !0 === o
                        ? xe("preferencesConsentAccepted")
                        : !1 === o && xe("preferencesConsentDeclined");
                    const i = (function (e) {
                      return {
                        marketingAllowed: e[Y],
                        saleOfDataAllowed: e[G],
                        analyticsAllowed: e[X],
                        preferencesAllowed: e[J],
                        firstPartyMarketingAllowed: e[Y],
                        thirdPartyMarketingAllowed: e[G],
                      };
                    })(e);
                    xe(K, i);
                    const s = [n, o, t, r];
                    s.every((e) => !0 === e) && xe("trackingConsentAccepted"),
                      s.every((e) => !1 === e) && xe("trackingConsentDeclined");
                  })({ [J]: Ae(), [X]: Ie(), [Y]: Pe(), [G]: Ce() }),
                (function (e, t) {
                  if (!e) return;
                  const r = (function (e) {
                    const t = new URL(e, window.location.origin),
                      r = Te(e)
                        ? Oe(t)
                        : Oe(t).replace(window.location.origin, ""),
                      n = document.querySelectorAll(`a[href^="${r}"]`),
                      o = document.querySelectorAll(
                        `a[href*="${window.location.hostname}/customer_authentication"]`
                      ),
                      i = new Set(),
                      s = [];
                    for (let a = 0; a < n.length; a++)
                      i.has(n[a]) || (i.add(n[a]), s.push(n[a]));
                    for (let a = 0; a < o.length; a++)
                      i.has(o[a]) || (i.add(o[a]), s.push(o[a]));
                    return s;
                  })(e);
                  if (r.length)
                    for (let n = 0; n < r.length; n++) {
                      const o = r[n],
                        i = o.getAttribute("href");
                      if (!i) continue;
                      const s = new URL(i, window.location.origin);
                      s.searchParams.set("_cs", t);
                      const a = Te(e)
                        ? s.toString()
                        : s.toString().replace(window.location.origin, "");
                      o.setAttribute("href", a);
                    }
                })(a, s),
                void 0 !== r && r(null, e),
                e
              );
            })
          ),
          je(t) &&
            ye() &&
            o.push(
              Re(
                t.granular_consent.storefrontRootDomain || window.location.host,
                t
              )
            ),
          Promise.race(o).catch((e) => {
            var t;
            const n =
                "Error while setting storefront API consent: " + e.message,
              o = null === (t = e.cause) || void 0 === t ? void 0 : t.status,
              i = { error: n };
            if ((void 0 !== o && (i.statusCode = o), void 0 === r)) throw i;
            r(i);
          })
        );
      }
      (pe.instance = void 0),
        r(3154),
        r(1649),
        r(9604),
        r(8142),
        r(1256),
        r(2513),
        r(6456),
        r(663),
        r(1884),
        r(8006);
      const De = ["marketing", "analytics", "preferences", "sale_of_data"],
        Me = [
          ...De,
          "email",
          "rootDomain",
          "checkoutRootDomain",
          "storefrontRootDomain",
          "storefrontAccessToken",
          "headlessStorefront",
          "isExtensionToken",
          "metafields",
          "customerAccountRequestInfo",
        ],
        Ue = De.map((e) => `"${e}"`).join(", "),
        Le = "https://shopify.dev/docs/api/customer-privacy";
      function Be() {
        try {
          if ("" === document.referrer) return !0;
          const e = document.createElement("a");
          return (
            (e.href = document.referrer), window.location.hostname != e.hostname
          );
        } catch {
          return !0;
        }
      }
      function ze() {
        return (
          !!(function (e = null) {
            return null === e && (e = Ee()), void 0 === e;
          })() ||
          (Pe() && Ie())
        );
      }
      function qe() {
        return Pe();
      }
      function He() {
        return Ie();
      }
      function Ve() {
        return Ae();
      }
      function We() {
        return Ce();
      }
      function Fe() {
        const e = "xxxx-4xxx-xxxx-xxxxxxxxxxxx";
        let t = "";
        try {
          const r = window.crypto,
            n = new Uint16Array(31);
          r.getRandomValues(n);
          let o = 0;
          t = e
            .replace(/[x]/g, (e) => {
              const t = n[o];
              if ("number" != typeof t)
                throw new Error(
                  `Event ID service: Invalid random number at index "${o}".`
                );
              const r = t % 16;
              return o++, ("x" === e ? r : (3 & r) | 8).toString(16);
            })
            .toUpperCase();
        } catch {
          t = e
            .replace(/[x]/g, (e) => {
              const t = (16 * Math.random()) | 0;
              return ("x" === e ? t : (3 & t) | 8).toString(16);
            })
            .toUpperCase();
        }
        return `${(function () {
          let e = 0,
            t = 0;
          e = new Date().getTime() >>> 0;
          try {
            t = performance.now() >>> 0;
          } catch {
            t = 0;
          }
          return Math.abs(e + t)
            .toString(16)
            .toLowerCase()
            .padStart(8, "0");
        })()}-${t}`;
      }
      const Ke = [
          "page_viewed",
          "collection_viewed",
          "product_viewed",
          "search_submitted",
          "product_added_to_cart",
          "product_added_to_cart_next",
          "checkout_started",
          "checkout_completed",
          "payment_info_submitted",
          "checkout_contact_step_started",
          "checkout_contact_info_submitted",
          "checkout_address_info_submitted",
          "checkout_shipping_step_started",
          "checkout_shipping_info_submitted",
          "checkout_payment_step_started",
          "session_started",
        ],
        Je = "wpm",
        Xe = "trekkie",
        Ye = "trekkie-next",
        Ge = "trekkie-parity";
      let Ze, Qe;
      function et(e) {
        return `${e || "sh"}-${Fe()}`;
      }
      function tt() {
        (window.Shopify = window.Shopify || {}),
          !window.Shopify.evids &&
            ((Ze = {}),
            (Qe = { [Je]: {}, [Xe]: {}, [Ye]: {}, [Ge]: {} }),
            (window.Shopify.evids = (...e) =>
              (function (e, t) {
                if (
                  !(function (e) {
                    return Ke.includes(e);
                  })(e) ||
                  ((null == t ? void 0 : t.analyticsFramework) !== Xe &&
                    "wpm" !== (null == t ? void 0 : t.analyticsFramework) &&
                    (null == t ? void 0 : t.analyticsFramework) !== Ye &&
                    (null == t ? void 0 : t.analyticsFramework) !== Ge)
                )
                  return et("shu");
                const r = (function (e) {
                    return "string" == typeof e && e ? e : "default";
                  })(t.cacheKey),
                  n = (function (e, t, r) {
                    const n = Qe[t],
                      o = n[e] ?? (n[e] = {}),
                      i = o[r];
                    return (o[r] = "number" == typeof i ? i + 1 : 0);
                  })(e, t.analyticsFramework, r);
                return (function (e, t, r) {
                  const n = Ze[e] ?? (Ze[e] = {}),
                    o = n[r] ?? [];
                  let i = o[t];
                  return i || ((i = et()), o.push(i)), (n[r] = o), i;
                })(e, n, r);
              })(...e)));
      }
      const rt = new Set();
      function nt(e) {
        return rt.has(e);
      }
      const ot = "6b3fd603",
        it = "b13923a8",
        st = "5acaffe6",
        at = "3209b71c";
      const ct = {
        randomUUID:
          "undefined" != typeof crypto &&
          crypto.randomUUID &&
          crypto.randomUUID.bind(crypto),
      };
      let ut;
      const lt = new Uint8Array(16);
      function dt() {
        if (
          !ut &&
          ((ut =
            "undefined" != typeof crypto &&
            crypto.getRandomValues &&
            crypto.getRandomValues.bind(crypto)),
          !ut)
        )
          throw new Error(
            "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported"
          );
        return ut(lt);
      }
      const pt = [];
      for (let r = 0; r < 256; ++r) pt.push((r + 256).toString(16).slice(1));
      const ft = function (e, t, r) {
          if (ct.randomUUID && !t && !e) return ct.randomUUID();
          const n = (e = e || {}).random || (e.rng || dt)();
          if (((n[6] = (15 & n[6]) | 64), (n[8] = (63 & n[8]) | 128), t)) {
            r = r || 0;
            for (let e = 0; e < 16; ++e) t[r + e] = n[e];
            return t;
          }
          return (function (e, t = 0) {
            return (
              pt[e[t + 0]] +
              pt[e[t + 1]] +
              pt[e[t + 2]] +
              pt[e[t + 3]] +
              "-" +
              pt[e[t + 4]] +
              pt[e[t + 5]] +
              "-" +
              pt[e[t + 6]] +
              pt[e[t + 7]] +
              "-" +
              pt[e[t + 8]] +
              pt[e[t + 9]] +
              "-" +
              pt[e[t + 10]] +
              pt[e[t + 11]] +
              pt[e[t + 12]] +
              pt[e[t + 13]] +
              pt[e[t + 14]] +
              pt[e[t + 15]]
            );
          })(n);
        },
        ht = /\/products\/([^/?#]+)/;
      class mt extends c {
        constructor(e, t) {
          super(t instanceof Error ? t.message : String(t), {
            groupingHash: e,
          }),
            (this.cause = void 0),
            (this.name = e),
            (this.cause = t);
        }
      }
      const vt = new Set();
      function gt() {
        document.removeEventListener("visibilitychange", gt);
        for (const e of vt) e();
        vt.clear();
      }
      function bt() {
        return new Promise((e) => {
          vt.add(e),
            "visible" === document.visibilityState
              ? (document.addEventListener("visibilitychange", gt),
                requestAnimationFrame(() =>
                  setTimeout(() => {
                    vt.delete(e), e();
                  })
                ))
              : gt();
        });
      }
      const yt = 'a[href*="/products/"]';
      function wt(e) {
        return e.nodeType === Node.ELEMENT_NODE;
      }
      function _t(e) {
        return !(!wt(e) || (!e.matches(yt) && null === e.querySelector(yt)));
      }
      function xt(e) {
        let t = !1;
        const { onProductFound: r, onProductRemoved: n, onError: o } = e;
        function i(e, t) {
          if (wt(e)) {
            e.matches(yt) && e instanceof HTMLAnchorElement && t(e);
            for (const r of Array.from(e.querySelectorAll(yt)))
              r instanceof HTMLAnchorElement && t(r);
          }
        }
        let s = [],
          a = [],
          c = null;
        const u = new MutationObserver((e) => {
            if (!t)
              try {
                let u = !1;
                for (const t of e) {
                  for (const e of Array.from(t.addedNodes))
                    _t(e) && (s.push(e), (u = !0));
                  for (const e of Array.from(t.removedNodes))
                    _t(e) && (a.push(e), (u = !0));
                }
                u &&
                  (c ||
                    (c = bt().then(() => {
                      (c = null),
                        (function () {
                          if (t) return (s = []), void (a = []);
                          const e = s,
                            c = a;
                          (s = []), (a = []);
                          for (const t of c)
                            try {
                              i(t, (e) => {
                                e.isConnected || n(e);
                              });
                            } catch (u) {
                              o?.(new mt("ProductScannerError", u));
                            }
                          for (const t of e)
                            try {
                              i(t, (e) => {
                                e.isConnected && r(e);
                              });
                            } catch (u) {
                              o?.(new mt("ProductScannerError", u));
                            }
                        })();
                    })));
              } catch (u) {
                o?.(new mt("ProductScannerError", u));
              }
          }),
          l =
            "function" == typeof requestIdleCallback &&
            "function" == typeof cancelIdleCallback,
          d = l ? requestIdleCallback : requestAnimationFrame,
          p = l ? cancelIdleCallback : cancelAnimationFrame,
          f = d(() => {
            if (!t)
              try {
                i(document.documentElement, r);
              } catch (e) {
                o?.(new mt("ProductScannerError", e));
              }
          });
        return (
          u.observe(document.documentElement, { childList: !0, subtree: !0 }),
          () => {
            t ||
              ((t = !0), p(f), u.disconnect(), (s = []), (a = []), (c = null));
          }
        );
      }
      function kt(e, t, { leading: r = !0, trailing: n = !0 } = {}) {
        if (t <= 0)
          throw new c(
            "The throttle function requires a positive wait time above zero.",
            { groupingHash: "Utilities:Throttle:InvalidWaitTime" }
          );
        if (!r && !n)
          throw new c(
            "The throttle function requires at least one of leading or trailing to be true, otherwise, its callback will never be called.",
            { groupingHash: "Utilities:Throttle:InvalidOptions" }
          );
        let o,
          i,
          s,
          a = null,
          u = 0;
        function l() {
          (u = !1 === r ? 0 : new Date().valueOf()),
            (a = null),
            o && (i = e.apply(s, o)),
            (s = null),
            (o = null);
        }
        return function (...c) {
          const d = new Date().valueOf();
          u || !1 !== r || (u = d);
          const p = t - (d - u);
          return (
            (s = this),
            (o = c),
            p <= 0 || p > t
              ? (a && (clearTimeout(a), (a = null)),
                (u = d),
                o && (i = e.apply(s, o)),
                (s = null),
                (o = null))
              : a || !1 === n || (a = setTimeout(l, p)),
            i
          );
        };
      }
      let Et;
      const St = () => (
          void 0 === Et &&
            (Et = (function () {
              let e = !1;
              try {
                const t = {
                    get passive() {
                      return (e = !0), !1;
                    },
                  },
                  r = () => {};
                self.addEventListener("test", r, t),
                  self.removeEventListener("test", r, t);
              } catch (t) {
                return !1;
              }
              return e;
            })()),
          Et
        ),
        At = { capture: !0, passive: !0 };
      function It(e, t, r, n) {
        const o = n.addEventListenerOptions
          ? { ...At, ...n.addEventListenerOptions }
          : At;
        try {
          const i = (function (
            e,
            { sampleRate: t, throttleDelay: r, onError: n }
          ) {
            const o = (r) => {
              bt()
                .then(() => e(r))
                .catch((e) => {
                  const r = /Maximum call stack size exceeded/i.test(
                    e?.message || ""
                  );
                  n(e, {
                    context: "listenTo/handler",
                    type: r ? "metric" : "error",
                    unhandled: !1,
                    options: { sampleRate: t ?? 50 },
                  });
                });
            };
            return "number" == typeof r ? kt(o, r) : o;
          })(r, n);
          return (
            e.addEventListener(t, i, St() ? o : o.capture),
            () => {
              e.removeEventListener(t, i, St() ? o : o.capture);
            }
          );
        } catch (i) {
          n.onError(i, { context: "listenTo", unhandled: !1 });
        }
        return () => {};
      }
      function Pt(e, t) {
        if (!{}.hasOwnProperty.call(e, t))
          throw new TypeError("attempted to use private field on non-instance");
        return e;
      }
      var Ct = 0;
      function Ot(e) {
        return "__private_" + Ct++ + "_" + e;
      }
      var Tt = Ot("observer"),
        Nt = Ot("watchesByElement"),
        jt = Ot("disposed"),
        Rt = Ot("onIntersect"),
        $t = Ot("armDwell"),
        Dt = Ot("clearTimer"),
        Mt = Ot("removeWatch");
      class Ut {
        constructor() {
          Object.defineProperty(this, Mt, { value: qt }),
            Object.defineProperty(this, Dt, { value: zt }),
            Object.defineProperty(this, $t, { value: Bt }),
            Object.defineProperty(this, Rt, { value: Lt }),
            Object.defineProperty(this, Tt, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Nt, { writable: !0, value: new Map() }),
            Object.defineProperty(this, jt, { writable: !0, value: !1 }),
            (Pt(this, Tt)[Tt] = new IntersectionObserver(
              (e) => Pt(this, Rt)[Rt](e),
              { threshold: 0.5 }
            ));
        }
        watch(e, t) {
          if (Pt(this, jt)[jt]) return () => {};
          const r = {
            ...t,
            el: e,
            durationMs: t.durationMs ?? 1e3,
            timer: null,
            satisfied: !1,
          };
          let n = Pt(this, Nt)[Nt].get(e);
          return (
            n ||
              ((n = new Set()),
              Pt(this, Nt)[Nt].set(e, n),
              Pt(this, Tt)[Tt].observe(e)),
            n.add(r),
            () => {
              Pt(this, Dt)[Dt](r), r.satisfied || Pt(this, Mt)[Mt](r);
            }
          );
        }
        dispose() {
          if (!Pt(this, jt)[jt]) {
            Pt(this, jt)[jt] = !0;
            for (const e of Pt(this, Nt)[Nt].values())
              for (const t of e) Pt(this, Dt)[Dt](t);
            Pt(this, Nt)[Nt].clear(), Pt(this, Tt)[Tt].disconnect();
          }
        }
      }
      function Lt(e) {
        if (!Pt(this, jt)[jt])
          for (const t of e) {
            const e = Pt(this, Nt)[Nt].get(t.target);
            if (e)
              if (t.intersectionRatio < 0.5)
                for (const t of e) Pt(this, Dt)[Dt](t);
              else for (const r of [...e]) Pt(this, $t)[$t](r, t);
          }
      }
      function Bt(e, t) {
        if (e.satisfied || null != e.timer) return;
        let r = !0;
        try {
          r = !e.shouldStartDwell || e.shouldStartDwell(t);
        } catch (n) {
          return (
            e.onError?.(new mt("VisibilityObserverError", n)),
            void Pt(this, Mt)[Mt](e)
          );
        }
        r
          ? (e.timer = setTimeout(() => {
              if (((e.timer = null), !e.satisfied)) {
                e.satisfied = !0;
                try {
                  e.onSatisfied();
                } catch (n) {
                  e.onError?.(new mt("VisibilityObserverError", n));
                } finally {
                  Pt(this, Mt)[Mt](e);
                }
              }
            }, e.durationMs))
          : Pt(this, Mt)[Mt](e);
      }
      function zt(e) {
        null != e.timer && (clearTimeout(e.timer), (e.timer = null));
      }
      function qt(e) {
        const t = Pt(this, Nt)[Nt].get(e.el);
        t &&
          (t.delete(e),
          0 === t.size &&
            (Pt(this, Nt)[Nt].delete(e.el), Pt(this, Tt)[Tt].unobserve(e.el)));
      }
      function Ht({ context: e, onEvent: t, onError: r }) {
        try {
          const n = nt(st),
            o = nt(at);
          if (!n && !o) return () => {};
          const i = n ? new Ut() : null,
            s = (function () {
              const e = new Map(),
                t = new Map();
              return (r) => {
                if (
                  (function (e) {
                    return (
                      !!e.closest("header") &&
                      !e.closest(
                        "predictive-search, predictive-search-component, [data-predictive-search], .predictive-search"
                      )
                    );
                  })(r)
                )
                  return null;
                const n = (function (e) {
                    try {
                      return new URL(e.href).pathname;
                    } catch {
                      return (e.getAttribute("href") ?? "").trim();
                    }
                  })(r),
                  o = (function (e) {
                    const t = ht.exec(e)?.[1];
                    return t ? { handle: t } : null;
                  })(n);
                if (!o) return null;
                const i = "other",
                  s = `${o.handle}:${i}`,
                  a = e.get(s);
                if (a) return a;
                const c = (t.get(i) ?? 0) + 1;
                t.set(i, c);
                const u = {
                  handle: o.handle,
                  impressionId: ft(),
                  placement: i,
                  position: c,
                  rect: r.getBoundingClientRect(),
                  viewport: {
                    width: window.innerWidth,
                    height: window.innerHeight,
                  },
                };
                return e.set(s, u), u;
              };
            })(),
            a = new Map();
          let c = !1;
          const u = i
              ? (function ({ visibility: e, context: t, emit: r, onError: n }) {
                  const o = new Set();
                  return {
                    track(i, s) {
                      const a = `${s.handle}:${s.placement}`;
                      return o.has(a)
                        ? () => {}
                        : e.watch(i, {
                            onError: n,
                            shouldStartDwell: (e) =>
                              e.boundingClientRect.width >= 10 &&
                              e.boundingClientRect.height >= 10,
                            onSatisfied: () => {
                              o.has(a) ||
                                (o.add(a),
                                r({
                                  interaction: "product_impression",
                                  event: {
                                    pageType: t.pageType,
                                    impressionId: s.impressionId,
                                    placement: s.placement,
                                    position: s.position,
                                    rect: s.rect,
                                    collectionId: t.collectionId,
                                  },
                                  viewport: s.viewport,
                                }));
                            },
                          });
                    },
                  };
                })({ visibility: i, context: e, emit: t, onError: r })
              : null,
            l = o
              ? (function ({ context: e, emit: t, onError: r }) {
                  const n = (e) => {
                    r?.(new mt("ClickTrackerError", e));
                  };
                  return {
                    track(r, o) {
                      let i = !1;
                      const s = It(
                        r,
                        "click",
                        (r) => {
                          i ||
                            (r.isTrusted &&
                              t({
                                interaction: "product_click",
                                event: {
                                  pageType: e.pageType,
                                  impressionId: o.impressionId,
                                  placement: o.placement,
                                  position: o.position,
                                  rect: o.rect,
                                  collectionId: e.collectionId,
                                },
                                viewport: o.viewport,
                              }));
                        },
                        { onError: n }
                      );
                      return () => {
                        (i = !0), s();
                      };
                    },
                  };
                })({ context: e, emit: t, onError: r })
              : null,
            d = xt({
              onProductFound: (e) => {
                if (c) return;
                if (a.has(e)) return;
                const t = s(e);
                if (!t) return;
                const n = [];
                u && n.push(u.track(e, t)),
                  l && n.push(l.track(e, t)),
                  a.set(
                    e,
                    (function (e, t) {
                      return () => {
                        for (const n of e)
                          try {
                            n();
                          } catch (r) {
                            t?.(new mt("ProductInteractionProducerError", r));
                          }
                      };
                    })(n, r)
                  );
              },
              onProductRemoved: (e) => {
                if (c) return;
                const t = a.get(e);
                t && (a.delete(e), t());
              },
              onError: r,
            });
          return () => {
            if (!c) {
              (c = !0), d();
              for (const e of a.values()) e();
              a.clear(), i?.dispose();
            }
          };
        } catch (n) {
          return r?.(new mt("ProductInteractionProducerError", n)), () => {};
        }
      }
      const Vt = "product",
        Wt = "collection";
      function Ft(e) {
        return e === Vt && nt("6faea013")
          ? Vt
          : e === Wt && nt("3b3c7daf")
          ? Wt
          : void 0;
      }
      class Kt extends c {
        constructor(e, t) {
          super(t instanceof Error ? t.message : String(t), {
            groupingHash: e,
          }),
            (this.cause = void 0),
            (this.name = e),
            (this.cause = t);
        }
      }
      const Jt = [5e3, 1e4, 3e4, 6e4];
      const Xt = "webPixelsManager",
        Yt = "production",
        Gt = "0.0.475",
        Zt = "modern",
        Qt = "7a919571w0b784b64p16d009bem0237e62e",
        er = "b7a919571w0b784b64p16d009bem0237e62em.js";
      function tr(e, t) {
        try {
          return e();
        } catch (r) {
          return t;
        }
      }
      const rr = "isMerchantSession";
      r(5864);
      const nr = () => {
        let e, t;
        return {
          promise: new Promise((...r) => {
            [e, t] = r;
          }),
          resolve: e,
          reject: t,
        };
      };
      function or(e) {
        if (e <= 0 || e > 100)
          throw new c("Invalid sampling percent", {
            groupingHash: "Utilities:Sample:InvalidSamplingPercent",
          });
        return 100 * Math.random() <= e;
      }
      class ir {
        constructor(e) {
          (this.maxSize = e), (this.cache = new Map());
        }
        get(e) {
          if (!this.cache.has(e)) return;
          const t = this.cache.get(e);
          return this.cache.delete(e), this.cache.set(e, t), t;
        }
        has(e) {
          return this.cache.has(e);
        }
        set(e, t) {
          if (this.cache.size >= this.maxSize) {
            const e = this.cache.keys().next().value;
            this.cache.delete(e);
          }
          return this.cache.set(e, t), this;
        }
        delete(e) {
          return this.cache.delete(e);
        }
        clear() {
          this.cache.clear();
        }
      }
      const sr = (e) => ("number" == typeof e ? new ir(e) : new Map()),
        ar = (...e) => JSON.stringify(e);
      function cr(e, { cache: t, cacheKey: r } = {}) {
        function n(...t) {
          const o = n.cache,
            i = (r ?? ar).apply(this, t);
          if (o.has(i)) return o.get(i);
          {
            const r = e(...t);
            return o.set(i, r), r;
          }
        }
        return (n.cache = t ?? sr()), n;
      }
      const ur = [
          /Googlebot/i,
          /Storebot-Google/i,
          /bingbot/i,
          /Baiduspider/i,
          /YandexBot/i,
          /DuckDuckBot/i,
          /Slurp/i,
          /facebookexternalhit/i,
          /Twitterbot/i,
          /LinkedInBot/i,
          /Applebot/i,
          /AdsBot-Google/i,
          /Mediapartners-Google/i,
          /APIs-Google/i,
          /bytedance/i,
          /PetalBot/i,
          /SemrushBot/i,
          /AhrefsBot/i,
          /MJ12bot/i,
          /DotBot/i,
          /Acunetix/i,
          /PerplexityBot/i,
          /Perplexity-User/i,
        ],
        lr = cr((e) => !!e && ur.some((t) => e.match(t)), {
          cacheKey: (e) => e ?? "unknown",
          cache: sr(100),
        });
      var dr = r(1554),
        pr = r(6718),
        fr = r.n(pr);
      class hr extends Error {
        constructor(...e) {
          super(...e),
            (this.message =
              "Excessive Stacktrace: May indicate infinite loop forming");
        }
      }
      const mr = (e, t) => {
          const r = (function (e) {
            if (
              ((t = e),
              "string" !=
                typeof (t?.stack || t?.stacktrace || t?.["opera#sourceloc"]) ||
                t.stack === `${t.name}: ${t.message}`)
            )
              return null;
            var t;
            try {
              const t = fr()
                .parse(e)
                .reduce((e, t) => {
                  const r = (function ({
                    functionName: e,
                    lineNumber: t,
                    columnNumber: r,
                  }) {
                    const n = /^global code$/i.test((o = e) || "")
                      ? "global code"
                      : o;
                    var o;
                    return {
                      file: `https://cdn.shopify.com/cdn/wpm/${er}`,
                      method: n,
                      lineNumber: t,
                      columnNumber: r,
                    };
                  })(t);
                  try {
                    return "{}" === JSON.stringify(r) ? e : e.concat(r);
                  } catch (n) {
                    return e;
                  }
                }, []);
              return {
                errorClass: e?.name,
                message: e?.message,
                stacktrace: t,
                type: "browserjs",
              };
            } catch (r) {
              return null;
            }
          })(e);
          if (r) return r;
          const n = (function (e, t) {
            let r = "";
            const n = {
                lineNumber: "1",
                columnNumber: "1",
                method: t,
                file: `https://cdn.shopify.com/cdn/wpm/${er}`,
              },
              o = e.stackTrace || e.stack || e.description;
            try {
              if (o) {
                r = e.stack.split("\n")[0];
                const t = e.stack.match(/([0-9]+):([0-9]+)/);
                if (
                  t &&
                  t.length > 2 &&
                  ((n.lineNumber = t[1]),
                  (n.columnNumber = t[2]),
                  parseInt(n.lineNumber, 10) > 1e5)
                )
                  throw new hr();
              }
              return {
                errorClass: e?.name || r,
                message: e?.message || r,
                stacktrace: [n],
                type: "browserjs",
              };
            } catch (i) {
              return null;
            }
          })(e, t);
          return (
            n || {
              errorClass: e?.name,
              message: e?.message,
              stacktrace: [],
              type: "browserjs",
            }
          );
        },
        vr = ["number", "boolean", "symbol"],
        gr = (e, { context: t }) => {
          const r = "v1/" + (t ? `${t}/` : "");
          return null == e || vr.includes(typeof e) || Array.isArray(e)
            ? `${r}UnknownError`
            : "string" == typeof e
            ? `${r}${e}`
            : "groupingHash" in e && "string" == typeof e.groupingHash
            ? `${r}${e.groupingHash}`
            : `${r}${"Error" !== e.name && e.name ? e.name : e.message}`;
        };
      class br extends Error {
        constructor(...e) {
          super(...e),
            Error.captureStackTrace && Error.captureStackTrace(this, br);
        }
      }
      const yr = {
          severity: "error",
          context: "",
          unhandled: !0,
          library: "browser",
          surface: u.Unknown,
        },
        wr = {
          metadata: {
            shopId: -1,
            surface: u.NotAvailable,
            browserTarget: f.NotAvailable,
            shopDomain: "n/a",
          },
          notify: (e, t) => {
            try {
              if ("metric" === t?.type || !0 === e?.metric) return;
              const r = t?.userAgent || self.navigator?.userAgent;
              if (lr(r)) return;
              if (t?.options?.sampleRate && !or(t.options.sampleRate)) return;
              const n = {
                ...yr,
                ...t,
                ...wr.metadata,
                shopUrl: self.location.href,
              };
              if (
                n.browserTarget === f.NotAvailable ||
                n.browserTarget === f.Unknown ||
                n.surface === u.NotAvailable ||
                n.surface === u.Unknown ||
                !_r(n.shopUrl)
              )
                return void (console?.error && console.error(e));
              const o = (function (e, t) {
                const {
                    userAgent: r,
                    context: n,
                    severity: o,
                    unhandled: i,
                    library: s,
                    hashVersionSandbox: a,
                    sandboxUrl: c,
                    pixelId: u,
                    pixelType: l,
                    runtimeContext: d,
                    shopId: p,
                    initConfig: f,
                    notes: h,
                    surface: m,
                    shopDomain: v,
                    browserTarget: g,
                    shopUrl: b,
                  } = t,
                  {
                    device: y,
                    os: w,
                    browser: _,
                    engine: x,
                  } = (function (t) {
                    try {
                      return new dr.UAParser(t).getResult();
                    } catch (e) {
                      return {
                        ua: "",
                        browser: { name: "", version: "", major: "" },
                        engine: { name: "", version: "" },
                        os: { name: "", version: "" },
                        device: { model: "", type: "", vendor: "" },
                        cpu: { architecture: "" },
                      };
                    }
                  })(r || self.navigator?.userAgent),
                  k = mr(e, n);
                return {
                  payload_version: 5,
                  notifier: {
                    name: "web-pixel-manager",
                    version: Gt,
                    url: "-",
                  },
                  events: [
                    {
                      exceptions: [k],
                      context: n ? `v1/${n}` : void 0,
                      severity: o,
                      unhandled: i,
                      app: { version: Qt },
                      device: {
                        manufacturer: y.vendor,
                        model: y.model,
                        osName: w.name,
                        osVersion: w.version,
                        browserName: _.name,
                        browserVersion: _.version,
                      },
                      request: { url: b, referrer: self.document?.referrer },
                      metaData: {
                        app: {
                          surface: m,
                          library: s,
                          build_target: Zt,
                          env: Yt,
                          hash_version_sandbox: a || "N/A",
                          sandbox_url: c || "N/A",
                        },
                        device: {
                          user_agent: r || self.navigator?.userAgent,
                          rendering_engine_name: x.name,
                          rendering_engine_version: x.version,
                          browser_target: g || "N/A",
                          deploy_phase: Yt,
                        },
                        request: {
                          shop_id: p,
                          shop_domain: v || "N/A",
                          shop_url: b,
                          pixel_id: u,
                          pixel_type: l,
                          runtime_context: d,
                        },
                        "Additional Notes": {
                          init_config: JSON.stringify(f),
                          notes: h,
                        },
                        error_source: { shop_id: p },
                        custom: {
                          slice_name: "signals",
                          slice_id: "S-27053f",
                          observe_grouping_key: gr(e, t),
                        },
                      },
                    },
                  ],
                };
              })(e, n);
              fetch("https://error-analytics-production.shopifysvc.com", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Bugsnag-Api-Key": "bcbc9f6762da195561967577c2d74ff8",
                  "Bugsnag-Payload-Version": "5",
                },
                body: JSON.stringify(o),
              }).catch(() => {});
            } catch (r) {}
          },
        },
        _r = (e) => {
          try {
            const t = new URL(e);
            return Boolean(t.protocol.startsWith("http") && t.host);
          } catch {
            return !1;
          }
        },
        xr = new Set(),
        kr = (e) => (
          xr.add(e),
          () => {
            xr.delete(e);
          }
        );
      function Er(e) {
        const t = e;
        xr.forEach((e) => {
          e(t);
        });
      }
      let Sr = !1;
      const Ar = ["analytics", "preferences", "marketing", "sale_of_data"];
      function Ir(e, t) {
        return e ? !t || Object.keys(e).every((r) => !e[r] || t[r]) : ze();
      }
      function Pr(e) {
        const { promise: t, resolve: r } = nr(),
          n = {
            analytics: He(),
            marketing: qe(),
            preferences: Ve(),
            sale_of_data: We(),
          };
        if (Ir(e, n)) return r(!0), t;
        const o = kr((t) => {
          const n = t.detail;
          Ir(e, {
            analytics: !0 === n?.analyticsAllowed,
            marketing: !0 === n?.marketingAllowed,
            preferences: !0 === n?.preferencesAllowed,
            sale_of_data: !0 === n?.saleOfDataAllowed,
          }) && (o(), r(!0));
        });
        return t;
      }
      let Cr = (function (e) {
        return (e.Wpm = "wpm"), (e.WebPixels = "web-pixels"), e;
      })({});
      const Or = {},
        Tr = {
          "pixel:register": {
            start: {
              name: "pixel:register:started",
              params: { pixelId: "", source: "" },
            },
            end: {
              name: "pixel:register:completed",
              params: { pixelId: "", source: "" },
            },
          },
          "page:session": {
            start: { name: "start", params: Or },
            end: { name: "page:unload", params: Or },
          },
          completed: {
            start: { name: "start", params: Or },
            end: { name: "pixels:resolved", params: Or },
          },
        };
      function Nr(e, t = Or) {
        const r = jr(e, "end", t),
          n = (function (e, t) {
            try {
              const r = Rr(e, "start", t),
                n = Rr(e, "end", t),
                o = (function (e, t) {
                  return $r(e, t);
                })(e, t),
                i = self.performance.measure(o, r, n);
              return {
                ...i,
                duration: Math.round(i.duration),
                startTime: Math.round(i.startTime),
              };
            } catch (r) {
              return null;
            }
          })(e, t);
        return { mark: r, measurement: n };
      }
      function jr(e, t, r) {
        try {
          const n = Rr(e, t, r);
          return self.performance.mark(n), { name: n, params: r };
        } catch (n) {
          return { name: null, params: r };
        }
      }
      function Rr(e, t, r) {
        return $r(Tr[e][t].name, r);
      }
      function $r(e, t = {}) {
        const r = ["wpm", e];
        return (
          Object.keys(t).forEach((e) => {
            const n = t[e];
            n && r.push(n);
          }),
          r.join(":")
        );
      }
      const Dr = {
        test: "edge_test_click/1.0",
        load: "web_pixels_manager_load/3.1",
        init: "web_pixels_manager_init/3.2",
        register: "web_pixels_manager_pixel_register/3.8",
        subscriberEventEmit: "web_pixels_manager_subscriber_event_emit/4.1",
        eventPublish: "web_pixels_manager_event_publish/1.7",
        unload: "web_pixels_manager_unload/1.2",
        visitor: "web_pixels_manager_visitor/1.0",
        subscriberEventEmitDom:
          "web_pixels_manager_subscriber_event_emit_dom/2.0",
        subscriberEventEmitPrivacy:
          "web_pixels_manager_subscriber_event_emit_privacy/1.0",
        helperLoad: "web_pixels_helper_load/1.0",
        helperWindowButtonClick: "web_pixels_helper_window_button_click/1.0",
        buyerEventSample: "web_pixels_manager_buyer_event_sample/1.0",
        firstPartyTracking: "storefront_customer_tracking/4.27",
        webPixelsStorefrontCustomerTracking:
          "web_pixels_manager_storefront_customer_tracking/1.0",
        webPixelsPublicEventPayloadTransform:
          "web_pixels_public_event_payload_transform/1.0",
        webPixelsManagerSubscriberEventBlocked:
          "web_pixels_manager_subscriber_event_blocked/1.0",
      };
      function Mr(e, t) {
        return { schemaId: Dr[e], payload: t };
      }
      let Ur;
      function Lr(e, t = !1) {
        Ur?.produce(e.schemaId, e.payload, { flush: t });
      }
      function Br(e, t, r = !1) {
        Lr(Mr(e, t), r);
      }
      function zr(e) {
        return e
          .replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2")
          .replace(/([a-z\d])([A-Z])/g, "$1_$2")
          .toLowerCase();
      }
      function qr(e) {
        return (
          null !== e &&
          "object" == typeof e &&
          !Array.isArray(e) &&
          "[object Object]" === Object.prototype.toString.call(e)
        );
      }
      function Hr(e, t = new WeakMap()) {
        if (!qr(e)) return e;
        const r = t.get(e);
        if (r) return r;
        const n = {};
        t.set(e, n);
        for (const [o, i] of Object.entries(e)) {
          const e = zr(o);
          Array.isArray(i)
            ? (n[e] = i.map((e) => Hr(e, t)))
            : qr(i)
            ? (n[e] = Hr(i, t))
            : (n[e] = i);
        }
        return n;
      }
      var Vr = Ot("endpoint"),
        Wr = Ot("batchTimeout"),
        Fr = Ot("onError"),
        Kr = Ot("buffer"),
        Jr = Ot("timeoutId"),
        Xr = Ot("skipXhr"),
        Yr = Ot("onPageHide"),
        Gr = Ot("send"),
        Zr = Ot("sendXhr");
      class Qr {
        constructor(e) {
          Object.defineProperty(this, Zr, { value: tn }),
            Object.defineProperty(this, Gr, { value: en }),
            Object.defineProperty(this, Vr, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Wr, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Fr, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Kr, { writable: !0, value: [] }),
            Object.defineProperty(this, Jr, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Xr, { writable: !0, value: !1 }),
            Object.defineProperty(this, Yr, {
              writable: !0,
              value: () => {
                (Pt(this, Xr)[Xr] = !0), this.flush();
              },
            }),
            (Pt(this, Vr)[Vr] = e.endpoint),
            (Pt(this, Wr)[Wr] = e.batchTimeout ?? 500),
            (Pt(this, Fr)[Fr] = e.onError),
            self.addEventListener("pagehide", Pt(this, Yr)[Yr]);
        }
        setEndpoint(e) {
          Pt(this, Vr)[Vr] = e;
        }
        destroy() {
          self.removeEventListener("pagehide", Pt(this, Yr)[Yr]),
            void 0 !== Pt(this, Jr)[Jr] &&
              (clearTimeout(Pt(this, Jr)[Jr]), (Pt(this, Jr)[Jr] = void 0));
        }
        produce(e, t, { flush: r, convertEventCase: n = !0 } = {}) {
          const o = n ? Hr(t) : t;
          Pt(this, Vr)[Vr]
            ? (Pt(this, Kr)[Kr].push({
                schema_id: e,
                payload: o,
                metadata: { event_created_at_ms: new Date().getTime() },
              }),
              r
                ? this.flush()
                : void 0 === Pt(this, Jr)[Jr] &&
                  (Pt(this, Jr)[Jr] = setTimeout(
                    () => this.flush(),
                    Pt(this, Wr)[Wr]
                  )))
            : console.log("[MonorailClient]", e, o);
        }
        flush() {
          if (
            (void 0 !== Pt(this, Jr)[Jr] &&
              (clearTimeout(Pt(this, Jr)[Jr]), (Pt(this, Jr)[Jr] = void 0)),
            0 === Pt(this, Kr)[Kr].length)
          )
            return;
          const e = {
            events: Pt(this, Kr)[Kr].splice(0),
            metadata: { event_sent_at_ms: new Date().getTime() },
          };
          Pt(this, Gr)[Gr](JSON.stringify(e));
        }
        get pendingEvents() {
          return Pt(this, Kr)[Kr];
        }
      }
      function en(e) {
        if (!Pt(this, Vr)[Vr]) return !1;
        const t = Pt(this, Xr)[Xr];
        Pt(this, Xr)[Xr] = !1;
        const r = Pt(this, Vr)[Vr];
        return (
          !!tr(
            () => self.navigator.sendBeacon.bind(self.navigator)(r, e),
            !1
          ) ||
          (!t && Pt(this, Zr)[Zr](r, e))
        );
      }
      function tn(e, t) {
        try {
          const r = new XMLHttpRequest();
          return (
            r.open("POST", e, !0),
            r.setRequestHeader("Content-Type", "text/plain"),
            r.send(t),
            !0
          );
        } catch (r) {
          return Pt(this, Fr)[Fr]?.(r), !1;
        }
      }
      function rn(e) {
        return e.replace(/\/$/, "");
      }
      function nn(e, t) {
        return `${(function (e, t) {
          const r = {
              global: "https://monorail-edge.shopifysvc.com",
              wellKnown: `${e}/.well-known/shopify/monorail`,
              staging: "https://monorail-edge-staging.shopifycloud.com",
              test: "https://localhost",
            },
            n = t || "wellKnown";
          return n in r ? r[n] : r.wellKnown;
        })(rn(e), t)}/unstable/produce_batch`;
      }
      let on;
      function sn() {
        return (
          on ||
            (on = (function () {
              let e;
              try {
                e = window.Shopify?.evids
                  ? window.Shopify?.evids("session_started", {
                      analyticsFramework: "wpm",
                    })
                  : ft();
              } catch (t) {
                e = ft();
              }
              return e;
            })()),
          on
        );
      }
      function an(e, t, r, n = !0) {
        try {
          const o = {
            ...(n ? Object.getOwnPropertyDescriptor(e, t) : {}),
            ...r,
          };
          return Object.defineProperty(e, t, o);
        } catch (o) {
          return e;
        }
      }
      const cn = cr(
          (e = "") => {
            const t = e.indexOf("=");
            return -1 === t
              ? [e.trim(), void 0]
              : [e.slice(0, t).trim(), e.slice(t + 1).trim()];
          },
          { cache: sr(100), cacheKey: (e = "") => e }
        ),
        un = cr(
          (e = "") =>
            e.split(";").reduce((e, t) => {
              const [r, n] = cn(t);
              if (r)
                try {
                  e[decodeURIComponent(r)] = decodeURIComponent(n ?? "");
                } catch {
                  e[r] = n ?? "";
                }
              return e;
            }, Object.create(null)),
          { cache: sr(50), cacheKey: (e = "") => e }
        ),
        ln = () => {
          try {
            return document.cookie;
          } catch {
            return;
          }
        },
        dn = (e) => {
          try {
            document.cookie = e;
          } catch {}
        },
        pn = (e) => {
          const t = ln();
          return t ? un(t)[e] : void 0;
        },
        fn = "_shopify_test",
        hn = new Map();
      const mn = () => pn("_shopify_y") ?? "";
      function vn(e, t) {
        return t.reduce((t, r) => (r in e && (t[r] = e[r]), t), {});
      }
      class gn extends Set {
        constructor(e, t) {
          if ((super(), (Number.isFinite(e) && !Number.isInteger(e)) || e <= 0))
            throw new Error("Invalid maxSize specified");
          (this.maxSize = e), (this.keep = t);
        }
        add(e) {
          if ("oldest" === this.keep) this.size < this.maxSize && super.add(e);
          else if (
            "newest" === this.keep &&
            (super.add(e), this.size > this.maxSize)
          )
            for (const t of this)
              if ((this.delete(t), this.size <= this.maxSize)) break;
          return this;
        }
      }
      class bn {
        constructor({
          bufferSize: e = 50,
          replayKeep: t = "oldest",
          subscribeAllKey: r,
          onSubscriberError: n,
        } = {}) {
          (this.channelSubscribers = new Map()),
            (this.bufferSize = e),
            (this.replayKeep = t),
            (this.subscribeAllKey = r),
            (this.replayQueue = new gn(e, t)),
            (this.onSubscriberError = n),
            (this.middlewareChain = (e) => e());
        }
        use(...e) {
          return e.forEach((e) => this.useMiddleware(e)), this;
        }
        publish(e, t, r = {}) {
          if (this.subscribeAllKey && e === this.subscribeAllKey)
            throw new Error(`Cannot publish to ${String(e)}`);
          this.replayQueue.add({ name: e, payload: t, options: r });
          const n = (n, o) => {
            this.processEvent(e, t, o, r, n);
          };
          return (
            [
              this.channelSubscribers.get(e),
              this.subscribeAllKey
                ? this.channelSubscribers.get(this.subscribeAllKey)
                : void 0,
            ]
              .filter((e) => !!e)
              .forEach((e) => e.forEach(n)),
            !0
          );
        }
        subscribe(e, t, r = {}) {
          const n = this.channelSubscribers.get(e) || new Map();
          return (
            this.channelSubscribers.set(e, n.set(t, r)),
            this.replayQueue.forEach(({ name: n, payload: o, options: i }) => {
              (e === n ||
                (this.subscribeAllKey && e === this.subscribeAllKey)) &&
                this.processEvent(n, o, t, i, r);
            }),
            () => n.delete(t)
          );
        }
        processEvent(e, t, r, n = {}, o = {}) {
          const i = (e = t) => {
            r.call({}, e);
          };
          try {
            this.middlewareChain(i, e, t, n, o);
          } catch (p) {
            this.onSubscriberError
              ? this.onSubscriberError(p)
              : console?.error(`Error in subscriber for event ${e}:`, p);
          }
        }
        useMiddleware(e) {
          const t = this.middlewareChain;
          this.middlewareChain = (r, n, o, ...i) => {
            let s = !1;
            const a = (e = o) => {
              s || ((s = !0), r(e));
            };
            t(
              (t = o) => {
                e(a, n, t, ...i), (s = !0);
              },
              n,
              o,
              ...i
            );
          };
        }
      }
      var yn = ((e) => (
        (e.Standard = "standard"), (e.Advanced = "advanced"), e
      ))(yn || {});
      const wn = "remote-ui::ready";
      function _n(e, { terminate: t = !0, targetOrigin: r = "*" } = {}) {
        var n;
        if ("undefined" == typeof window)
          throw new Error(
            "You can only run fromIframe() in a browser context, but no window was found."
          );
        const o = new WeakMap();
        let i;
        function s(t) {
          t.source === e.contentWindow &&
            t.data === wn &&
            (window.removeEventListener("message", s), i());
        }
        null === (n = e.contentWindow) || void 0 === n || n.postMessage(wn, r);
        const a = new Promise((e) => {
          (i = e), window.addEventListener("message", s);
        });
        return {
          async postMessage(t, n) {
            var o;
            await a,
              null === (o = e.contentWindow) ||
                void 0 === o ||
                o.postMessage(t, r, n);
          },
          addEventListener(t, r) {
            const n = (t) => {
              t.source === e.contentWindow && r(t);
            };
            o.set(r, n), self.addEventListener(t, n);
          },
          removeEventListener(e, t) {
            const r = o.get(t);
            null != r && (o.delete(t), self.removeEventListener(e, r));
          },
          terminate() {
            window.removeEventListener("message", s), t && e.remove();
          },
        };
      }
      const xn = Symbol.for("RemoteUi::Retain"),
        kn = Symbol.for("RemoteUi::Release"),
        En = Symbol.for("RemoteUi::RetainedBy");
      class Sn {
        constructor() {
          this.memoryManaged = new Set();
        }
        add(e) {
          this.memoryManaged.add(e), e[En].add(this), e[xn]();
        }
        release() {
          for (const e of this.memoryManaged) e[En].delete(this), e[kn]();
          this.memoryManaged.clear();
        }
      }
      function An(e) {
        return Boolean(e && e[xn] && e[kn]);
      }
      function In(e, { deep: t = !0 } = {}) {
        return Pn(e, t, new Map());
      }
      function Pn(e, t, r) {
        const n = r.get(e);
        if (null != n) return n;
        const o = An(e);
        if ((o && e[xn](), r.set(e, o), t)) {
          if (Array.isArray(e)) {
            const n = e.reduce((e, n) => Pn(n, t, r) || e, o);
            return r.set(e, n), n;
          }
          if (Tn(e)) {
            const n = Object.keys(e).reduce((n, o) => Pn(e[o], t, r) || n, o);
            return r.set(e, n), n;
          }
        }
        return r.set(e, o), o;
      }
      function Cn(e, { deep: t = !0 } = {}) {
        return On(e, t, new Map());
      }
      function On(e, t, r) {
        const n = r.get(e);
        if (null != n) return n;
        const o = An(e);
        if ((o && e[kn](), r.set(e, o), t)) {
          if (Array.isArray(e)) {
            const n = e.reduce((e, n) => On(n, t, r) || e, o);
            return r.set(e, n), n;
          }
          if (Tn(e)) {
            const n = Object.keys(e).reduce((n, o) => On(e[o], t, r) || n, o);
            return r.set(e, n), n;
          }
        }
        return o;
      }
      function Tn(e) {
        if (null == e || "object" != typeof e) return !1;
        const t = Object.getPrototypeOf(e);
        return null == t || t === Object.prototype;
      }
      const Nn = "_@f";
      function jn(e) {
        const t = new Map(),
          r = new Map(),
          n = new Map();
        return {
          encode: function n(o, i = new Map()) {
            if (null == o) return [o];
            const s = i.get(o);
            if (s) return s;
            if ("object" == typeof o) {
              if (Array.isArray(o)) {
                i.set(o, [void 0]);
                const e = [],
                  t = [
                    o.map((t) => {
                      const [r, o = []] = n(t, i);
                      return e.push(...o), r;
                    }),
                    e,
                  ];
                return i.set(o, t), t;
              }
              if (Tn(o)) {
                i.set(o, [void 0]);
                const e = [],
                  t = [
                    Object.keys(o).reduce((t, r) => {
                      const [s, a = []] = n(o[r], i);
                      return e.push(...a), { ...t, [r]: s };
                    }, {}),
                    e,
                  ];
                return i.set(o, t), t;
              }
            }
            if ("function" == typeof o) {
              if (t.has(o)) {
                const e = t.get(o),
                  r = [{ [Nn]: e }];
                return i.set(o, r), r;
              }
              const n = e.uuid();
              t.set(o, n), r.set(n, o);
              const s = [{ [Nn]: n }];
              return i.set(o, s), s;
            }
            const a = [o];
            return i.set(o, a), a;
          },
          decode: o,
          async call(e, t) {
            const n = new Sn(),
              i = r.get(e);
            if (null == i)
              throw new Error(
                "You attempted to call a function that was already released."
              );
            try {
              const e = An(i) ? [n, ...i[En]] : [n];
              return await i(...o(t, e));
            } finally {
              n.release();
            }
          },
          release(e) {
            const n = r.get(e);
            n && (r.delete(e), t.delete(n));
          },
          terminate() {
            t.clear(), r.clear(), n.clear();
          },
        };
        function o(t, r) {
          if ("object" == typeof t) {
            if (null == t) return t;
            if (Array.isArray(t)) return t.map((e) => o(e, r));
            if (Nn in t) {
              const o = t[Nn];
              if (n.has(o)) return n.get(o);
              let i = 0,
                s = !1;
              const a = () => {
                  (i -= 1), 0 === i && ((s = !0), n.delete(o), e.release(o));
                },
                c = () => {
                  i += 1;
                },
                u = new Set(r),
                l = (...t) => {
                  if (s)
                    throw new Error(
                      "You attempted to call a function that was already released."
                    );
                  if (!n.has(o))
                    throw new Error(
                      "You attempted to call a function that was already revoked."
                    );
                  return e.call(o, t);
                };
              Object.defineProperties(l, {
                [kn]: { value: a, writable: !1 },
                [xn]: { value: c, writable: !1 },
                [En]: { value: u, writable: !1 },
              });
              for (const e of u) e.add(l);
              return n.set(o, l), l;
            }
            if (Tn(t))
              return Object.keys(t).reduce(
                (e, n) => ({ ...e, [n]: o(t[n], r) }),
                {}
              );
          }
          return t;
        }
      }
      class Rn extends Error {
        constructor(e) {
          const { callId: t, error: r, result: n } = e;
          super(
            `No resolver found for call ID: ${t}${
              r ? ` Error: ${String(r)}` : ""
            }${null == n ? "" : ` Result: ${JSON.stringify(n)}`}`
          ),
            (this.callId = void 0),
            (this.error = void 0),
            (this.result = void 0),
            (this.groupingHash = "RemoteUI::MissingResolverError"),
            (this.name = "MissingResolverError"),
            (this.callId = t),
            (this.error = r),
            (this.result = n);
        }
      }
      function $n(
        e,
        { uuid: t = Dn, createEncoder: r = jn, callable: n } = {}
      ) {
        let o = !1,
          i = e;
        const s = new Map(),
          a = new Map(),
          c = (function (e, t) {
            let r;
            if (null == t) {
              if ("function" != typeof Proxy)
                throw new Error(
                  "You must pass an array of callable methods in environments without Proxies."
                );
              const t = new Map();
              r = new Proxy(
                {},
                {
                  get(r, n) {
                    if (t.has(n)) return t.get(n);
                    const o = e(n);
                    return t.set(n, o), o;
                  },
                }
              );
            } else {
              r = {};
              for (const n of t)
                Object.defineProperty(r, n, {
                  value: e(n),
                  writable: !1,
                  configurable: !0,
                  enumerable: !0,
                });
            }
            return r;
          })(p, n),
          u = r({
            uuid: t,
            release(e) {
              l(3, [e]);
            },
            call(e, r, n) {
              const o = t(),
                i = f(o, n),
                [s, a] = u.encode(r);
              return l(5, [o, e, s], a), i;
            },
          });
        return (
          i.addEventListener("message", d),
          {
            call: c,
            replace(e) {
              const t = i;
              (i = e),
                t.removeEventListener("message", d),
                e.addEventListener("message", d);
            },
            expose(e) {
              for (const t of Object.keys(e)) {
                const r = e[t];
                "function" == typeof r ? s.set(t, r) : s.delete(t);
              }
            },
            callable(...e) {
              if (null != n)
                for (const t of e)
                  Object.defineProperty(c, t, {
                    value: p(t),
                    writable: !1,
                    configurable: !0,
                    enumerable: !0,
                  });
            },
            terminate() {
              l(2, void 0), h(), i.terminate && i.terminate();
            },
          }
        );
        function l(e, t, r) {
          o || i.postMessage(t ? [e, t] : [e], r);
        }
        async function d(e) {
          if (o) return;
          const { data: t } = e;
          var r;
          if (
            ((r = t),
            Array.isArray(r) &&
              "number" == typeof r[0] &&
              (null == r[1] || Array.isArray(r[1])))
          )
            switch (t[0]) {
              case 2:
                h();
                break;
              case 0: {
                const e = new Sn(),
                  [r, o, i] = t[1],
                  a = s.get(o);
                try {
                  if (null == a)
                    throw new Error(
                      `No '${o}' method is exposed on this endpoint`
                    );
                  const [t, n] = u.encode(await a(...u.decode(i, [e])));
                  l(1, [r, void 0, t], n);
                } catch (n) {
                  const { name: e, message: t, stack: o } = n;
                  throw (l(1, [r, { name: e, message: t, stack: o }]), n);
                } finally {
                  e.release();
                }
                break;
              }
              case 1: {
                const [e, r, n] = t[1],
                  o = a.get(e);
                if (null == o) throw new Rn({ callId: e, error: r, result: n });
                o(...t[1]), a.delete(e);
                break;
              }
              case 3: {
                const [e] = t[1];
                u.release(e);
                break;
              }
              case 6: {
                const [e, r, n] = t[1],
                  o = a.get(e);
                if (null == o) throw new Rn({ callId: e, error: r, result: n });
                o(...t[1]), a.delete(e);
                break;
              }
              case 5: {
                const [e, r, o] = t[1];
                try {
                  const t = await u.call(r, o),
                    [n, i] = u.encode(t);
                  l(6, [e, void 0, n], i);
                } catch (n) {
                  const { name: t, message: r, stack: o } = n;
                  throw (l(6, [e, { name: t, message: r, stack: o }]), n);
                }
                break;
              }
            }
        }
        function p(e) {
          return (...r) => {
            if (o)
              return Promise.reject(
                new Error(
                  "You attempted to call a function on a terminated web worker."
                )
              );
            if ("string" != typeof e && "number" != typeof e)
              return Promise.reject(
                new Error(
                  `Can’t call a symbol method on a remote endpoint: ${e.toString()}`
                )
              );
            const n = t(),
              i = f(n),
              [s, a] = u.encode(r);
            return l(0, [n, e, s], a), i;
          };
        }
        function f(e, t) {
          return new Promise((r, n) => {
            a.set(e, (e, o, i) => {
              if (null == o) r(i && u.decode(i, t));
              else {
                const e = new Error();
                Object.assign(e, o), n(e);
              }
            });
          });
        }
        function h() {
          var e;
          (o = !0),
            s.clear(),
            a.clear(),
            null === (e = u.terminate) || void 0 === e || e.call(u),
            i.removeEventListener("message", d);
        }
      }
      function Dn() {
        return `${Mn()}-${Mn()}-${Mn()}-${Mn()}`;
      }
      function Mn() {
        return Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16);
      }
      const Un = (e, t, { important: r = !1 } = {}) =>
          Object.keys(t).forEach((n) => {
            const o = t[n],
              [i = "", s = r ? "important" : void 0] = Array.isArray(o)
                ? o
                : [o];
            e.style.setProperty(n, i, s);
          }),
        Ln = "web-pixels-helper-sandbox-handle",
        Bn = { height: "26px", width: "21px", top: "12px", left: "12px" },
        zn = { height: "100%", width: "100%", top: "0px", left: "0px" };
      const qn = 25;
      function Hn(e) {
        return e instanceof HTMLElement || e instanceof SVGElement;
      }
      function Vn({ id: e, tagName: t, attributes: r, dataset: n, styles: o }) {
        const i = document.querySelector(`${t}#${e}`);
        if (i) return [i, !1];
        const s = ((e, t) => {
          const r = document.createElement(e);
          return (
            Object.keys(t).forEach((e) => {
              const n = t[e];
              void 0 !== n && r.setAttribute(e, n);
            }),
            r
          );
        })(t, { ...r, id: e });
        return (
          n &&
            Object.keys(n).forEach((e) => {
              s.dataset[e] = n[e];
            }),
          Un(s, o.props, o.options),
          [s, !0]
        );
      }
      async function Wn({ containerSpec: e, iframeSpec: t }) {
        await new Promise((e) => {
          if (document.body) e();
          else {
            const t = () => {
              "loading" !== document.readyState &&
                (e(), document.removeEventListener("readystatechange", t));
            };
            document.addEventListener("readystatechange", t);
          }
        });
        const [r, n] = Vn({
          id: e.id,
          tagName: e.tagName,
          styles: { props: e.styles, options: { important: !0 } },
          attributes: { tabIndex: "-1", ...e.attributes },
          dataset: e.dataset,
        });
        n && document.body.appendChild(r);
        const o = t.attributes || {},
          [i, s] = Vn({
            id: t.id,
            tagName: "iframe",
            styles: { props: t.styles, options: { important: !0 } },
            attributes: { tabIndex: "-1", ...o, name: t.id, src: t.src },
          });
        if (s) {
          if (t.privileges) {
            if (
              !(function (e) {
                return "sandbox" in e;
              })(i)
            )
              throw new br(
                "browser does not support the sandbox attribute on IFrames"
              );
            i.setAttribute("sandbox", t.privileges.join(" "));
          }
          r.appendChild(i);
        }
        return { container: r, iframe: i };
      }
      async function Fn({ state: e, extensionsBaseUrl: t, onHelperReady: r }) {
        const n = await (async function ({
            extensionsBaseUrl: e,
            height: t = 216,
            position: r = null,
          }) {
            const n = `${e}/web-pixels-helper/h${Qt}m.html`;
            return Wn({
              containerSpec: {
                id: "web-pixels-helper-sandbox-container",
                tagName: "dialog",
                attributes: { popover: "manual" },
                styles: {
                  ...(r
                    ? {
                        top: `${r.y}px`,
                        left: `${r.x}px`,
                        right: "auto",
                        bottom: "auto",
                      }
                    : {
                        top: "max(0px, calc(100% - 770px))",
                        bottom: "auto",
                        right: "30px",
                        left: "auto",
                      }),
                  width: "393px",
                  height: `${t}px`,
                  position: "fixed",
                  border: "0",
                  opacity: "0",
                  margin: "0",
                  padding: "0",
                  background: "transparent",
                  overflow: "hidden",
                  visibility: "hidden",
                  transform: "translate(0px, 0px)",
                  "border-radius": "16px",
                  "box-shadow":
                    "rgba(0, 0, 0, 0.2) 0px 3px 5px -1px, rgba(0, 0, 0, 0.14) 0px 5px 8px 0px, rgba(0, 0, 0, 0.12) 0px 1px 14px 0px",
                  transition:
                    "opacity 200ms ease-in-out, height 300ms ease-in-out, top 300ms ease-in-out, box-shadow 300ms",
                  display: "block",
                  "pointer-events": "auto",
                },
                dataset: { shopifyPrivacy: "exclude" },
              },
              iframeSpec: {
                id: "web-pixels-helper-sandbox-iframe",
                src: n,
                styles: {
                  border: "none",
                  background: "#fff",
                  clip: "initial",
                  display: "inline",
                  margin: "0",
                  opacity: "1",
                  padding: "0",
                  visibility: "visible",
                  width: "100%",
                  height: "100%",
                  "border-radius": "16px",
                },
              },
            });
          })({ extensionsBaseUrl: t, height: e.height, position: e.position }),
          o = $n(_n(n.iframe), {
            callable: [
              "initializeHelper",
              "logConsentGranted",
              "logPixelRegister",
              "logSubscribe",
              "logEvent",
            ],
          }),
          i = Kn({ state: e, reference: n, onHelperReady: r });
        return (
          o.expose({ ...i }),
          (function (e, t) {
            if (e.querySelector(`#${Ln}`)) return;
            const r = document.createElement("div");
            r.setAttribute("id", Ln),
              Un(
                r,
                {
                  display: "block",
                  position: "absolute",
                  cursor: "grab",
                  background: "transparent",
                  ...Bn,
                },
                { important: !0 }
              ),
              e.appendChild(r),
              r.addEventListener(
                "mousedown",
                (function ({ container: e, handle: t, onMove: r }, n) {
                  function o(t) {
                    t.preventDefault();
                    const o = qn,
                      i = self.innerHeight - qn,
                      s = qn,
                      a = self.innerWidth - qn;
                    if (
                      t.clientY < o ||
                      t.clientY > i ||
                      t.clientX < s ||
                      t.clientX > a
                    )
                      return;
                    r && r(t.clientX - qn, t.clientY - qn),
                      (n[1] = n[3] - t.clientX),
                      (n[2] = n[4] - t.clientY),
                      (n[3] = t.clientX),
                      (n[4] = t.clientY);
                    const c = new DOMMatrix(getComputedStyle(e).transform),
                      u = c.e,
                      l = c.f,
                      d = u - n[1],
                      p = l - n[2];
                    Un(
                      e,
                      { transform: `translate(${d}px, ${p}px)` },
                      { important: !0 }
                    );
                  }
                  function i(e) {
                    Un(t, Bn, { important: !0 }),
                      self.removeEventListener("mouseup", i),
                      self.removeEventListener("mousemove", o);
                  }
                  return (e) => {
                    e.preventDefault(),
                      (n[3] = e.clientX),
                      (n[4] = e.clientY),
                      self.addEventListener("mouseup", i),
                      self.addEventListener("mousemove", o),
                      Un(t, zn, { important: !0 });
                  };
                })(
                  { container: e, handle: r, onMove: t },
                  { 1: 0, 2: 0, 3: 0, 4: 0 }
                )
              );
          })(n.container, (t, r) => {
            e.setPosition({ x: t, y: r });
          }),
          o
        );
      }
      const Kn = ({ state: e, reference: t, onHelperReady: r }) => ({
          async setHelperReady() {
            t.container.showPopover(),
              Un(
                t.container,
                { visibility: "visible", opacity: "1" },
                { important: !0 }
              ),
              r();
          },
          setHeight: ({ height: r }) =>
            new Promise((n, o) => {
              try {
                Un(t.container, { height: `${r}px` }, { important: !0 }),
                  e.setHeight(r),
                  n(!0);
              } catch (i) {
                n(!1);
              }
            }),
          async proceedWithoutConsent() {
            try {
              const { success: e } = await (function (e, t) {
                if (re())
                  throw new Error(
                    "setTrackingConsent is not supported in Node.js environments. This function requires browser APIs (XHR, cookies, window) and can only be called client-side."
                  );
                const r = new pe();
                if (
                  (Ie() && r.produce("setTrackingConsent", "v0.2"),
                  (function (e) {
                    if ("boolean" != typeof e && "object" != typeof e)
                      throw new F(
                        `setTrackingConsent received an invalid argument of type "${typeof e}". Expected an object with consent keys. Example: setTrackingConsent({ analytics: true, marketing: false }). See ${Le} for documentation.`
                      );
                    if ("object" == typeof e) {
                      const t = Object.keys(e);
                      if (0 === t.length)
                        throw new F(
                          `The submitted consent object is empty. Expected at least one consent key: ${Ue}. Example: setTrackingConsent({ analytics: true, marketing: false }). See ${Le} for documentation.`
                        );
                      for (const e of t)
                        if (!Me.includes(e))
                          throw new F(
                            `The submitted consent object contains an invalid key: "${e}". Valid keys are: ${Ue}. Example: setTrackingConsent({ analytics: true, marketing: false }). See ${Le} for documentation.`
                          );
                    }
                  })(e),
                  void 0 !== t && "function" != typeof t)
                )
                  throw new F(
                    `setTrackingConsent received an invalid callback of type "${typeof t}". The second argument must be a function if provided. Example: setTrackingConsent({ analytics: true }, (error, result) => { ... }). See ${Le} for documentation.`
                  );
                const n = (function (e) {
                    if (!e) return null;
                    try {
                      return Be() ? document.referrer : "";
                    } catch {
                      return "";
                    }
                  })(e.analytics),
                  o = (function (e) {
                    if (!e) return null;
                    if (!Be()) return "/";
                    try {
                      return window.location.pathname + window.location.search;
                    } catch {
                      return "/";
                    }
                  })(e.analytics);
                return $e(
                  0,
                  {
                    granular_consent: e,
                    ...(null !== n && { referrer: n }),
                    ...(null !== o && { landing_page: o }),
                  },
                  t
                );
              })(Ar.reduce((e, t) => ((e[t] = !0), e), {}));
              return Boolean(e);
            } catch (e) {
              return !1;
            }
          },
          async setClipboard({ text: e }) {
            try {
              return self.navigator.clipboard.writeText(e), !0;
            } catch (t) {
              return !1;
            }
          },
          async reportTelemetry(e) {
            Br("helperWindowButtonClick", e);
          },
        }),
        Jn = new Set(),
        Xn = "webPixelDebug";
      class Yn extends c {
        constructor(e) {
          super(`Helper state is invalid.\n\nState: ${JSON.stringify(e)}`),
            (this.name = "InvalidHelperStateError");
        }
      }
      class Gn extends c {
        constructor(e, t) {
          super(
            `Helper's selected pixel is invalid.\n\nPixel: ${JSON.stringify(
              t
            )}\n\nState: ${JSON.stringify(e)}`
          ),
            (this.name = "InvalidPixelHelperError");
        }
      }
      const Zn = [l.Custom, l.App];
      function Qn(e) {
        try {
          sessionStorage.setItem(Xn, JSON.stringify(e));
        } catch {
          (t =
            "Session storage is not available. The Pixel Helper experience may be degraded."),
            Jn.has(t) || (Jn.add(t), "console" in self && console.warn(t));
        }
        var t;
      }
      function eo() {
        tr(() => sessionStorage.removeItem(Xn));
      }
      const to = (e, t) => ({
          version: Gt,
          pageUrl: self.location.href,
          surface: e.surface ?? u.Unknown,
          status: t,
          bundleTarget: Zt,
          shopId: e.shopId,
        }),
        ro = (function () {
          const e = new gn(1e3, "newest");
          let t = null;
          return {
            message(r, n) {
              const o = () => t?.call[r](n);
              if (t)
                try {
                  o();
                } catch (i) {
                  wr.notify(i, {
                    context: "createWebPixelsHelper/message/endpoint-call",
                    unhandled: !1,
                    severity: "warning",
                  });
                }
              else e?.add(o);
            },
            async init(r) {
              const n = (() => {
                try {
                  return ((e) => {
                    const t = new URL(window.location.href),
                      r = t.searchParams.get(Xn),
                      n = tr(() => (r ? JSON.parse(atob(r)) : null), null);
                    r &&
                      (t.searchParams.delete(Xn),
                      self.history.replaceState(null, "", t.toString()));
                    const o = tr(
                      () => JSON.parse(sessionStorage.getItem(Xn) ?? "null"),
                      null
                    );
                    if (!n && !o) return null;
                    const i = { position: null, height: 216, ...(n ?? o) };
                    if (
                      !(function (e) {
                        return !(
                          !e ||
                          !e.pixel ||
                          "string" != typeof e.pixel.type ||
                          "string" != typeof e.pixel.id ||
                          (e.pixel.name && "string" != typeof e.pixel.name) ||
                          "number" != typeof e.height
                        );
                      })(i)
                    )
                      throw (eo(), new Yn(i));
                    const s = e.find(
                      (e) => e.type === i.pixel.type && e.id === i.pixel.id
                    );
                    if (!s || !Zn.includes(s.type) || s.id.match(/shopify/i))
                      throw (eo(), new Gn(i, i.pixel));
                    return (
                      (i.pixel = {
                        ...i.pixel,
                        name: i.pixel.name || s?.name || "",
                      }),
                      Qn(i),
                      {
                        get pixel() {
                          return i.pixel;
                        },
                        get height() {
                          return i.height;
                        },
                        get position() {
                          return i.position;
                        },
                        setHeight(e) {
                          (i.height = e), Qn(i);
                        },
                        setPosition(e) {
                          (i.position = e), Qn(i);
                        },
                      }
                    );
                  })(r.webPixelsConfigList);
                } catch (e) {
                  wr.notify(e, {
                    context: "createWebPixelsHelper/init/state",
                    unhandled: !1,
                    severity: "warning",
                    options: { sampleRate: 0.1 },
                  }),
                    Br("helperLoad", to(r, "helper-read-error"));
                }
                return null;
              })();
              if (!n) return;
              let o = !1;
              const { shopId: i, surface: s = u.Unknown } = r,
                a = Mr("helperLoad", {
                  version: Gt,
                  pageUrl: self.location.href,
                  surface: s,
                  status: "loaded",
                  bundleTarget: Zt,
                  shopId: i,
                });
              await Fn({
                state: n,
                extensionsBaseUrl: r.extensionsBaseUrl,
                onHelperReady: () => {
                  o || (Lr(a), (o = !0));
                },
              })
                .then((o) => {
                  if (!o) return;
                  t = o;
                  const i = n.pixel;
                  this.message("initializeHelper", {
                    pixelUid: { id: i.id, type: i.type },
                    pixelName: i.name ?? "",
                    config: r,
                    isCollapsed: n.height <= 216,
                    loggerLevel: tr(
                      () =>
                        "true" ===
                        self.localStorage.getItem("pixel-helper-advanced")
                          ? yn.Advanced
                          : yn.Standard,
                      yn.Standard
                    ),
                  }),
                    e.forEach((e) => e()),
                    e.clear();
                })
                .catch((e) => {
                  wr.notify(e, {
                    context: "createWebPixelsHelper/init/createHelperSandbox",
                    unhandled: !1,
                    severity: "warning",
                  }),
                    Br("helperLoad", to(r, "helper-create-error"));
                });
            },
          };
        })();
      let no = (function (e) {
          return (
            (e.WebPixelExtension = "web-pixel-extension"),
            (e.CheckoutOneSdk = "checkout-one-sdk"),
            (e.Unknown = "unknown"),
            e
          );
        })({}),
        oo = (function (e) {
          return (
            (e.Storefront = "storefront"),
            (e.Checkout = "checkout"),
            (e.Unknown = "unknown"),
            e
          );
        })({}),
        io = (function (e) {
          return (e.Custom = "custom"), (e.All = "all"), e;
        })({});
      function so(e) {
        return "shopify-custom-pixel" === e.id
          ? "shopify-pixel"
          : e.type === l.Custom
          ? "-1"
          : e.apiClientId
          ? `${e.apiClientId}`
          : void 0;
      }
      const ao = "[object Undefined]",
        co = "[object Null]",
        uo = ["[object String]", "[object Number]", "[object Boolean]", ao, co],
        lo = (e) =>
          null === e
            ? co
            : void 0 === e
            ? ao
            : Object.prototype.toString.call(e);
      function po(e) {
        let t = null,
          r = null;
        function n(e) {
          return "[object Object]" === lo(e);
        }
        return void 0 === e || n(e)
          ? {
              isValid: (function e(o, i = "root") {
                if (Array.isArray(o))
                  return o.every((t, r) => e(t, `${i}[${r}]`));
                if (n(o))
                  return Object.keys(o).every((t) => e(o[t], `${i}.${t}`));
                const s = lo(o),
                  a = uo.includes(s);
                return (
                  a ||
                    ((r = i),
                    (t = `Value of type "${s}" at "${r}" must be one of the following types: ${uo.join(
                      ", "
                    )}.`)),
                  a
                );
              })(e, "root"),
              error: t,
              errorKey: r,
            }
          : ((r = "root"),
            (t = `Value of type "${lo(e)}" at "${r}" must be an object.`),
            { isValid: !1, error: t, errorKey: r });
      }
      const fo = cr(
          (e) => {
            if (!e) return 0;
            let t = 5381;
            for (let r = 0; r < e.length; r++)
              t = (t << 5) + t + e.charCodeAt(r);
            return Math.abs(t);
          },
          { cacheKey: (e) => e }
        ),
        ho = [
          "page_viewed",
          "product_viewed",
          "collection_viewed",
          "cart_viewed",
          "clicked",
          "form_submitted",
          "input_blurred",
          "input_focused",
          "input_changed",
          "advanced_dom_clicked",
          "advanced_dom_scrolled",
          "advanced_dom_window_resized",
        ];
      function mo(e, t, r) {
        try {
          if (!ho.includes(e.name)) return;
          const n = pn("_shopify_s") || "";
          (function (e, t) {
            if (!t) return !1;
            return (fo(t.toLowerCase()) % 100) + 1 <= 1;
          })(0, n) &&
            Br("buyerEventSample", {
              shopId: t,
              eventType: e.type,
              eventName: e.name,
              surface: r,
              eventPayloadJson: JSON.stringify(e),
              sessionToken: n,
            });
        } catch (n) {
          wr.notify(n, {
            severity: "warning",
            unhandled: !1,
            context: "logBuyerEvent",
            options: { sampleRate: 20 },
          });
        }
      }
      const vo = new Set([
        "innerHeight",
        "innerWidth",
        "scrollX",
        "scrollY",
        "pageXOffset",
        "pageYOffset",
      ]);
      let go = {},
        bo = !1,
        yo = !0;
      function wo() {
        (go.innerHeight = tr(() => window.innerHeight, 0)),
          (go.innerWidth = tr(() => window.innerWidth, 0));
        const e = tr(() => window.scrollX, 0),
          t = tr(() => window.scrollY, 0);
        (go.scrollX = e),
          (go.pageXOffset = e),
          (go.scrollY = t),
          (go.pageYOffset = t),
          (yo = !1);
      }
      function _o() {
        yo = !0;
      }
      const xo = new Proxy(window, {
        get: (e, t) => (
          bo ||
            ((bo = !0),
            wo(),
            window.addEventListener("resize", _o, { passive: !0 }),
            window.addEventListener("scroll", _o, { passive: !0 }),
            window.addEventListener("orientationchange", _o, { passive: !0 })),
          vo.has(t) ? (yo && wo(), go[t]) : tr(() => Reflect.get(e, t))
        ),
      });
      function ko() {
        const e = xo.location,
          t = xo.screen,
          r = {
            href: tr(() => e?.href) ?? "",
            hash: tr(() => e?.hash) ?? "",
            host: tr(() => e?.host) ?? "",
            hostname: tr(() => e?.hostname) ?? "",
            origin: tr(() => e?.origin) ?? "",
            pathname: tr(() => e?.pathname) ?? "",
            port: tr(() => e?.port) ?? "",
            protocol: tr(() => e?.protocol) ?? "",
            search: tr(() => e?.search) ?? "",
          };
        return {
          document: {
            location: r,
            referrer: tr(() => document?.referrer) ?? "",
            characterSet: tr(() => document?.characterSet) ?? "",
            title: tr(() => document?.title) ?? "",
          },
          navigator: {
            language: tr(() => navigator?.language) ?? "",
            cookieEnabled: tr(() => navigator?.cookieEnabled) ?? !1,
            languages: tr(() => navigator?.languages) ?? [],
            userAgent: tr(() => navigator?.userAgent) ?? "",
          },
          window: {
            innerHeight: xo.innerHeight ?? 0,
            innerWidth: xo.innerWidth ?? 0,
            outerHeight: xo.outerHeight ?? 0,
            outerWidth: xo.outerWidth ?? 0,
            pageXOffset: xo.pageXOffset ?? 0,
            pageYOffset: xo.pageYOffset ?? 0,
            location: r,
            origin: xo.origin ?? "",
            screen: {
              height: tr(() => t?.height) ?? 0,
              width: tr(() => t?.width) ?? 0,
            },
            screenX: xo.screenX ?? 0,
            screenY: xo.screenY ?? 0,
            scrollX: xo.scrollX ?? 0,
            scrollY: xo.scrollY ?? 0,
          },
        };
      }
      const Eo = new Map(),
        So = (e) => {
          const t = (Eo.get(e) ?? 0) + 1;
          return Eo.set(e, t), t;
        },
        Ao = (e) => ({
          ...e,
          get clientId() {
            return mn();
          },
          timestamp: new Date().toISOString(),
          context: ko(),
          id: "string" == typeof e.id && e.id.length > 0 ? e.id : ft(),
          seq: So(e.name),
        });
      function Io(e, t, r = {}) {
        const o = (function (e, t, r) {
          if ("checkout_completed" === e && r.eventId) return r.eventId;
          const n = { analyticsFramework: "wpm" };
          try {
            return (
              "product_added_to_cart" === e &&
                "cartLine" in t &&
                (n.cacheKey = (function ({ cartLine: e } = { cartLine: null }) {
                  const t = e?.merchandise.product.id,
                    r = e?.merchandise.id;
                  if (t && r) return `${t}-${r}`;
                })(t)),
              window.Shopify?.evids?.(e, n)
            );
          } catch {
            return;
          }
        })(e, t, r);
        return Ao({ id: o, name: e, data: t, type: n(e) });
      }
      function Po(t, r = null) {
        return Ao({ name: t, customData: r, type: e.Custom });
      }
      r(2341);
      const Co = "wpmLoggedConversion1",
        Oo = ["thank_you", "thank-you", "post_purchase", "post-purchase"];
      class To extends c {
        constructor(e) {
          super(
            `Duplicate conversion event blocked for checkout token: "${e}"`
          ),
            (this.name = "ExcludedConversionError");
        }
      }
      class No extends c {
        constructor() {
          super("Checkout token unavailable from payload"),
            (this.name = "MissingCheckoutTokenError");
        }
      }
      class jo extends c {
        constructor() {
          super("Failed to extract valid checkout token from pathname"),
            (this.name = "MissingPathnameCheckoutTokenError");
        }
      }
      function Ro(e) {
        const t = {},
          r = new Date().getTime();
        for (const [n, o] of Object.entries(e))
          if ("number" == typeof o) {
            const e = new Date(o);
            e.setMonth(e.getMonth() + 2), r < e.getTime() && (t[n] = o);
          }
        return t;
      }
      const $o =
          /^\/checkouts\/([^/]+)\/([^/]+)(?:\/((?:[a-z]{2,3}|zh-hans|zh-hant)(?:-[a-zA-Z0-9]+)?))?(?:\/([^/]+))\/?$/,
        Do = (e, t, r, n, o) => {
          const { pixelRuntimeConfig: i } = o || {},
            { apiClientId: s, restrictions: a } = i || {},
            { allowedEvents: c, disallowedEvents: u } = a || {},
            { sendTo: l } = n || {},
            d = l && String(l) === String(s),
            p = l && !d,
            f = !c || c.includes(t),
            h = u && u.includes(t);
          Boolean((f && !h && !p) || d) && e();
        },
        Mo = (e, t, r, n, o) => {
          if (!a(t)) return void e();
          const { pixelRuntimeConfig: i } = o || {},
            { capabilities: s, type: c } = i || {},
            u = s?.includes(p.AdvancedDomEvents);
          u && c === l.App && e();
        };
      class Uo extends c {
        constructor(e) {
          super(
            `Circular reference detected at "${e}" while applying protected customer data filtering. Event payload contains cyclic structures which are not supported.`
          ),
            (this.name = "ProtectedCustomerDataTransformError");
        }
      }
      function Lo(e, t, r) {
        if ("function" == typeof t) {
          const n = t(e, r.context);
          return r.onTransformed?.(e, n, r.path), n;
        }
        if (null == t || "object" != typeof t)
          return r.onTransformed?.(e, t, r.path), t;
        if (null == e) return r.onTransformed?.(e, e, r.path), e;
        if ("object" != typeof e) return r.onTransformed?.(e, e, r.path), e;
        if (r.ancestors.has(e)) throw new Uo(r.path);
        const n = (function (e, t, r) {
          return e.get(t)?.get(r);
        })(r.cache, e, t);
        if (void 0 !== n) return n;
        let o;
        return (
          r.ancestors.add(e),
          (o = Array.isArray(e)
            ? (function (e, t, r) {
                let n = e;
                for (let o = 0; o < e.length; o++) {
                  const i = e[o],
                    s = Lo(i, t, { ...r, path: `${r.path}[${o}]` });
                  s !== i && (n === e && (n = e.slice()), (n[o] = s));
                }
                return n;
              })(e, t, r)
            : (function (e, t, r) {
                const n = Object.keys(t);
                if (0 === n.length) return e;
                let o = e;
                for (const i of n)
                  if (i in e) {
                    const n = e[i],
                      s = Lo(n, t[i], { ...r, path: `${r.path}.${i}` });
                    s !== n && (o === e && (o = { ...e }), (o[i] = s));
                  }
                return o;
              })(e, t, r)),
          r.ancestors.delete(e),
          (function (e, t, r, n) {
            let o = e.get(t);
            o || ((o = new WeakMap()), e.set(t, o)), o.set(r, n);
          })(r.cache, e, t, o),
          o
        );
      }
      const Bo = cr(
          (e) => {
            const t = e?.protectedCustomerApprovalScopes ?? [];
            return {
              protectedCustomerApprovalScopes: {
                read_customer_address: t.includes("read_customer_address"),
                read_customer_email: t.includes("read_customer_email"),
                read_customer_name: t.includes("read_customer_name"),
                read_customer_personal_data: t.includes(
                  "read_customer_personal_data"
                ),
                read_customer_phone: t.includes("read_customer_phone"),
              },
            };
          },
          { cache: new WeakMap(), cacheKey: (e) => e }
        ),
        zo = (e, t, r, n) => {
          if (!r?.protectedCustomerApprovalScopes) return e;
          const o = { adjustmentsTriggers: 0, adjustmentsApplied: 0 },
            i = (function (e, t, r) {
              return Lo(e, t, {
                context: r,
                ancestors: new WeakSet(),
                cache: new WeakMap(),
                path: "$",
                onTransformed: (e, t, r) => {
                  o.adjustmentsTriggers++, e !== t && o.adjustmentsApplied++;
                },
              });
            })(e, t, Bo(r));
          return n?.(o), i;
        },
        qo = (e) => (t, r) => r.protectedCustomerApprovalScopes[e] ? t : null,
        Ho = {
          data: {
            checkout: {
              email: qo("read_customer_email"),
              phone: qo("read_customer_phone"),
              smsMarketingPhone: qo("read_customer_phone"),
              billingAddress: {
                firstName: qo("read_customer_name"),
                lastName: qo("read_customer_name"),
                phone: qo("read_customer_phone"),
                address1: qo("read_customer_address"),
                address2: qo("read_customer_address"),
                zip: qo("read_customer_address"),
              },
              shippingAddress: {
                firstName: qo("read_customer_name"),
                lastName: qo("read_customer_name"),
                phone: qo("read_customer_phone"),
                address1: qo("read_customer_address"),
                address2: qo("read_customer_address"),
                zip: qo("read_customer_address"),
              },
            },
          },
        },
        Vo = {
          checkout_address_info_submitted: Ho,
          checkout_completed: Ho,
          checkout_contact_info_submitted: Ho,
          checkout_shipping_info_submitted: Ho,
          checkout_started: Ho,
          payment_info_submitted: Ho,
        };
      class Wo extends c {
        constructor(e, t) {
          super(
            `Failed to apply protected customer data filtering for event: ${e}. ${t.message}`
          ),
            (this.name = "ProtectedCustomerDataError");
        }
      }
      const Fo = ["share_all_events"],
        Ko = (e) => (t, r, n, o, i) => {
          const s = i?.pixelRuntimeConfig;
          if (!s) return void t();
          const { dataSharingAdjustments: a, dataSharingState: c } = s;
          if (((u = s), Boolean(u.enabledFlags?.includes("9a3ed68a"))))
            return void t();
          var u;
          const { dataSharingControls: l } = a ?? {};
          ((e, t) =>
            Boolean(t) &&
            "unrestricted" !== t &&
            !1 === e?.includes("share_all_events"))(l, c)
            ? (function (e) {
                return e?.filter((e) => !Fo.includes(e)) ?? [];
              })(l).length > 0
              ? t()
              : e.emit("log:event-bus:publish:blocked", {
                  pixel: s,
                  event: { name: r, id: n.id },
                })
            : t();
        },
        Jo = "all_standard_events",
        Xo = "all_custom_events",
        Yo = "all_dom_events";
      class Go extends c {
        constructor(e, t = "PublishEventError") {
          super(e, { groupingHash: `EventBus:${t}` }), (this.name = t);
        }
      }
      function Zo(t) {
        const { shopId: r, surface: c, emit: l } = t,
          d = (({ logError: e }) =>
            function (t, r) {
              if ("checkout_completed" !== t) return !1;
              let n = r && "checkout" in r ? r?.checkout?.token : null;
              if (
                ((n && "string" == typeof n) ||
                  (e(new No(), {
                    severity: "info",
                    unhandled: !1,
                    context: "isExcludedDuplicateConversion",
                  }),
                  (n = (function () {
                    try {
                      const e = new URL(window.location.href),
                        t = $o.exec(e.pathname);
                      if (!t) return null;
                      const [, r, n, o, i] = t;
                      return n ?? null;
                    } catch (e) {
                      return null;
                    }
                  })())),
                !n || "string" != typeof n)
              )
                return (
                  e(new jo(), {
                    severity: "info",
                    unhandled: !1,
                    context: "isExcludedDuplicateConversion",
                  }),
                  !1
                );
              if (
                !(function () {
                  try {
                    const e = new URL(window.location.href).pathname
                      .split("/")
                      .filter(Boolean);
                    return (
                      e.includes("checkouts") && e.some((e) => Oo.includes(e))
                    );
                  } catch (e) {
                    return !1;
                  }
                })()
              )
                return !1;
              const o = (function () {
                try {
                  const e = localStorage.getItem(Co);
                  if (!e) return {};
                  const t = JSON.parse(e);
                  return "object" != typeof t || null === t ? {} : Ro(t);
                } catch (e) {
                  return {};
                }
              })();
              return n in o
                ? (e(new To(n), {
                    severity: "info",
                    unhandled: !1,
                    context: "isExcludedDuplicateConversion",
                  }),
                  !0)
                : ((function (e, t) {
                    (t[e] = new Date().getTime()),
                      (function (e) {
                        try {
                          const t = Ro(e);
                          localStorage.setItem(Co, JSON.stringify(t));
                        } catch (t) {}
                      })(t);
                  })(n, o),
                  !1);
            })(t),
          p = new bn({
            bufferSize: Number.POSITIVE_INFINITY,
            subscribeAllKey: Jo,
          }).use(
            Do,
            Ko(t),
            ((e) => (t, r, n, o, i) => {
              const s = i?.pixelRuntimeConfig,
                { dataSharingAdjustments: a } = s || {},
                c = Vo[r] ?? null;
              if (c)
                try {
                  t(
                    zo(n, c, a, (t) => {
                      s &&
                        e.emit("log:event-bus:publish:transformed", {
                          pixel: s,
                          event: n,
                          adjustmentsTriggers: t.adjustmentsTriggers,
                          adjustmentsApplied: t.adjustmentsApplied,
                        });
                    })
                  );
                } catch (u) {
                  e.logError(
                    new Wo(r, u instanceof Error ? u : new Error(String(u))),
                    {
                      context: "eventBus/middleware/protected-customer-data",
                      unhandled: !1,
                      severity: "error",
                      pixelId: s?.id,
                    }
                  );
                }
              else t();
            })(t)
          ),
          f = new bn({ bufferSize: 1e3, subscribeAllKey: Xo }).use(Do, Ko(t)),
          h = new bn({
            bufferSize: 1e3,
            replayKeep: "newest",
            subscribeAllKey: Yo,
          }).use(Do),
          m = new bn({ bufferSize: 1e3, replayKeep: "newest" }).use(Do, Mo);
        return {
          publish(t, v, g) {
            if (!nt(ot) && c !== u.CustomerAccount)
              return (function (e, t, n) {
                if ("string" != typeof e)
                  throw new Go(
                    "Expected event name to be a string, but got " + typeof e,
                    "LegacyPublishStandardEventError"
                  );
                if (!o(e)) return !1;
                const i = po(t);
                if (!i.isValid) return console.error(i.error), !1;
                const s = Io(e, t, n),
                  a = s.data?.checkout?.token;
                return (
                  mo(s, r, c),
                  Br("eventPublish", {
                    version: Gt,
                    bundleTarget: Zt,
                    pageUrl: self.location.href,
                    shopId: r,
                    surface: c,
                    eventName: s.name,
                    eventType: s.type,
                    extensionId: n?.extension?.extensionId,
                    extensionAppId: n?.extension?.appId,
                    extensionType: n?.extension?.type,
                    userCanBeTracked: ze().toString(),
                    eventId: s.id,
                    checkoutToken: a,
                    checkoutCompletedPageType: n?.checkoutCompletedPageType,
                  }),
                  l("log:event-bus:publish", { event: s, options: n }),
                  !d(e, s.data) && p.publish(s.name, s)
                );
              })(t, v, g);
            if ("string" != typeof t) {
              const e = JSON.stringify(t);
              throw new Go(
                `Expected event name "${e}" to be a string, but got ${typeof t}`,
                "PublishEventError"
              );
            }
            if (n(t) === e.Meta) return !1;
            const b = po(v);
            if (!b.isValid) {
              if (s(t) || a(t)) {
                const e = new Go(
                  `Input Validation Error for event ${t}: ${
                    b.error
                  }\nPayload: ${JSON.stringify(v)}`,
                  "PublishAdvancedDomEventError"
                );
                return (
                  wr.notify(e, {
                    type: "metric",
                    context: "publish/invalidPayload",
                  }),
                  !1
                );
              }
              return console.error(b.error), !1;
            }
            let y;
            if (((y = i(t) ? Po(t, v) : Io(t, v, g)), i(t) || o(t))) {
              let e = {
                version: Gt,
                bundleTarget: Zt,
                pageUrl: self.location.href,
                shopId: r,
                surface: c,
                eventName: y.name,
                eventType: y.type,
                extensionId: g?.extension?.extensionId,
                extensionAppId: g?.extension?.appId,
                extensionType: g?.extension?.type,
                eventId: y.id,
              };
              if (o(t)) {
                const t = y.data?.checkout?.token;
                mo(y, r, c),
                  (e = {
                    ...e,
                    userCanBeTracked: ze().toString(),
                    checkoutToken: t,
                    checkoutCompletedPageType: g?.checkoutCompletedPageType,
                  });
              }
              Br("eventPublish", e);
            } else mo(y, r, c);
            return (
              l("log:event-bus:publish", { event: y, options: g }),
              !d(t, y.data) &&
                (o(t)
                  ? p.publish(t, y)
                  : s(t)
                  ? h.publish(t, y)
                  : a(t)
                  ? m.publish(t, y)
                  : f.publish(t, y, g))
            );
          },
          publishCustomEvent(e, t, n) {
            if (nt(ot)) return this.publish(e, t, n);
            if ("string" != typeof e)
              throw new Go(
                "Expected event name to be a string, but got " + typeof e,
                "PublishCustomEventError"
              );
            if (!i(e)) return !1;
            const o = po(t);
            if (!o.isValid) return console.error(o.error), !1;
            const s = Po(e, t);
            return (
              Br("eventPublish", {
                version: Gt,
                bundleTarget: Zt,
                pageUrl: self.location.href,
                shopId: r,
                surface: c,
                eventName: s.name,
                eventType: "custom",
                extensionId: n?.extension?.extensionId,
                extensionAppId: n?.extension?.appId,
                extensionType: n?.extension?.type,
                eventId: s.id,
              }),
              f.publish(e, s, n)
            );
          },
          publishDomEvent(e, t, n) {
            if (nt(ot)) return this.publish(e, t, n);
            if ("string" != typeof e) {
              const t = JSON.stringify(e);
              throw new Go(
                `Expected event name "${t}" to be a string, but got ${typeof e}`,
                "PublishDomEventError"
              );
            }
            if (!s(e) && !a(e))
              throw new Go(
                `Event name "${e}" is not a supported DOM Event`,
                "PublishDomEventError"
              );
            const o = po(t);
            if (!o.isValid) {
              const t = new Go(
                `Input Validation Error for event ${e}: ${o.error}`,
                "PublishDomEventError"
              );
              return (
                wr.notify(t, {
                  type: "metric",
                  context: "publishDomEvent/invalidPayload",
                }),
                !1
              );
            }
            const i = Io(e, t, n);
            return mo(i, r, c), a(e) ? m.publish(e, i) : h.publish(e, i);
          },
          subscribe(t, r, i = {}) {
            const l = ft(),
              d = async (s) => {
                if (c === u.CheckoutOneSdk && i.scope !== no.CheckoutOneSdk)
                  return;
                await bt();
                const a = {
                    configuration: i.pixelRuntimeConfig?.configuration,
                    eventPayloadVersion:
                      i.schemaVersion ||
                      i.pixelRuntimeConfig?.eventPayloadVersion ||
                      "unknown",
                    id: i.pixelRuntimeConfig?.id || "unknown",
                    type: i.pixelRuntimeConfig?.type || "unknown",
                    runtimeContext:
                      i.pixelRuntimeConfig?.runtimeContext || "unknown",
                    restrictions: i.pixelRuntimeConfig?.restrictions,
                    scriptVersion:
                      i.pixelRuntimeConfig?.scriptVersion || "unknown",
                    apiClientId: i.pixelRuntimeConfig?.apiClientId,
                    name: i.pixelRuntimeConfig?.name,
                  },
                  d = {
                    pixelUid: { id: a.id, type: a.type },
                    event: s,
                    eventNameAsSubscribed: t,
                    subscriptionId: l,
                    status: "SUCCESS",
                  };
                let p;
                try {
                  await r.call(s, s), ro.message("logEvent", d);
                } catch (g) {
                  (p = g),
                    ro.message("logEvent", { ...d, status: "FAIL", error: p });
                }
                const f = n(s.name),
                  h = {
                    version: Gt,
                    bundleTarget: Zt,
                    pageUrl: self.location.href,
                    shopId: i.shopId,
                    surface: i.surface,
                    pixelName: a.name,
                    pixelId: a.id,
                    pixelAppId: so(a),
                    pixelSource: a.type,
                    pixelRuntimeContext: a.runtimeContext,
                    pixelScriptVersion: a.scriptVersion,
                    pixelConfiguration: a.configuration,
                    pixelEventSchemaVersion: a.eventPayloadVersion,
                    eventName: s.name,
                    eventId: s.id,
                  },
                  m = p ? "FAILURE" : "SUCCESS",
                  v = p ? String(p) : void 0;
                if ([e.Dom, e.AdvancedDom].includes(f))
                  or(1) &&
                    Br("subscriberEventEmitDom", {
                      ...h,
                      status: m,
                      errorMessage: v,
                    });
                else {
                  let e;
                  o(s.name) && (e = s?.data?.checkout?.token),
                    Br("subscriberEventEmit", {
                      ...h,
                      eventType: f,
                      checkoutToken: e || void 0,
                      status: m,
                      errorMessage: v,
                    });
                }
              };
            if (a(t)) return m.subscribe(t, d, i);
            if ("all_events" === t) {
              const e = p.subscribe(Jo, d, i),
                t = f.subscribe(Xo, d, i),
                r = h.subscribe(Yo, d, i);
              return () => {
                const n = e(),
                  o = t(),
                  i = r();
                return n && o && i;
              };
            }
            return t === Xo
              ? f.subscribe(Xo, d, i)
              : t === Jo || o(t)
              ? p.subscribe(t, d, i)
              : t === Yo || s(t)
              ? h.subscribe(t, d, i)
              : f.subscribe(t, d, i);
          },
        };
      }
      const Qo = ["31014027265", "28638674945", "44186959873"],
        ei = {
          customer: {
            email: qo("read_customer_email"),
            firstName: qo("read_customer_name"),
            lastName: qo("read_customer_name"),
            phone: qo("read_customer_phone"),
          },
        };
      class ti extends c {
        constructor(e) {
          super(
            `Failed to apply protected customer data filtering to init data. ${e.message}`
          ),
            (this.name = "ProtectedCustomerDataInitError");
        }
      }
      function ri(e, t, r) {
        const n = {
          context: ko(),
          data: {
            customer:
              ((s = t.customer),
              s
                ? {
                    email: s.email,
                    firstName: s.firstName,
                    id: s.id,
                    lastName: s.lastName,
                    phone: s.phone,
                    ordersCount: s.ordersCount,
                  }
                : null),
            cart:
              ((i = t.cart),
              i
                ? {
                    id: i?.id,
                    cost: {
                      totalAmount: {
                        amount: i?.cost?.totalAmount?.amount,
                        currencyCode: i?.cost?.totalAmount?.currencyCode,
                      },
                    },
                    lines: i?.lines,
                    totalQuantity: i?.totalQuantity,
                    attributes: i?.attributes,
                  }
                : null),
            shop: t.shop,
            purchasingCompany:
              ((o = t.purchasingCompany),
              o ? { company: o.company, location: o.location } : null),
          },
          customerPrivacy: {
            analyticsProcessingAllowed: He(),
            marketingAllowed: qe(),
            preferencesProcessingAllowed: Ve(),
            saleOfDataAllowed: We(),
          },
        };
        var o, i, s;
        const a = (function (e, t, r) {
          const { dataSharingAdjustments: n } = r;
          try {
            return zo(t, ei, n, (t) => {
              e.emit("log:pixel:init:transformed", { pixel: r, ...t });
            });
          } catch (o) {
            return (
              wr.notify(new ti(o instanceof Error ? o : new Error(String(o))), {
                context: "createRegisterInit/filterProtectedCustomerData",
                unhandled: !1,
                severity: "error",
                pixelId: r.id,
              }),
              {
                ...t,
                customer: t.customer
                  ? {
                      ...t.customer,
                      email: null,
                      firstName: null,
                      lastName: null,
                      phone: null,
                    }
                  : null,
              }
            );
          }
        })(e, n.data, r);
        return { ...n, data: a };
      }
      const ni = new Set();
      function oi(e) {
        ni.add(e);
      }
      function ii(
        e,
        {
          eventBus: t,
          customerPrivacyEventBus: r,
          webPixelConfig: n,
          initData: o,
          forRPC: i = !1,
        }
      ) {
        const { shopId: s, surface: a } = e;
        let c = {};
        try {
          c = n.configuration ? JSON.parse(n.configuration) : {};
        } catch (d) {}
        const l = (function (e) {
          return e === u.Shopify ||
            e === u.CheckoutOne ||
            e === u.CheckoutOneSdk ||
            e === u.CheckoutOneShopApp
            ? oo.Checkout
            : e === u.StorefrontRenderer
            ? oo.Storefront
            : oo.Unknown;
        })(a);
        return {
          analytics: {
            subscribe(e, r, o) {
              i && In(r);
              const c = t.subscribe(e, r, {
                ...o,
                pixelRuntimeConfig: n,
                shopId: s,
                surface: a,
                scope: no.WebPixelExtension,
              });
              return (
                oi(() => {
                  c(), i && tr(() => Cn(r));
                }),
                c
              );
            },
          },
          browser: {
            cookie: {
              get: async (e) => (e ? pn(e) ?? "" : ln() ?? ""),
              set: async (e, t) => {
                if (t) {
                  const r = `${e}=${t}`;
                  document.cookie = r;
                } else document.cookie = e;
                return ln() ?? "";
              },
            },
            sendBeacon: async (e, t = "") => {
              if (
                e.includes(self.location.origin) &&
                !e.match(
                  /\/\.well-known\/shopify\/monorail\/unstable\/produce_batch/
                )
              )
                return !1;
              const r = new window.Blob([t], { type: "text/plain" });
              return tr(() => window.navigator.sendBeacon(e, r), !1);
            },
            localStorage: {
              setItem: async (e, t) => {
                tr(() => window.localStorage.setItem(e, t));
              },
              getItem: async (e) =>
                tr(() => window.localStorage.getItem(e), null),
              key: async (e) => tr(() => window.localStorage.key(e), null),
              removeItem: async (e) => {
                tr(() => window.localStorage.removeItem(e));
              },
              clear: async () => {
                tr(() => window.localStorage.clear());
              },
              length: async () => tr(() => window.localStorage.length, 0),
            },
            sessionStorage: {
              setItem: async (e, t) => {
                tr(() => window.sessionStorage.setItem(e, t));
              },
              getItem: async (e) =>
                tr(() => window.sessionStorage.getItem(e), null),
              key: async (e) => tr(() => window.sessionStorage.key(e), null),
              removeItem: async (e) => {
                tr(() => window.sessionStorage.removeItem(e));
              },
              clear: async () => {
                tr(() => window.sessionStorage.clear());
              },
              length: async () => tr(() => window.sessionStorage.length, 0),
            },
          },
          settings: c,
          init: ri(e, o, n),
          _pixelInfo: { ...n, surface: a, surfaceNext: l },
          customerPrivacy: {
            subscribe(e, t, o) {
              i && In(t);
              const c = r.subscribe(e, t, {
                ...o,
                pixelRuntimeConfig: n,
                shopId: s,
                surface: a,
                scope: no.WebPixelExtension,
              });
              return (
                oi(() => {
                  c(), i && tr(() => Cn(t));
                }),
                c
              );
            },
          },
        };
      }
      window.addEventListener(
        "pagehide",
        ({ persisted: e }) => {
          e ||
            (ni.forEach((e) => {
              tr(e);
            }),
            ni.clear());
        },
        { capture: !0 }
      );
      class si extends Error {
        constructor(e, t) {
          super(e),
            (this.url = void 0),
            (this.name = "WebWorkerTopLevelError"),
            (this.url = t);
        }
      }
      let ai;
      class ci extends Error {
        constructor(...e) {
          super(...e),
            (this.name = "SandboxAlreadyCreatedError"),
            (this.message = "Sandbox already created.");
        }
      }
      class ui extends Error {
        constructor(e, t) {
          super(e), (this.name = "PixelInitializationError"), (this.stack = t);
        }
      }
      class li extends c {
        constructor(...e) {
          super(...e),
            (this.name = "InvalidExtensionPointError"),
            (this.message = "Invalid Extension Point");
        }
      }
      const di = new Map();
      async function pi(e, t) {
        let r = !1,
          n = null;
        const { webPixelConfig: o, eventBus: i } = t,
          { shopId: s, surface: a } = e,
          l = o.id,
          p = o.type.toLowerCase(),
          f = Cr.WebPixels;
        var h, m;
        switch (
          (o.restrictions ||
            (o.restrictions = (function (e, t) {
              const r = {};
              return (
                Qo.includes(String(e)) &&
                  ((r.allowedEvents = []),
                  t !== u.StorefrontRenderer &&
                    (r.preventLoadingBeforeEvent = `shopify:app:pixels:load:${e}`)),
                r
              );
            })(String(o.apiClientId), a)),
          await Promise.all([
            (async () => {
              await Pr(
                (function (e) {
                  if (e)
                    return Ar.reduce(
                      (t, r) => ((t[r] = e.includes(r.toUpperCase())), t),
                      {}
                    );
                })(o.privacyPurposes)
              ),
                ro.message("logConsentGranted", {
                  pixelUid: { id: l, type: o.type },
                });
            })(),
            ((h = (e, t) =>
              i.subscribe(e, t, {
                pixelRuntimeConfig: { apiClientId: "PIXEL-LOADER" },
              })),
            (m = o.restrictions?.preventLoadingBeforeEvent),
            new Promise((e, t) => {
              void 0 === m
                ? e(!0)
                : h(m, () => {
                    e(!0);
                  });
            })),
          ]),
          jr("pixel:register", "start", { pixelId: l, source: p }),
          o.runtimeContext)
        ) {
          case d.Lax:
          case d.Strict:
            try {
              r = await (async function (
                e,
                {
                  webPixelConfig: t,
                  eventBus: r,
                  customerPrivacyEventBus: n,
                  initData: o,
                  cookieRestrictedDomains: i,
                  pixelPath: s,
                }
              ) {
                const { shopId: a, storefrontBaseUrl: u } = e,
                  l = `web-pixel-sandbox-${t.type}-${t.id}-${t.runtimeContext}-${Qt}`;
                if (t.runtimeContext === d.Lax && document.getElementById(l)) {
                  const e = new ci();
                  throw (
                    (wr.notify(e, {
                      type: "metric",
                      pixelId: t.id,
                      pixelType: t.type,
                      runtimeContext: t.runtimeContext,
                      shopId: a,
                      context: "createWebPixelSandbox/alreadyCreatedError",
                      userAgent: self.navigator.userAgent,
                      hashVersionSandbox: Qt,
                      sandboxUrl: self.location.href || "unknown",
                      options: { sampleRate: 15 },
                    }),
                    e)
                  );
                }
                let p, f;
                switch (t.runtimeContext) {
                  case d.Strict:
                    [p, f] = await (async function ({
                      sandboxId: e,
                      webPixelConfig: t,
                      storefrontBaseUrl: r,
                      pixelPath: n = Cr.Wpm,
                    }) {
                      const o = t.id,
                        i = [
                          rn(r),
                          `/${n}`,
                          `@${Qt}`,
                          `/web-pixel-${o}`,
                          `@${t.scriptVersion}`,
                          "/sandbox",
                          `/worker.${Zt}.js`,
                        ].join(""),
                        s = new Worker(i, {
                          name: e,
                          type: "classic",
                          credentials: "omit",
                        }),
                        a = new Promise((e, t) => {
                          const r = (e) => {
                            s.removeEventListener("error", r),
                              t(
                                e?.filename && e?.lineno && e?.message
                                  ? new si(e.message, i)
                                  : new c(
                                      `Failed to load web worker for pixel ${o} with url ${i}}`,
                                      {
                                        groupingHash:
                                          "WebPixelCreateWebWorkerSandbox:WebWorkerLoadError",
                                      }
                                    )
                              );
                          };
                          s.addEventListener("error", r);
                        });
                      return [s, a];
                    })({
                      sandboxId: l,
                      webPixelConfig: t,
                      storefrontBaseUrl: u,
                      pixelPath: s,
                    });
                    break;
                  case d.Lax:
                    [p, f] = await (async function ({
                      sandboxId: e,
                      webPixelConfig: t,
                      storefrontBaseUrl: r,
                      pixelPath: n = Cr.Wpm,
                    }) {
                      const { search: o } = self.location,
                        i = t.id,
                        s = t.type.toLowerCase(),
                        a = [
                          rn(r),
                          `/${n}`,
                          `@${Qt}`,
                          `/${s}`,
                          `/web-pixel-${i}`,
                          `@${t.scriptVersion}`,
                          "/sandbox",
                          `/${Zt}`,
                          /\.(js|json|xml)$/.test(self.location.pathname)
                            ? ""
                            : self.location.pathname,
                          o,
                        ].join(""),
                        { iframe: u } = await Wn({
                          containerSpec: {
                            id: "web-pixels-manager-sandbox-container",
                            tagName: "div",
                            styles: {
                              height: "0",
                              width: "0",
                              position: "fixed",
                              visibility: "hidden",
                              overflow: "hidden",
                              "z-index": "-100",
                              margin: "0",
                              padding: "0",
                              border: "0",
                            },
                            attributes: { "aria-hidden": "true" },
                            dataset: { shopifyPrivacy: "exclude" },
                          },
                          iframeSpec: {
                            id: e,
                            src: a,
                            privileges: ["allow-scripts", "allow-forms"],
                            styles: {
                              height: "0",
                              width: "0",
                              visibility: "hidden",
                            },
                            attributes: { "aria-hidden": "true" },
                          },
                        }),
                        { promise: l, reject: d } = nr();
                      let p;
                      const f = () => {
                        p = setTimeout(() => {
                          d(
                            new c(
                              `Failed to load iframe for pixel ${i} with url ${a}`,
                              {
                                groupingHash:
                                  "WebPixelCreateIframeSandbox:IframeLoadError",
                              }
                            )
                          );
                        }, 1e3);
                      };
                      u.addEventListener("load", f);
                      const h = _n(u);
                      return (
                        h.addEventListener("message", (e) => {
                          "remote-ui::ready" === e.data &&
                            (clearTimeout(p), u.removeEventListener("load", f));
                        }),
                        [h, l]
                      );
                    })({
                      sandboxId: l,
                      webPixelConfig: t,
                      storefrontBaseUrl: u,
                      pixelPath: s,
                    });
                    break;
                  default:
                    throw new c(
                      `Unsupported runtime context: ${t.runtimeContext}`,
                      {
                        groupingHash:
                          "WebPixelCreateSandbox:UnsupportedRuntimeContext",
                      }
                    );
                }
                const h = $n(p, { callable: ["initialize"] }),
                  m = ii(e, {
                    eventBus: r,
                    customerPrivacyEventBus: n,
                    webPixelConfig: t,
                    initData: o,
                    forRPC: !0,
                  }),
                  v = ko();
                let g = {
                  status: "unknown",
                  hashVersion: "unknown",
                  sandboxUrl: "unknown",
                };
                const b =
                    t.runtimeContext === d.Lax
                      ? (ai ||
                          (ai = {
                            localStorageItems: { ...self.localStorage },
                            sessionStorageItems: { ...self.sessionStorage },
                          }),
                        ai)
                      : { localStorageItems: {}, sessionStorageItems: {} },
                  y = [
                    h.call
                      .initialize({
                        pageTitle: self.document.title,
                        webPixelConfig: t,
                        shopId: a,
                        webPixelApi: m,
                        cookieRestrictedDomains: i,
                        cookie: ln() ?? "",
                        origin: self.origin,
                        referrer: self.document.referrer,
                        ...b,
                      })
                      .then((e) => {
                        g = e;
                      })
                      .catch((e) => {
                        throw new ui(e.toString(), e.stack ?? "");
                      }),
                  ];
                if (
                  (f && y.push(f), await Promise.race(y), Qt !== g.hashVersion)
                ) {
                  const e = new c(
                    `The main bundle hash (${Qt}) does not match the sandbox hash (${g.hashVersion})`,
                    { groupingHash: "WebPixelCreateSandbox:HashMismatch" }
                  );
                  throw (
                    (wr.notify(e, {
                      type: "metric",
                      severity: "warning",
                      pixelId: t.id,
                      pixelType: t.type,
                      runtimeContext: t.runtimeContext,
                      context: "createSandbox/hashMismatch",
                      shopId: a,
                      userAgent:
                        v.navigator.userAgent || self.navigator.userAgent,
                      hashVersionSandbox: g.hashVersion,
                      sandboxUrl: g.sandboxUrl,
                    }),
                    e)
                  );
                }
                return !0;
              })(e, { ...t, pixelPath: f });
            } catch (w) {
              (n = w), (r = !1);
            }
            break;
          case d.Open:
            try {
              r = await (async function (
                e,
                {
                  webPixelConfig: t,
                  eventBus: r,
                  customerPrivacyEventBus: n,
                  initData: o,
                  pixelPath: i = Cr.Wpm,
                }
              ) {
                const { storefrontBaseUrl: s } = e,
                  { promise: a, resolve: u, reject: l } = nr(),
                  { id: d, type: p, integrityHash: f } = t,
                  h = `${d}-${p}`.toLowerCase();
                di.set(h, () => ({
                  webPixelApi: ii(e, {
                    eventBus: r,
                    customerPrivacyEventBus: n,
                    webPixelConfig: t,
                    initData: o,
                    forRPC: !0,
                  }),
                  resolve: u,
                  reject: l,
                }));
                const m = [
                  rn(s),
                  `/${i}@${Qt}`,
                  `/${t.type.toLocaleLowerCase()}`,
                  `/web-pixel-${d}@${t.scriptVersion}`,
                  "~2",
                  `/pixel.${Zt}.js`,
                ].join("");
                if (!self[Xt]) {
                  const e = new c(
                    `${Xt} was not found on the global scope. ${Xt}.createShopifyExtend() was not exposed to the window.`,
                    {
                      groupingHash: "WebPixelOpen:GlobalObjectMissing",
                      severity: "warning",
                    }
                  );
                  return (
                    wr.notify(e, {
                      type: "metric",
                      context: "createWebPixelOpen/globalObjectMissing",
                      severity: "warning",
                      unhandled: !1,
                    }),
                    l(e),
                    a
                  );
                }
                if (!("createShopifyExtend" in self[Xt])) {
                  const e = (e, t) => {
                    let r;
                    try {
                      r = document.currentScript?.dataset || {};
                    } catch (w) {
                      (r = {}),
                        wr.notify(w, {
                          type: "metric",
                          context:
                            "createWebPixel/createWebPixelOpen/createShopifyExtend",
                          unhandled: !1,
                        });
                    }
                    let { pixelId: n, pixelType: o } = r;
                    if (((n && o) || ((n = e), (o = t)), !n || !o))
                      return (
                        l(
                          new c(
                            "No pixelId or pixelType found in script tag or params.",
                            { groupingHash: "WebPixelOpen:NoPixelIdOrType" }
                          )
                        ),
                        null
                      );
                    const i = `${n}-${o}`.toLowerCase(),
                      s = di.get(i);
                    if (!s)
                      return (
                        l(
                          new c(`No openPixelFn found for ${i}.`, {
                            groupingHash: "WebPixelOpen:NoOpenPixelFn",
                          })
                        ),
                        null
                      );
                    const { resolve: a, reject: u, webPixelApi: d } = s();
                    return (
                      d ||
                        u(
                          new c(`No api found for pixel ${i}.`, {
                            groupingHash: "WebPixelOpen:NoApiFound",
                          })
                        ),
                      Object.freeze({
                        extend: (e, t) => {
                          "WebPixel::Render" !== e &&
                            u(
                              new li(`Invalid extension point: ${e}`, {
                                groupingHash:
                                  "WebPixelOpen:InvalidExtensionPoint",
                              })
                            );
                          try {
                            t.call(d, d), a(!0);
                          } catch (w) {
                            u(
                              new c(w, {
                                groupingHash: "WebPixelOpen:PixelCallbackError",
                              })
                            );
                          }
                        },
                      })
                    );
                  };
                  an(self[Xt], "createShopifyExtend", {
                    value: e,
                    enumerable: !1,
                    writable: !1,
                    configurable: !1,
                  });
                }
                var v, g;
                return (
                  await ((v = m),
                  (g = (e) => {
                    (e.dataset.pixelId = d),
                      (e.dataset.pixelType = p),
                      f
                        ? ((e.integrity = f), (e.crossOrigin = "anonymous"))
                        : wr.notify(
                            new c(
                              `Missing integrityHash for SRI-enabled open pixel of type ${p} with id ${d} and src ${m}`,
                              {
                                groupingHash:
                                  "WebPixelOpen:MissingIntegrityHash",
                              }
                            ),
                            {
                              type: "metric",
                              context: "createWebPixelOpen/loadScript",
                              severity: "warning",
                              unhandled: !1,
                            }
                          );
                  }),
                  new Promise((e, t) => {
                    try {
                      const r = document.createElement("script");
                      (r.src = v),
                        (r.async = !0),
                        (r.onload = () => {
                          e();
                        }),
                        (r.onerror = () => {
                          n(),
                            t(
                              new c(`Failed to load script: ${v}`, {
                                groupingHash: "WebPixelOpen:LoadScriptError",
                              })
                            );
                        });
                      const n = () => {
                        (r.onload = null), (r.onerror = null), r.remove();
                      };
                      g && g(r), document.head.appendChild(r);
                    } catch (w) {
                      t(w);
                    }
                  })),
                  a
                );
              })(e, { ...t, pixelPath: f });
            } catch (w) {
              (n = w), (r = !1);
            }
            break;
          default: {
            const e = new c(`Invalid runtimeContext: ${o.runtimeContext}`, {
              groupingHash: "WebPixel:InvalidRuntimeContext",
            });
            throw (
              (ro.message("logPixelRegister", {
                pixelUid: { id: l, type: o.type },
                status: "FAIL",
                errorType: "PixelRegistrationError",
                error: e,
              }),
              e)
            );
          }
        }
        const v = so(o),
          { measurement: g } = Nr("pixel:register", { pixelId: l, source: p });
        n && !r
          ? ro.message("logPixelRegister", {
              pixelUid: { id: l, type: o.type },
              status: "FAIL",
              errorType:
                n instanceof ui
                  ? "PixelInitializationError"
                  : "PixelRegistrationError",
              error: n,
            })
          : r &&
            ro.message("logPixelRegister", {
              pixelUid: { id: l, type: o.type },
              status: "SUCCESS",
            });
        const b = n ? "failed" : "registered",
          y = n ? n.message : void 0;
        return (
          Br("register", {
            version: Gt,
            pageUrl: self.location.href,
            shopId: s,
            surface: a,
            pixelId: l,
            pixelAppId: v,
            pixelSource: o.type,
            pixelRuntimeContext: o.runtimeContext,
            pixelScriptVersion: o.scriptVersion,
            pixelConfiguration: o?.configuration,
            pixelEventSchemaVersion: o.eventPayloadVersion,
            pixelName: o.name,
            status: b,
            userCanBeTracked: ze().toString(),
            bundleTarget: Zt,
            errorMsg: y,
            duration: g?.duration,
            startTime: g?.startTime,
            sessionId: sn(),
          }),
          r
        );
      }
      const fi = new RegExp(
          [
            "password",
            "pass",
            "pw",
            "ssn",
            "sin",
            "social",
            "security",
            "cc",
            "card",
            "creditcard",
            "cvv",
            "cvc",
            "cvn",
            "billing",
            "license",
            "health",
            "secret",
            "unique",
          ]
            .map((e) => `^(.*[^a-z])?${e}([^a-z].*)?$`)
            .join("|"),
          "i"
        ),
        hi = (function (e, { cache: t, cacheKey: r } = {}) {
          if ("function" != typeof queueMicrotask) return e;
          const n = t ?? sr();
          let o = !1;
          const i = cr(e, { cache: n, cacheKey: r });
          return function (...e) {
            return (
              o ||
                (queueMicrotask(() => {
                  n.clear(), (o = !1);
                }),
                (o = !0)),
              i(...e)
            );
          };
        })(
          function (e) {
            return (
              !!Hn(e) &&
              null !==
                e.closest('script, iframe, [data-shopify-privacy="exclude"]')
            );
          },
          { cacheKey: (e) => e }
        ),
        mi = ["id", "name", "type"],
        vi = (e, t) => (
          "value" in t &&
            "string" == typeof t.value &&
            ((e) => {
              if (!Hn(e)) return !1;
              if ("redact" === e.dataset?.shopifyPrivacy) return !0;
              for (const t of mi) {
                const r = e.getAttribute(t);
                if ("string" == typeof r && fi.test(r)) return !0;
              }
              return !1;
            })(e) &&
            (t.value = "******"),
          t
        );
      function gi(e, t, r) {
        if (t in e)
          try {
            const r = e[t],
              n = typeof r;
            if ("string" === n || "number" === n || "boolean" === n) return r;
          } catch (n) {
            wr.notify(n, {
              context:
                "createDomEventsListener/getElementAttributes/getElementAttribute",
              type: "metric",
            });
          }
        return e.getAttribute(t) ?? r;
      }
      function bi(e, t, r) {
        const n = {};
        for (const o of t) {
          const t = gi(e, o, r?.[o]);
          void 0 !== t && (n[o] = t);
        }
        return vi(e, n), n;
      }
      const yi = {
          id: null,
          href: null,
          name: null,
          tagName: null,
          type: null,
          value: null,
        },
        wi = Object.keys(yi);
      function _i(e) {
        return bi(e, wi, yi);
      }
      const xi = [
          "screenX",
          "screenY",
          "pageX",
          "pageY",
          "clientX",
          "clientY",
          "offsetX",
          "offsetY",
          "movementX",
          "movementY",
        ],
        ki = xi.reduce((e, t) => ((e[t] = 0), e), {});
      let Ei = 0,
        Si = new WeakMap();
      function Ai(e) {
        if (!e) return -1;
        let t = Si.get(e);
        return void 0 === t && ((t = Ei++), Si.set(e, t)), t;
      }
      let Ii = new WeakMap();
      const Pi = { parentSerializationId: -1, prevSiblingSerializationId: -1 };
      function Ci(e) {
        if (!e) return Pi;
        let t = Ii.get(e);
        if (void 0 === t) {
          let r = e.previousSibling;
          for (; r && hi(r); ) r = r.previousSibling;
          (t = {
            parentSerializationId: Ai(e.parentNode),
            prevSiblingSerializationId: Ai(r),
          }),
            Oi(e, t);
        }
        return t;
      }
      function Oi(e, t) {
        Ii.set(e, t);
      }
      function Ti(e) {
        Ii.delete(e);
      }
      function Ni(e) {
        const t = e.nodeType;
        if (t === Node.ELEMENT_NODE) {
          const r = e,
            n = {},
            o = r.attributes;
          if (o)
            for (let e = 0; e < o.length; e++) {
              const t = o[e];
              if (t) {
                const e = t.name;
                if (e in r)
                  try {
                    const t = r[e],
                      o = typeof t;
                    if ("string" === o || "number" === o || "boolean" === o) {
                      n[e] = t;
                      continue;
                    }
                  } catch {}
                n[e] = t.value;
              }
            }
          if ("value" in r)
            try {
              const e = r.value,
                t = typeof e;
              ("string" !== t && "number" !== t && "boolean" !== t) ||
                (n.value = e);
            } catch {}
          vi(r, n);
          const i = r.getBoundingClientRect(),
            s = {
              nodeType: t,
              serializationId: Ai(e),
              attributes: n,
              tagName: r.tagName,
              clientRect: { x: i.x, y: i.y, height: i.height, width: i.width },
              scroll: {
                x: r.scrollLeft,
                y: r.scrollTop,
                width: r.scrollWidth,
                height: r.scrollHeight,
              },
            };
          if (
            r instanceof HTMLInputElement &&
            ("checkbox" === r.type || "radio" === r.type)
          ) {
            const e = r.getAttribute("checked");
            null !== e && (n.checked = e), (s.checked = r.checked);
          }
          return s;
        }
        if (t === Node.TEXT_NODE)
          return {
            nodeType: t,
            serializationId: Ai(e),
            textContent: e.textContent ?? "",
          };
        if (t === Node.DOCUMENT_TYPE_NODE) {
          const r = e;
          return {
            nodeType: t,
            serializationId: Ai(e),
            attributes: {
              name: r.name,
              publicId: r.publicId,
              systemId: r.systemId,
            },
          };
        }
        return { nodeType: t, serializationId: Ai(e) };
      }
      function ji(e, t) {
        return { node: Ni(t), ...ki, ...vn(e, xi) };
      }
      const Ri = [
          HTMLInputElement,
          HTMLSelectElement,
          HTMLTextAreaElement,
          HTMLButtonElement,
        ],
        $i = ["id", "name", "tagName", "type", "value"];
      function Di(e) {
        return bi(e, $i);
      }
      const Mi =
          (e, t) =>
          (r, { eventPrefix: n, onError: o }) =>
            It(
              window,
              e,
              (i) => {
                try {
                  const e = i?.target;
                  if (
                    !(
                      e instanceof HTMLInputElement ||
                      e instanceof HTMLSelectElement ||
                      e instanceof HTMLTextAreaElement
                    ) ||
                    hi(e)
                  )
                    return;
                  n ? r(`${n}${t}`, { node: Ni(e) }) : r(t, { element: Di(e) });
                } catch (s) {
                  o?.(s, {
                    context: `createInputListenerFactory/${e}/${t}`,
                    type: "error",
                    unhandled: !1,
                  });
                }
              },
              { onError: o }
            ),
        Ui = Mi("blur", "input_blurred"),
        Li = Mi("focus", "input_focused"),
        Bi = Mi("change", "input_changed"),
        zi = ["action", "id"],
        qi = [
          Ui,
          Bi,
          (e, { eventPrefix: t, onError: r }) =>
            It(
              window,
              "click",
              (r) => {
                const n = r?.target;
                if (!(n instanceof Element) || hi(n)) return;
                const o = t
                  ? ji(r, n)
                  : (function (e, t) {
                      return { element: _i(t), ...ki, ...vn(e, xi) };
                    })(r, n);
                e(`${t ?? ""}clicked`, o);
              },
              { onError: r, throttleDelay: 50 }
            ),
          Li,
          (e, { eventPrefix: t, onError: r }) =>
            It(
              window,
              "submit",
              (r) => {
                const n = r?.target;
                n instanceof HTMLFormElement &&
                  !hi(n) &&
                  (t
                    ? e(`${t}form_submitted`, { node: Ni(n) })
                    : e("form_submitted", {
                        element: {
                          ...bi(n, zi),
                          elements: Array.from(n.elements)
                            .filter(
                              (e) => Ri.some((t) => e instanceof t) && !hi(e)
                            )
                            .map((e) => Di(e)),
                        },
                      }));
              },
              { onError: r }
            ),
        ],
        Hi = (e, t) => {
          const r = qi.map((r) => {
            try {
              return r(e, t);
            } catch (n) {
              return (
                t?.onError?.(n, { context: "createDomEventsListener" }),
                () => {}
              );
            }
          });
          return () => {
            r.forEach((e) => e());
          };
        };
      function Vi(e, t, { onError: r }) {
        return It(
          document,
          e,
          (r) => {
            if (!(r instanceof Event && r.type === e)) return;
            const n = r.target;
            if (!(n instanceof Element) || hi(n)) return;
            const o = Ni(n);
            t("advanced_dom_clipboard", { node: o, action: r.type ?? "copy" });
          },
          { onError: r, throttleDelay: 100 }
        );
      }
      const Wi = (e, t) => {
        const r = [],
          n = e.length;
        for (let o = 0; o < n; o++) {
          const n = e[o];
          n && !hi(n) && r.push(t(n));
        }
        return r;
      };
      function Fi(e) {
        const t = Ai(e),
          r = e.childNodes,
          n = [];
        let o = -1;
        const i = r.length;
        for (let s = 0; s < i; s++) {
          const e = r[s];
          if (!e || hi(e)) continue;
          const i = { parentSerializationId: t, prevSiblingSerializationId: o };
          Oi(e, i), n.push({ node: Ni(e), children: Fi(e), ...i }), (o = Ai(e));
        }
        return n;
      }
      const Ki = (e) => {
          const t = Ci(e);
          return {
            node: Ni(e),
            children: Fi(e),
            parentSerializationId: t.parentSerializationId,
            prevSiblingSerializationId: t.prevSiblingSerializationId,
          };
        },
        Ji = [
          (e, { onError: t }) => {
            let r = null;
            return It(
              window,
              "mousemove",
              (t) => {
                if (!(t instanceof MouseEvent)) return;
                const n = t?.target;
                if (!(n instanceof Element) || hi(n)) return;
                const o = ji(t, n);
                (o.movementX = r ? t.screenX - r.screenX : 0),
                  (o.movementY = r ? t.screenY - r.screenY : 0),
                  e("advanced_dom_mouse_moved", o),
                  (r = t);
              },
              { onError: t, throttleDelay: 50 }
            );
          },
          (e, { onError: t }) =>
            It(
              window,
              "resize",
              (t) => {
                const r = t.view;
                r &&
                  e("advanced_dom_window_resized", {
                    innerHeight: r.innerHeight,
                    innerWidth: r.innerWidth,
                  });
              },
              { onError: t, throttleDelay: 100 }
            ),
          (e, { onError: t }) =>
            It(
              window,
              "scroll",
              (t) => {
                if (!(t instanceof Event)) return;
                const r = t?.target;
                let n;
                if (r instanceof Document)
                  n = r.scrollingElement ?? document.documentElement;
                else {
                  if (!(r instanceof Element)) return;
                  n = r;
                }
                hi(n) || e("advanced_dom_scrolled", { node: Ni(n) });
              },
              { onError: t, throttleDelay: 100 }
            ),
          (e, t) => {
            const r = [Vi("cut", e, t), Vi("paste", e, t), Vi("copy", e, t)];
            return () => {
              r.forEach((e) => e());
            };
          },
          (e, { onError: t }) =>
            It(
              document,
              "selectionchange",
              (t) => {
                const r = document.activeElement;
                r instanceof Element &&
                  !hi(r) &&
                  e("advanced_dom_selection_changed", { node: Ni(r) });
              },
              { onError: t, throttleDelay: 250 }
            ),
          (e, { onError: t }) => {
            const r = () => {
              e("advanced_dom_available", { root: Ki(document) });
            };
            return "loading" !== document.readyState
              ? (r(), () => {})
              : It(window, "DOMContentLoaded", r, { onError: t });
          },
          (e, { onError: t }) => {
            const r = new MutationObserver((r) => {
                bt()
                  .then(() => {
                    r.forEach((t) => {
                      if (hi(t.target)) return;
                      const r = Wi(
                          Array.from(t.addedNodes).filter((e) => e.parentNode),
                          Ki
                        ),
                        n = (function (e) {
                          if (0 === e.removedNodes.length) return [];
                          if (hi(e.target))
                            return e.removedNodes.forEach((e) => Ti(e)), [];
                          const t = Array.from(e.removedNodes).filter((e) => {
                            const { parentSerializationId: t } = Ci(e);
                            return -1 !== t || (Ti(e), !1);
                          });
                          return Wi(t, (e) => {
                            const t = Ni(e);
                            return Ti(e), t;
                          });
                        })(t),
                        o = [];
                      if ("attributes" === t.type) {
                        const { target: e, attributeName: r } = t;
                        r &&
                          e instanceof HTMLElement &&
                          t.oldValue !== e.getAttribute(r) &&
                          o.push(Ni(t.target));
                      }
                      if ("characterData" === t.type) {
                        const { target: e } = t;
                        e instanceof Text &&
                          t.oldValue !== e.data &&
                          o.push(Ni(e));
                      }
                      (0 === r.length && 0 === n.length && 0 === o.length) ||
                        e("advanced_dom_changed", {
                          addedFragments: r,
                          removedNodes: n,
                          modifiedNodes: o,
                        });
                    });
                  })
                  .catch((e) => {
                    t?.(e, {
                      context: "createDomChangeListener/observer",
                      unhandled: !1,
                    });
                  });
              }),
              n = () => {
                r.observe(document.documentElement, {
                  attributes: !0,
                  attributeOldValue: !0,
                  childList: !0,
                  subtree: !0,
                  characterData: !0,
                  characterDataOldValue: !0,
                });
              };
            if ("loading" !== document.readyState)
              return (
                n(),
                () => {
                  r.disconnect();
                }
              );
            const o = It(window, "DOMContentLoaded", n, { onError: t });
            return () => {
              o(), r.disconnect();
            };
          },
        ];
      class Xi extends Error {
        constructor(...e) {
          super(...e), (this.name = "VisitorError");
        }
      }
      const Yi = {
        publish: () => !1,
        publishCustomEvent: () => !1,
        publishDomEvent: () => !1,
        visitor: () => !1,
        subscribe: () => () => !1,
      };
      const Gi = (e, t, r) => {
        const n = (e.gates ?? []).filter((e) => !e.isOpen);
        if (0 === n.length) return void e.register(t);
        const o = { remaining: n.length },
          i = [],
          s = () => {
            if ((o.remaining--, 0 === o.remaining)) {
              i.forEach((e) => e());
              try {
                e.register(t);
              } catch (n) {
                r && r(n);
              }
            }
          };
        for (const a of n) i.push(a.onOpen(s));
      };
      class Zi {
        constructor(
          e,
          {
            onError: t,
            bufferSize: r,
            replayKeep: n,
            registrationStrategy: o = Gi,
          } = {}
        ) {
          (this.eventBus = void 0),
            (this.eventBus = new bn({
              subscribeAllKey: "*",
              onSubscriberError: t,
              bufferSize: r,
              replayKeep: n,
            }));
          const i = this.eventBus.subscribe.bind(this.eventBus);
          e.forEach((e) => {
            try {
              o(e, i, t);
            } catch (r) {
              t
                ? t(r)
                : console?.error("Error registering event hub adapter:", r);
            }
          });
        }
        emit(e, t) {
          this.eventBus.publish(e, {
            name: e,
            timestamp: new Date().valueOf(),
            payload: t,
          });
        }
      }
      function Qi(e, t) {
        return (e.gates = [...(e.gates ?? []), ...t]), e;
      }
      var es = Ot("open"),
        ts = Ot("callbacks");
      class rs {
        constructor(e, t) {
          Object.defineProperty(this, es, { writable: !0, value: void 0 }),
            Object.defineProperty(this, ts, { writable: !0, value: new Set() }),
            (Pt(this, es)[es] = e()),
            Pt(this, es)[es] ||
              t(() => {
                !Pt(this, es)[es] &&
                  e() &&
                  ((Pt(this, es)[es] = !0),
                  Pt(this, ts)[ts].forEach((e) => e()),
                  Pt(this, ts)[ts].clear());
              });
        }
        get isOpen() {
          return Pt(this, es)[es];
        }
        onOpen(e) {
          return Pt(this, es)[es]
            ? (e(), () => {})
            : (Pt(this, ts)[ts].add(e),
              () => {
                Pt(this, ts)[ts].delete(e);
              });
        }
      }
      class ns extends rs {
        constructor({ predicate: e, onChange: t } = {}) {
          super(e ?? (() => He() || qe()), t ?? ((e) => kr(e)));
        }
      }
      var os = Ot("monorailClient"),
        is = Ot("configuration");
      class ss {
        constructor(e, t) {
          Object.defineProperty(this, os, { writable: !0, value: void 0 }),
            Object.defineProperty(this, is, { writable: !0, value: void 0 }),
            (Pt(this, os)[os] = e),
            (Pt(this, is)[is] = t);
        }
        register(e) {
          Pt(this, is)[is].surface === u.CustomerAccount &&
            e("log:event-bus:publish", ({ payload: { event: e } }) => {
              if ("page_viewed" === e.name) {
                const { context: t } = e,
                  r = Pt(this, is)[is].analyticsProcessingAllowed(),
                  n = Pt(this, is)[is].marketingAllowed(),
                  o = Pt(this, is)[is].preferencesProcessingAllowed(),
                  i = Pt(this, is)[is].saleOfDataAllowed(),
                  s = !(n && r),
                  a = {
                    eventName: "page_rendered",
                    shopifyEmitted: !0,
                    eventTime: new Date(e.timestamp).valueOf(),
                    eventId: e.id,
                    uniqueToken: e.clientId,
                    userAgent: t.navigator.userAgent,
                    acceptLanguage: t.navigator.language,
                    referrer: t.document.referrer,
                    eventSourceUrl: t.document.location.href,
                    source: `wpm-${Pt(this, is)[is].surface}`,
                    shopId: Pt(this, is)[is].shopId,
                    isMerchantRequest: Pt(this, is)[is].isMerchantRequest,
                    apiClientId: Pt(this, is)[is].apiClientId,
                    analyticsAllowed: r,
                    marketingAllowed: n,
                    preferencesAllowed: o,
                    saleOfDataAllowed: i,
                    deprecatedVisitToken: pn("_shopify_s") ?? "",
                  };
                Pt(this, os)[os].produce("storefront_customer_tracking/4.27", {
                  ...a,
                  emittedToV5: !0,
                  ccpaEnforced: !i,
                  gdprEnforced: s,
                  isPersistentCookie:
                    "persistent" === (pn("_shopify_m") ?? "persistent"),
                }),
                  Pt(this, os)[os].produce(
                    "storefront_customer_tracking/5.4",
                    a
                  );
              }
            });
        }
      }
      const as = [
          "checkout_completed",
          "checkout_started",
          "payment_info_submitted",
          "checkout_shipping_info_submitted",
          "checkout_contact_info_submitted",
          "checkout_address_info_submitted",
        ],
        cs = new Set([
          ...as,
          "page_viewed",
          "product_viewed",
          "collection_viewed",
          "product_added_to_cart",
          "search_submitted",
        ]),
        us = {
          page_viewed: "page_rendered",
          product_viewed: "product_page_rendered",
          collection_viewed: "collection_page_rendered",
        },
        ls = (e) => us[e] || e;
      var ds = Ot("client"),
        ps = Ot("surface");
      class fs {
        constructor(e, { surface: t }) {
          Object.defineProperty(this, ds, { writable: !0, value: void 0 }),
            Object.defineProperty(this, ps, { writable: !0, value: void 0 }),
            (Pt(this, ds)[ds] = e),
            (Pt(this, ps)[ps] = t);
        }
        register(e) {
          e("log:event-bus:publish", ({ payload: { event: e } }) => {
            if (!((e) => cs.has(e.name))(e)) return;
            const { context: t } = e,
              r = {
                eventTime: new Date(e.timestamp).valueOf(),
                eventId: e.id,
                uniqueToken: e.clientId,
                eventSourceUrl: t.document.location.href,
                surface: Pt(this, ps)[ps],
                userAgent: t.navigator.userAgent,
                sessionId: sn(),
                referrer: t.document.referrer,
              };
            if (((e) => as.includes(e.name))(e)) {
              const { checkout: t } = e.data;
              Pt(this, ds)[ds].track({
                ...r,
                eventName: e.name,
                checkoutToken: t.token || void 0,
                orderId: t.order?.id || void 0,
                subtotalValue: t.subtotalPrice?.amount,
                totalValue: t.totalPrice?.amount,
                currency: t.currencyCode || void 0,
                email: t.email || void 0,
                phone: t.shippingAddress?.phone || void 0,
                billingAddressCity: t.shippingAddress?.city || void 0,
                billingAddressCountry: t.shippingAddress?.country || void 0,
                billingAddressRegion: t.shippingAddress?.province || void 0,
              });
            } else if ("product_viewed" === e.name) {
              const { productVariant: t } = e.data;
              Pt(this, ds)[ds].track({
                ...r,
                eventName: ls(e.name),
                productId: t.product?.id || void 0,
                productTitle: t.product?.title || void 0,
                totalValue: t.price?.amount || void 0,
                currency: t.price?.currencyCode || void 0,
              });
            } else if ("collection_viewed" === e.name) {
              const { collection: t } = e.data;
              Pt(this, ds)[ds].track({
                ...r,
                eventName: ls(e.name),
                collectionName: t?.title || void 0,
                currency:
                  t?.productVariants?.find((e) => e?.price?.currencyCode)?.price
                    ?.currencyCode || void 0,
              });
            } else if ("product_added_to_cart" === e.name) {
              const { cartLine: t } = e.data,
                { merchandise: o } = t || {},
                i = o?.product?.title,
                s = o?.title,
                a = i && s ? `${i} - ${s}` : i,
                c = {
                  variant_id: o?.id || void 0,
                  product_id: o?.product?.id || void 0,
                  name: a || void 0,
                  price: o?.price?.amount || void 0,
                  sku: o?.sku || void 0,
                  brand: o?.product?.vendor || void 0,
                  variant: o?.title || void 0,
                  category: o?.product?.type || void 0,
                  quantity: t?.quantity || void 0,
                };
              let u = [];
              try {
                u = [JSON.stringify(c)];
              } catch (n) {
                console.warn(
                  "Failed to serialize product object for tracking:",
                  n
                );
              }
              Pt(this, ds)[ds].track({
                ...r,
                eventName: e.name,
                products: u,
                totalValue: t?.cost?.totalAmount?.amount || void 0,
                currency: t?.cost?.totalAmount?.currencyCode || void 0,
              });
            } else if ("page_viewed" === e.name)
              Pt(this, ds)[ds].track({
                ...r,
                eventName: ls(e.name),
                referrer: t.document.referrer,
              });
            else if ("search_submitted" === e.name) {
              const { searchResult: n } = e.data;
              Pt(this, ds)[ds].track({
                ...r,
                eventName: e.name,
                searchString: n?.query || "",
                referrer: t.document.referrer,
              });
            }
          });
        }
      }
      var hs = Ot("sendEvent"),
        ms = Ot("configuration");
      class vs {
        constructor(e, t) {
          Object.defineProperty(this, hs, { writable: !0, value: void 0 }),
            Object.defineProperty(this, ms, { writable: !0, value: void 0 }),
            (Pt(this, hs)[hs] = e),
            (Pt(this, ms)[ms] = t);
        }
        track(e) {
          try {
            const t = {
              ...e,
              shopId: Pt(this, ms)[ms].shopId,
              source: this.constructSource(e.surface),
              analyticsAllowed: Pt(this, ms)[ms].analyticsProcessingAllowed(),
              marketingAllowed: Pt(this, ms)[ms].marketingAllowed(),
              preferencesAllowed: Pt(this, ms)[
                ms
              ].preferencesProcessingAllowed(),
              saleOfDataAllowed: Pt(this, ms)[ms].saleOfDataAllowed(),
              assetVersionId: Qt,
              facebookCapiEnabled: !1,
              shopifyEmitted: !0,
            };
            Pt(this, hs)[hs](Mr("webPixelsStorefrontCustomerTracking", t));
          } catch (t) {}
        }
        constructSource(e) {
          return `wpm-${e}`;
        }
      }
      const gs = "__shopify_agent_context_events";
      var bs = Ot("onError");
      class ys {
        constructor({ onError: e } = {}) {
          Object.defineProperty(this, bs, { writable: !0, value: void 0 }),
            (Pt(this, bs)[bs] = e);
        }
        persist(e) {
          try {
            const t = sessionStorage.getItem(gs),
              r = t ? JSON.parse(t) : [];
            r.length >= 50 && r.shift(),
              r.push(e),
              sessionStorage.setItem(gs, JSON.stringify(r));
          } catch (t) {
            Pt(this, bs)[bs]?.(t);
          }
        }
      }
      const ws = new Set([
        "page_viewed",
        "product_viewed",
        "collection_viewed",
        "product_added_to_cart",
        "search_submitted",
      ]);
      var _s = Ot("client"),
        xs = Ot("extractDetail");
      class ks {
        constructor({ client: e }) {
          Object.defineProperty(this, xs, { value: Es }),
            Object.defineProperty(this, _s, { writable: !0, value: void 0 }),
            (Pt(this, _s)[_s] = e);
        }
        register(e) {
          e("log:event-bus:publish", ({ payload: { event: e } }) => {
            if (!((e) => ws.has(e.name))(e)) return;
            const t = Pt(this, xs)[xs](e);
            t && Pt(this, _s)[_s].persist(t);
          });
        }
      }
      function Es(e) {
        const t = e.context.document.location.href,
          r = new Date(e.timestamp).valueOf();
        switch (e.name) {
          case "page_viewed":
            return {
              type: "page_viewed",
              url: t,
              referrer: e.context.document.referrer,
              timestamp: r,
            };
          case "product_viewed": {
            const { productVariant: n } = e.data;
            return {
              type: "product_viewed",
              title: n.product?.title || "",
              productId: n.product?.id || "",
              price: n.price?.amount || 0,
              currency: n.price?.currencyCode || "",
              url: t,
              timestamp: r,
            };
          }
          case "collection_viewed": {
            const { collection: n } = e.data;
            return {
              type: "collection_viewed",
              title: n?.title || "",
              currency:
                n?.productVariants?.find((e) => e?.price?.currencyCode)?.price
                  ?.currencyCode || "",
              url: t,
              timestamp: r,
            };
          }
          case "product_added_to_cart": {
            const { cartLine: n } = e.data,
              { merchandise: o } = n || {};
            return {
              type: "product_added_to_cart",
              productTitle: o?.product?.title || "",
              variantTitle: o?.title || "",
              price: o?.price?.amount || 0,
              currency: o?.price?.currencyCode || "",
              quantity: n?.quantity || 0,
              sku: o?.sku || "",
              url: t,
              timestamp: r,
            };
          }
          case "search_submitted": {
            const { searchResult: n } = e.data;
            return {
              type: "search_submitted",
              query: n?.query || "",
              url: t,
              timestamp: r,
            };
          }
          default:
            return null;
        }
      }
      const Ss = "storefront_product_interaction_event_test/1.0";
      var As = Ot("monorailClient"),
        Is = Ot("options"),
        Ps = Ot("isAboveFold"),
        Cs = Ot("produce");
      class Os {
        constructor(e, t) {
          Object.defineProperty(this, Cs, { value: Ns }),
            Object.defineProperty(this, Ps, { value: Ts }),
            Object.defineProperty(this, As, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Is, { writable: !0, value: void 0 }),
            (Pt(this, As)[As] = e),
            (Pt(this, Is)[Is] = t);
        }
        register(e) {
          e(
            "log:buyer-behavior:product-interaction",
            ({ payload: { interaction: e, event: t, viewport: r } }) => {
              Pt(this, Cs)[Cs](e, t, r);
            }
          );
        }
      }
      function Ts(e, t) {
        return e.top >= 0 && e.top + e.height / 2 < t.height;
      }
      function Ns(e, t, r) {
        Pt(this, As)[As].produce(Ss, {
          shopId: Pt(this, Is)[Is].shopId,
          eventName: e,
          pageUrl: Pt(this, Is)[Is].pageUrl,
          pageId: Pt(this, Is)[Is].pageId,
          pageType: t.pageType,
          productId: t.productId,
          variantId: t.variantId,
          apiClientId: Pt(this, Is)[Is].apiClientId,
          remoteShopId: t.remoteShopId,
          impressionId: t.impressionId,
          placement: t.placement,
          position: t.position,
          aboveFold: Pt(this, Ps)[Ps](t.rect, r),
          collectionId: t.collectionId,
          analyticsAllowed: Pt(this, Is)[Is].analyticsProcessingAllowed(),
          marketingAllowed: Pt(this, Is)[Is].marketingAllowed(),
          preferencesAllowed: Pt(this, Is)[Is].preferencesProcessingAllowed(),
          saleOfDataAllowed: Pt(this, Is)[Is].saleOfDataAllowed(),
          visitToken: pn("_shopify_s") ?? "",
          uniqueToken: pn("_shopify_y") ?? "",
        }),
          Pt(this, Is)[Is].onEmission?.({ eventName: e, schemaId: Ss });
      }
      const js = "storefront_product_interaction_event_test/1.0",
        Rs = { [Vt]: "product_page_dwell", [Wt]: "collection_page_dwell" };
      var $s = Ot("monorailClient"),
        Ds = Ot("options"),
        Ms = Ot("handle");
      class Us {
        constructor(e, t) {
          Object.defineProperty(this, Ms, { value: Ls }),
            Object.defineProperty(this, $s, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Ds, { writable: !0, value: void 0 }),
            (Pt(this, $s)[$s] = e),
            (Pt(this, Ds)[Ds] = t);
        }
        register(e) {
          e("log:buyer-behavior:page-dwell", ({ payload: { event: e } }) => {
            Pt(this, Ms)[Ms](e);
          });
        }
      }
      function Ls(e) {
        const { pageType: t, resourceId: r } = Pt(this, Ds)[Ds],
          n = Rs[t];
        Pt(this, $s)[$s].produce(js, {
          shopId: Pt(this, Ds)[Ds].shopId,
          eventName: n,
          pageUrl: Pt(this, Ds)[Ds].pageUrl,
          pageId: Pt(this, Ds)[Ds].pageId,
          pageType: t,
          productId: t === Vt ? r : void 0,
          collectionId: t === Wt ? r : void 0,
          apiClientId: Pt(this, Ds)[Ds].apiClientId,
          dwellMilliseconds: e.dwellMilliseconds,
          analyticsAllowed: Pt(this, Ds)[Ds].analyticsProcessingAllowed(),
          marketingAllowed: Pt(this, Ds)[Ds].marketingAllowed(),
          preferencesAllowed: Pt(this, Ds)[Ds].preferencesProcessingAllowed(),
          saleOfDataAllowed: Pt(this, Ds)[Ds].saleOfDataAllowed(),
          visitToken: pn("_shopify_s") ?? "",
          uniqueToken: pn("_shopify_y") ?? "",
        }),
          Pt(this, Ds)[Ds].onEmission?.({ eventName: n, schemaId: js });
      }
      var Bs = Ot("client");
      class zs {
        constructor(e) {
          Object.defineProperty(this, Bs, { writable: !0, value: void 0 }),
            (Pt(this, Bs)[Bs] = e);
        }
        register(e) {
          e("log:event-bus:publish:transformed", ({ payload: e }) => {
            const { pixel: t, event: r } = e;
            Pt(this, Bs)[Bs].track({
              eventName: r.name,
              pixelId: t.id,
              pixelAppId: so(t),
              pixelSource: t.type,
              adjustmentsTriggers: e.adjustmentsTriggers,
              adjustmentsApplied: e.adjustmentsApplied,
              adjustmentsContext: "publish",
              dataSharingAdjustments: t.dataSharingAdjustments,
            });
          }),
            e("log:pixel:init:transformed", ({ payload: e }) => {
              const { pixel: t } = e;
              Pt(this, Bs)[Bs].track({
                eventName: "register:init",
                pixelId: t.id,
                pixelAppId: so(t),
                pixelSource: t.type,
                adjustmentsTriggers: e.adjustmentsTriggers,
                adjustmentsApplied: e.adjustmentsApplied,
                adjustmentsContext: "init",
                dataSharingAdjustments: t.dataSharingAdjustments,
              });
            }),
            e("log:event-bus:publish:blocked", ({ payload: e }) => {
              const { pixel: t, event: r } = e;
              Pt(this, Bs)[Bs].trackBlockedEvent({
                eventId: r.id,
                apiClientId: t.apiClientId?.toString(),
                pixelId: t.id,
                eventName: r.name,
                eventType: n(r.name),
                dataSharingState: t.dataSharingState,
              });
            });
        }
      }
      const qs = cr((e) => JSON.stringify(e), {
        cache: new WeakMap(),
        cacheKey: (e) => e,
      });
      var Hs = Ot("sendEvent"),
        Vs = Ot("configuration");
      class Ws {
        constructor(e, t) {
          Object.defineProperty(this, Hs, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Vs, { writable: !0, value: void 0 }),
            (Pt(this, Hs)[Hs] = e),
            (Pt(this, Vs)[Vs] = t);
        }
        track(e) {
          try {
            Pt(this, Hs)[Hs](
              Mr("webPixelsPublicEventPayloadTransform", {
                shopId: Pt(this, Vs)[Vs].shopId,
                pixelSource: e.pixelSource,
                surface: Pt(this, Vs)[Vs].surface,
                eventName: e.eventName,
                pixelId: e.pixelId,
                pixelAppId: e.pixelAppId,
                pageUrl: Pt(this, Vs)[Vs].pageUrl,
                bundleTarget: Zt,
                adjustmentsTriggers: e.adjustmentsTriggers,
                adjustmentsApplied: e.adjustmentsApplied,
                adjustmentsContext: e.adjustmentsContext,
                adjustmentsJson: e.dataSharingAdjustments
                  ? qs(e.dataSharingAdjustments)
                  : void 0,
              })
            );
          } catch (t) {}
        }
        trackBlockedEvent(e) {
          try {
            Pt(this, Hs)[Hs](
              Mr("webPixelsManagerSubscriberEventBlocked", {
                eventId: e.eventId,
                apiClientId: e.apiClientId,
                shopId: Pt(this, Vs)[Vs].shopId,
                pixelId: e.pixelId,
                surface: Pt(this, Vs)[Vs].surface,
                eventName: e.eventName,
                eventType: e.eventType,
                dataSharingState: e.dataSharingState ?? "unknown",
                bundleTarget: Zt,
                pageUrl: Pt(this, Vs)[Vs].pageUrl,
              })
            );
          } catch (t) {}
        }
      }
      function Fs(e, t) {
        if (!{}.hasOwnProperty.call(e, t))
          throw new TypeError("attempted to use private field on non-instance");
        return e;
      }
      var Ks = 0;
      function Js(e) {
        return "__private_" + Ks++ + "_" + e;
      }
      function Xs(e) {
        return Object.entries(e).map(([e, t]) => ({
          key: e,
          value: { stringValue: String(t) },
        }));
      }
      function Ys(e) {
        if (Array.isArray(e))
          return { arrayValue: { values: e.map((e) => Ys(e)) } };
        switch (typeof e) {
          case "boolean":
            return { boolValue: Boolean(e) };
          case "number":
            return { doubleValue: Number(e) };
          default:
            return { stringValue: String(e) };
        }
      }
      const Gs = (function () {
        const e = [0];
        for (let t = 0; t < 12; t++) {
          const r = Math.floor(5 * 2 ** t);
          e.push(r);
        }
        return e;
      })();
      var Zs = Js("exporter"),
        Qs = Js("attributes"),
        ea = Js("metrics"),
        ta = Js("logs");
      class ra {
        constructor({ exporter: e, attributes: t }) {
          Object.defineProperty(this, Zs, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Qs, { writable: !0, value: void 0 }),
            Object.defineProperty(this, ea, { writable: !0, value: [] }),
            Object.defineProperty(this, ta, { writable: !0, value: [] }),
            (Fs(this, Zs)[Zs] = e),
            (Fs(this, Qs)[Qs] = null != t ? t : {});
        }
        addAttributes(e) {
          Fs(this, Qs)[Qs] = { ...Fs(this, Qs)[Qs], ...e };
        }
        histogram({
          name: e,
          value: t,
          unit: r,
          bounds: n,
          attributes: o,
          scale: i,
          requiresKeepalive: s,
        }) {
          const a = 1e6 * Date.now();
          n
            ? Fs(this, ea)[ea].push({
                name: e,
                type: "histogram",
                value: t,
                unit: r,
                timeUnixNano: a,
                attributes: o,
                bounds: n,
                requiresKeepalive: s,
              })
            : Fs(this, ea)[ea].push({
                name: e,
                type: "exponential_histogram",
                value: t,
                unit: r,
                timeUnixNano: a,
                attributes: o,
                scale: i,
                requiresKeepalive: s,
              });
        }
        counter({
          name: e,
          value: t,
          unit: r,
          attributes: n,
          requiresKeepalive: o,
        }) {
          const i = 1e6 * Date.now();
          Fs(this, ea)[ea].push({
            name: e,
            type: "counter",
            value: t,
            unit: r,
            timeUnixNano: i,
            attributes: n,
            requiresKeepalive: o,
          });
        }
        gauge({
          name: e,
          value: t,
          unit: r,
          attributes: n,
          requiresKeepalive: o,
        }) {
          const i = 1e6 * Date.now();
          Fs(this, ea)[ea].push({
            name: e,
            type: "gauge",
            value: t,
            unit: r,
            timeUnixNano: i,
            attributes: n,
            requiresKeepalive: o,
          });
        }
        log({ body: e, attributes: t, requiresKeepalive: r }) {
          const n = 1e6 * Date.now();
          Fs(this, ta)[ta].push({
            timeUnixNano: n,
            body: e,
            attributes: t,
            requiresKeepalive: r,
          });
        }
        async exportMetrics() {
          Fs(this, ea)[ea].forEach((e) => {
            e.attributes = { ...Fs(this, Qs)[Qs], ...e.attributes };
          });
          const e = Fs(this, ea)[ea];
          (Fs(this, ea)[ea] = []),
            await this.exportByKeepalive(e, (e, t) =>
              Fs(this, Zs)[Zs].exportMetrics(this.aggregateMetrics(e), t)
            );
        }
        async exportLogs() {
          const e = Fs(this, ta)[ta];
          (Fs(this, ta)[ta] = []),
            await this.exportByKeepalive(e, (e, t) =>
              Fs(this, Zs)[Zs].exportLogs(this.formatLogs(e), t)
            );
        }
        aggregateMetrics(e) {
          const t = {};
          return (
            e.forEach((e) => {
              switch (e.type) {
                case "histogram":
                  !(function (e, t) {
                    var r;
                    const {
                        name: n,
                        value: o,
                        unit: i,
                        timeUnixNano: s,
                        attributes: a,
                      } = t,
                      c = null !== (r = t.bounds) && void 0 !== r ? r : Gs,
                      u = new Array(c.length + 1).fill(0);
                    e[n] ||= {
                      name: n,
                      unit: i || "1",
                      histogram: { aggregationTemporality: 1, dataPoints: [] },
                    };
                    for (let l = 0; l < u.length; l++) {
                      const e = c[l];
                      if (void 0 === e) u[l] = 1;
                      else if (o <= e) {
                        u[l] = 1;
                        break;
                      }
                    }
                    e[n].histogram.dataPoints.push({
                      startTimeUnixNano: s,
                      timeUnixNano: s,
                      count: 1,
                      sum: o,
                      min: o,
                      max: o,
                      bucketCounts: u,
                      explicitBounds: c,
                      attributes: Xs(null != a ? a : {}),
                    });
                  })(t, e);
                  break;
                case "exponential_histogram":
                  !(function (e, t) {
                    const {
                      name: r,
                      value: n,
                      unit: o,
                      timeUnixNano: i,
                      attributes: s,
                      scale: a,
                    } = t;
                    e[r] ||= {
                      name: r,
                      unit: o || "1",
                      exponentialHistogram: {
                        aggregationTemporality: 1,
                        dataPoints: [],
                      },
                    };
                    const c = n <= 0 ? 0 : n,
                      u = a || 3,
                      l = 2 ** u / Math.log(2),
                      d = Math.ceil(Math.log(n) * l) - 1,
                      p = n <= 0 ? 1 : 0,
                      f = {
                        offset: n > 0 ? d : 0,
                        bucketCounts: n > 0 ? [1] : [],
                      };
                    e[r].exponentialHistogram.dataPoints.push({
                      attributes: Xs(null != s ? s : {}),
                      startTimeUnixNano: i,
                      timeUnixNano: i,
                      count: 1,
                      sum: c,
                      scale: u,
                      zeroCount: p,
                      positive: f,
                      negative: { offset: 0, bucketCounts: [] },
                      min: c,
                      max: c,
                      zeroThreshold: 0,
                    });
                  })(t, e);
                  break;
                case "counter":
                  !(function (e, t) {
                    const {
                      name: r,
                      value: n,
                      unit: o,
                      timeUnixNano: i,
                      attributes: s,
                    } = t;
                    (e[r] ||= {
                      name: r,
                      unit: o || "1",
                      sum: {
                        aggregationTemporality: 1,
                        isMonotonic: !0,
                        dataPoints: [],
                      },
                    }),
                      e[r].sum.dataPoints.push({
                        startTimeUnixNano: i,
                        timeUnixNano: i,
                        asDouble: n,
                        attributes: Xs(null != s ? s : {}),
                      });
                  })(t, e);
                  break;
                case "gauge":
                  !(function (e, t) {
                    const {
                      name: r,
                      value: n,
                      unit: o,
                      timeUnixNano: i,
                      attributes: s,
                    } = t;
                    (e[r] ||= {
                      name: r,
                      unit: o || "1",
                      gauge: { dataPoints: [] },
                    }),
                      e[r].gauge.dataPoints.push({
                        startTimeUnixNano: i,
                        timeUnixNano: i,
                        asDouble: n,
                        attributes: Xs(null != s ? s : {}),
                      });
                  })(t, e);
              }
            }),
            Object.values(t)
          );
        }
        async exportByKeepalive(e, t) {
          if (0 === e.length) return;
          const r = [],
            n = [];
          e.forEach((e) => {
            var t;
            null === (t = e.requiresKeepalive) || void 0 === t || t
              ? r.push(e)
              : n.push(e);
          });
          const o = [
            r.length > 0 ? t(r, { keepalive: !0 }) : void 0,
            n.length > 0 ? t(n, { keepalive: !1 }) : void 0,
          ].filter((e) => void 0 !== e);
          await Promise.all(o);
        }
        formatLogs(e) {
          return e.map((e) => {
            const t = {
              timeUnixNano: e.timeUnixNano,
              observedTimeUnixNano: e.timeUnixNano,
              attributes:
                ((r = { ...Fs(this, Qs)[Qs], ...e.attributes }),
                Object.entries(r).map(([e, t]) => ({ key: e, value: Ys(t) }))),
            };
            var r;
            return e.body && (t.body = { stringValue: e.body }), t;
          });
        }
      }
      var na = Js("url"),
        oa = Js("serviceName"),
        ia = Js("logger"),
        sa = Js("fetchFn"),
        aa = Js("maxPayloadSizeBytes");
      class ca {
        constructor(e, t, r) {
          var n;
          Object.defineProperty(this, na, { writable: !0, value: void 0 }),
            Object.defineProperty(this, oa, { writable: !0, value: void 0 }),
            Object.defineProperty(this, ia, { writable: !0, value: void 0 }),
            Object.defineProperty(this, sa, { writable: !0, value: void 0 }),
            Object.defineProperty(this, aa, { writable: !0, value: void 0 }),
            (Fs(this, na)[na] = e.replace(
              /\/v1\/(logs|metrics|traces)\/?$/,
              ""
            )),
            (Fs(this, oa)[oa] = t),
            (Fs(this, ia)[ia] = null == r ? void 0 : r.logger),
            (Fs(this, sa)[sa] = null == r ? void 0 : r.fetchFn),
            (Fs(this, aa)[aa] =
              null !== (n = null == r ? void 0 : r.maxPayloadSizeBytes) &&
              void 0 !== n
                ? n
                : 51200);
        }
        async exportMetrics(e, t) {
          var r;
          const n =
            null === (r = null == t ? void 0 : t.keepalive) ||
            void 0 === r ||
            r;
          await this.exportBatches(
            "/v1/metrics",
            [...e],
            (e) => ({
              resourceMetrics: [
                {
                  resource: {
                    attributes: [
                      {
                        key: "service.name",
                        value: { stringValue: Fs(this, oa)[oa] },
                      },
                    ],
                  },
                  scopeMetrics: [
                    {
                      scope: {
                        name: "open-telemetry-mini-client",
                        version: "1.1.0",
                        attributes: [],
                      },
                      metrics: e,
                    },
                  ],
                },
              ],
            }),
            n
          );
        }
        async exportLogs(e, t) {
          var r;
          const n =
            null === (r = null == t ? void 0 : t.keepalive) ||
            void 0 === r ||
            r;
          await this.exportBatches(
            "/v1/logs",
            [...e],
            (e) => ({
              resourceLogs: [
                {
                  resource: {
                    attributes: [
                      {
                        key: "service.name",
                        value: { stringValue: Fs(this, oa)[oa] },
                      },
                    ],
                  },
                  scopeLogs: [
                    {
                      scope: {
                        name: "open-telemetry-mini-client",
                        version: "1.1.0",
                        attributes: [],
                      },
                      logRecords: e,
                    },
                  ],
                },
              ],
            }),
            n
          );
        }
        async exportTo(e, t, r) {
          var n;
          const o = JSON.stringify(e),
            i = new TextEncoder().encode(o).length;
          if (i > Fs(this, aa)[aa])
            throw new la(`Payload size ${i} exceeds ${Fs(this, aa)[aa]} bytes`);
          const s = await this.exporterFetch()(`${Fs(this, na)[na]}${t}`, {
            method: "POST",
            keepalive: r,
            headers: { "Content-Type": "application/json" },
            body: o,
          });
          if (
            (null === (n = Fs(this, ia)[ia]) ||
              void 0 === n ||
              n.log({ status: s.status }),
            !s.ok)
          ) {
            if (400 === s.status) {
              const e = await s.text();
              throw new ua(`Invalid OpenTelemetry Data: ${e}`);
            }
            if (429 === s.status || 503 === s.status) {
              const t = await s.text(),
                r = s.headers.get("Retry-After"),
                n = r ? { seconds: Number(r) } : void 0;
              throw new ua("Server did not accept data", {
                errorData: t,
                retryAfter: n,
                body: e,
              });
            }
            if (401 === s.status || 403 === s.status) {
              const t = await s.text();
              throw new da(
                `Authentication failed: ${s.status} ${
                  401 === s.status ? "Unauthorized" : "Forbidden"
                }`,
                { errorData: t, body: e }
              );
            }
            throw new ua(`Server responded with ${s.status}`);
          }
        }
        exporterFetch() {
          return Fs(this, sa)[sa] || fetch;
        }
        async exportBatches(e, t, r, n) {
          let o = t.length;
          for (; t.length > 0; )
            try {
              const i = t.slice(0, o);
              await this.exportTo(r(i), e, n), t.splice(0, o);
            } catch (i) {
              if (!(i instanceof la && o > 1)) throw i;
              o = Math.ceil(o / 2);
            }
        }
      }
      class ua extends Error {
        constructor(e, t) {
          super(e),
            (this.metadata = void 0),
            (this.name = "OpenTelemetryClientError"),
            (this.metadata = t);
        }
      }
      class la extends Error {
        constructor(...e) {
          super(...e), (this.name = "PayloadTooLargeError");
        }
      }
      class da extends Error {
        constructor(e, t) {
          super(e),
            (this.name = "AuthenticationFailedError"),
            (this.metadata = void 0),
            (this.name = "AuthenticationFailedError"),
            (this.metadata = t);
        }
      }
      let pa = (function (e) {
        return (
          (e.Histogram = "histogram"),
          (e.Counter = "counter"),
          (e.Gauge = "gauge"),
          (e.ExponentialHistogram = "exponential_histogram"),
          e
        );
      })({});
      var fa = Ot("client"),
        ha = Ot("metrics"),
        ma = Ot("prefix"),
        va = Ot("defaultAttributes");
      class ga {
        constructor({
          client: e,
          metrics: t,
          prefix: r,
          defaultAttributes: n,
        }) {
          Object.defineProperty(this, fa, { writable: !0, value: void 0 }),
            Object.defineProperty(this, ha, { writable: !0, value: void 0 }),
            Object.defineProperty(this, ma, { writable: !0, value: void 0 }),
            Object.defineProperty(this, va, { writable: !0, value: void 0 }),
            (Pt(this, fa)[fa] = e),
            (Pt(this, ha)[ha] = t),
            (Pt(this, ma)[ma] = r ?? ""),
            (Pt(this, va)[va] = n ?? {});
        }
        record(e, t, ...r) {
          const n = Pt(this, ha)[ha][e],
            o = String(e),
            i = r[0] ?? {},
            s = {
              name: Pt(this, ma)[ma] ? `${Pt(this, ma)[ma]}_${o}` : o,
              value: t,
              unit: n.unit,
              attributes: { ...Pt(this, va)[va], ...i },
            },
            a = n.type;
          switch (a) {
            case pa.Counter:
            case pa.Gauge:
              Pt(this, fa)[fa][a](s);
              break;
            case pa.Histogram:
              Pt(this, fa)[fa].histogram({ ...s, bounds: n.bounds });
              break;
            case pa.ExponentialHistogram:
              Pt(this, fa)[fa].histogram({ ...s, scale: n.scale });
              break;
            default:
              throw new c(`Unknown metric type: ${a}`);
          }
          Pt(this, fa)
            [fa].exportMetrics()
            .catch(() => {});
        }
        log(e, t) {
          Pt(this, fa)[fa].log({
            body: e,
            attributes: { ...Pt(this, va)[va], ...t },
          }),
            Pt(this, fa)
              [fa].exportLogs()
              .catch(() => {});
        }
      }
      var ba = Ot("client");
      class ya {
        constructor({ client: e, throttleDelay: t }) {
          Object.defineProperty(this, ba, { writable: !0, value: void 0 }),
            (Pt(this, ba)[ba] = t
              ? (function (e, t) {
                  return {
                    counter: e.counter.bind(e),
                    gauge: e.gauge.bind(e),
                    histogram: e.histogram.bind(e),
                    log: e.log.bind(e),
                    exportMetrics: kt(
                      () => e.exportMetrics().catch(() => {}),
                      t
                    ),
                    exportLogs: kt(() => e.exportLogs().catch(() => {}), t),
                  };
                })(e, t)
              : e);
        }
        createClient(e) {
          return new ga({ ...e, client: Pt(this, ba)[ba] });
        }
      }
      var wa = Ot("prefix");
      class _a {
        constructor(e = "OpenTelemetry") {
          Object.defineProperty(this, wa, { writable: !0, value: void 0 }),
            (Pt(this, wa)[wa] = e);
        }
        exportMetrics(e) {
          return (
            console.log(`[${Pt(this, wa)[wa]}] Metrics:`, e), Promise.resolve()
          );
        }
        exportLogs(e) {
          return (
            console.log(`[${Pt(this, wa)[wa]}] Logs:`, e), Promise.resolve()
          );
        }
      }
      const xa = { feature_usage: { unit: "1", type: pa.Counter } };
      function ka(e) {
        return "string" == typeof e ? e : void 0;
      }
      function Ea(e) {
        if (!e && 0 !== e) return;
        const t = Number(e);
        return Number.isNaN(t) ? void 0 : t;
      }
      function Sa(e) {
        if (e && "object" == typeof e && !Array.isArray(e)) return e;
      }
      function Aa(e) {
        return Array.isArray(e)
          ? e.filter(
              (e) => Boolean(e) && "object" == typeof e && !Array.isArray(e)
            )
          : [];
      }
      const Ia = [
          [/^[ _]?viewed[ _]?product[ _]?$/i, "product_page_rendered"],
          [
            /^[ _]?viewed[ _]?product[ _]?category[ _]?$/i,
            "collection_page_rendered",
          ],
          [/^[ _]?added[ _]?product[ _]?$/i, "product_added_to_cart"],
          [/^[ _]?completed[ _]?order[ _]?$/i, "checkout_completed"],
          [
            /^[ _]?started[ _]?order[ _]?once[ _]?per[ _]?checkout[ _]?remote[ _]?$/i,
            "remote_checkout_started_once_per_checkout",
          ],
          [
            /^[ _]?started[ _]?order[ _]?once[ _]?per[ _]?checkout[ _]?$/i,
            "checkout_started_once_per_checkout",
          ],
          [
            /^[ _]?started[ _]?order[ _]?remote[ _]?$/i,
            "remote_checkout_started",
          ],
          [/^[ _]?started[ _]?order[ _]?$/i, "checkout_started"],
          [/^[ _]?performed[ _]?search[ _]?$/i, "search_submitted"],
          [
            /^[ _]?added[ _]?payment[ _]?remote[ _]?$/i,
            "remote_payment_info_submitted",
          ],
          [/^[ _]?added[ _]?payment[ _]?$/i, "payment_info_submitted"],
          [
            /^[ _]?checkout[ _]?[ _]?contact[ _]?info[ _]?submitted[ _]?remote[ _]?$/i,
            "remote_checkout_contact_info_submitted",
          ],
          [
            /^[ _]?checkout[ _]?[ _]?contact[ _]?info[ _]?submitted[ _]?$/i,
            "checkout_contact_info_submitted",
          ],
          [
            /^[ _]?checkout[ _]?[ _]?address[ _]?info[ _]?submitted[ _]?remote[ _]?$/i,
            "remote_checkout_address_info_submitted",
          ],
          [
            /^[ _]?checkout[ _]?[ _]?address[ _]?info[ _]?submitted[ _]?$/i,
            "checkout_address_info_submitted",
          ],
          [
            /^[ _]?checkout[ _]?[ _]?shipping[ _]?info[ _]?submitted[ _]?remote[ _]?$/i,
            "remote_checkout_shipping_info_submitted",
          ],
          [
            /^[ _]?checkout[ _]?[ _]?shipping[ _]?info[ _]?submitted[ _]?$/i,
            "checkout_shipping_info_submitted",
          ],
        ],
        Pa = {
          page_rendered: "page_viewed",
          remote_page_rendered: "page_viewed",
          product_page_rendered: "product_viewed",
          remote_product_page_rendered: "product_viewed",
          product_added_to_cart: "product_added_to_cart",
          remote_product_added_to_cart: "product_added_to_cart",
          product_added_to_cart_legacy: "product_added_to_cart",
          checkout_started: "checkout_started",
          remote_checkout_started: "checkout_started",
          checkout_started_once_per_checkout: "checkout_started",
          remote_checkout_started_once_per_checkout: "checkout_started",
          checkout_completed: "checkout_completed",
          search_submitted: "search_submitted",
          payment_info_submitted: "payment_info_submitted",
          remote_payment_info_submitted: "payment_info_submitted",
          collection_page_rendered: "collection_viewed",
          checkout_contact_info_submitted: "checkout_contact_info_submitted",
          remote_checkout_contact_info_submitted:
            "checkout_contact_info_submitted",
          checkout_address_info_submitted: "checkout_address_info_submitted",
          remote_checkout_address_info_submitted:
            "checkout_address_info_submitted",
          checkout_shipping_info_submitted: "checkout_shipping_info_submitted",
          remote_checkout_shipping_info_submitted:
            "checkout_shipping_info_submitted",
        };
      function Ca(e) {
        if (e.productId && e.variantId) return `${e.productId}-${e.variantId}`;
      }
      const Oa = /^https?:\/\//;
      let Ta, Na;
      function ja() {
        const e = self.location?.href;
        return (
          (e && e === Ta) ||
            ((Ta = e),
            (Na = (function () {
              const e = self.document?.getElementsByTagName("link");
              if (e)
                for (const t of Array.from(e)) {
                  if ("canonical" !== t.getAttribute("rel")) continue;
                  const e = t.getAttribute("href");
                  if (e && Oa.test(e) && !(e.replace(Oa, "").length <= 5))
                    return e;
                }
            })())),
          Na
        );
      }
      function Ra(e) {
        return ("string" == typeof e && e) || "USD";
      }
      function $a(e) {
        return e.map((e) =>
          JSON.stringify({
            variant_id: Ea(e.variantId) ?? null,
            product_id: Ea(e.productId) ?? null,
            product_gid: e.productGid,
            name: e.name,
            price: Ea(e.price) ?? 0,
            sku: e.sku,
            brand: e.brand,
            variant: e.variant,
            category: e.category,
            quantity: Ea(e.quantity) ?? 0,
          })
        );
      }
      function Da(e) {
        return { totalValue: Ea(e.price) ?? 0, currency: Ra(e.currency) };
      }
      function Ma(e) {
        return {
          totalValue: Ea(e.total) ?? 0,
          subtotalValue: Ea(e.subtotalAfterMerchandiseDiscounts) ?? 0,
          currency: Ra(e.currency),
        };
      }
      function Ua(e) {
        return Ea(e.subtotalAfterMerchandiseDiscounts) ?? 0;
      }
      function La(e) {
        return {
          billingAddressCity: ka(e?.city),
          billingAddressCountry: ka(e?.country),
          billingAddressRegion: ka(e?.province),
        };
      }
      function Ba() {
        const e = window.performance?.getEntriesByType("navigation");
        return e?.[0];
      }
      function za() {
        try {
          const e = Ba();
          if (e?.type)
            return {
              navigationType: e.type,
              navigationApi: "PerformanceNavigationTiming",
            };
          const t = window.performance?.navigation;
          if (void 0 !== t)
            return {
              navigationType:
                { 0: "navigate", 1: "reload", 2: "back_forward" }[t.type] ??
                "unknown",
              navigationApi: "performance.navigation",
            };
        } catch {
          return { navigationType: "error", navigationApi: "error" };
        }
        return { navigationType: "unknown", navigationApi: "unknown" };
      }
      function qa() {
        try {
          const e = Ba(),
            t = e?.serverTiming;
          if (t) {
            const e = t.find((e) => "_s" === e.name)?.description;
            if (e) return e;
            const r = t.map((e) => e.name).join(",");
            return `no_s_field|${window.location?.href}|${r}`;
          }
          return e ? "no_server_timing" : "no_navigation";
        } catch {
          return "error_while_reading";
        }
      }
      const Ha = {
        page_rendered: "z",
        product_page_rendered: "x",
        collection_page_rendered: "c",
        search_submitted: "b",
      };
      function Va(e, t) {
        try {
          if (!Ha[e] || "storefront-renderer" !== t) return;
          const r = Ba()?.serverTiming?.find(
            (e) => "requestID" === e.name
          )?.description;
          if (!r) return;
          return (function (e, t) {
            try {
              const r = Wa(e, t);
              return r ? window.sessionStorage.getItem(r) : null;
            } catch {
              return null;
            }
          })(r, e)
            ? Fe().toUpperCase()
            : ((function (e, t) {
                try {
                  const r = Wa(e, t);
                  if (!r) return;
                  window.sessionStorage.setItem(
                    r,
                    new Date().getTime().toString()
                  );
                } catch {}
              })(r, e),
              r);
        } catch {
          return;
        }
      }
      function Wa(e, t) {
        const r = Ha[t];
        if (r) return `wpm-ri-${e}-${r}`;
      }
      var Fa = Ot("monorailClient"),
        Ka = Ot("configuration"),
        Ja = Ot("resolveEventName"),
        Xa = Ot("produce");
      class Ya {
        constructor(e, t) {
          Object.defineProperty(this, Xa, { value: Za }),
            Object.defineProperty(this, Ja, { value: Ga }),
            Object.defineProperty(this, Fa, { writable: !0, value: void 0 }),
            Object.defineProperty(this, Ka, { writable: !0, value: void 0 }),
            (Pt(this, Fa)[Fa] = e),
            (Pt(this, Ka)[Ka] = t);
        }
        register(e) {
          e(
            "log:trekkie:track",
            ({
              payload: {
                method: e,
                args: [t, r, n, o],
              },
            }) => {
              const i = Sa(r) ?? {},
                s = Pt(this, Ja)[Ja](e, t, i);
              s &&
                ("checkout_completed" !== s || o) &&
                Pt(this, Xa)[Xa](s, i, ka(n));
            }
          );
        }
      }
      function Ga(e, t, r) {
        let n;
        if ("page" === e) n = "page_rendered";
        else {
          const e = ka(t);
          if (!e) return null;
          n = (function (e) {
            for (const [t, r] of Ia) if (t.test(e)) return r;
          })(e);
        }
        if (!n) return null;
        switch (n) {
          case "page_rendered":
            return Pt(this, Ka)[Ka].isRemoteProduct()
              ? "remote_page_rendered"
              : n;
          case "product_page_rendered":
            return Pt(this, Ka)[Ka].isRemoteProduct(ka(r.variantId))
              ? "remote_product_page_rendered"
              : n;
          case "product_added_to_cart": {
            const e = Pt(this, Ka)[Ka].isRemoteProduct(ka(r.variantId)),
              t = nt("bdb960ec");
            return e && t
              ? null
              : t
              ? "product_added_to_cart_legacy"
              : e
              ? "remote_product_added_to_cart"
              : n;
          }
          default:
            return n;
        }
      }
      function Za(e, t, r) {
        const n = (function (e, t, r) {
            const n = Pa[e];
            if (!n) return;
            if ("checkout_completed" === n && r) return r;
            const o = self.Shopify?.evids;
            return o
              ? o(
                  n,
                  "product_added_to_cart" === n
                    ? { analyticsFramework: "trekkie-parity", cacheKey: Ca(t) }
                    : { analyticsFramework: "trekkie-parity" }
                )
              : void 0;
          })(e, t, r),
          o = (function (e, t) {
            switch (e) {
              case "page_rendered":
              case "remote_page_rendered":
                return {
                  referrer: self.document?.referrer || void 0,
                  canonicalUrl: ja() ?? "",
                };
              case "product_page_rendered":
              case "remote_product_page_rendered":
                return { ...Da(t), products: $a([{ ...t, quantity: 1 }]) };
              case "product_added_to_cart":
              case "remote_product_added_to_cart":
              case "product_added_to_cart_legacy":
                return {
                  ...Da(t),
                  products: $a([t]),
                  cartToken: ka(t.cartToken),
                };
              case "payment_info_submitted":
              case "remote_payment_info_submitted":
              case "checkout_shipping_info_submitted":
              case "remote_checkout_shipping_info_submitted":
                return Ma(t);
              case "search_submitted":
                return { searchString: ka(t.query) ?? "" };
              case "checkout_started":
              case "remote_checkout_started":
              case "checkout_started_once_per_checkout":
              case "remote_checkout_started_once_per_checkout":
                return { ...Ma(t), products: $a(Aa(t.products)) };
              case "checkout_completed": {
                const e = Sa(t.customerEventData),
                  r = Sa(e?.customer),
                  n = Sa(e?.address),
                  o = {
                    ...Ma(t),
                    ...La(n),
                    products: $a(Aa(t.products)),
                    firstName: ka(r?.firstName),
                    lastName: ka(r?.lastName),
                    email: ka(r?.emailAddress),
                    phone: ka(r?.phoneNumber),
                    billingAddressZipcode: ka(n?.zip),
                  };
                return t.orderId && (o.orderId = String(t.orderId)), o;
              }
              case "collection_page_rendered":
                return {
                  collectionId: Ea(t.collectionId),
                  collectionName: ka(t.collectionName),
                  currency: Ra(t.currency),
                };
              case "checkout_contact_info_submitted":
              case "remote_checkout_contact_info_submitted":
                return {
                  email: ka(t.email),
                  phone: ka(t.phone),
                  subtotalValue: Ua(t),
                };
              case "checkout_address_info_submitted":
              case "remote_checkout_address_info_submitted":
                return { ...La(t), phone: ka(t.phone), subtotalValue: Ua(t) };
              default:
                return e;
            }
          })(e, t),
          i = !(
            Pt(this, Ka)[Ka].marketingAllowed() &&
            Pt(this, Ka)[Ka].analyticsProcessingAllowed()
          );
        Pt(this, Fa)[Fa].produce("storefront_customer_tracking_parity/1.0", {
          eventId: n,
          eventTime: new Date().getTime(),
          eventSourceUrl: self.location?.href ?? "",
          uniqueToken: pn("_shopify_y") ?? "",
          userAgent: self.navigator?.userAgent,
          eventName: e,
          shopId: Pt(this, Ka)[Ka].shopId,
          source: `wpm-${Pt(this, Ka)[Ka].surface}`,
          shopifyEmitted: !0,
          assetVersionId: Qt,
          ccpaEnforced: !Pt(this, Ka)[Ka].saleOfDataAllowed(),
          gdprEnforced: i,
          gdprEnforcedAsString: String(i),
          isPersistentCookie:
            "persistent" === (pn("_shopify_m") ?? "persistent"),
          analyticsAllowed: Pt(this, Ka)[Ka].analyticsProcessingAllowed(),
          marketingAllowed: Pt(this, Ka)[Ka].marketingAllowed(),
          preferencesAllowed: Pt(this, Ka)[Ka].preferencesProcessingAllowed(),
          saleOfDataAllowed: Pt(this, Ka)[Ka].saleOfDataAllowed(),
          deprecatedVisitToken: pn("_shopify_s") ?? "",
          trackingConsent: qa(),
          sessionId: sn(),
          pageId: Pt(this, Ka)[Ka].pageId,
          requestId: Va(e, Pt(this, Ka)[Ka].surface),
          ...za(),
          ...(Pt(this, Ka)[Ka].isMerchantRequest && { isMerchantRequest: !0 }),
          ...(Pt(this, Ka)[Ka].eventMetadataId && {
            eventMetadataId: Pt(this, Ka)[Ka].eventMetadataId,
          }),
          ...o,
        }),
          Pt(this, Ka)[Ka].onProduce?.(e);
      }
      var Qa = Ot("monorailClient"),
        ec = Ot("configuration");
      class tc {
        constructor(e, t = {}) {
          Object.defineProperty(this, Qa, { writable: !0, value: void 0 }),
            Object.defineProperty(this, ec, { writable: !0, value: void 0 }),
            (Pt(this, Qa)[Qa] = e),
            (Pt(this, ec)[ec] = t);
        }
        register(e) {
          e(
            "log:trekkie:track",
            ({
              payload: {
                method: e,
                args: [t, r, , n],
              },
            }) => {
              if ("track" !== e) return;
              const o = ka(t);
              if (!o) return;
              const i = (function (e) {
                const t = e.toLowerCase();
                if (t.startsWith("monorail://") && t.length > 11)
                  return t.slice(11);
              })(o);
              if (!i) return;
              const s = {
                ...(Sa(r) ?? {}),
                ...(!0 === n && { emit_conversion_event: !0 }),
              };
              Pt(this, ec)[ec].onEventReceived?.(i),
                nt(it) &&
                  Pt(this, Qa)[Qa].produce(i, s, { convertEventCase: !1 });
            }
          );
        }
      }
      var rc = Ot("client"),
        nc = Ot("options");
      class oc {
        constructor(e, t) {
          Object.defineProperty(this, rc, { writable: !0, value: void 0 }),
            Object.defineProperty(this, nc, { writable: !0, value: void 0 }),
            (Pt(this, rc)[rc] = e),
            (Pt(this, nc)[nc] = t);
        }
        register(e) {
          e("log:trekkie:track", ({ payload: { method: e, args: t } }) => {
            if ("track" !== e && "page" !== e) return;
            const r = "page" === e ? "Page Viewed" : t[0];
            "string" == typeof r &&
              Pt(this, rc)[rc].record("feature_usage", 1, {
                feature: "event_emission",
                event_name: r,
                user_can_be_tracked:
                  Pt(this, nc)[nc].analyticsProcessingAllowed() ||
                  Pt(this, nc)[nc].marketingAllowed(),
              });
          });
        }
      }
      function ic(e) {
        const t = self.ShopifyAnalytics?.meta;
        if (!t?.remoteProductsEnabled) return !1;
        if (e) {
          const r = (function (e, t) {
            return e.products
              ? (function (e, t) {
                  for (const r of t)
                    if (r.variants)
                      for (const t of r.variants)
                        if (String(t.id) === e) return r;
                })(t, e.products)
              : e.product?.variants &&
                e.product.variants.some((e) => String(e.id) === t)
              ? e.product
              : void 0;
          })(t, e);
          return Boolean(r?.remote);
        }
        return Boolean(t.product?.remote);
      }
      let sc;
      const ac = Object.values(f),
        cc = (e) => {
          const t = e.trim().toLowerCase();
          return (r = t), ac.includes(r) ? t : f.NotAvailable;
          var r;
        },
        uc = Object.values(u),
        lc = [u.NotAvailable, u.Unknown, u.StorefrontRenderer],
        dc = (e) => {
          if (!e) return -1;
          const t = e.trim();
          if (!/^\d+$/.test(t)) return -1;
          const r = window.parseInt(t, 10);
          return window.isNaN(r) || r <= 0 ? -1 : r;
        };
      function pc(e) {
        if (!e) return [];
        try {
          const t = JSON.parse(e);
          return Array.isArray(t) ? t : [];
        } catch (t) {
          return [];
        }
      }
      const fc = () => {
        const e = (() => {
            try {
              return document.currentScript?.dataset;
            } catch {
              return null;
            }
          })(),
          t = ((e) => {
            const t = e.trim().toLowerCase();
            return (
              (r = t),
              uc.includes(r)
                ? t
                : window.Shopify?.Checkout
                ? u.Shopify
                : window.Shopify?.analytics?.replayQueue
                ? u.StorefrontRenderer
                : window.CardFields
                ? u.CheckoutOne
                : u.Unknown
            );
            var r;
          })(e?.surface ?? ""),
          r = ((e) => {
            if (!e) return [];
            try {
              const t = JSON.parse(e);
              return Array.isArray(t)
                ? t.filter((e) => "string" == typeof e)
                : [];
            } catch {
              return [];
            }
          })(e?.enabledBetaFlags),
          n = r.includes("532bb929");
        return {
          browserTarget: cc(e?.browserTarget ?? ""),
          surface: t,
          enabledBetaFlags: r,
          isMerchantRequest: "true" === e?.isMerchantRequest,
          hashVersion: e?.hashVersion ?? "",
          shopId: dc(e?.shopId),
          apiClientId: Number(e?.apiClientId) || void 0,
          pageId: e?.pageId ?? ft(),
          pageType: e?.pageType,
          resourceId: e?.resourceId,
          storefrontBaseUrl:
            (window.location.origin || e?.storefrontBaseUrl) ?? "",
          extensionBaseUrl: e?.extensionBaseUrl ?? "",
          shopDomain: e?.shopDomain ?? window.Shopify?.shop ?? "",
          events: pc(e?.events),
          features: {
            domEvents: !n && "false" !== e?.domEvents && lc.includes(t),
            advancedDomEvents: !n && "false" !== e?.advancedDomEvents,
            storefrontEvents: "false" !== e?.storefrontEvents && lc.includes(t),
            cartPermalink:
              "false" !== e?.cartPermalink &&
              [...lc, u.CheckoutOne, u.CheckoutOneShopApp, u.Shopify].includes(
                t
              ),
            trekkieShim: "true" === e?.trekkieShim,
            agentContext: "true" === e?.agentContext,
          },
          scope: { publish: e?.publish === io.All ? io.All : io.Custom },
        };
      };
      try {
        !(function ({ configuration: e, eventHub: t }) {
          const r = window.location.href;
          wr.metadata = vn(e, [
            "shopId",
            "surface",
            "browserTarget",
            "shopDomain",
          ]);
          try {
            (({ storefrontBaseUrl: e }) => {
              if (!e) throw new br("storefrontBaseUrl is required.");
              if (
                !(function (e) {
                  try {
                    return new URL(e), !0;
                  } catch (t) {
                    return (function (e) {
                      const t = new RegExp(
                        "^(https?:\\/\\/)((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)*[a-z]{1,}|((\\d{1,3}\\.){3}\\d{1,3}))(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*(\\?[;&a-z\\d%_.~+=-]*)?(\\#[-a-z\\d_]*)?$",
                        "i"
                      );
                      return Boolean(t.test(e));
                    })(e);
                  }
                })(e)
              )
                throw new br(
                  `storefrontBaseUrl is not a valid absolute URL: "${e}"`
                );
            })(e);
            const s = new Qr({
              endpoint: nn(e.storefrontBaseUrl),
              onError: (e) => {
                wr.notify(e, {
                  context: "utilities/monorail/sendRequest",
                  unhandled: !1,
                  type: "metric",
                });
              },
            });
            (Ur = s),
              (function (e = []) {
                (Array.isArray(e) ? e : [e]).forEach((e) => rt.add(e));
              })(e.enabledBetaFlags);
            const a =
                t ??
                ((e, { monorailClient: t, onError: r, pageUrl: n }) => {
                  const o = new ns();
                  let i;
                  const s = () => (
                      i ||
                        (i = ((e) => {
                          return ((t =
                            "https://otlp-http-production.shopifysvc.com"),
                          new ya({
                            throttleDelay: 1e3,
                            client: new ra({
                              exporter: t
                                ? new ca(t, "web-pixels-manager")
                                : new _a("WPM OTel"),
                            }),
                          })).createClient({
                            metrics: xa,
                            prefix: "web_pixels_manager",
                            defaultAttributes: { surface: e.surface },
                          });
                          var t;
                        })(e)),
                      i
                    ),
                    a = [
                      Qi(
                        new ss(t, {
                          ...e,
                          analyticsProcessingAllowed: He,
                          marketingAllowed: qe,
                          preferencesProcessingAllowed: Ve,
                          saleOfDataAllowed: We,
                        }),
                        [o]
                      ),
                    ];
                  if (
                    (nt("f12a06f7") &&
                      a.push(
                        Qi(
                          new fs(
                            new vs(Lr, {
                              ...e,
                              analyticsProcessingAllowed: He,
                              marketingAllowed: qe,
                              preferencesProcessingAllowed: Ve,
                              saleOfDataAllowed: We,
                            }),
                            { surface: e.surface }
                          ),
                          [o]
                        )
                      ),
                    e.features.agentContext)
                  ) {
                    const e = new ys({ onError: r });
                    a.push(Qi(new ks({ client: e }), [o]));
                  }
                  if (e.features.storefrontEvents) {
                    (nt(st) || nt(at)) &&
                      a.push(
                        Qi(
                          new Os(t, {
                            ...e,
                            pageUrl: n ?? "",
                            analyticsProcessingAllowed: He,
                            marketingAllowed: qe,
                            preferencesProcessingAllowed: Ve,
                            saleOfDataAllowed: We,
                            onEmission: (e) => {
                              s().record("feature_usage", 1, {
                                feature: "monorail_emission",
                                schema_id: e.schemaId,
                                event_name: e.eventName,
                              });
                            },
                          }),
                          [o]
                        )
                      );
                    const r = Ft(e.pageType);
                    r &&
                      e.resourceId &&
                      a.push(
                        Qi(
                          new Us(t, {
                            ...e,
                            pageType: r,
                            resourceId: e.resourceId,
                            pageUrl: n ?? "",
                            analyticsProcessingAllowed: He,
                            marketingAllowed: qe,
                            preferencesProcessingAllowed: Ve,
                            saleOfDataAllowed: We,
                            onEmission: (e) => {
                              s().record("feature_usage", 1, {
                                feature: "monorail_emission",
                                schema_id: e.schemaId,
                                event_name: e.eventName,
                              });
                            },
                          }),
                          [o]
                        )
                      );
                  }
                  return (
                    a.push(
                      new zs(
                        new Ws(Lr, {
                          shopId: e.shopId,
                          surface: e.surface,
                          pageUrl: n ?? "",
                        })
                      )
                    ),
                    (nt("d5bdd5d0") || nt(it)) &&
                      a.push(
                        Qi(
                          new Ya(t, {
                            ...e,
                            analyticsProcessingAllowed: He,
                            marketingAllowed: qe,
                            preferencesProcessingAllowed: Ve,
                            saleOfDataAllowed: We,
                            isRemoteProduct: ic,
                            onProduce: (e) => {
                              s().record("feature_usage", 1, {
                                feature: "monorail_emission",
                                schema_id:
                                  "storefront_customer_tracking_parity",
                                event_name: e,
                              });
                            },
                          }),
                          [o]
                        ),
                        Qi(
                          new tc(t, {
                            onEventReceived: (t) => {
                              const r = s();
                              r.record("feature_usage", 1, {
                                feature: "monorail_forwarding",
                              }),
                                r.log("monorail_forwarding", {
                                  schema_id: t,
                                  shop_id: e.shopId,
                                  shop_domain: e.shopDomain,
                                  api_client_id: e.apiClientId,
                                  page_url: n,
                                });
                            },
                          }),
                          [o]
                        )
                      ),
                    a.push(
                      new oc(s(), {
                        analyticsProcessingAllowed: He,
                        marketingAllowed: qe,
                      })
                    ),
                    new Zi(a, {
                      onError: r,
                      bufferSize: 500,
                      replayKeep: "newest",
                    })
                  );
                })(e, {
                  pageUrl: r,
                  monorailClient: s,
                  onError: (e) => {
                    wr.notify(e, {
                      context: "createWebPixelsManager/eventHub",
                      severity: "warning",
                      unhandled: !1,
                    });
                  },
                }),
              l = a.emit.bind(a),
              {
                shopId: d,
                surface: f,
                storefrontBaseUrl: m,
                extensionBaseUrl: y,
                browserTarget: w,
                features: _,
                scope: x,
              } = e,
              k = {
                shopId: d,
                surface: f,
                browserTarget: w,
                pageUrl: r,
                storefrontBaseUrl: m,
                extensionBaseUrl: y,
                addMonorailEvent: Lr,
                logError: wr.notify,
                userConsent: Pr,
                getClientId: mn,
                emit: l,
              };
            if (self[Xt]) {
              const e = [];
              let t = {};
              try {
                const r = document.querySelectorAll(
                  "#web-pixels-manager-setup"
                );
                r.length > 0 &&
                  Array.from(r).map((t) => {
                    e.push(
                      Array.from(t.attributes).reduce(
                        (e, t) => ((e[t.name] = t.value), e),
                        {}
                      )
                    );
                  });
                const n = document.currentScript;
                n &&
                  (t = Array.from(n.attributes).reduce(
                    (e, t) => ((e[t.name] = t.value), e),
                    {}
                  ));
              } catch (n) {}
              const r = new c(
                `WebPixelsManager: ${Xt} global object is already defined`,
                {
                  groupingHash: "WebPixelsManager:GlobalObjectAlreadyDefined",
                  severity: "info",
                }
              );
              return (
                wr.notify(r, {
                  type: "metric",
                  context: "createWebPixelsManager",
                  severity: "info",
                  unhandled: !1,
                  notes: `setupScriptElementAttributes: ${JSON.stringify(
                    e
                  )}, currentScriptElementAttributes: ${JSON.stringify(t)}`,
                }),
                self[Xt]
              );
            }
            _.trekkieShim &&
              (async function ({ callback: e, onError: t }) {
                if (nt(it)) {
                  const e = window.trekkie;
                  Array.isArray(e) &&
                    e.forEach(function (t) {
                      if (
                        Array.isArray(t) &&
                        "ready" === t[0] &&
                        "function" == typeof t[1]
                      )
                        try {
                          t[1].call(e);
                        } catch {}
                    });
                }
                if (window.__TREKKIE_SHIM_QUEUE) {
                  for (; window.__TREKKIE_SHIM_QUEUE.length > 0; ) {
                    const {
                      from: r,
                      method: o,
                      args: i,
                    } = window.__TREKKIE_SHIM_QUEUE.shift();
                    try {
                      e({
                        from: `${r} -> wpm-replay-queue`,
                        method: o,
                        args: i,
                      });
                    } catch (n) {
                      t(n, { context: `trekkieShim/replay/${o}` });
                    }
                  }
                  window.__TREKKIE_SHIM_QUEUE.push = function (...r) {
                    return (
                      r.forEach(({ from: r, method: o, args: i }) => {
                        try {
                          e({
                            from: `${r} -> wpm-replay-queue-push`,
                            method: o,
                            args: i,
                          });
                        } catch (n) {
                          t(n, { context: `trekkieShim/push/${o}` });
                        }
                      }),
                      r.length
                    );
                  };
                }
                try {
                  await new Promise((e, t) => {
                    const r = window.__TREKKIE_SHIM_QUEUE;
                    if (!r)
                      return void t(
                        new Error(
                          "__TREKKIE_SHIM_QUEUE is not defined on the window object."
                        )
                      );
                    let n = !1;
                    const o = setTimeout(() => {
                        n ||
                          ((n = !0),
                          t(
                            new Error(
                              "Trekkie did not become ready within 30000ms."
                            )
                          ));
                      }, 3e4),
                      i = () => {
                        n || ((n = !0), clearTimeout(o), e(window.trekkie));
                      };
                    if (r.ready) return void i();
                    let s = !1;
                    Object.defineProperty(r, "ready", {
                      get: () => s,
                      set(e) {
                        (s = e), i();
                      },
                      configurable: !0,
                    });
                  });
                } catch {}
              })({
                callback: (e) => {
                  l("log:trekkie:track", e);
                },
                onError: (e, t) => {
                  wr.notify(e, { ...t, severity: "warning", unhandled: !1 });
                },
              }).catch((e) => {
                wr.notify(e, {
                  context: "createWebPixelsManager/trekkieShim",
                  severity: "warning",
                  unhandled: !1,
                });
              });
            const E = Mr("load", {
                version: Gt,
                bundleTarget: Zt,
                pageUrl: r,
                status: "loading",
                surface: f,
              }),
              S = sn(),
              A = {
                init(t) {
                  if (
                    (function () {
                      const e = `\\/(${Cr.Wpm}|${Cr.WebPixels})@(.+)\\/sandbox`;
                      return null !== self.location.href.match(new RegExp(e));
                    })()
                  )
                    return Yi;
                  const {
                      initData: a,
                      isMerchantRequest: y,
                      monorailRegion: w,
                      webPixelsConfigList: E,
                    } = t,
                    A = { ...t, ...e };
                  if (sc)
                    return (
                      wr.notify(
                        new c(
                          `WebPixelsManager: ${Xt} is being initialized multiple times`,
                          {
                            groupingHash:
                              "WebPixelsManager:MultipleInitialization",
                            severity: "info",
                          }
                        ),
                        {
                          type: "metric",
                          context: "createWebPixelsManager/init",
                          severity: "info",
                          unhandled: !1,
                          initConfig: A,
                        }
                      ),
                      sc
                    );
                  const I = (function () {
                    const e = self?.location?.hostname || "",
                      t = hn.get(e);
                    if (t) return t;
                    const r = e.split("."),
                      n = [];
                    return (
                      r.reverse().reduce((e, t) => {
                        const r = "" === e ? t : `${t}.${e}`;
                        return (
                          (function (e) {
                            dn(`${fn}=1; path=/; domain=${e}`);
                          })(r),
                          pn(fn) || n.push(r),
                          (function (e) {
                            dn(
                              `${fn}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; domain=${e}`
                            );
                          })(r),
                          r
                        );
                      }, ""),
                      hn.set(e, n),
                      n
                    );
                  })();
                  y && tr(() => self.sessionStorage.setItem(rr, "true")),
                    tt(),
                    s.setEndpoint(nn(m, w)),
                    (tr(() => "true" === self.sessionStorage.getItem(rr), !1) ||
                      f === u.CustomerAccount) &&
                      ro.init(A);
                  const P = ze().toString(),
                    C = Mr("unload", {
                      version: Gt,
                      bundleTarget: Zt,
                      pageUrl: r,
                      shopId: d,
                      surface: f,
                      isCompleted: "false",
                      runtimeErrorCaught: "false",
                      userCanBeTracked: P,
                      sessionId: S,
                    });
                  var O;
                  (O = C),
                    window.addEventListener("pagehide", () => {
                      (O.payload.pageDuration =
                        Nr("page:session")?.measurement?.duration),
                        Lr(O, !0);
                    });
                  const T = Zo(k),
                    N = (function (e) {
                      const t = new bn({
                        bufferSize: 1e3,
                        subscribeAllKey: "all_customer_privacy_events",
                      });
                      return (
                        t.use(Do),
                        {
                          publish(e, r, n) {
                            if ("string" != typeof e)
                              throw new c(
                                "Expected event name to be a string, but got " +
                                  typeof e,
                                {
                                  groupingHash:
                                    "CustomerPrivacyEventBus:PublishEventNameNotString",
                                }
                              );
                            if (e !== K)
                              throw new c(
                                `Expected event name to be a ${K}, but got "${e}".`,
                                {
                                  groupingHash:
                                    "CustomerPrivacyEventBus:PublishEventNameNotSupported",
                                }
                              );
                            return t.publish(e, r, n);
                          },
                          subscribe(r, n, o = {}) {
                            if (r !== K)
                              throw new c(
                                `Event name "${r}" is not supported in the CustomerPrivacyEventBus.`,
                                {
                                  groupingHash:
                                    "CustomerPrivacyEventBus:SubscribeEventNameNotSupported",
                                }
                              );
                            return t.subscribe(
                              r,
                              (t) => {
                                if (
                                  e === u.CheckoutOneSdk &&
                                  o.scope !== no.CheckoutOneSdk
                                )
                                  return;
                                const r = {
                                  configuration:
                                    o.pixelRuntimeConfig?.configuration,
                                  eventPayloadVersion:
                                    o.schemaVersion ||
                                    o.pixelRuntimeConfig?.eventPayloadVersion ||
                                    "unknown",
                                  id: o.pixelRuntimeConfig?.id || "unknown",
                                  type: o.pixelRuntimeConfig?.type || "unknown",
                                  runtimeContext:
                                    o.pixelRuntimeConfig?.runtimeContext ||
                                    "unknown",
                                  restrictions:
                                    o.pixelRuntimeConfig?.restrictions,
                                  scriptVersion:
                                    o.pixelRuntimeConfig?.scriptVersion ||
                                    "unknown",
                                  apiClientId:
                                    o.pixelRuntimeConfig?.apiClientId,
                                };
                                n.call(t, t),
                                  Br("subscriberEventEmitPrivacy", {
                                    version: Gt,
                                    bundleTarget: Zt,
                                    pageUrl: self.location.href,
                                    shopId: o.shopId,
                                    surface: o.surface,
                                    pixelId: r.id,
                                    pixelAppId: so(r),
                                    pixelSource: r.type,
                                    pixelRuntimeContext: r.runtimeContext,
                                    pixelScriptVersion: r.scriptVersion,
                                    pixelConfiguration: r.configuration,
                                    pixelEventSchemaVersion:
                                      r.eventPayloadVersion,
                                    eventName: K,
                                    eventId: ft(),
                                  });
                              },
                              o
                            );
                          },
                        }
                      );
                    })(f),
                    R = {
                      context: "createWebPixelsManager/init",
                      severity: "warning",
                      unhandled: !1,
                      initConfig: A,
                    },
                    $ = Mr("init", {
                      version: Gt,
                      bundleTarget: Zt,
                      pageUrl: r,
                      shopId: d,
                      surface: f,
                      status: "initializing",
                      userCanBeTracked: P,
                    });
                  try {
                    if (window.Shopify && !0 === window.Shopify.designMode)
                      return (
                        window.console &&
                          console.log(
                            "[WebPixelsManager] Prevented from executing in the Theme Editor"
                          ),
                        Yi
                      );
                    if (/^web-pixel-sandbox/.test(self.name)) {
                      const e = new br(
                        "WebPixelsManager: browser library is being run in a sandbox"
                      );
                      throw (
                        (wr.notify(e, {
                          ...R,
                          type: "metric",
                          library: "browser",
                        }),
                        e)
                      );
                    }
                    f === u.CheckoutOneSdk && (E.length = 0);
                    const t = E.reduce(
                      (e, t) => {
                        (t.type = t.type.toUpperCase()),
                          (t.runtimeContext = t.runtimeContext?.toUpperCase());
                        const r = pi(k, {
                          webPixelConfig: t,
                          eventBus: T,
                          customerPrivacyEventBus: N,
                          initData: a,
                          cookieRestrictedDomains: I,
                        });
                        return (
                          t.restrictions?.preventLoadingBeforeEvent
                            ? e.waiting.push(r)
                            : e.ready.push(r),
                          e
                        );
                      },
                      { ready: [], waiting: [] }
                    );
                    Promise.all(t.ready)
                      .then(() =>
                        (function (e) {
                          const { measurement: t } = Nr("completed");
                          (e.payload.isCompleted = "true"),
                            (e.payload.runTimeDuration = t?.duration),
                            (e.payload.startTime = t?.startTime);
                        })(C)
                      )
                      .catch((e) => {
                        window.console && console.error("[Web Pixels]", e);
                      }),
                      Promise.all(t.waiting).catch(() => {}),
                      (function () {
                        if (!Sr)
                          try {
                            document.addEventListener(K, Er), (Sr = !0);
                          } catch (n) {
                            wr.notify(n, {
                              context:
                                "onConsentCollected/createOnConsentCollectedListener",
                              unhandled: !1,
                            });
                          }
                      })(),
                      kr((e) => {
                        e &&
                          e.detail &&
                          N.publish(K, {
                            customerPrivacy: {
                              analyticsProcessingAllowed:
                                e.detail.analyticsAllowed,
                              marketingAllowed: e.detail.marketingAllowed,
                              preferencesProcessingAllowed:
                                e.detail.preferencesAllowed,
                              saleOfDataAllowed: e.detail.saleOfDataAllowed,
                            },
                          });
                      });
                    const r = (
                        f === u.CustomerAccount ? T.publish : T.publishDomEvent
                      ).bind(T),
                      s = { onError: wr.notify.bind(wr) };
                    if (_.storefrontEvents) {
                      try {
                        !(function (e, t) {
                          W(e, t),
                            (function (e, t) {
                              b((r) => {
                                const n = r.querySelector(
                                  '[name="previous_step"]'
                                );
                                n &&
                                  n instanceof HTMLInputElement &&
                                  "payment_method" === n.value &&
                                  g(document.body, "submit", (r) => {
                                    !(function (e, t, r) {
                                      const n = t || window.event;
                                      if (!n) return;
                                      const o = n.target || n.srcElement;
                                      if (
                                        o &&
                                        o instanceof HTMLFormElement &&
                                        o.getAttribute("action") &&
                                        null !==
                                          o.getAttribute("data-payment-form")
                                      )
                                        try {
                                          const t = r.checkout;
                                          if (!t)
                                            throw new c(
                                              "Checkout data not found"
                                            );
                                          e("payment_info_submitted", {
                                            checkout: t,
                                          });
                                        } catch {}
                                    })(e, r, t);
                                  });
                              });
                            })(e, t);
                        })(T.publish.bind(T), a);
                      } catch (n) {
                        wr.notify(n, {
                          context:
                            "createWebPixelsManager/createShopEventsListener",
                        });
                      }
                      (nt(st) || nt(at)) &&
                        or(1) &&
                        Ht({
                          context: {
                            pageType: e.pageType,
                            collectionId:
                              e.pageType === Wt ? e.resourceId : void 0,
                          },
                          onEvent: (e) => {
                            l("log:buyer-behavior:product-interaction", e);
                          },
                          onError: (e) => {
                            wr.notify(e, {
                              context:
                                "createWebPixelsManager/productInteractionProducer",
                              severity: "warning",
                              unhandled: !1,
                            });
                          },
                        }),
                        Ft(e.pageType) &&
                          e.resourceId &&
                          (function (e, { onError: t }) {
                            let r = !1,
                              n = 0,
                              o = 0,
                              i = null;
                            function s() {
                              if (r) return;
                              a();
                              const t = Jt[n];
                              if (void 0 === t) return;
                              const c = Math.max(0, t - o);
                              i = setTimeout(() => {
                                return (
                                  (i = null),
                                  (o = r = t),
                                  n++,
                                  e({ event: { dwellMilliseconds: r } }),
                                  void (n >= Jt.length ? u() : s())
                                );
                                var r;
                              }, c);
                            }
                            function a() {
                              null !== i && (clearTimeout(i), (i = null));
                            }
                            const c = It(
                              document,
                              "visibilitychange",
                              function () {
                                "visible" !== document.visibilityState
                                  ? (a(), (o = 0))
                                  : !r && n < Jt.length && s();
                              },
                              {
                                onError: (e) => {
                                  t(new Kt("PageDwellListenerError", e));
                                },
                              }
                            );
                            function u() {
                              r || ((r = !0), a(), c());
                            }
                            "visible" === document.visibilityState && s();
                          })((e) => l("log:buyer-behavior:page-dwell", e), {
                            onError: (e) => {
                              wr.notify(e, {
                                context:
                                  "createWebPixelsManager/pageDwellListener",
                                severity: "warning",
                                unhandled: !1,
                              });
                            },
                          });
                    }
                    return (
                      _.cartPermalink &&
                        (function (e, { cart: t }) {
                          try {
                            if (!window.localStorage) return;
                            const r = new URLSearchParams(
                              window.location.search
                            ).get(v);
                            if (!r) return;
                            if (r === window.localStorage.getItem(v)) return;
                            window.localStorage.setItem(v, r),
                              t?.lines.forEach((t) => {
                                j(e, t, t.quantity, h, "permalink");
                              });
                          } catch {}
                        })(T.publish.bind(T), a),
                      _.domEvents && Hi(r, s),
                      _.advancedDomEvents &&
                        E.some(({ capabilities: e }) =>
                          (e || []).includes(p.AdvancedDomEvents)
                        ) &&
                        ((D = r),
                        (M = s),
                        Ji.map((e) => {
                          try {
                            return e(D, M);
                          } catch (n) {
                            return (
                              M?.onError?.(n, {
                                context: "createAdvancedDomEventsListener",
                              }),
                              () => {}
                            );
                          }
                        }),
                        Hi(r, { ...s, eventPrefix: "advanced_dom_" })),
                      ($.payload.status = "initialized"),
                      Lr($),
                      (sc = (function (
                        e,
                        { eventBus: t, customerId: r, scope: n }
                      ) {
                        const o = (function (
                            {
                              addMonorailEvent: e,
                              logError: t,
                              userConsent: r,
                              shopId: n,
                              pageUrl: o,
                              surface: i,
                              getClientId: s,
                            },
                            a
                          ) {
                            return {
                              visitor: (c = {}, u) => {
                                const l = (function (e = {}, t) {
                                  if (!e || "object" != typeof e)
                                    return "Visitor info must be of type object";
                                  const { email: r, phone: n } = e;
                                  return r || n
                                    ? r && "string" != typeof r
                                      ? "Email must be of type string"
                                      : n && "string" != typeof n
                                      ? "Phone must be of type string"
                                      : t?.appId && "string" != typeof t.appId
                                      ? "appId must be of type string"
                                      : t?.apiClientId &&
                                        "string" != typeof t.apiClientId
                                      ? "apiClientId must be of type string"
                                      : null
                                    : "Visitor must have one of phone or email";
                                })(c, u);
                                if (l) throw new Xi(l);
                                return (
                                  r({
                                    analytics: !0,
                                    marketing: !0,
                                    preferences: !1,
                                    sale_of_data: !1,
                                  })
                                    .then(() =>
                                      e(
                                        Mr("visitor", {
                                          ...a,
                                          ...c,
                                          shopId: n,
                                          version: Gt,
                                          pageUrl: o,
                                          surface: i,
                                          apiClientId:
                                            u?.appId || u?.apiClientId,
                                          clientId: s(),
                                        })
                                      )
                                    )
                                    .catch(() =>
                                      t("visitor error", {
                                        severity: "error",
                                        context: "createVisitorApi/visitor",
                                        unhandled: !1,
                                        shopId: n,
                                        surface: i,
                                      })
                                    ),
                                  !0
                                );
                              },
                            };
                          })(e, { customerId: r }),
                          { shopId: s, surface: a } = e,
                          c = (e, r, o) =>
                            !(
                              a === u.CustomerAccount &&
                              !i(e) &&
                              n.publish !== io.All
                            ) && t.publish(e, r, o);
                        return {
                          publish: (e, t, r) => c(e, t, r),
                          publishCustomEvent: (e, r, n = {}) =>
                            a === u.CustomerAccount
                              ? c(e, r, n)
                              : t.publishCustomEvent(e, r, n),
                          publishDomEvent: (e, r, n = {}) =>
                            a === u.CustomerAccount
                              ? c(e, r, n)
                              : t.publishDomEvent(e, r, n),
                          subscribe: (e, r, n) =>
                            t.subscribe(e, r, {
                              ...n,
                              shopId: s,
                              surface: a,
                              scope:
                                a === u.CheckoutOneSdk
                                  ? no.CheckoutOneSdk
                                  : void 0,
                            }),
                          visitor: (e, t) => o.visitor(e, t),
                        };
                      })(k, {
                        eventBus: T,
                        customerId: a?.customer?.id,
                        scope: x,
                      })),
                      e.events.forEach(([e, t, r]) => {
                        try {
                          f === u.CustomerAccount || o(e)
                            ? T.publish(e, t, r)
                            : T.publishCustomEvent(e, t, r);
                        } catch (n) {
                          wr.notify(n, {
                            context: "createWebPixelsManager/init/replayEvents",
                            severity: "warning",
                            unhandled: !1,
                            initConfig: A,
                          });
                        }
                      }),
                      sc
                    );
                  } catch (n) {
                    return (
                      n instanceof br ||
                        wr.notify(n, { context: "init", initConfig: A }),
                      window.console && console.error(n),
                      ($.payload.status = "failed"),
                      ($.payload.errorMsg = n?.message),
                      Lr($),
                      (C.payload.runtimeErrorCaught = "true"),
                      Yi
                    );
                  }
                  var D, M;
                },
              };
            return (
              an(
                self,
                Xt,
                { value: A, writable: !1, configurable: !1, enumerable: !1 },
                !1
              ),
              (E.payload.status = "loaded"),
              Lr(E),
              A
            );
          } catch (n) {
            const t = n instanceof br || "WebPixelsHandledError" === n.name;
            return (
              wr.notify(n, {
                context: "createWebPixelsManager",
                severity: t ? "warning" : "error",
                unhandled: !t,
              }),
              window.console && console.error(n),
              Lr(
                Mr("load", {
                  version: Gt,
                  bundleTarget: Zt,
                  pageUrl: r,
                  status: "manager-create-error",
                  surface: e.surface,
                  errorMsg: n?.message,
                }),
                !0
              ),
              { init: () => Yi }
            );
          }
        })({ configuration: fc() });
      } catch (hc) {
        wr.notify(hc, {
          context: "entry-browser",
          severity: "error",
          unhandled: !1,
        });
      }
    })();
})();
