(function (shopify) {
  (() => {
    var E = (r, m, w) =>
      new Promise((x, A) => {
        var v = (g) => {
            try {
              k(w.next(g));
            } catch (h) {
              A(h);
            }
          },
          C = (g) => {
            try {
              k(w.throw(g));
            } catch (h) {
              A(h);
            }
          },
          k = (g) =>
            g.done ? x(g.value) : Promise.resolve(g.value).then(v, C);
        k((w = w.apply(r, m)).next());
      });
    var H = "WebPixel::Render";
    var T = (r) => shopify.extend(H, r);
    var Q = "https://connect.facebook.net/en_US/fbevents.js",
      Y = ["default", "title", "default title", ""];
    function Z() {
      (window.fbq && typeof window.fbq == "function") ||
        ((window.fbq = function (...r) {
          var m;
          window.fbq.callMethod
            ? window.fbq.callMethod.apply(window.fbq, r)
            : (m = window.fbq.queue) == null || m.push(r);
        }),
        window._fbq || (window._fbq = window.fbq),
        (window.fbq.push = window.fbq),
        (window.fbq.loaded = !0),
        (window.fbq.version = "2.0"),
        (window.fbq.queue = []));
    }
    function K() {
      let r = document.createElement("script");
      return r.setAttribute("async", "true"), r.setAttribute("src", Q), r;
    }
    function $() {
      var m;
      let r = document.getElementsByTagName("script")[0];
      r === void 0
        ? document.head.appendChild(K())
        : (m = r.parentNode) == null || m.insertBefore(K(), r);
    }
    Z();
    $();
    T(
      ({
        analytics: r,
        browser: m,
        settings: w,
        init: x,
        customerPrivacy: A,
        _pixelInfo: v,
      }) => {
        var G;
        let C = w.pixel_id,
          k = (G = v == null ? void 0 : v.runtimeContext) != null ? G : "OPEN";
        function g() {
          return E(this, null, function* () {
            if (m != null && m.cookie) {
              let [n, t, e] = yield Promise.all([
                m.cookie.get("_fbp").catch(() => ""),
                m.cookie.get("_fbc").catch(() => ""),
                m.cookie.get("_fbleid").catch(() => ""),
              ]);
              return { _fbp: n, _fbc: t, _fbleid: e };
            }
            return { _fbp: "", _fbc: "", _fbleid: "" };
          });
        }
        function h(n) {
          window.fbq("set", "shopifySandboxContext", {
            pixelId: C,
            runtimeContext: k,
            browser: m,
            context: x.context,
            initialCookies: n,
          });
        }
        h({ _fbp: "", _fbc: "", _fbleid: "" }),
          g().then((n) => {
            h(n);
          });
        function U(n) {
          let t = new Promise((o) => {
              window.fbq(
                "gateCheck",
                n,
                () => o(!0),
                () => o(!1),
                C
              );
            }),
            e = new Promise((o) => setTimeout(() => o(!1), 3e3));
          return Promise.race([t, e]);
        }
        function y(s, u) {
          return E(this, arguments, function* (n, t, e = {}, o = {}) {
            let [i, d] = yield Promise.all([
              U("shopify_sandbox_refresh_cookie"),
              U("shopify_sandbox"),
            ]);
            if (i && d) {
              let c = yield g();
              h(c);
            }
            window.fbq("trackShopify", C, n, e, { eventID: t }, o);
          });
        }
        function P(n) {
          return (
            (n == null ? void 0 : n.product.id) ||
            (n == null ? void 0 : n.id) ||
            (n == null ? void 0 : n.sku)
          );
        }
        function q(n) {
          return (
            (n == null ? void 0 : n.id) ||
            (n == null ? void 0 : n.sku) ||
            (n == null ? void 0 : n.product.id)
          );
        }
        function N(n) {
          let t = [],
            e = n.lineItems;
          if (e != null)
            for (let o of e) {
              let s = P(o.variant);
              s != null && t.push(parseInt(s));
            }
          return t;
        }
        function O(n) {
          var e;
          let t = n.lineItems;
          if (t != null) {
            for (let o of t)
              if ((e = o.variant) != null && e.product.id)
                return "product_group";
          }
          return "product";
        }
        function F(n) {
          let t = [],
            e = n.lineItems;
          if (e != null)
            for (let o of e) {
              let s = q(o.variant);
              s != null && t.push(parseInt(s));
            }
          return t;
        }
        function B(n) {
          var e, o;
          let t = n.lineItems;
          if (t != null) {
            for (let s of t)
              if (
                ((e = s.variant) != null && e.id) ||
                ((o = s.variant) != null && o.sku)
              )
                return "product";
          }
          return "product_group";
        }
        function M(n) {
          let t = 0,
            e = n.lineItems;
          if (e != null) for (let o of e) t += o.quantity || 1;
          return t;
        }
        function R(n) {
          var o, s, u, i, d, c, l, f;
          let t = [],
            e = n.lineItems;
          if (e != null)
            for (let p of e) {
              let _ =
                  ((o = p.variant) == null ? void 0 : o.product.id) ||
                  ((s = p.variant) == null ? void 0 : s.id) ||
                  ((u = p.variant) == null ? void 0 : u.sku),
                a =
                  ((i = p.variant) == null ? void 0 : i.id) ||
                  ((d = p.variant) == null ? void 0 : d.sku) ||
                  ((c = p.variant) == null ? void 0 : c.product.id);
              if (_ != null && a != null) {
                let b = {};
                (b.id = _ ? parseInt(_) : null),
                  (b.sku = a ? parseInt(a) : null),
                  (b.item_price =
                    ((f = (l = p.variant) == null ? void 0 : l.price) == null
                      ? void 0
                      : f.amount) || null),
                  (b.quantity = p.quantity || 1),
                  (b.currency = n.currencyCode || "USD"),
                  t.push(b);
              }
            }
          return t;
        }
        function D(n) {
          let t = {},
            e = P(n),
            o = q(n);
          return (
            e != null &&
              o != null &&
              ((t.id = e ? parseInt(e) : null),
              (t.sku = o ? parseInt(o) : null),
              (t.item_price = (n == null ? void 0 : n.price.amount) || null),
              (t.currency =
                (n == null ? void 0 : n.price.currencyCode) || "USD"),
              (t.quantity = 1)),
            t
          );
        }
        function J(n) {
          var e, o;
          let t = n.transactions;
          if (t != null && t.length > 0) {
            let s = t[0],
              u = s.gateway || "",
              i = ((e = s.paymentMethod) == null ? void 0 : e.name) || "",
              d = ((o = s.paymentMethod) == null ? void 0 : o.type) || "",
              c = {};
            return (c.gateway = u), (c.name = i), (c.type = d), c;
          }
          return null;
        }
        function j(n, t) {
          return t == null || Y.includes(t.toLowerCase())
            ? n || ""
            : n + " - " + t;
        }
        function I(n) {
          var o, s, u, i, d, c, l, f, p, _, a, b, W, X;
          let t = {};
          (t.ct =
            ((o = n.billingAddress) == null ? void 0 : o.city) ||
            ((s = n.shippingAddress) == null ? void 0 : s.city)),
            (t.country =
              ((u = n.billingAddress) == null ? void 0 : u.countryCode) ||
              ((i = n.shippingAddress) == null ? void 0 : i.countryCode)),
            (t.fn =
              ((d = n.billingAddress) == null ? void 0 : d.firstName) ||
              ((c = n.shippingAddress) == null ? void 0 : c.firstName)),
            (t.ln =
              ((l = n.billingAddress) == null ? void 0 : l.lastName) ||
              ((f = n.shippingAddress) == null ? void 0 : f.lastName)),
            (t.ph = n.phone),
            (t.st =
              ((p = n.billingAddress) == null ? void 0 : p.provinceCode) ||
              ((_ = n.shippingAddress) == null ? void 0 : _.provinceCode)),
            (t.zp =
              ((a = n.billingAddress) == null ? void 0 : a.zip) ||
              ((b = n.shippingAddress) == null ? void 0 : b.zip)),
            (t.em = n.email);
          let e =
            (X = (W = n.order) == null ? void 0 : W.customer) == null
              ? void 0
              : X.id;
          e != null && e.length > 0 && (t.external_id = e),
            window.fbq("set", "userData", t);
        }
        function z(n) {
          n
            ? window.fbq("dataProcessingOptions", [])
            : window.fbq("dataProcessingOptions", ["LDU"], 0, 0);
        }
        let S = x.customerPrivacy.saleOfDataAllowed;
        z(S),
          window.fbq("init", C, {}, { agent: "shopify_web_pixel" }),
          A.subscribe("visitorConsentCollected", (n) => {
            (S = n.customerPrivacy.saleOfDataAllowed), z(S);
          }),
          r.subscribe("page_viewed", (n) => {
            y("PageView", n.id);
          }),
          r.subscribe("search_submitted", (n) => {
            let t = n.data.searchResult.query || "",
              { productVariants: e } = n.data.searchResult,
              o = [];
            for (let s of e) {
              if (s == null) continue;
              let u = D(s);
              o.push(u);
            }
            y("Search", n.id, { search_string: t }, { contents: o });
          }),
          r.subscribe("product_viewed", (n) => {
            let { productVariant: t } = n.data,
              e = P(t),
              o = e ? [parseInt(e)] : [],
              s = t.product.id ? "product_group" : "product",
              u = j(t.product.title, t.title),
              i = t.product.type || "",
              d = t.price.currencyCode || "USD",
              c = t.price.amount || null,
              l = q(t),
              f = l ? [parseInt(l)] : [],
              p = t.id || t.sku ? "product" : "product_group",
              a = [D(t)];
            y(
              "ViewContent",
              n.id,
              {
                content_ids: o,
                content_type: s,
                content_name: u,
                content_category: i,
                currency: d,
                value: c,
              },
              {
                product_variant_ids: f,
                content_type_favor_variant: p,
                contents: a,
              }
            );
          }),
          r.subscribe("cart_viewed", (n) => {
            var s, u;
            let { cart: t } = n.data,
              e = [],
              o = t == null ? void 0 : t.lines;
            if (o != null && o.length > 0)
              for (let i of o) {
                let d = P(i == null ? void 0 : i.merchandise),
                  c = q(i == null ? void 0 : i.merchandise);
                if (d != null && c != null) {
                  let l = {};
                  (l.id = d ? parseInt(d) : null),
                    (l.sku = c ? parseInt(c) : null),
                    (l.item_price =
                      ((s = i == null ? void 0 : i.merchandise) == null
                        ? void 0
                        : s.price.amount) || null),
                    (l.quantity = (i == null ? void 0 : i.quantity) || 1),
                    (l.currency =
                      ((u = i == null ? void 0 : i.merchandise) == null
                        ? void 0
                        : u.price.currencyCode) || "USD"),
                    e.push(l);
                }
              }
            y(
              "ViewContent",
              n.id,
              { contents: e },
              { shopify_event_name: "cart_viewed" }
            );
          }),
          r.subscribe("collection_viewed", (n) => {
            let { collection: t } = n.data,
              e = t.productVariants,
              o = [];
            for (let s of e) {
              if (s == null) continue;
              let u = D(s);
              o.push(u);
            }
            y(
              "ViewContent",
              n.id,
              { contents: o },
              { shopify_event_name: "collection_viewed" }
            );
          }),
          r.subscribe("product_added_to_cart", (n) => {
            let { cartLine: t } = n.data,
              e = P(t == null ? void 0 : t.merchandise),
              o = e ? [parseInt(e)] : [],
              s =
                t != null && t.merchandise.product.id
                  ? "product_group"
                  : "product",
              u = j(
                t == null ? void 0 : t.merchandise.product.title,
                t == null ? void 0 : t.merchandise.title
              ),
              i = (t == null ? void 0 : t.merchandise.product.type) || "",
              d =
                (t == null ? void 0 : t.merchandise.price.currencyCode) ||
                "USD",
              c = (t == null ? void 0 : t.merchandise.price.amount) || null,
              l = (t == null ? void 0 : t.quantity) || 1,
              f = q(t == null ? void 0 : t.merchandise),
              p = f ? [parseInt(f)] : [],
              _ =
                (t != null && t.merchandise.id) ||
                (t != null && t.merchandise.sku)
                  ? "product"
                  : "product_group",
              a = {};
            (a.id = e ? parseInt(e) : null),
              (a.sku = f ? parseInt(f) : null),
              (a.item_price = c),
              (a.quantity = l),
              (a.currency = d);
            let b = [a];
            y(
              "AddToCart",
              n.id,
              {
                content_ids: o,
                content_type: s,
                content_name: u,
                content_category: i,
                currency: d,
                value: c,
                num_items: l,
              },
              {
                product_variant_ids: p,
                content_type_favor_variant: _,
                contents: b,
              }
            );
          }),
          r.subscribe("checkout_started", (n) => {
            var f;
            let { checkout: t } = n.data;
            I(t);
            let e = N(t),
              o = O(t),
              s = t.currencyCode || "USD",
              u = ((f = t.subtotalPrice) == null ? void 0 : f.amount) || 0,
              i = M(t),
              d = F(t),
              c = B(t),
              l = R(t);
            y(
              "InitiateCheckout",
              n.id,
              {
                content_ids: e,
                content_type: o,
                currency: s,
                value: u,
                num_items: i,
              },
              {
                product_variant_ids: d,
                content_type_favor_variant: c,
                contents: l,
              }
            );
          }),
          r.subscribe("checkout_completed", (n) => {
            var _, a;
            let { checkout: t } = n.data;
            I(t);
            let e = N(t),
              o = O(t),
              s = t.currencyCode || "USD",
              u = ((_ = t.totalPrice) == null ? void 0 : _.amount) || 0,
              i = M(t),
              d = F(t),
              c = B(t),
              l = R(t),
              f = (a = t.order) == null ? void 0 : a.id,
              p = J(t);
            y(
              "Purchase",
              n.id,
              {
                content_ids: e,
                content_type: o,
                currency: s,
                value: u,
                num_items: i,
              },
              {
                product_variant_ids: d,
                content_type_favor_variant: c,
                contents: l,
                order_id: f,
                payment_method: p,
              }
            );
          }),
          r.subscribe("payment_info_submitted", (n) => {
            var s;
            let { checkout: t } = n.data;
            I(t);
            let e = t.currencyCode || "USD",
              o = ((s = t.totalPrice) == null ? void 0 : s.amount) || 0;
            y("AddPaymentInfo", n.id, { currency: e, value: o });
          });
      }
    );
  })();
})(self.webPixelsManager.createShopifyExtend());
