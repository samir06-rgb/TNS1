(function (shopify) {
  (() => {
    var Pe = Object.defineProperty,
      Oe = Object.defineProperties;
    var Ue = Object.getOwnPropertyDescriptors;
    var be = Object.getOwnPropertySymbols;
    var Ge = Object.prototype.hasOwnProperty,
      Le = Object.prototype.propertyIsEnumerable;
    var z = (t, r, l) =>
        r in t
          ? Pe(t, r, {
              enumerable: !0,
              configurable: !0,
              writable: !0,
              value: l,
            })
          : (t[r] = l),
      P = (t, r) => {
        for (var l in r || (r = {})) Ge.call(r, l) && z(t, l, r[l]);
        if (be) for (var l of be(r)) Le.call(r, l) && z(t, l, r[l]);
        return t;
      },
      W = (t, r) => Oe(t, Ue(r));
    var V = (t, r, l) => z(t, typeof r != "symbol" ? r + "" : r, l);
    var Fe = "WebPixel::Render";
    var q = (t) => shopify.extend(Fe, t);
    var ye = {
      2: { percent: 100, enabled: !1 },
      3: { percent: 0, enabled: !1 },
      4: {
        percent: 100,
        enabled: !0,
        allowlist: new Set(["-277581468", "-1995663228"]),
      },
      5: {
        percent: 100,
        enabled: !0,
        allowlist: new Set(["1629646268", "-277581468", "-1995663228"]),
      },
      6: {
        percent: 0,
        enabled: !1,
        allowlist: new Set(["-277581468", "-1995663228"]),
      },
    };
    var X = class {
      constructor(r, l) {
        V(this, "currentShopDomainHash");
        V(this, "webPixelFeatureFlagConfig");
        (this.webPixelFeatureFlagConfig = l),
          r && (this.currentShopDomainHash = this.hashShopDomain(r)),
          this.initializeFeatureFlags();
      }
      hashShopDomain(r) {
        let l = 0;
        if (r.length === 0) return l.toString();
        for (let p = 0; p < r.length; p++) {
          let F = r.charCodeAt(p);
          (l = (l << 5) - l + F), (l |= 0);
        }
        return l.toString();
      }
      initializeFeatureFlags() {
        for (let r of Object.values(this.webPixelFeatureFlagConfig))
          r.allowlist &&
          this.currentShopDomainHash &&
          r.allowlist.has(this.currentShopDomainHash)
            ? (r.enabled = !0)
            : (r.enabled = r.percent > Math.random() * 100);
      }
      isFeatureFlagEnabled(r) {
        var l, p;
        return (p =
          (l = this.webPixelFeatureFlagConfig[r]) == null
            ? void 0
            : l.enabled) != null
          ? p
          : !1;
      }
    };
    var xe = "developer_id.dYmNjMT",
      O = "dNzYwYj";
    function ve(t) {
      let r = t.init.customerPrivacy;
      if (r === void 0 || r.marketingAllowed || r.analyticsProcessingAllowed)
        Ie(t, r);
      else {
        let l = !1;
        t.customerPrivacy.subscribe("visitorConsentCollected", (p) => {
          let F = p.customerPrivacy;
          !l &&
            (F.marketingAllowed || F.analyticsProcessingAllowed) &&
            (Ie(t, F), (l = !0));
        });
      }
    }
    function Ie(t, r) {
      var Z, J, K, Q, k, ee, te, ne, ie, ae, re, le, oe, se, de;
      let l = (window.dataLayer = window.dataLayer || []),
        p = JSON.parse(t.settings.config),
        F = [],
        c = new X(
          (K =
            (J = (Z = t.init) == null ? void 0 : Z.data) == null
              ? void 0
              : J.shop) == null
            ? void 0
            : K.myshopifyDomain,
          ye
        );
      if (p.google_tag_ids && p.google_tag_ids.length > 0) {
        let e = p.google_tag_ids;
        F.push(...e);
      } else F.push(p.pixel_id);
      let g = (window.gtag =
        window.gtag ||
        function () {
          l.push(arguments);
        });
      r && (g("consent", "default", Re(r)), g("set", De(r))),
        G(t) &&
          (g("set", { ignore_referrer: "true" }),
          g("policy", "detect_click_events", () => !1),
          g("policy", "detect_element_visibility_events", () => !1),
          g("policy", "detect_history_change_events", () => !1),
          g("policy", "detect_link_click_events", () => !1),
          g("policy", "detect_timer_events", () => !1),
          g("policy", "detect_youtube_activity_events", () => !1),
          g("policy", "detect_scroll_events", () => !1)),
        g("policy", "internal_sw_allowed", () => !1),
        g("policy", "inject_cmp_banner", () => !1),
        g("set", xe, !0),
        g("js", new Date());
      let H = { send_page_view: !1 };
      G(t) && (H.ignore_referrer = "true");
      for (let e of F) {
        let i = document.createElement("script"),
          n = `https://www.googletagmanager.com/gtag/js?id=${e}`;
        c.isFeatureFlagEnabled(6) &&
          String(e || "").startsWith("GTM-") &&
          (n += "&google_only=true"),
          (i.src = n),
          document.body.appendChild(i),
          g("config", e, H);
      }
      let R = p.gtag_events,
        T = (e) => {
          var i;
          return (
            "shopify_" +
            (p.target_country || "US") +
            "_" +
            String(
              (i = e == null ? void 0 : e.product) == null ? void 0 : i.id
            ) +
            "_" +
            String(e == null ? void 0 : e.id)
          );
        },
        U = (e) => {
          let i = e == null ? void 0 : e.title;
          return ["default", "title", "default title", ""].includes(
            String(i).toLowerCase()
          )
            ? null
            : i;
        },
        j = (e) => {
          var u, m, N, a, A, f, y, I, d, E, v, b;
          let n = {
              value:
                (u = e == null ? void 0 : e.subtotalPrice) == null
                  ? void 0
                  : u.amount,
            },
            s =
              (N =
                (m = e == null ? void 0 : e.totalPrice) == null
                  ? void 0
                  : m.amount) != null
                ? N
                : 0;
          (s -=
            (A =
              (a = e == null ? void 0 : e.totalTax) == null
                ? void 0
                : a.amount) != null
              ? A
              : 0),
            (s -=
              (I =
                (y =
                  (f = e == null ? void 0 : e.shippingLine) == null
                    ? void 0
                    : f.price) == null
                  ? void 0
                  : y.amount) != null
                ? I
                : 0);
          let _ = 0,
            o = (d = e == null ? void 0 : e.lineItems) != null ? d : [];
          for (let C of o) {
            let D =
              (v = (E = C.variant) == null ? void 0 : E.price.amount) != null
                ? v
                : 0;
            D *= C.quantity;
            for (let S of C.discountAllocations)
              D -= (b = S.amount.amount) != null ? b : 0;
            _ += D;
          }
          return n;
        },
        Y = (e, i) => (i ? `${e} - ${i}` : e),
        Te = (e, i) => {
          var n;
          if (e === "/search") {
            let s =
              (n = document.querySelector("link[rel='canonical']")) == null
                ? void 0
                : n.getAttribute("href");
            if (s) return s;
          }
          return i;
        },
        $ = (e) => e && e.endsWith("thank_you"),
        we = (e, i, n) => ($(e) ? Y(i, n) : i),
        h = (e) => {
          var i, n, s, _, o, u, m;
          return {
            email: e == null ? void 0 : e.email,
            phone_number: e == null ? void 0 : e.phone,
            address: {
              first_name:
                (i = e == null ? void 0 : e.billingAddress) == null
                  ? void 0
                  : i.firstName,
              last_name:
                (n = e == null ? void 0 : e.billingAddress) == null
                  ? void 0
                  : n.lastName,
              street:
                (s = e == null ? void 0 : e.billingAddress) == null
                  ? void 0
                  : s.address1,
              city:
                (_ = e == null ? void 0 : e.billingAddress) == null
                  ? void 0
                  : _.city,
              region:
                (o = e == null ? void 0 : e.billingAddress) == null
                  ? void 0
                  : o.province,
              postal_code:
                (u = e == null ? void 0 : e.billingAddress) == null
                  ? void 0
                  : u.zip,
              country:
                (m = e == null ? void 0 : e.billingAddress) == null
                  ? void 0
                  : m.country,
            },
          };
        },
        w = (e) => (e ? `shp.${e}` : void 0),
        Se = (e, i) => {
          var _, o, u, m, N, a, A, f, y, I, d, E, v;
          let n = (_ = i.data) == null ? void 0 : _.checkout;
          return P(
            W(
              P(
                {
                  send_to: e,
                  developer_id: { [O]: !0 },
                  event_id: c.isFeatureFlagEnabled(5) ? i.id : void 0,
                  ext_client_id: c.isFeatureFlagEnabled(5)
                    ? w(i.clientId)
                    : void 0,
                  transaction_id:
                    (o = n == null ? void 0 : n.order) == null ? void 0 : o.id,
                  new_customer:
                    ((m =
                      (u = n == null ? void 0 : n.order) == null
                        ? void 0
                        : u.customer) == null
                      ? void 0
                      : m.isFirstOrder) == null ||
                    (a =
                      (N = n == null ? void 0 : n.order) == null
                        ? void 0
                        : N.customer) == null
                      ? void 0
                      : a.isFirstOrder,
                },
                j(n)
              ),
              {
                customer_type: Me(
                  (f =
                    (A = n == null ? void 0 : n.order) == null
                      ? void 0
                      : A.customer) == null
                    ? void 0
                    : f.isFirstOrder
                ),
                currency:
                  ((y = n == null ? void 0 : n.subtotalPrice) == null
                    ? void 0
                    : y.currencyCode) || "USD",
                tax:
                  (I = n == null ? void 0 : n.totalTax) == null
                    ? void 0
                    : I.amount,
                shipping:
                  (E =
                    (d = n == null ? void 0 : n.shippingLine) == null
                      ? void 0
                      : d.price) == null
                    ? void 0
                    : E.amount,
                items:
                  (v = n == null ? void 0 : n.lineItems) == null
                    ? void 0
                    : v.map((b) => {
                        var C,
                          D,
                          S,
                          L,
                          x,
                          M,
                          _e,
                          Ee,
                          ue,
                          ge,
                          ce,
                          fe,
                          pe,
                          me,
                          Ne,
                          Ae;
                        return {
                          id: T(b.variant),
                          name: c.isFeatureFlagEnabled(4)
                            ? (D =
                                (C = b.variant) == null ? void 0 : C.product) ==
                              null
                              ? void 0
                              : D.title
                            : we(
                                (x =
                                  (L =
                                    (S = i.context) == null
                                      ? void 0
                                      : S.window) == null
                                    ? void 0
                                    : L.location) == null
                                  ? void 0
                                  : x.pathname,
                                (_e =
                                  (M = b.variant) == null
                                    ? void 0
                                    : M.product) == null
                                  ? void 0
                                  : _e.title,
                                U(b.variant)
                              ),
                          brand:
                            (ue =
                              (Ee = b.variant) == null ? void 0 : Ee.product) ==
                            null
                              ? void 0
                              : ue.vendor,
                          category:
                            (ce =
                              (ge = b.variant) == null ? void 0 : ge.product) ==
                            null
                              ? void 0
                              : ce.type,
                          coupon:
                            (me =
                              (pe =
                                (fe = b.discountAllocations) == null
                                  ? void 0
                                  : fe[0]) == null
                                ? void 0
                                : pe.discountApplication) == null
                              ? void 0
                              : me.title,
                          price:
                            (Ae =
                              (Ne = b.variant) == null ? void 0 : Ne.price) ==
                            null
                              ? void 0
                              : Ae.amount,
                          quantity: b.quantity,
                          variant: U(b.variant),
                        };
                      }),
                user_data: h(n),
              }
            ),
            !c.isFeatureFlagEnabled(2) && G(t) && { ignore_referrer: "true" }
          );
        },
        B = {
          email:
            (ee =
              (k = (Q = t.init) == null ? void 0 : Q.data) == null
                ? void 0
                : k.customer) == null
              ? void 0
              : ee.email,
          phone_number:
            (ie =
              (ne = (te = t.init) == null ? void 0 : te.data) == null
                ? void 0
                : ne.customer) == null
              ? void 0
              : ie.phone,
          address: {
            first_name:
              (le =
                (re = (ae = t.init) == null ? void 0 : ae.data) == null
                  ? void 0
                  : re.customer) == null
                ? void 0
                : le.firstName,
            last_name:
              (de =
                (se = (oe = t.init) == null ? void 0 : oe.data) == null
                  ? void 0
                  : se.customer) == null
                ? void 0
                : de.lastName,
          },
        };
      t.analytics.subscribe("page_viewed", (e) => {
        var n, s, _, o, u, m, N, a;
        let i = R.find((A) => A.type === "page_view");
        if (i && i.action_label) {
          let A =
              (_ =
                (s = (n = e.context) == null ? void 0 : n.window) == null
                  ? void 0
                  : s.location) == null
                ? void 0
                : _.pathname,
            f = P(
              {
                send_to: i.action_label,
                developer_id: { [O]: !0 },
                event_id: c.isFeatureFlagEnabled(5) ? e.id : void 0,
                ext_client_id: c.isFeatureFlagEnabled(5)
                  ? w(e.clientId)
                  : void 0,
                page_path: A,
                page_title: Be(
                  (u = (o = e.context) == null ? void 0 : o.document) == null
                    ? void 0
                    : u.title,
                  A
                ),
                page_location: Te(
                  A,
                  (a =
                    (N = (m = e.context) == null ? void 0 : m.window) == null
                      ? void 0
                      : N.location) == null
                    ? void 0
                    : a.href
                ),
                user_data: B,
              },
              !c.isFeatureFlagEnabled(2) && G(t) && { ignore_referrer: "true" }
            );
          g("event", "page_view", f);
        }
      }),
        t.analytics.subscribe("product_viewed", (e) => {
          var n, s, _, o, u, m, N;
          let i = R.find((a) => a.type === "view_item");
          if (i && i.action_label) {
            let a = (n = e.data) == null ? void 0 : n.productVariant;
            g("event", "view_item", {
              send_to: i.action_label,
              developer_id: { [O]: !0 },
              event_id: c.isFeatureFlagEnabled(5) ? e.id : void 0,
              ext_client_id: c.isFeatureFlagEnabled(5) ? w(e.clientId) : void 0,
              ecomm_prodid: [T(a)],
              ecomm_totalvalue:
                (s = a == null ? void 0 : a.price) == null ? void 0 : s.amount,
              ecomm_pagetype: "product",
              items: [
                {
                  id: T(a),
                  name: c.isFeatureFlagEnabled(4)
                    ? (_ = a == null ? void 0 : a.product) == null
                      ? void 0
                      : _.title
                    : Y(
                        (o = a == null ? void 0 : a.product) == null
                          ? void 0
                          : o.title,
                        U(a)
                      ),
                  brand:
                    (u = a == null ? void 0 : a.product) == null
                      ? void 0
                      : u.vendor,
                  category:
                    (m = a == null ? void 0 : a.product) == null
                      ? void 0
                      : m.type,
                  price:
                    (N = a == null ? void 0 : a.price) == null
                      ? void 0
                      : N.amount,
                  variant: U(a),
                },
              ],
              user_data: B,
            });
          }
        }),
        t.analytics.subscribe("product_added_to_cart", (e) => {
          var n, s, _, o, u, m, N, a, A, f, y, I;
          let i = R.find((d) => d.type === "add_to_cart");
          if (i && i.action_label) {
            let d = (n = e.data) == null ? void 0 : n.cartLine,
              E = d == null ? void 0 : d.merchandise;
            g("event", "add_to_cart", {
              send_to: i.action_label,
              developer_id: { [O]: !0 },
              event_id: c.isFeatureFlagEnabled(5) ? e.id : void 0,
              ext_client_id: c.isFeatureFlagEnabled(5) ? w(e.clientId) : void 0,
              ecomm_prodid: [T(d == null ? void 0 : d.merchandise)],
              ecomm_totalvalue:
                (_ =
                  (s = d == null ? void 0 : d.cost) == null
                    ? void 0
                    : s.totalAmount) == null
                  ? void 0
                  : _.amount,
              ecomm_pagetype: "cart",
              value:
                (u =
                  (o = d == null ? void 0 : d.cost) == null
                    ? void 0
                    : o.totalAmount) == null
                  ? void 0
                  : u.amount,
              currency:
                ((N =
                  (m = d == null ? void 0 : d.cost) == null
                    ? void 0
                    : m.totalAmount) == null
                  ? void 0
                  : N.currencyCode) || "USD",
              items: [
                {
                  id: T(E),
                  name: c.isFeatureFlagEnabled(4)
                    ? (a = E == null ? void 0 : E.product) == null
                      ? void 0
                      : a.title
                    : Y(
                        (A = E == null ? void 0 : E.product) == null
                          ? void 0
                          : A.title,
                        U(E)
                      ),
                  brand:
                    (f = E == null ? void 0 : E.product) == null
                      ? void 0
                      : f.vendor,
                  category:
                    (y = E == null ? void 0 : E.product) == null
                      ? void 0
                      : y.type,
                  price:
                    (I = E == null ? void 0 : E.price) == null
                      ? void 0
                      : I.amount,
                  quantity: d == null ? void 0 : d.quantity,
                  variant: U(E),
                },
              ],
              user_data: B,
            });
          }
        }),
        t.analytics.subscribe("checkout_completed", (e) => {
          var s, _, o;
          let i = [],
            n = R.find((u) => u.type === "purchase");
          Ce(n, i),
            c.isFeatureFlagEnabled(3) &&
              !$(
                (o =
                  (_ = (s = e.context) == null ? void 0 : s.window) == null
                    ? void 0
                    : _.location) == null
                  ? void 0
                  : o.pathname
              ) &&
              ((n = R.find((u) => u.type === "purchase_new_page_only")),
              Ce(n, i)),
            i.length > 0 && g("event", "purchase", Se(i, e));
        }),
        t.analytics.subscribe("checkout_started", (e) => {
          var n, s, _, o, u, m, N;
          let i = R.find((a) => a.type === "begin_checkout");
          if (i && i.action_label) {
            let a = (n = e.data) == null ? void 0 : n.checkout,
              A = P(
                W(
                  P(
                    {
                      send_to: i.action_label,
                      developer_id: { [O]: !0 },
                      event_id: c.isFeatureFlagEnabled(5) ? e.id : void 0,
                      ext_client_id: c.isFeatureFlagEnabled(5)
                        ? w(e.clientId)
                        : void 0,
                      ecomm_prodid:
                        (s = a == null ? void 0 : a.lineItems) == null
                          ? void 0
                          : s.map((f) => T(f.variant)),
                      ecomm_totalvalue:
                        (_ = a == null ? void 0 : a.subtotalPrice) == null
                          ? void 0
                          : _.amount,
                      ecomm_pagetype: "cart",
                    },
                    j(a)
                  ),
                  {
                    currency:
                      ((o = a == null ? void 0 : a.subtotalPrice) == null
                        ? void 0
                        : o.currencyCode) || "USD",
                    coupon:
                      (m =
                        (u = a == null ? void 0 : a.discountApplications) ==
                        null
                          ? void 0
                          : u[0]) == null
                        ? void 0
                        : m.title,
                    items:
                      (N = a == null ? void 0 : a.lineItems) == null
                        ? void 0
                        : N.map((f) => {
                            var y, I, d, E, v, b, C, D, S, L, x, M;
                            return {
                              id: T(f.variant),
                              name:
                                (I =
                                  (y = f.variant) == null
                                    ? void 0
                                    : y.product) == null
                                  ? void 0
                                  : I.title,
                              brand:
                                (E =
                                  (d = f.variant) == null
                                    ? void 0
                                    : d.product) == null
                                  ? void 0
                                  : E.vendor,
                              category:
                                (b =
                                  (v = f.variant) == null
                                    ? void 0
                                    : v.product) == null
                                  ? void 0
                                  : b.type,
                              coupon:
                                (S =
                                  (D =
                                    (C = f.discountAllocations) == null
                                      ? void 0
                                      : C[0]) == null
                                    ? void 0
                                    : D.discountApplication) == null
                                  ? void 0
                                  : S.title,
                              price:
                                (x =
                                  (L = f.variant) == null ? void 0 : L.price) ==
                                null
                                  ? void 0
                                  : x.amount,
                              quantity: f.quantity,
                              variant:
                                (M = f.variant) == null ? void 0 : M.title,
                            };
                          }),
                    user_data: h(a),
                  }
                ),
                !c.isFeatureFlagEnabled(2) &&
                  G(t) && { ignore_referrer: "true" }
              );
            g("event", "begin_checkout", A);
          }
        }),
        t.analytics.subscribe("search_submitted", (e) => {
          var n, s;
          let i = R.find((_) => _.type === "search");
          i &&
            i.action_label &&
            g("event", "search", {
              send_to: i.action_label,
              developer_id: { [O]: !0 },
              event_id: c.isFeatureFlagEnabled(5) ? e.id : void 0,
              ext_client_id: c.isFeatureFlagEnabled(5) ? w(e.clientId) : void 0,
              search_term:
                (s = (n = e.data) == null ? void 0 : n.searchResult) == null
                  ? void 0
                  : s.query,
              user_data: B,
            });
        }),
        t.analytics.subscribe("payment_info_submitted", (e) => {
          var n, s, _;
          let i = R.find((o) => o.type === "add_payment_info");
          if (i && i.action_label) {
            let o = (n = e.data) == null ? void 0 : n.checkout,
              u = P(
                {
                  send_to: i.action_label,
                  developer_id: { [O]: !0 },
                  event_id: c.isFeatureFlagEnabled(5) ? e.id : void 0,
                  ext_client_id: c.isFeatureFlagEnabled(5)
                    ? w(e.clientId)
                    : void 0,
                  currency:
                    ((s = o == null ? void 0 : o.totalPrice) == null
                      ? void 0
                      : s.currencyCode) || "USD",
                  total:
                    (_ = o == null ? void 0 : o.totalPrice) == null
                      ? void 0
                      : _.amount,
                  user_data: h(o),
                },
                !c.isFeatureFlagEnabled(2) &&
                  G(t) && { ignore_referrer: "true" }
              );
            g("event", "add_payment_info", u);
          }
        }),
        t.customerPrivacy.subscribe("visitorConsentCollected", (e) => {
          let i = e.customerPrivacy;
          g("consent", "update", Re(i)), g("set", De(i));
        });
    }
    function Ce(t, r) {
      if (t && t.action_label) {
        let l = Array.isArray(t.action_label)
          ? t.action_label
          : [t.action_label];
        for (let p of l) r.includes(p) || r.push(p);
      }
    }
    function De(t) {
      return { restricted_data_processing: !t.saleOfDataAllowed };
    }
    function Re(t) {
      return {
        ad_storage: t.marketingAllowed ? "granted" : "denied",
        ad_user_data: t.marketingAllowed ? "granted" : "denied",
        ad_personalization: t.marketingAllowed ? "granted" : "denied",
        analytics_storage: t.analyticsProcessingAllowed ? "granted" : "denied",
      };
    }
    function Me(t) {
      if (t != null) return t ? "new" : "returning";
    }
    function G(t) {
      var r;
      return (
        ((r = t == null ? void 0 : t._pixelInfo) == null
          ? void 0
          : r.surfaceNext) === "checkout"
      );
    }
    function Be(t, r) {
      if (!r) return t;
      let l = [
        ["/information", "Checkout - Contact Information"],
        ["/shipping", "Checkout - Shipping"],
        ["/payment", "Checkout - Payment"],
        ["/review", "Checkout - Review"],
        ["/processing", "Checkout - Processing"],
        ["/thank-you", "Checkout - Receipt"],
        ["/stock-problems", "Checkout - Stock problems"],
        ["/error", "Checkout - Error"],
      ];
      for (let [p, F] of l) if (r.endsWith(p)) return F;
      return /^\/checkouts\/[A-Za-z0-9]+\/[A-Za-z0-9]+$/.test(r)
        ? "Checkout - Contact Information"
        : t;
    }
    q(ve);
  })();
})(self.webPixelsManager.createShopifyExtend());
