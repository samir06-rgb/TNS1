// Copyright 2012 Google Inc. All rights reserved.

(function () {
  var data = {
    resource: {
      version: "2",

      macros: [
        {
          function: "__u",
          vtp_component: "URL",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "HOST",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "PATH",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        { function: "__f", vtp_component: "URL" },
        { function: "__e" },
      ],
      tags: [],
      predicates: [],
      rules: [],
    },
    runtime: [
      [
        50,
        "__e",
        [46, "a"],
        [
          36,
          [
            13,
            [41, "$0"],
            [3, "$0", ["require", "internal.getEventData"]],
            ["$0", "event"],
          ],
        ],
      ],
      [
        50,
        "__f",
        [46, "a"],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "getReferrerUrl"]],
        [52, "d", ["require", "makeString"]],
        [52, "e", ["require", "parseUrl"]],
        [52, "f", [15, "__module_legacyUrls"]],
        [52, "g", [30, ["b", "gtm.referrer", 1], ["c"]]],
        [22, [28, [15, "g"]], [46, [36, ["d", [15, "g"]]]]],
        [
          38,
          [17, [15, "a"], "component"],
          [46, "PROTOCOL", "HOST", "PORT", "PATH", "QUERY", "FRAGMENT", "URL"],
          [
            46,
            [5, [46, [36, [2, [15, "f"], "B", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "C",
                    [7, [15, "g"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "D", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "E",
                    [7, [15, "g"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [
              5,
              [
                46,
                [
                  22,
                  [17, [15, "a"], "queryKey"],
                  [
                    46,
                    [
                      53,
                      [
                        36,
                        [
                          2,
                          [15, "f"],
                          "H",
                          [7, [15, "g"], [17, [15, "a"], "queryKey"]],
                        ],
                      ],
                    ],
                  ],
                ],
                [52, "h", ["e", [15, "g"]]],
                [36, [2, [17, [15, "h"], "search"], "replace", [7, "?", ""]]],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "G", [7, [15, "g"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "f"], "A", [7, ["d", [15, "g"]]]]]]],
          ],
        ],
      ],
      [
        50,
        "__u",
        [46, "a"],
        [
          50,
          "k",
          [46, "l", "m"],
          [52, "n", [17, [15, "m"], "multiQueryKeys"]],
          [52, "o", [30, [17, [15, "m"], "queryKey"], ""]],
          [52, "p", [17, [15, "m"], "ignoreEmptyQueryParam"]],
          [
            22,
            [20, [15, "o"], ""],
            [
              46,
              [
                53,
                [
                  52,
                  "r",
                  [
                    2,
                    [17, ["i", [15, "l"]], "search"],
                    "replace",
                    [7, "?", ""],
                  ],
                ],
                [36, [39, [1, [28, [15, "r"]], [15, "p"]], [44], [15, "r"]]],
              ],
            ],
          ],
          [41, "q"],
          [
            22,
            [15, "n"],
            [
              46,
              [
                53,
                [
                  22,
                  [20, ["e", [15, "o"]], "array"],
                  [46, [53, [3, "q", [15, "o"]]]],
                  [
                    46,
                    [
                      53,
                      [52, "r", ["c", "\\s+", "g"]],
                      [
                        3,
                        "q",
                        [
                          2,
                          [2, ["f", [15, "o"]], "replace", [7, [15, "r"], ""]],
                          "split",
                          [7, ","],
                        ],
                      ],
                    ],
                  ],
                ],
              ],
            ],
            [46, [53, [3, "q", [7, ["f", [15, "o"]]]]]],
          ],
          [
            65,
            "r",
            [15, "q"],
            [
              46,
              [
                53,
                [52, "s", [2, [15, "h"], "H", [7, [15, "l"], [15, "r"]]]],
                [
                  22,
                  [29, [15, "s"], [44]],
                  [
                    46,
                    [
                      53,
                      [
                        22,
                        [1, [15, "p"], [20, [15, "s"], ""]],
                        [46, [53, [6]]],
                      ],
                      [36, [15, "s"]],
                    ],
                  ],
                ],
              ],
            ],
          ],
          [36, [44]],
        ],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "internal.createRegex"]],
        [52, "d", ["require", "getUrl"]],
        [52, "e", ["require", "getType"]],
        [52, "f", ["require", "makeString"]],
        [52, "g", ["require", "parseUrl"]],
        [52, "h", [15, "__module_legacyUrls"]],
        [52, "i", ["require", "internal.legacyParseUrl"]],
        [41, "j"],
        [
          22,
          [17, [15, "a"], "customUrlSource"],
          [46, [53, [3, "j", [17, [15, "a"], "customUrlSource"]]]],
          [46, [53, [3, "j", ["b", "gtm.url", 1]]]],
        ],
        [3, "j", [30, [15, "j"], ["d"]]],
        [
          38,
          [17, [15, "a"], "component"],
          [
            46,
            "PROTOCOL",
            "HOST",
            "PORT",
            "PATH",
            "EXTENSION",
            "QUERY",
            "FRAGMENT",
            "URL",
          ],
          [
            46,
            [5, [46, [36, [2, [15, "h"], "B", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "C",
                    [7, [15, "j"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "D", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "E",
                    [7, [15, "j"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "F", [7, [15, "j"]]]]]],
            [5, [46, [36, ["k", [15, "j"], [15, "a"]]]]],
            [5, [46, [36, [2, [15, "h"], "G", [7, [15, "j"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "h"], "A", [7, ["f", [15, "j"]]]]]]],
          ],
        ],
      ],
      [
        52,
        "__module_legacyUrls",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [
                  50,
                  "h",
                  [46, "p"],
                  [52, "q", [2, [15, "p"], "indexOf", [7, "#"]]],
                  [
                    36,
                    [
                      39,
                      [23, [15, "q"], 0],
                      [15, "p"],
                      [2, [15, "p"], "substring", [7, 0, [15, "q"]]],
                    ],
                  ],
                ],
                [
                  50,
                  "i",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "protocol"]],
                  [
                    36,
                    [
                      39,
                      [15, "q"],
                      [2, [15, "q"], "replace", [7, ":", ""]],
                      "",
                    ],
                  ],
                ],
                [
                  50,
                  "j",
                  [46, "p", "q"],
                  [41, "r"],
                  [3, "r", [17, ["e", [15, "p"]], "hostname"]],
                  [22, [28, [15, "r"]], [46, [36, ""]]],
                  [52, "s", ["b", ":[0-9]+"]],
                  [3, "r", [2, [15, "r"], "replace", [7, [15, "s"], ""]]],
                  [
                    22,
                    [15, "q"],
                    [
                      46,
                      [
                        53,
                        [52, "t", ["b", "^www\\d*\\."]],
                        [52, "u", [2, [15, "r"], "match", [7, [15, "t"]]]],
                        [
                          22,
                          [1, [15, "u"], [16, [15, "u"], 0]],
                          [
                            46,
                            [
                              3,
                              "r",
                              [
                                2,
                                [15, "r"],
                                "substring",
                                [7, [17, [16, [15, "u"], 0], "length"]],
                              ],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "r"]],
                ],
                [
                  50,
                  "k",
                  [46, "p"],
                  [52, "q", ["e", [15, "p"]]],
                  [41, "r"],
                  [3, "r", ["f", [17, [15, "q"], "port"]]],
                  [
                    22,
                    [28, [15, "r"]],
                    [
                      46,
                      [
                        53,
                        [
                          22,
                          [20, [17, [15, "q"], "protocol"], "http:"],
                          [46, [53, [3, "r", 80]]],
                          [
                            46,
                            [
                              22,
                              [20, [17, [15, "q"], "protocol"], "https:"],
                              [46, [53, [3, "r", 443]]],
                              [46, [53, [3, "r", ""]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, ["g", [15, "r"]]],
                ],
                [
                  50,
                  "l",
                  [46, "p", "q"],
                  [52, "r", ["e", [15, "p"]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [
                        20,
                        [2, [17, [15, "r"], "pathname"], "indexOf", [7, "/"]],
                        0,
                      ],
                      [17, [15, "r"], "pathname"],
                      [0, "/", [17, [15, "r"], "pathName"]],
                    ],
                  ],
                  [
                    22,
                    [20, ["d", [15, "q"]], "array"],
                    [
                      46,
                      [
                        53,
                        [52, "t", [2, [15, "s"], "split", [7, "/"]]],
                        [
                          22,
                          [
                            19,
                            [
                              2,
                              [15, "q"],
                              "indexOf",
                              [
                                7,
                                [
                                  16,
                                  [15, "t"],
                                  [37, [17, [15, "t"], "length"], 1],
                                ],
                              ],
                            ],
                            0,
                          ],
                          [
                            46,
                            [
                              53,
                              [
                                43,
                                [15, "t"],
                                [37, [17, [15, "t"], "length"], 1],
                                "",
                              ],
                              [3, "s", [2, [15, "t"], "join", [7, "/"]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "s"]],
                ],
                [
                  50,
                  "m",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "pathname"]],
                  [52, "r", [2, [15, "q"], "split", [7, "."]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [18, [17, [15, "r"], "length"], 1],
                      [16, [15, "r"], [37, [17, [15, "r"], "length"], 1]],
                      "",
                    ],
                  ],
                  [36, [16, [2, [15, "s"], "split", [7, "/"]], 0]],
                ],
                [
                  50,
                  "n",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "hash"]],
                  [36, [2, [15, "q"], "replace", [7, "#", ""]]],
                ],
                [
                  50,
                  "o",
                  [46, "p", "q"],
                  [
                    50,
                    "s",
                    [46, "t"],
                    [
                      36,
                      [
                        "c",
                        [2, [15, "t"], "replace", [7, ["b", "\\+", "g"], " "]],
                      ],
                    ],
                  ],
                  [
                    52,
                    "r",
                    [
                      2,
                      [17, ["e", [15, "p"]], "search"],
                      "replace",
                      [7, "?", ""],
                    ],
                  ],
                  [
                    65,
                    "t",
                    [2, [15, "r"], "split", [7, "&"]],
                    [
                      46,
                      [
                        53,
                        [52, "u", [2, [15, "t"], "split", [7, "="]]],
                        [
                          22,
                          [21, ["s", [16, [15, "u"], 0]], [15, "q"]],
                          [46, [6]],
                        ],
                        [
                          36,
                          [
                            "s",
                            [
                              2,
                              [2, [15, "u"], "slice", [7, 1]],
                              "join",
                              [7, "="],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36],
                ],
                [52, "b", ["require", "internal.createRegex"]],
                [52, "c", ["require", "decodeUriComponent"]],
                [52, "d", ["require", "getType"]],
                [52, "e", ["require", "internal.legacyParseUrl"]],
                [52, "f", ["require", "makeNumber"]],
                [52, "g", ["require", "makeString"]],
                [
                  36,
                  [
                    8,
                    "F",
                    [15, "m"],
                    "H",
                    [15, "o"],
                    "G",
                    [15, "n"],
                    "C",
                    [15, "j"],
                    "E",
                    [15, "l"],
                    "D",
                    [15, "k"],
                    "B",
                    [15, "i"],
                    "A",
                    [15, "h"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
    ],
    entities: {
      __e: { 2: true, 5: true },
      __f: { 2: true, 5: true },
      __u: { 2: true, 5: true },
    },
    blob: {
      1: "2",
      10: "GTM-MKNRPF8",
      14: "65e0",
      15: "2",
      16: "ChAI8Kug0AYQ3pbLkdLfyZQeEhwA3F+LfaP5PYTFUuB0V8na96y7gAUepBb08fbuGgL5VA==",
      19: "dataLayer",
      20: "",
      21: "www.googletagmanager.com",
      22: "eyIwIjoiQkQiLCIxIjoiQkQtQyIsIjIiOmZhbHNlLCIzIjoiZ29vZ2xlLmNvbS5iZCIsIjQiOiIiLCI1Ijp0cnVlLCI2IjpmYWxzZSwiNyI6ImFkX3N0b3JhZ2V8YW5hbHl0aWNzX3N0b3JhZ2V8YWRfdXNlcl9kYXRhfGFkX3BlcnNvbmFsaXphdGlvbiJ9",
      23: "google.tagmanager.debugui2.queue",
      24: "tagassistant.google.com",
      27: 0.005,
      3: "www.googletagmanager.com",
      30: "BD",
      31: "BD-C",
      32: true,
      36: "https://adservice.google.com/pagead/regclk",
      37: "__TAGGY_INSTALLED",
      38: "cct.google",
      39: "googTaggyReferrer",
      40: "https://cct.google/taggy/agent.js",
      41: "google.tagmanager.ta.prodqueue",
      42: 0.01,
      43: '{"keys":[{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BKsqKjVTX9+hPTLovGyyCyd3bUnMILGSHScfnLSJBzoT4WV0PNnAf5/7eRQ5hNFjS+qo5iaQTbG9mmedccE4Z6I=","version":0},"id":"d1e17eb4-9d4c-4b04-9d27-0aaff7ef4d49"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BOif6X7T0SQBD2vZVU/D6qOHmmfVmKo+JWm3B4lhXfqN1T/3w3w/jKNCxEsFWFOqgfN0DrH1427yoOgJ/D3D8ac=","version":0},"id":"b55f2fc6-e74f-4a2b-af92-7d14de4265e4"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BDr5OSuWjtYGnNnZ/antWcrHoAlX2G3ujaakzW59ASYVcdBvTL6SQs8cOfWMseM14GwJ5vvSeXgK09yUV4LVB+Y=","version":0},"id":"a615f8fd-f6b9-4fec-a193-87a7ce43e04b"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BM0xTl8/aqC0kzBHVEQbZatgLae6IOabhaNpNXPASaL1piVMi8ZKbkc+5svOqHFQZ03PyBicle+Xa+Ezd6hiidE=","version":0},"id":"a314e237-e0a7-4b70-94de-f44e1596582a"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BKnhp+J3+9Y3VX1Ev4v4rL0LfhibNKpaPqKzXPVOwDMTyewPwSBJDoCLClcJA1UMDUWMUjcJhXasWtZ9/9rr9yY=","version":0},"id":"118e8c55-ca6d-4f7a-a331-791d0a4f75a2"}]}',
      44: "0",
      46: {
        1: "1000",
        10: "65d0",
        11: "63a0",
        14: "1000",
        16: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
        17: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
        2: "9",
        20: "5000",
        21: "5000",
        22: "4.3.0",
        23: "0.0.0",
        25: "1",
        26: "4000",
        27: "100",
        3: "5",
        4: "ad_storage|analytics_storage|ad_user_data|ad_personalization",
        44: "15000",
        48: "30000",
        5: "ad_storage|analytics_storage|ad_user_data",
        6: "1",
        61: "1000",
        62: "A6ONHRY7/bvBro+IMZd/a6LNjn7SSv999SkN/hFAE9L6vMr34dNgfdSVdYmv4U+NHZg1sxd38RtciRpRUtIRPgQAAACCeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiU2hhcmVkV29ya2VyRXh0ZW5kZWRMaWZldGltZSIsImV4cGlyeSI6MTc3NjcyOTYwMCwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==",
        63: "1000",
        66: "100",
        7: "10",
      },
      48: true,
      5: "GTM-MKNRPF8",
      55: ["GTM-MKNRPF8"],
      56: [
        { 1: 403, 3: 0.5, 4: 115938465, 5: 115938466, 6: 0, 7: 2 },
        { 1: 404, 3: 0.5, 4: 115938468, 5: 115938469, 6: 0, 7: 1 },
        { 1: 502, 2: true },
        { 1: 490, 2: true },
        { 1: 491, 3: 0.01, 4: 118012007, 5: 118012008, 6: 118012009, 7: 1 },
        { 1: 480, 2: true },
        { 1: 530, 2: true },
        { 1: 537, 3: 0.001, 4: 118690343, 5: 118690341, 6: 118690342, 7: 1 },
        { 1: 523, 3: 0.01, 4: 118228214, 5: 118228215, 6: 0, 7: 1 },
        { 1: 504, 2: true },
        { 1: 462, 3: 0.05, 4: 118806524, 5: 118806525, 6: 118806526, 7: 1 },
        { 1: 413, 2: true },
        { 1: 408, 2: true },
        { 1: 549, 2: true },
        { 1: 500, 2: true },
        { 1: 511, 2: true },
        { 1: 552, 2: true },
        { 1: 492, 2: true },
        { 1: 450, 3: 0.01, 4: 117227714, 5: 117227715, 6: 117227716, 7: 3 },
        { 1: 458, 2: true },
        { 1: 443, 3: 0.001, 4: 117628654, 5: 117628655, 6: 117628656, 7: 3 },
        { 1: 498, 3: 0.2, 4: 115616985, 5: 115616986, 6: 0, 7: 1 },
        { 1: 518, 2: true },
        { 1: 465, 2: true },
        { 1: 495, 3: 0.05, 4: 118131810, 5: 118131808, 6: 118131809, 7: 3 },
        { 1: 431, 3: 0.1, 4: 116701381, 5: 116701382, 6: 116767281, 7: 3 },
        { 1: 419, 2: true },
        { 1: 520, 3: 0.25, 4: 118806963, 5: 118806961, 6: 118806962, 7: 1 },
        { 1: 551, 3: 0.001, 4: 118948627, 5: 118948625, 6: 118948626, 7: 1 },
        { 1: 554, 3: 0.001, 4: 119034493, 5: 119034491, 6: 119034492, 7: 1 },
        { 1: 538, 3: 0.001, 4: 119027224, 5: 119027222, 6: 119027223, 7: 1 },
        { 1: 539, 3: 0.01, 4: 118689382, 5: 118689381, 6: 118694324, 7: 1 },
        { 1: 529, 2: true },
        { 1: 541, 2: true },
        { 1: 558, 2: true },
        { 1: 499, 3: 0.01, 4: 118168306, 5: 118168307, 6: 118168308, 7: 1 },
        { 1: 544, 2: true },
        { 1: 535, 3: 0.01, 4: 118851535, 5: 118851533, 6: 118851534, 7: 1 },
        { 1: 515, 3: 0.05, 4: 118128922, 5: 118128923, 6: 0, 7: 1 },
        { 1: 446, 2: true },
        { 1: 524, 2: true },
      ],
      59: ["GTM-MKNRPF8"],
      6: "53089572",
      63: 0.005,
    },
    permissions: {
      __e: {
        read_event_data: {
          eventDataAccess: "specific",
          keyPatterns: ["event"],
        },
      },
      __f: {
        read_data_layer: { keyPatterns: ["gtm.referrer"] },
        get_referrer: { urlParts: "any" },
      },
      __u: {
        read_data_layer: { keyPatterns: ["gtm.url"] },
        get_url: { urlParts: "any" },
      },
    },

    security_groups: {
      google: ["__e", "__f", "__u"],
    },
  };

  var k,
    aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ca = function (a) {
      for (
        var b = [
            "object" == typeof globalThis && globalThis,
            a,
            "object" == typeof window && window,
            "object" == typeof self && self,
            "object" == typeof global && global,
          ],
          c = 0;
        c < b.length;
        ++c
      ) {
        var d = b[c];
        if (d && d.Math == Math) return d;
      }
      throw Error("Cannot find global object");
    },
    da = ca(this),
    ea = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
    ha = {},
    la = {},
    ma = function (a, b, c) {
      if (!c || a != null) {
        var d = la[b];
        if (d == null) return a[b];
        var e = a[d];
        return e !== void 0 ? e : a[b];
      }
    },
    na = function (a, b, c) {
      if (b)
        a: {
          var d = a.split("."),
            e = d.length === 1,
            f = d[0],
            g;
          !e && f in ha ? (g = ha) : (g = da);
          for (var h = 0; h < d.length - 1; h++) {
            var l = d[h];
            if (!(l in g)) break a;
            g = g[l];
          }
          var m = d[d.length - 1],
            p = ea && c === "es6" ? g[m] : null,
            q = b(p);
          if (q != null)
            if (e) ba(ha, m, { configurable: !0, writable: !0, value: q });
            else if (q !== p) {
              if (la[m] === void 0) {
                var r = (Math.random() * 1e9) >>> 0;
                la[m] = ea ? da.Symbol(m) : "$jscp$" + r + "$" + m;
              }
              ba(g, la[m], { configurable: !0, writable: !0, value: q });
            }
        }
    },
    oa;
  if (ea && typeof Object.setPrototypeOf == "function")
    oa = Object.setPrototypeOf;
  else {
    var pa;
    a: {
      var qa = { a: !0 },
        sa = {};
      try {
        sa.__proto__ = qa;
        pa = sa.a;
        break a;
      } catch (a) {}
      pa = !1;
    }
    oa = pa
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var ta = oa,
    va = function (a, b) {
      a.prototype = aa(b.prototype);
      a.prototype.constructor = a;
      if (ta) ta(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.Xt = b.prototype;
    },
    wa = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    n = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: wa(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    xa = function (a) {
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      return c;
    },
    za = function (a) {
      return a instanceof Array ? a : xa(n(a));
    },
    Ba = function (a) {
      return Aa(a, a);
    },
    Aa = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    Ca =
      ea && typeof ma(Object, "assign") == "function"
        ? ma(Object, "assign")
        : function (a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d)
                for (var e in d)
                  Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e]);
            }
            return a;
          };
  na(
    "Object.assign",
    function (a) {
      return a || Ca;
    },
    "es6"
  );
  var Da = function (a) {
      if (!(a instanceof Object))
        throw new TypeError("Iterator result " + a + " is not an object");
    },
    Ea = function () {
      this.ka = !1;
      this.V = null;
      this.la = void 0;
      this.H = 1;
      this.O = this.Z = 0;
      this.Va = this.K = null;
    },
    Fa = function (a) {
      if (a.ka) throw new TypeError("Generator is already running");
      a.ka = !0;
    };
  Ea.prototype.ya = function (a) {
    this.la = a;
  };
  var Ga = function (a, b) {
    a.K = { so: b, isException: !0 };
    a.H = a.Z || a.O;
  };
  Ea.prototype.getNextAddressJsc = function () {
    return this.H;
  };
  Ea.prototype.getYieldResultJsc = function () {
    return this.la;
  };
  Ea.prototype.return = function (a) {
    this.K = { return: a };
    this.H = this.O;
  };
  Ea.prototype["return"] = Ea.prototype.return;
  Ea.prototype.Yj = function (a) {
    this.K = { sd: a };
    this.H = this.O;
  };
  Ea.prototype.jumpThroughFinallyBlocks = Ea.prototype.Yj;
  Ea.prototype.jc = function (a, b) {
    this.H = b;
    return { value: a };
  };
  Ea.prototype.yield = Ea.prototype.jc;
  Ea.prototype.Rs = function (a, b) {
    var c = n(a),
      d = c.next();
    Da(d);
    if (d.done) (this.la = d.value), (this.H = b);
    else return (this.V = c), this.jc(d.value, b);
  };
  Ea.prototype.yieldAll = Ea.prototype.Rs;
  Ea.prototype.sd = function (a) {
    this.H = a;
  };
  Ea.prototype.jumpTo = Ea.prototype.sd;
  Ea.prototype.ek = function () {
    this.H = 0;
  };
  Ea.prototype.jumpToEnd = Ea.prototype.ek;
  Ea.prototype.ls = function (a, b) {
    this.Z = a;
    b != void 0 && (this.O = b);
  };
  Ea.prototype.setCatchFinallyBlocks = Ea.prototype.ls;
  Ea.prototype.Pg = function (a) {
    this.Z = 0;
    this.O = a || 0;
  };
  Ea.prototype.setFinallyBlock = Ea.prototype.Pg;
  Ea.prototype.kk = function (a, b) {
    this.H = a;
    this.Z = b || 0;
  };
  Ea.prototype.leaveTryBlock = Ea.prototype.kk;
  Ea.prototype.Xj = function (a) {
    this.Z = a || 0;
    var b = this.K.so;
    this.K = null;
    return b;
  };
  Ea.prototype.enterCatchBlock = Ea.prototype.Xj;
  Ea.prototype.nd = function (a, b, c) {
    c ? (this.Va[c] = this.K) : (this.Va = [this.K]);
    this.Z = a || 0;
    this.O = b || 0;
  };
  Ea.prototype.enterFinallyBlock = Ea.prototype.nd;
  Ea.prototype.oe = function (a, b) {
    var c = this.Va.splice(b || 0)[0],
      d = (this.K = this.K || c);
    d
      ? d.isException
        ? (this.H = this.Z || this.O)
        : d.sd != void 0 && this.O < d.sd
        ? ((this.H = d.sd), (this.K = null))
        : (this.H = this.O)
      : (this.H = a);
  };
  Ea.prototype.leaveFinallyBlock = Ea.prototype.oe;
  Ea.prototype.ne = function (a) {
    return new Ha(a);
  };
  Ea.prototype.forIn = Ea.prototype.ne;
  var Ha = function (a) {
    this.K = a;
    this.H = [];
    for (var b in a) this.H.push(b);
    this.H.reverse();
  };
  Ha.prototype.Ao = function () {
    for (; this.H.length > 0; ) {
      var a = this.H.pop();
      if (a in this.K) return a;
    }
    return null;
  };
  Ha.prototype.getNext = Ha.prototype.Ao;
  var Ia = function (a) {
      this.H = new Ea();
      this.K = a;
    },
    La = function (a, b) {
      Fa(a.H);
      var c = a.H.V;
      if (c)
        return Ja(
          a,
          "return" in c
            ? c["return"]
            : function (d) {
                return { value: d, done: !0 };
              },
          b,
          a.H.return
        );
      a.H.return(b);
      return Ka(a);
    },
    Ja = function (a, b, c, d) {
      try {
        var e = b.call(a.H.V, c);
        Da(e);
        if (!e.done) return (a.H.ka = !1), e;
        var f = e.value;
      } catch (g) {
        return (a.H.V = null), Ga(a.H, g), Ka(a);
      }
      a.H.V = null;
      d.call(a.H, f);
      return Ka(a);
    },
    Ka = function (a) {
      for (; a.H.H; )
        try {
          var b = a.K(a.H);
          if (b) return (a.H.ka = !1), { value: b.value, done: !1 };
        } catch (d) {
          (a.H.la = void 0), Ga(a.H, d);
        }
      a.H.ka = !1;
      if (a.H.K) {
        var c = a.H.K;
        a.H.K = null;
        if (c.isException) throw c.so;
        return { value: c.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    Ma = function (a) {
      this.next = function (b) {
        var c;
        Fa(a.H);
        a.H.V ? (c = Ja(a, a.H.V.next, b, a.H.ya)) : (a.H.ya(b), (c = Ka(a)));
        return c;
      };
      this.throw = function (b) {
        var c;
        Fa(a.H);
        a.H.V
          ? (c = Ja(a, a.H.V["throw"], b, a.H.ya))
          : (Ga(a.H, b), (c = Ka(a)));
        return c;
      };
      this.return = function (b) {
        return La(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Na = function (a, b) {
      var c = new Ma(new Ia(b));
      ta && a.prototype && ta(c, a.prototype);
      return c;
    },
    Pa = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    },
    Qa = function (a) {
      return a;
    }; /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var Ra = this || self,
    Sa = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.Xt = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.Dv = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g);
      };
    };
  var Ta = function (a, b) {
    this.type = a;
    this.data = b;
  };
  var Ua = function () {
    this.map = {};
    this.H = {};
  };
  Ua.prototype.get = function (a) {
    return this.map["dust." + a];
  };
  Ua.prototype.set = function (a, b) {
    var c = "dust." + a;
    this.H.hasOwnProperty(c) || (this.map[c] = b);
  };
  Ua.prototype.has = function (a) {
    return this.map.hasOwnProperty("dust." + a);
  };
  Ua.prototype.remove = function (a) {
    var b = "dust." + a;
    this.H.hasOwnProperty(b) || delete this.map[b];
  };
  var Va = function (a, b) {
    var c = [],
      d;
    for (d in a.map)
      if (a.map.hasOwnProperty(d)) {
        var e = d.substring(5);
        switch (b) {
          case 1:
            c.push(e);
            break;
          case 2:
            c.push(a.map[d]);
            break;
          case 3:
            c.push([e, a.map[d]]);
        }
      }
    return c;
  };
  Ua.prototype.Ga = function () {
    return Va(this, 1);
  };
  Ua.prototype.Lc = function () {
    return Va(this, 2);
  };
  Ua.prototype.oc = function () {
    return Va(this, 3);
  };
  var Wa = function () {};
  Wa.prototype.reset = function () {};
  var Xa = function () {
    this.value = {};
    this.prefix = "gtm.";
  };
  k = Xa.prototype;
  k.set = function (a, b) {
    this.value[this.prefix + String(a)] = b;
  };
  k.get = function (a) {
    return this.value[this.prefix + String(a)];
  };
  k.has = function (a) {
    return this.value.hasOwnProperty(this.prefix + String(a));
  };
  k.delete = function (a) {
    var b = this.prefix + String(a);
    return this.value.hasOwnProperty(b) ? (delete this.value[b], !0) : !1;
  };
  k.clear = function () {
    this.value = {};
  };
  k.values = function () {
    var a = this;
    return (function c() {
      var d, e, f;
      return Na(c, function (g) {
        switch (g.H) {
          case 1:
            g.Pg(2), (e = g.ne(a.value));
          case 4:
            if ((d = e.Ao()) == null) {
              g.sd(2);
              break;
            }
            if (!a.value.hasOwnProperty(d)) {
              g.sd(4);
              break;
            }
            f = Qa;
            return g.jc(a.value[d], 8);
          case 8:
            f(g.la);
            g.sd(4);
            break;
          case 2:
            g.nd(), g.oe(0);
        }
      });
    })();
  };
  da.Object.defineProperties(Xa.prototype, {
    size: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return Object.keys(this.value).length;
      },
    },
  });
  function Ya() {
    try {
      if (Map) return new Map();
    } catch (a) {}
    return new Xa();
  }
  var Za = function () {
    this.values = [];
  };
  Za.prototype.add = function (a) {
    this.values.indexOf(a) === -1 && this.values.push(a);
  };
  Za.prototype.has = function (a) {
    return this.values.indexOf(a) > -1;
  };
  var $a = function (a, b) {
    this.ka = a;
    this.parent = b;
    this.V = this.K = void 0;
    this.Jb = !1;
    this.O = function (d, e, f) {
      return d.apply(e, f);
    };
    this.H = Ya();
    var c;
    a: {
      try {
        if (Set) {
          c = new Set();
          break a;
        }
      } catch (d) {}
      c = new Za();
    }
    this.Z = c;
  };
  $a.prototype.add = function (a, b) {
    ab(this, a, b, !1);
  };
  $a.prototype.Ai = function (a, b) {
    ab(this, a, b, !0);
  };
  var ab = function (a, b, c, d) {
    a.Jb || a.Z.has(b) || (d && a.Z.add(b), a.H.set(b, c));
  };
  k = $a.prototype;
  k.set = function (a, b) {
    this.Jb ||
      (!this.H.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.Z.has(a) || this.H.set(a, b));
  };
  k.get = function (a) {
    return this.H.has(a)
      ? this.H.get(a)
      : this.parent
      ? this.parent.get(a)
      : void 0;
  };
  k.has = function (a) {
    return !!this.H.has(a) || !(!this.parent || !this.parent.has(a));
  };
  k.Db = function () {
    var a = new $a(this.ka, this);
    this.K && a.Tb(this.K);
    a.zd(this.O);
    a.Ee(this.V);
    return a;
  };
  k.ue = function () {
    return this.ka;
  };
  k.Tb = function (a) {
    this.K = a;
  };
  k.yo = function () {
    return this.K;
  };
  k.zd = function (a) {
    this.O = a;
  };
  k.sk = function () {
    return this.O;
  };
  k.Ya = function () {
    this.Jb = !0;
  };
  k.Ee = function (a) {
    this.V = a;
  };
  k.Eb = function () {
    return this.V;
  };
  var bb = function (a, b, c) {
    var d;
    d = Error.call(this, a.message);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.Mo = a;
    this.lo = c === void 0 ? !1 : c;
    this.debugInfo = [];
    this.H = b;
  };
  va(bb, Error);
  var cb = function (a) {
    return a instanceof bb ? a : new bb(a, void 0, !0);
  };
  var db = Ya();
  function eb(a, b) {
    for (
      var c, d = n(b), e = d.next();
      !e.done && !((c = gb(a, e.value)), c instanceof Ta);
      e = d.next()
    );
    return c;
  }
  function gb(a, b) {
    try {
      var c = b[0],
        d = b.slice(1),
        e = String(c),
        f = db.has(e) ? db.get(e) : a.get(e);
      if (!f || typeof f.invoke !== "function")
        throw cb(Error("Attempting to execute non-function " + b[0] + "."));
      return f.apply(a, d);
    } catch (h) {
      var g = a.yo();
      g && g(h, b.context ? { id: b[0], line: b.context.line } : null);
      throw h;
    }
  }
  var hb = function () {
    this.K = new Wa();
    this.H = new $a(this.K);
  };
  k = hb.prototype;
  k.ue = function () {
    return this.K;
  };
  k.Tb = function (a) {
    this.H.Tb(a);
  };
  k.zd = function (a) {
    this.H.zd(a);
  };
  k.execute = function (a) {
    return this.Qk([a].concat(za(Pa.apply(1, arguments))));
  };
  k.Qk = function () {
    for (
      var a, b = n(Pa.apply(0, arguments)), c = b.next();
      !c.done;
      c = b.next()
    )
      a = gb(this.H, c.value);
    return a;
  };
  k.er = function (a) {
    var b = Pa.apply(1, arguments),
      c = this.H.Db();
    c.Ee(a);
    for (var d, e = n(b), f = e.next(); !f.done; f = e.next())
      d = gb(c, f.value);
    return d;
  };
  k.Ya = function () {
    this.H.Ya();
  };
  var ib = function (a, b) {
    this.V = a;
    this.parent = b;
    this.O = this.H = void 0;
    this.Jb = !1;
    this.K = function (c, d, e) {
      return c.apply(d, e);
    };
    this.values = new Ua();
  };
  ib.prototype.add = function (a, b) {
    jb(this, a, b, !1);
  };
  ib.prototype.Ai = function (a, b) {
    jb(this, a, b, !0);
  };
  var jb = function (a, b, c, d) {
    if (!a.Jb)
      if (d) {
        var e = a.values;
        e.set(b, c);
        e.H["dust." + b] = !0;
      } else a.values.set(b, c);
  };
  k = ib.prototype;
  k.set = function (a, b) {
    this.Jb ||
      (!this.values.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.values.set(a, b));
  };
  k.get = function (a) {
    return this.values.has(a)
      ? this.values.get(a)
      : this.parent
      ? this.parent.get(a)
      : void 0;
  };
  k.has = function (a) {
    return !!this.values.has(a) || !(!this.parent || !this.parent.has(a));
  };
  k.Db = function () {
    var a = new ib(this.V, this);
    this.H && a.Tb(this.H);
    a.zd(this.K);
    a.Ee(this.O);
    return a;
  };
  k.ue = function () {
    return this.V;
  };
  k.Tb = function (a) {
    this.H = a;
  };
  k.yo = function () {
    return this.H;
  };
  k.zd = function (a) {
    this.K = a;
  };
  k.sk = function () {
    return this.K;
  };
  k.Ya = function () {
    this.Jb = !0;
  };
  k.Ee = function (a) {
    this.O = a;
  };
  k.Eb = function () {
    return this.O;
  };
  var kb = function () {
    this.Oa = !1;
    this.ma = new Ua();
  };
  k = kb.prototype;
  k.get = function (a) {
    return this.ma.get(a);
  };
  k.set = function (a, b) {
    this.Oa || this.ma.set(a, b);
  };
  k.has = function (a) {
    return this.ma.has(a);
  };
  k.remove = function (a) {
    this.Oa || this.ma.remove(a);
  };
  k.Ga = function () {
    return this.ma.Ga();
  };
  k.Lc = function () {
    return this.ma.Lc();
  };
  k.oc = function () {
    return this.ma.oc();
  };
  k.Ya = function () {
    this.Oa = !0;
  };
  k.Jb = function () {
    return this.Oa;
  };
  function lb() {
    for (var a = mb, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
    return b;
  }
  function nb() {
    var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    a += a.toLowerCase() + "0123456789-_";
    return a + ".";
  }
  var mb, ob;
  function pb(a) {
    mb = mb || nb();
    ob = ob || lb();
    for (var b = [], c = 0; c < a.length; c += 3) {
      var d = c + 1 < a.length,
        e = c + 2 < a.length,
        f = a.charCodeAt(c),
        g = d ? a.charCodeAt(c + 1) : 0,
        h = e ? a.charCodeAt(c + 2) : 0,
        l = f >> 2,
        m = ((f & 3) << 4) | (g >> 4),
        p = ((g & 15) << 2) | (h >> 6),
        q = h & 63;
      e || ((q = 64), d || (p = 64));
      b.push(mb[l], mb[m], mb[p], mb[q]);
    }
    return b.join("");
  }
  function qb(a) {
    function b(l) {
      for (; d < a.length; ) {
        var m = a.charAt(d++),
          p = ob[m];
        if (p != null) return p;
        if (!/^[\s\xa0]*$/.test(m))
          throw Error("Unknown base64 encoding at char: " + m);
      }
      return l;
    }
    mb = mb || nb();
    ob = ob || lb();
    for (var c = "", d = 0; ; ) {
      var e = b(-1),
        f = b(0),
        g = b(64),
        h = b(64);
      if (h === 64 && e === -1) return c;
      c += String.fromCharCode((e << 2) | (f >> 4));
      g !== 64 &&
        ((c += String.fromCharCode(((f << 4) & 240) | (g >> 2))),
        h !== 64 && (c += String.fromCharCode(((g << 6) & 192) | h)));
    }
  }
  var rb = {};
  function sb(a, b) {
    var c = rb[a];
    c || (c = rb[a] = []);
    c[b] = !0;
  }
  function tb() {
    delete rb.GA4_EVENT;
  }
  function ub() {
    var a = vb.H.slice();
    rb.GTAG_EVENT_FEATURE_CHANNEL = a;
  }
  function wb(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++)
      d % 8 === 0 && d > 0 && (b.push(String.fromCharCode(c)), (c = 0)),
        a[d] && (c |= 1 << d % 8);
    c > 0 && b.push(String.fromCharCode(c));
    return pb(b.join("")).replace(/\.+$/, "");
  }
  function xb() {}
  function yb(a) {
    return typeof a === "function";
  }
  function zb(a) {
    return typeof a === "string";
  }
  function Ab(a) {
    return typeof a === "number" && !isNaN(a);
  }
  function Bb(a) {
    return Array.isArray(a) ? a : [a];
  }
  function Cb(a, b) {
    if (a && Array.isArray(a))
      for (var c = 0; c < a.length; c++) if (a[c] && b(a[c])) return a[c];
  }
  function Db(a, b) {
    if (!Ab(a) || !Ab(b) || a > b) (a = 0), (b = 2147483647);
    return Math.floor(Math.random() * (b - a + 1) + a);
  }
  function Eb(a, b) {
    for (var c = new Fb(), d = 0; d < a.length; d++) c.set(a[d], !0);
    for (var e = 0; e < b.length; e++) if (c.get(b[e])) return !0;
    return !1;
  }
  function Gb(a, b) {
    for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c]);
  }
  function Hb(a) {
    return (
      !!a &&
      (Object.prototype.toString.call(a) === "[object Arguments]" ||
        Object.prototype.hasOwnProperty.call(a, "callee"))
    );
  }
  function Ib(a) {
    return Math.round(Number(a)) || 0;
  }
  function Jb(a) {
    return "false" === String(a).toLowerCase() ? !1 : !!a;
  }
  function Kb(a) {
    var b = [];
    if (Array.isArray(a))
      for (var c = 0; c < a.length; c++) b.push(String(a[c]));
    return b;
  }
  function Lb(a) {
    return a ? a.replace(/^\s+|\s+$/g, "") : "";
  }
  function Mb() {
    return new Date(Date.now());
  }
  function Ob() {
    return Mb().getTime();
  }
  var Fb = function () {
    this.prefix = "gtm.";
    this.values = {};
  };
  Fb.prototype.set = function (a, b) {
    this.values[this.prefix + a] = b;
  };
  Fb.prototype.get = function (a) {
    return this.values[this.prefix + a];
  };
  Fb.prototype.contains = function (a) {
    return this.get(a) !== void 0;
  };
  function Pb(a, b, c) {
    return a && a.hasOwnProperty(b) ? a[b] : c;
  }
  function Rb(a) {
    var b = a;
    return function () {
      if (b) {
        var c = b;
        b = void 0;
        try {
          c();
        } catch (d) {}
      }
    };
  }
  function Sb(a, b) {
    for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
  }
  function Tb(a, b) {
    for (var c = [], d = 0; d < a.length; d++)
      c.push(a[d]), c.push.apply(c, b[a[d]] || []);
    return c;
  }
  function Ub(a, b) {
    return a.length >= b.length && a.substring(0, b.length) === b;
  }
  function Vb(a, b) {
    return (
      a.length >= b.length && a.substring(a.length - b.length, a.length) === b
    );
  }
  function Wb(a, b, c) {
    c = c || [];
    for (var d = a, e = 0; e < b.length - 1; e++) {
      if (!d.hasOwnProperty(b[e])) return;
      d = d[b[e]];
      if (c.indexOf(d) >= 0) return;
    }
    return d;
  }
  function Xb(a, b) {
    for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++)
      d = d[e[f]] = {};
    d[e[e.length - 1]] = b;
    return c;
  }
  var Yb = /^\w{1,9}$/;
  function Zb(a, b) {
    a = a || {};
    b = b || ",";
    var c = [];
    Gb(a, function (d, e) {
      Yb.test(d) && e && c.push(d);
    });
    return c.join(b);
  }
  function $b(a) {
    for (var b = [], c = 0; c < a.length; c++) {
      var d = a.charCodeAt(c);
      d < 128
        ? b.push(d)
        : d < 2048
        ? b.push(192 | (d >> 6), 128 | (d & 63))
        : d < 55296 || d >= 57344
        ? b.push(224 | (d >> 12), 128 | ((d >> 6) & 63), 128 | (d & 63))
        : ((d = 65536 + (((d & 1023) << 10) | (a.charCodeAt(++c) & 1023))),
          b.push(
            240 | (d >> 18),
            128 | ((d >> 12) & 63),
            128 | ((d >> 6) & 63),
            128 | (d & 63)
          ));
    }
    return new Uint8Array(b);
  }
  function ac(a, b) {
    function c() {
      e && ++d === b && (e(), (e = null), (c.done = !0));
    }
    var d = 0,
      e = a;
    c.done = !1;
    return c;
  }
  function bc(a) {
    if (!a) return a;
    var b = a;
    try {
      b = decodeURIComponent(a);
    } catch (d) {}
    var c = b.split(",");
    return c.length === 2 && c[0] === c[1] ? c[0] : a;
  }
  function cc(a, b, c) {
    function d(m) {
      var p = m.split("=")[0];
      if (a.indexOf(p) < 0) return m;
      if (c !== void 0) return p + "=" + c;
    }
    function e(m) {
      return m
        .split("&")
        .map(d)
        .filter(function (p) {
          return p !== void 0;
        })
        .join("&");
    }
    var f = b.href.split(/[?#]/)[0],
      g = b.search,
      h = b.hash;
    g[0] === "?" && (g = g.substring(1));
    h[0] === "#" && (h = h.substring(1));
    g = e(g);
    h = e(h);
    g !== "" && (g = "?" + g);
    h !== "" && (h = "#" + h);
    var l = "" + f + g + h;
    l[l.length - 1] === "/" && (l = l.substring(0, l.length - 1));
    return l;
  }
  function dc(a) {
    for (var b = 0; b < 3; ++b)
      try {
        var c = decodeURIComponent(a).replace(/\+/g, " ");
        if (c === a) break;
        a = c;
      } catch (d) {
        return "";
      }
    return a;
  }
  function ec() {
    var a = w,
      b;
    a: {
      var c = a.crypto || a.msCrypto;
      if (c && c.getRandomValues)
        try {
          var d = new Uint8Array(25);
          c.getRandomValues(d);
          b = btoa(String.fromCharCode.apply(String, za(d)))
            .replace(/\+/g, "-")
            .replace(/\//g, "_")
            .replace(/=+$/, "");
          break a;
        } catch (e) {}
      b = void 0;
    }
    return b;
  } /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var fc = globalThis.trustedTypes,
    hc;
  function ic() {
    var a = null;
    if (!fc) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = fc.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function kc() {
    hc === void 0 && (hc = ic());
    return hc;
  }
  var lc = function (a) {
    this.H = a;
  };
  lc.prototype.toString = function () {
    return this.H + "";
  };
  function mc(a) {
    var b = a,
      c = kc(),
      d = c ? c.createScriptURL(b) : b;
    return new lc(d);
  }
  function nc(a) {
    if (a instanceof lc) return a.H;
    throw Error("");
  }
  var oc = Ba([""]),
    pc = Aa(["\x00"], ["\\0"]),
    qc = Aa(["\n"], ["\\n"]),
    sc = Aa(["\x00"], ["\\u0000"]);
  function tc(a) {
    return a.toString().indexOf("`") === -1;
  }
  tc(function (a) {
    return a(oc);
  }) ||
    tc(function (a) {
      return a(pc);
    }) ||
    tc(function (a) {
      return a(qc);
    }) ||
    tc(function (a) {
      return a(sc);
    });
  var uc = function (a) {
    this.H = a;
  };
  uc.prototype.toString = function () {
    return this.H;
  };
  var vc = function (a) {
    this.et = a;
  };
  function xc(a) {
    return new vc(function (b) {
      return b.substr(0, a.length + 1).toLowerCase() === a + ":";
    });
  }
  var yc = [
    xc("data"),
    xc("http"),
    xc("https"),
    xc("mailto"),
    xc("ftp"),
    new vc(function (a) {
      return /^[^:]*([/?#]|$)/.test(a);
    }),
  ];
  function zc(a) {
    var b;
    b = b === void 0 ? yc : b;
    if (a instanceof uc) return a;
    for (var c = 0; c < b.length; ++c) {
      var d = b[c];
      if (d instanceof vc && d.et(a)) return new uc(a);
    }
  }
  var Ac = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function Bc(a) {
    var b;
    if (a instanceof uc)
      if (a instanceof uc) b = a.H;
      else throw Error("");
    else b = Ac.test(a) ? a : void 0;
    return b;
  }
  function Cc(a, b) {
    var c = Bc(b);
    c !== void 0 && (a.action = c);
  }
  function Dc(a, b) {
    throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
  }
  var Ec = function (a) {
    this.H = a;
  };
  Ec.prototype.toString = function () {
    return this.H + "";
  };
  var Gc = function () {
    this.H = Fc[0].toLowerCase();
  };
  Gc.prototype.toString = function () {
    return this.H;
  };
  function Hc(a, b) {
    var c = [new Gc()];
    if (c.length === 0) throw Error("");
    var d = c.map(function (f) {
        var g;
        if (f instanceof Gc) g = f.H;
        else throw Error("");
        return g;
      }),
      e = b.toLowerCase();
    if (
      d.every(function (f) {
        return e.indexOf(f) !== 0;
      })
    )
      throw Error(
        'Attribute "' + b + '" does not match any of the allowed prefixes.'
      );
    a.setAttribute(b, "true");
  }
  var Ic = Array.prototype.indexOf
    ? function (a, b) {
        return Array.prototype.indexOf.call(a, b, void 0);
      }
    : function (a, b) {
        if (typeof a === "string")
          return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
        return -1;
      };
  "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT"
    .split(" ")
    .concat(["BUTTON", "INPUT"]);
  function Jc(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a;
  }
  var w = window,
    Kc = [],
    Lc = window.history,
    z = document,
    Mc = navigator;
  function Nc() {
    var a;
    try {
      a = Mc.serviceWorker;
    } catch (b) {
      return;
    }
    return a;
  }
  var Oc = z.currentScript,
    Pc = Oc && Oc.src;
  function Qc(a, b) {
    var c = w,
      d = c[a];
    c[a] = d === void 0 ? b : d;
    return c[a];
  }
  function Rc(a) {
    return (Mc.userAgent || "").indexOf(a) !== -1;
  }
  function Sc() {
    return Rc("Firefox") || Rc("FxiOS");
  }
  function Tc() {
    return (Rc("GSA") || Rc("GoogleApp")) && (Rc("iPhone") || Rc("iPad"));
  }
  function Uc() {
    return Rc("Edg/") || Rc("EdgA/") || Rc("EdgiOS/");
  }
  var Vc = { async: 1, nonce: 1, onerror: 1, onload: 1, src: 1, type: 1 },
    Wc = { height: 1, onload: 1, src: 1, style: 1, width: 1 };
  function Xc(a, b, c) {
    b &&
      Gb(b, function (d, e) {
        d = d.toLowerCase();
        c.hasOwnProperty(d) || a.setAttribute(d, e);
      });
  }
  function Yc(a, b, c, d, e) {
    var f = z.createElement("script");
    Xc(f, d, Vc);
    f.type = "text/javascript";
    f.async = d && d.async === !1 ? !1 : !0;
    var g;
    g = mc(Jc(a));
    f.src = nc(g);
    var h,
      l = f.ownerDocument;
    l = l === void 0 ? document : l;
    var m,
      p,
      q =
        (p = (m = l).querySelector) == null
          ? void 0
          : p.call(m, "script[nonce]");
    (h = q == null ? "" : q.nonce || q.getAttribute("nonce") || "") &&
      f.setAttribute("nonce", h);
    b && (f.onload = b);
    c && (f.onerror = c);
    if (e) e.appendChild(f);
    else {
      var r = z.getElementsByTagName("script")[0] || z.body || z.head;
      r.parentNode.insertBefore(f, r);
    }
    return f;
  }
  function Zc() {
    if (Pc) {
      var a = Pc.toLowerCase();
      if (a.indexOf("https://") === 0) return 2;
      if (a.indexOf("http://") === 0) return 3;
    }
    return 1;
  }
  function $c(a, b, c, d, e, f) {
    f = f === void 0 ? !0 : f;
    var g = e,
      h = !1;
    g || ((g = z.createElement("iframe")), (h = !0));
    Xc(g, c, Wc);
    d &&
      Gb(d, function (m, p) {
        g.dataset[m] = p;
      });
    f &&
      ((g.height = "0"),
      (g.width = "0"),
      (g.style.display = "none"),
      (g.style.visibility = "hidden"));
    a !== void 0 && (g.src = a);
    if (h) {
      var l = (z.body && z.body.lastChild) || z.body || z.head;
      l.parentNode.insertBefore(g, l);
    }
    b && (g.onload = b);
    return g;
  }
  function ad(a, b, c, d) {
    return bd(a, b, c, d);
  }
  function cd(a, b, c, d) {
    a.addEventListener && a.addEventListener(b, c, !!d);
  }
  function dd(a, b, c) {
    a.removeEventListener && a.removeEventListener(b, c, !1);
  }
  function ed(a) {
    w.setTimeout(a, 0);
  }
  function fd(a, b) {
    var c = Pa.apply(2, arguments),
      d,
      e = (d = w).setInterval.apply(d, [a, b].concat(za(c)));
    Kc.push(e);
    return e;
  }
  function gd(a) {
    var b = w;
    yb(b.queueMicrotask)
      ? b.queueMicrotask(a)
      : yb(b.Promise) && b.Promise.resolve
      ? b.Promise.resolve()
          .then(function () {
            a();
          })
          .catch(function () {})
      : ed(a);
  }
  function hd(a, b) {
    return a && b && a.attributes && a.attributes[b]
      ? a.attributes[b].value
      : null;
  }
  function id(a) {
    var b = a.innerText || a.textContent || "";
    b &&
      b !== " " &&
      ((b = b.replace(/^[\s\xa0]+/g, "")), (b = b.replace(/[\s\xa0]+$/g, "")));
    b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
    return b;
  }
  function jd(a) {
    var b = z.createElement("div"),
      c = b,
      d,
      e = Jc("A<div>" + a + "</div>"),
      f = kc(),
      g = f ? f.createHTML(e) : e;
    d = new Ec(g);
    if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName))
      throw Error("");
    var h;
    if (d instanceof Ec) h = d.H;
    else throw Error("");
    c.innerHTML = h;
    b = b.lastChild;
    for (var l = []; b && b.firstChild; ) l.push(b.removeChild(b.firstChild));
    return l;
  }
  function kd(a, b, c) {
    c = c || 100;
    for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
    for (var f = a, g = 0; f && g <= c; g++) {
      if (d[String(f.tagName).toLowerCase()]) return f;
      f = f.parentElement;
    }
    return null;
  }
  function ld(a, b, c) {
    var d;
    try {
      d = Mc.sendBeacon && Mc.sendBeacon(a);
    } catch (e) {
      sb("TAGGING", 15);
    }
    d ? b == null || b() : bd(a, b, c);
  }
  function md(a, b) {
    try {
      if (Mc.sendBeacon !== void 0) return Mc.sendBeacon(a, b);
    } catch (c) {
      sb("TAGGING", 15);
    }
    return !1;
  }
  var nd = {
    cache: "no-store",
    credentials: "include",
    keepalive: !0,
    method: "POST",
    mode: "no-cors",
    redirect: "follow",
  };
  function od(a, b, c, d, e) {
    if (pd()) {
      var f = ma(Object, "assign").call(Object, {}, nd);
      b && (f.body = b);
      c &&
        (c.attributionReporting &&
          (f.attributionReporting = c.attributionReporting),
        c.browsingTopics !== void 0 && (f.browsingTopics = c.browsingTopics),
        c.credentials && (f.credentials = c.credentials),
        c.keepalive !== void 0 && (f.keepalive = c.keepalive),
        c.method && (f.method = c.method),
        c.mode && (f.mode = c.mode));
      try {
        var g = w.fetch(a, f);
        if (g)
          return (
            g
              .then(function (l) {
                l && (l.ok || l.status === 0)
                  ? d == null || d()
                  : e == null || e();
              })
              .catch(function () {
                e == null || e();
              }),
            !0
          );
      } catch (l) {}
    }
    if (
      (c == null ? 0 : c.wf) ||
      ((c == null ? 0 : c.credentials) && c.credentials !== "include")
    )
      return e == null || e(), !1;
    if (b) {
      var h = md(a, b);
      h ? d == null || d() : e == null || e();
      return h;
    }
    qd(a, d, e);
    return !0;
  }
  function pd() {
    return yb(w.fetch);
  }
  function rd(a, b) {
    var c = a[b];
    c && typeof c.animVal === "string" && (c = c.animVal);
    return c;
  }
  function sd() {
    var a = w.performance;
    if (a && yb(a.now)) return a.now();
  }
  function td() {
    var a,
      b = w.performance;
    if (b && b.getEntriesByType)
      try {
        var c = b.getEntriesByType("navigation");
        c && c.length > 0 && (a = c[0].type);
      } catch (d) {
        return "e";
      }
    if (!a) return "u";
    switch (a) {
      case "navigate":
        return "n";
      case "back_forward":
        return "h";
      case "reload":
        return "r";
      case "prerender":
        return "p";
      default:
        return "x";
    }
  }
  function ud() {
    return w.performance || void 0;
  }
  function vd() {
    var a = w.webPixelsManager;
    return a ? a.createShopifyExtend !== void 0 : !1;
  }
  var bd = function (a, b, c, d) {
      var e = new Image(1, 1);
      Xc(e, d, {});
      e.onload = function () {
        e.onload = null;
        b && b();
      };
      e.onerror = function () {
        e.onerror = null;
        c && c();
      };
      e.src = a;
      return e;
    },
    qd = ld;
  function wd(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function xd(a, b) {
    return this.evaluate(a) === this.evaluate(b);
  }
  function yd(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function zd(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    return String(c).indexOf(String(d)) > -1;
  }
  function Ad(a, b) {
    var c = String(this.evaluate(a)),
      d = String(this.evaluate(b));
    return c.substring(0, d.length) === d;
  }
  function Bd(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    switch (c) {
      case "pageLocation":
        var e = w.location.href;
        d instanceof kb &&
          d.get("stripProtocol") &&
          (e = e.replace(/^https?:\/\//, ""));
        return e;
    }
  } /*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
*/
  var Cd = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
    Dd = function (a) {
      if (a == null) return String(a);
      var b = Cd.exec(Object.prototype.toString.call(Object(a)));
      return b ? b[1].toLowerCase() : "object";
    },
    Ed = function (a, b) {
      return Object.prototype.hasOwnProperty.call(Object(a), b);
    },
    Fd = function (a) {
      if (!a || Dd(a) != "object" || a.nodeType || a == a.window) return !1;
      try {
        if (
          a.constructor &&
          !Ed(a, "constructor") &&
          !Ed(a.constructor.prototype, "isPrototypeOf")
        )
          return !1;
      } catch (c) {
        return !1;
      }
      for (var b in a);
      return b === void 0 || Ed(a, b);
    },
    Gd = function (a, b) {
      var c = b || (Dd(a) == "array" ? [] : {}),
        d;
      for (d in a)
        if (Ed(a, d)) {
          var e = a[d];
          Dd(e) == "array"
            ? (Dd(c[d]) != "array" && (c[d] = []), (c[d] = Gd(e, c[d])))
            : Fd(e)
            ? (Fd(c[d]) || (c[d] = {}), (c[d] = Gd(e, c[d])))
            : (c[d] = e);
        }
      return c;
    };
  function Hd(a) {
    return (
      (typeof a === "number" && a >= 0 && isFinite(a) && a % 1 === 0) ||
      (typeof a === "string" && a[0] !== "-" && a === "" + parseInt(a))
    );
  }
  var Id = function (a) {
    a = a === void 0 ? [] : a;
    this.ma = new Ua();
    this.values = [];
    this.Oa = !1;
    for (var b in a)
      a.hasOwnProperty(b) &&
        (Hd(b)
          ? (this.values[Number(b)] = a[Number(b)])
          : this.ma.set(b, a[b]));
  };
  k = Id.prototype;
  k.toString = function (a) {
    if (a && a.indexOf(this) >= 0) return "";
    for (var b = [], c = 0; c < this.values.length; c++) {
      var d = this.values[c];
      d === null || d === void 0
        ? b.push("")
        : d instanceof Id
        ? ((a = a || []), a.push(this), b.push(d.toString(a)), a.pop())
        : b.push(String(d));
    }
    return b.join(",");
  };
  k.set = function (a, b) {
    if (!this.Oa)
      if (a === "length") {
        if (!Hd(b))
          throw cb(
            Error("RangeError: Length property must be a valid integer.")
          );
        this.values.length = Number(b);
      } else Hd(a) ? (this.values[Number(a)] = b) : this.ma.set(a, b);
  };
  k.get = function (a) {
    return a === "length"
      ? this.length()
      : Hd(a)
      ? this.values[Number(a)]
      : this.ma.get(a);
  };
  k.length = function () {
    return this.values.length;
  };
  k.Ga = function () {
    for (var a = this.ma.Ga(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(String(b));
    return a;
  };
  k.Lc = function () {
    for (var a = this.ma.Lc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(this.values[b]);
    return a;
  };
  k.oc = function () {
    for (var a = this.ma.oc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push([String(b), this.values[b]]);
    return a;
  };
  k.remove = function (a) {
    Hd(a) ? delete this.values[Number(a)] : this.Oa || this.ma.remove(a);
  };
  k.pop = function () {
    return this.values.pop();
  };
  k.push = function () {
    return this.values.push.apply(this.values, za(Pa.apply(0, arguments)));
  };
  k.shift = function () {
    return this.values.shift();
  };
  k.splice = function (a, b) {
    var c = Pa.apply(2, arguments);
    return b === void 0 && c.length === 0
      ? new Id(this.values.splice(a))
      : new Id(
          this.values.splice.apply(this.values, [a, b || 0].concat(za(c)))
        );
  };
  k.unshift = function () {
    return this.values.unshift.apply(this.values, za(Pa.apply(0, arguments)));
  };
  k.has = function (a) {
    return (Hd(a) && this.values.hasOwnProperty(a)) || this.ma.has(a);
  };
  k.Ya = function () {
    this.Oa = !0;
    Object.freeze(this.values);
  };
  k.Jb = function () {
    return this.Oa;
  };
  function Jd(a) {
    for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
    return b;
  }
  var Kd = function (a, b) {
    this.functionName = a;
    this.se = b;
    this.ma = new Ua();
    this.Oa = !1;
  };
  k = Kd.prototype;
  k.toString = function () {
    return this.functionName;
  };
  k.getName = function () {
    return this.functionName;
  };
  k.getKeys = function () {
    return new Id(this.Ga());
  };
  k.invoke = function (a) {
    return this.se.call.apply(
      this.se,
      [new Ld(this, a)].concat(za(Pa.apply(1, arguments)))
    );
  };
  k.apply = function (a, b) {
    return this.se.apply(new Ld(this, a), b);
  };
  k.Tc = function (a) {
    var b = Pa.apply(1, arguments);
    try {
      return this.invoke.apply(this, [a].concat(za(b)));
    } catch (c) {}
  };
  k.get = function (a) {
    return this.ma.get(a);
  };
  k.set = function (a, b) {
    this.Oa || this.ma.set(a, b);
  };
  k.has = function (a) {
    return this.ma.has(a);
  };
  k.remove = function (a) {
    this.Oa || this.ma.remove(a);
  };
  k.Ga = function () {
    return this.ma.Ga();
  };
  k.Lc = function () {
    return this.ma.Lc();
  };
  k.oc = function () {
    return this.ma.oc();
  };
  k.Ya = function () {
    this.Oa = !0;
  };
  k.Jb = function () {
    return this.Oa;
  };
  var Md = function (a, b) {
    Kd.call(this, a, b);
  };
  va(Md, Kd);
  var Nd = function (a, b) {
    Kd.call(this, a, b);
  };
  va(Nd, Kd);
  var Ld = function (a, b) {
    this.se = a;
    this.T = b;
  };
  Ld.prototype.evaluate = function (a) {
    var b = this.T;
    return Array.isArray(a) ? gb(b, a) : a;
  };
  Ld.prototype.getName = function () {
    return this.se.getName();
  };
  Ld.prototype.ue = function () {
    return this.T.ue();
  };
  var Od = function () {
    this.map = new Map();
  };
  Od.prototype.set = function (a, b) {
    this.map.set(a, b);
  };
  Od.prototype.get = function (a) {
    return this.map.get(a);
  };
  var Pd = function () {
    this.keys = [];
    this.values = [];
  };
  Pd.prototype.set = function (a, b) {
    this.keys.push(a);
    this.values.push(b);
  };
  Pd.prototype.get = function (a) {
    var b = this.keys.indexOf(a);
    if (b > -1) return this.values[b];
  };
  function Qd() {
    try {
      return Map ? new Od() : new Pd();
    } catch (a) {
      return new Pd();
    }
  }
  var Rd = function (a) {
    if (a instanceof Rd) return a;
    var b;
    a: if (a == void 0 || Array.isArray(a) || Fd(a)) b = !0;
    else {
      switch (typeof a) {
        case "boolean":
        case "number":
        case "string":
        case "function":
          b = !0;
          break a;
      }
      b = !1;
    }
    if (b) throw Error("Type of given value has an equivalent Pixie type.");
    this.value = a;
  };
  Rd.prototype.getValue = function () {
    return this.value;
  };
  Rd.prototype.toString = function () {
    return String(this.value);
  };
  var Td = function (a) {
    this.promise = a;
    this.Oa = !1;
    this.ma = new Ua();
    this.ma.set("then", Sd(this));
    this.ma.set("catch", Sd(this, !0));
    this.ma.set("finally", Sd(this, !1, !0));
  };
  k = Td.prototype;
  k.get = function (a) {
    return this.ma.get(a);
  };
  k.set = function (a, b) {
    this.Oa || this.ma.set(a, b);
  };
  k.has = function (a) {
    return this.ma.has(a);
  };
  k.remove = function (a) {
    this.Oa || this.ma.remove(a);
  };
  k.Ga = function () {
    return this.ma.Ga();
  };
  k.Lc = function () {
    return this.ma.Lc();
  };
  k.oc = function () {
    return this.ma.oc();
  };
  var Sd = function (a, b, c) {
    b = b === void 0 ? !1 : b;
    c = c === void 0 ? !1 : c;
    return new Md("", function (d, e) {
      b && ((e = d), (d = void 0));
      c && (e = d);
      d instanceof Md || (d = void 0);
      e instanceof Md || (e = void 0);
      var f = this.T.Db(),
        g = function (l) {
          return function (m) {
            try {
              return c ? (l.invoke(f), a.promise) : l.invoke(f, m);
            } catch (p) {
              return Promise.reject(p instanceof Error ? new Rd(p) : String(p));
            }
          };
        },
        h = a.promise.then(d && g(d), e && g(e));
      return new Td(h);
    });
  };
  Td.prototype.Ya = function () {
    this.Oa = !0;
  };
  Td.prototype.Jb = function () {
    return this.Oa;
  };
  function B(a, b, c) {
    var d = Qd(),
      e = function (g, h) {
        for (var l = g.Ga(), m = 0; m < l.length; m++) h[l[m]] = f(g.get(l[m]));
      },
      f = function (g) {
        if (g === null || g === void 0) return g;
        var h = d.get(g);
        if (h) return h;
        if (g instanceof Id) {
          var l = [];
          d.set(g, l);
          for (var m = g.Ga(), p = 0; p < m.length; p++)
            l[m[p]] = f(g.get(m[p]));
          return l;
        }
        if (g instanceof Td)
          return g.promise.then(
            function (v) {
              return B(v, b, 1);
            },
            function (v) {
              return Promise.reject(B(v, b, 1));
            }
          );
        if (g instanceof kb) {
          var q = {};
          d.set(g, q);
          e(g, q);
          return q;
        }
        if (g instanceof Md) {
          var r = function () {
            for (var v = [], u = 0; u < arguments.length; u++)
              v[u] = Ud(arguments[u], b, c);
            var x = new ib(b ? b.ue() : new Wa());
            b && x.Ee(b.Eb());
            return f(g.apply(x, v));
          };
          d.set(g, r);
          e(g, r);
          return r;
        }
        var t = !1;
        switch (c) {
          case 1:
            t = !0;
            break;
          case 2:
            t = !1;
            break;
          case 3:
            t = !1;
            break;
          default:
        }
        if (g instanceof Rd && t) return g.getValue();
        switch (typeof g) {
          case "boolean":
          case "number":
          case "string":
          case "undefined":
            return g;
          case "object":
            if (g === null) return null;
        }
      };
    return f(a);
  }
  function Ud(a, b, c) {
    var d = Qd(),
      e = function (g, h) {
        for (var l in g) g.hasOwnProperty(l) && h.set(l, f(g[l]));
      },
      f = function (g) {
        var h = d.get(g);
        if (h) return h;
        if (Array.isArray(g) || Hb(g)) {
          var l = new Id();
          d.set(g, l);
          for (var m in g) g.hasOwnProperty(m) && l.set(m, f(g[m]));
          return l;
        }
        if (Fd(g)) {
          var p = new kb();
          d.set(g, p);
          e(g, p);
          return p;
        }
        if (typeof g === "function") {
          var q = new Md("", function () {
            for (
              var v = Pa.apply(0, arguments), u = [], x = 0;
              x < v.length;
              x++
            )
              u[x] = B(this.evaluate(v[x]), b, c);
            return f(this.T.sk()(g, g, u));
          });
          d.set(g, q);
          e(g, q);
          return q;
        }
        var r = typeof g;
        if (g === null || r === "string" || r === "number" || r === "boolean")
          return g;
        var t = !1;
        switch (c) {
          case 1:
            t = !0;
            break;
          case 2:
            t = !1;
            break;
          default:
        }
        if (g !== void 0 && t) return new Rd(g);
      };
    return f(a);
  }
  var Vd = {
    supportedMethods:
      "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(
        " "
      ),
    concat: function (a) {
      for (var b = [], c = 0; c < this.length(); c++) b.push(this.get(c));
      for (var d = 1; d < arguments.length; d++)
        if (arguments[d] instanceof Id)
          for (var e = arguments[d], f = 0; f < e.length(); f++)
            b.push(e.get(f));
        else b.push(arguments[d]);
      return new Id(b);
    },
    every: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && !b.invoke(a, this.get(d), d, this)) return !1;
      return !0;
    },
    filter: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && b.invoke(a, this.get(e), e, this) && d.push(this.get(e));
      return new Id(d);
    },
    forEach: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        this.has(d) && b.invoke(a, this.get(d), d, this);
    },
    hasOwnProperty: function (a, b) {
      return this.has(b);
    },
    indexOf: function (a, b, c) {
      var d = this.length(),
        e = c === void 0 ? 0 : Number(c);
      e < 0 && (e = Math.max(d + e, 0));
      for (var f = e; f < d; f++)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    join: function (a, b) {
      for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
      return c.join(b);
    },
    lastIndexOf: function (a, b, c) {
      var d = this.length(),
        e = d - 1;
      c !== void 0 && (e = c < 0 ? d + c : Math.min(c, e));
      for (var f = e; f >= 0; f--)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    map: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && (d[e] = b.invoke(a, this.get(e), e, this));
      return new Id(d);
    },
    pop: function () {
      return this.pop();
    },
    push: function (a) {
      return this.push.apply(this, za(Pa.apply(1, arguments)));
    },
    reduce: function (a, b, c) {
      var d = this.length(),
        e,
        f = 0;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw cb(Error("TypeError: Reduce on List with no elements."));
        for (var g = 0; g < d; g++)
          if (this.has(g)) {
            e = this.get(g);
            f = g + 1;
            break;
          }
        if (g === d)
          throw cb(Error("TypeError: Reduce on List with no elements."));
      }
      for (var h = f; h < d; h++)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reduceRight: function (a, b, c) {
      var d = this.length(),
        e,
        f = d - 1;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw cb(Error("TypeError: ReduceRight on List with no elements."));
        for (var g = 1; g <= d; g++)
          if (this.has(d - g)) {
            e = this.get(d - g);
            f = d - (g + 1);
            break;
          }
        if (g > d)
          throw cb(Error("TypeError: ReduceRight on List with no elements."));
      }
      for (var h = f; h >= 0; h--)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reverse: function () {
      for (var a = Jd(this), b = a.length - 1, c = 0; b >= 0; b--, c++)
        a.hasOwnProperty(b) ? this.set(c, a[b]) : this.remove(c);
      return this;
    },
    shift: function () {
      return this.shift();
    },
    slice: function (a, b, c) {
      var d = this.length();
      b === void 0 && (b = 0);
      b = b < 0 ? Math.max(d + b, 0) : Math.min(b, d);
      c = c === void 0 ? d : c < 0 ? Math.max(d + c, 0) : Math.min(c, d);
      c = Math.max(b, c);
      for (var e = [], f = b; f < c; f++) e.push(this.get(f));
      return new Id(e);
    },
    some: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && b.invoke(a, this.get(d), d, this)) return !0;
      return !1;
    },
    sort: function (a, b) {
      var c = Jd(this);
      b === void 0
        ? c.sort()
        : c.sort(function (e, f) {
            return Number(b.invoke(a, e, f));
          });
      for (var d = 0; d < c.length; d++)
        c.hasOwnProperty(d) ? this.set(d, c[d]) : this.remove(d);
      return this;
    },
    splice: function (a, b, c) {
      return this.splice.apply(this, [b, c].concat(za(Pa.apply(3, arguments))));
    },
    toString: function () {
      return this.toString();
    },
    unshift: function (a) {
      return this.unshift.apply(this, za(Pa.apply(1, arguments)));
    },
  };
  var Wd = {
      charAt: 1,
      concat: 1,
      indexOf: 1,
      lastIndexOf: 1,
      match: 1,
      replace: 1,
      search: 1,
      slice: 1,
      split: 1,
      substring: 1,
      toLowerCase: 1,
      toLocaleLowerCase: 1,
      toString: 1,
      toUpperCase: 1,
      toLocaleUpperCase: 1,
      trim: 1,
    },
    Xd = new Ta("break"),
    Yd = new Ta("continue");
  function Zd(a, b) {
    return this.evaluate(a) + this.evaluate(b);
  }
  function $d(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function ae(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!(f instanceof Id))
      throw Error("Error: Non-List argument given to Apply instruction.");
    if (d === null || d === void 0)
      throw cb(Error("TypeError: Can't read property " + e + " of " + d + "."));
    var g = typeof d === "number";
    if (typeof d === "boolean" || g) {
      if (e === "toString") {
        if (g && f.length()) {
          var h = B(f.get(0));
          try {
            return d.toString(h);
          } catch (v) {}
        }
        return d.toString();
      }
      throw cb(Error("TypeError: " + d + "." + e + " is not a function."));
    }
    if (typeof d === "string") {
      if (Wd.hasOwnProperty(e)) {
        var l = B(f, void 0, 1);
        return Ud(d[e].apply(d, l), this.T);
      }
      throw cb(Error("TypeError: " + e + " is not a function"));
    }
    if (d instanceof Id) {
      if (d.has(e)) {
        var m = d.get(String(e));
        if (m instanceof Md) {
          var p = Jd(f);
          return m.apply(this.T, p);
        }
        throw cb(Error("TypeError: " + e + " is not a function"));
      }
      if (Vd.supportedMethods.indexOf(e) >= 0) {
        var q = Jd(f);
        return Vd[e].call.apply(Vd[e], [d, this.T].concat(za(q)));
      }
    }
    if (d instanceof Md || d instanceof kb || d instanceof Td) {
      if (d.has(e)) {
        var r = d.get(e);
        if (r instanceof Md) {
          var t = Jd(f);
          return r.apply(this.T, t);
        }
        throw cb(Error("TypeError: " + e + " is not a function"));
      }
      if (e === "toString") return d instanceof Md ? d.getName() : d.toString();
      if (e === "hasOwnProperty") return d.has(f.get(0));
    }
    if (d instanceof Rd && e === "toString") return d.toString();
    throw cb(Error("TypeError: Object has no '" + e + "' property."));
  }
  function be(a, b) {
    a = this.evaluate(a);
    if (typeof a !== "string")
      throw Error("Invalid key name given for assignment.");
    var c = this.T;
    if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
    var d = this.evaluate(b);
    c.set(a, d);
    return d;
  }
  function ce() {
    var a = Pa.apply(0, arguments),
      b = this.T.Db(),
      c = eb(b, a);
    if (c instanceof Ta) return c;
  }
  function de() {
    return Xd;
  }
  function ee(a) {
    for (var b = this.evaluate(a), c = 0; c < b.length; c++) {
      var d = this.evaluate(b[c]);
      if (d instanceof Ta) return d;
    }
  }
  function fe() {
    for (var a = this.T, b = 0; b < arguments.length - 1; b += 2) {
      var c = arguments[b];
      if (typeof c === "string") {
        var d = this.evaluate(arguments[b + 1]);
        a.Ai(c, d);
      }
    }
  }
  function ge() {
    return Yd;
  }
  function he(a, b) {
    return new Ta(a, this.evaluate(b));
  }
  function ie(a, b) {
    var c = Pa.apply(2, arguments),
      d;
    d = new Id();
    for (var e = this.evaluate(b), f = 0; f < e.length; f++) d.push(e[f]);
    var g = [51, a, d].concat(za(c));
    this.T.add(a, this.evaluate(g));
  }
  function je(a, b) {
    return this.evaluate(a) / this.evaluate(b);
  }
  function ke(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b),
      e = c instanceof Rd,
      f = d instanceof Rd;
    return e || f ? (e && f ? c.getValue() === d.getValue() : !1) : c == d;
  }
  function le() {
    for (var a, b = 0; b < arguments.length; b++)
      a = this.evaluate(arguments[b]);
    return a;
  }
  function me(a, b, c, d) {
    for (var e = 0; e < b(); e++) {
      var f = a(c(e)),
        g = eb(f, d);
      if (g instanceof Ta) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
    }
  }
  function ne(a, b, c) {
    if (typeof b === "string")
      return me(
        a,
        function () {
          return b.length;
        },
        function (f) {
          return f;
        },
        c
      );
    if (
      b instanceof kb ||
      b instanceof Td ||
      b instanceof Id ||
      b instanceof Md
    ) {
      var d = b.Ga(),
        e = d.length;
      return me(
        a,
        function () {
          return e;
        },
        function (f) {
          return d[f];
        },
        c
      );
    }
  }
  function oe(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return ne(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f
    );
  }
  function pe(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return ne(
      function (h) {
        var l = g.Db();
        l.Ai(d, h);
        return l;
      },
      e,
      f
    );
  }
  function qe(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return ne(
      function (h) {
        var l = g.Db();
        l.add(d, h);
        return l;
      },
      e,
      f
    );
  }
  function re(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return se(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f
    );
  }
  function te(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return se(
      function (h) {
        var l = g.Db();
        l.Ai(d, h);
        return l;
      },
      e,
      f
    );
  }
  function ue(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return se(
      function (h) {
        var l = g.Db();
        l.add(d, h);
        return l;
      },
      e,
      f
    );
  }
  function se(a, b, c) {
    if (typeof b === "string")
      return me(
        a,
        function () {
          return b.length;
        },
        function (d) {
          return b[d];
        },
        c
      );
    if (b instanceof Id)
      return me(
        a,
        function () {
          return b.length();
        },
        function (d) {
          return b.get(d);
        },
        c
      );
    throw cb(Error("The value is not iterable."));
  }
  function we(a, b, c, d) {
    function e(q, r) {
      for (var t = 0; t < f.length(); t++) {
        var v = f.get(t);
        r.add(v, q.get(v));
      }
    }
    var f = this.evaluate(a);
    if (!(f instanceof Id))
      throw Error("TypeError: Non-List argument given to ForLet instruction.");
    var g = this.T,
      h = this.evaluate(d),
      l = g.Db();
    for (e(g, l); gb(l, b); ) {
      var m = eb(l, h);
      if (m instanceof Ta) {
        if (m.type === "break") break;
        if (m.type === "return") return m;
      }
      var p = g.Db();
      e(l, p);
      gb(p, c);
      l = p;
    }
  }
  function xe(a, b) {
    var c = Pa.apply(2, arguments),
      d = this.T,
      e = this.evaluate(b);
    if (!(e instanceof Id))
      throw Error("Error: non-List value given for Fn argument names.");
    return new Md(
      a,
      (function () {
        return function () {
          var f = Pa.apply(0, arguments),
            g = d.Db();
          g.Eb() === void 0 && g.Ee(this.T.Eb());
          for (var h = [], l = 0; l < f.length; l++) {
            var m = this.evaluate(f[l]);
            h[l] = m;
          }
          for (var p = e.get("length"), q = 0; q < p; q++)
            q < h.length ? g.add(e.get(q), h[q]) : g.add(e.get(q), void 0);
          g.add("arguments", new Id(h));
          var r = eb(g, c);
          if (r instanceof Ta) return r.type === "return" ? r.data : r;
        };
      })()
    );
  }
  function ye(a) {
    var b = this.evaluate(a),
      c = this.T;
    if (ze && !c.has(b)) throw new ReferenceError(b + " is not defined.");
    return c.get(b);
  }
  function Ae(a, b) {
    var c,
      d = this.evaluate(a),
      e = this.evaluate(b);
    if (d === void 0 || d === null)
      throw cb(
        Error(
          "TypeError: Cannot read properties of " + d + " (reading '" + e + "')"
        )
      );
    if (
      d instanceof kb ||
      d instanceof Td ||
      d instanceof Id ||
      d instanceof Md
    )
      c = d.get(e);
    else if (typeof d === "string")
      e === "length" ? (c = d.length) : Hd(e) && (c = d[e]);
    else if (d instanceof Rd) return;
    return c;
  }
  function Be(a, b) {
    return this.evaluate(a) > this.evaluate(b);
  }
  function Ce(a, b) {
    return this.evaluate(a) >= this.evaluate(b);
  }
  function De(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    c instanceof Rd && (c = c.getValue());
    d instanceof Rd && (d = d.getValue());
    return c === d;
  }
  function Ee(a, b) {
    return !De.call(this, a, b);
  }
  function Fe(a, b, c) {
    var d = [];
    this.evaluate(a) ? (d = this.evaluate(b)) : c && (d = this.evaluate(c));
    var e = eb(this.T, d);
    if (e instanceof Ta) return e;
  }
  var ze = !1;
  function Ge(a, b) {
    return this.evaluate(a) < this.evaluate(b);
  }
  function He(a, b) {
    return this.evaluate(a) <= this.evaluate(b);
  }
  function Ie() {
    for (var a = new Id(), b = 0; b < arguments.length; b++) {
      var c = this.evaluate(arguments[b]);
      a.push(c);
    }
    return a;
  }
  function Je() {
    for (var a = new kb(), b = 0; b < arguments.length - 1; b += 2) {
      var c = String(this.evaluate(arguments[b])),
        d = this.evaluate(arguments[b + 1]);
      a.set(c, d);
    }
    return a;
  }
  function Ke(a, b) {
    return this.evaluate(a) % this.evaluate(b);
  }
  function Le(a, b) {
    return this.evaluate(a) * this.evaluate(b);
  }
  function Me(a) {
    return -this.evaluate(a);
  }
  function Ne(a) {
    return !this.evaluate(a);
  }
  function Oe(a, b) {
    return !ke.call(this, a, b);
  }
  function Pe() {
    return null;
  }
  function Qe(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function Re(a, b) {
    var c = this.evaluate(a);
    this.evaluate(b);
    return c;
  }
  function Se(a) {
    return this.evaluate(a);
  }
  function Te() {
    return Pa.apply(0, arguments);
  }
  function Ue(a) {
    return new Ta("return", this.evaluate(a));
  }
  function Ve(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (d === null || d === void 0)
      throw cb(Error("TypeError: Can't set property " + e + " of " + d + "."));
    (d instanceof Md || d instanceof Id || d instanceof kb) &&
      d.set(String(e), f);
    return f;
  }
  function We(a, b) {
    return this.evaluate(a) - this.evaluate(b);
  }
  function Xe(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!Array.isArray(e) || !Array.isArray(f))
      throw Error("Error: Malformed switch instruction.");
    for (var g, h = !1, l = 0; l < e.length; l++)
      if (h || d === this.evaluate(e[l]))
        if (((g = this.evaluate(f[l])), g instanceof Ta)) {
          var m = g.type;
          if (m === "break") return;
          if (m === "return" || m === "continue") return g;
        } else h = !0;
    if (
      f.length === e.length + 1 &&
      ((g = this.evaluate(f[f.length - 1])),
      g instanceof Ta && (g.type === "return" || g.type === "continue"))
    )
      return g;
  }
  function Ye(a, b, c) {
    return this.evaluate(a) ? this.evaluate(b) : this.evaluate(c);
  }
  function Ze(a) {
    var b = this.evaluate(a);
    return b instanceof Md ? "function" : typeof b;
  }
  function $e() {
    for (var a = this.T, b = 0; b < arguments.length; b++) {
      var c = arguments[b];
      typeof c !== "string" || a.add(c, void 0);
    }
  }
  function af(a, b, c, d) {
    var e = this.evaluate(d);
    if (this.evaluate(c)) {
      var f = eb(this.T, e);
      if (f instanceof Ta) {
        if (f.type === "break") return;
        if (f.type === "return") return f;
      }
    }
    for (; this.evaluate(a); ) {
      var g = eb(this.T, e);
      if (g instanceof Ta) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
      this.evaluate(b);
    }
  }
  function bf(a) {
    return ~Number(this.evaluate(a));
  }
  function cf(a, b) {
    return Number(this.evaluate(a)) << Number(this.evaluate(b));
  }
  function df(a, b) {
    return Number(this.evaluate(a)) >> Number(this.evaluate(b));
  }
  function ef(a, b) {
    return Number(this.evaluate(a)) >>> Number(this.evaluate(b));
  }
  function ff(a, b) {
    return Number(this.evaluate(a)) & Number(this.evaluate(b));
  }
  function gf(a, b) {
    return Number(this.evaluate(a)) ^ Number(this.evaluate(b));
  }
  function hf(a, b) {
    return Number(this.evaluate(a)) | Number(this.evaluate(b));
  }
  function jf() {}
  function kf(a, b, c) {
    try {
      var d = this.evaluate(b);
      if (d instanceof Ta) return d;
    } catch (h) {
      if (!(h instanceof bb && h.lo)) throw h;
      var e = this.T.Db();
      a !== "" && (h instanceof bb && (h = h.Mo), e.add(a, new Rd(h)));
      var f = this.evaluate(c),
        g = eb(e, f);
      if (g instanceof Ta) return g;
    }
  }
  function lf(a, b) {
    var c, d;
    try {
      d = this.evaluate(a);
    } catch (f) {
      if (!(f instanceof bb && f.lo)) throw f;
      c = f;
    }
    var e = this.evaluate(b);
    if (e instanceof Ta) return e;
    if (c) throw c;
    if (d instanceof Ta) return d;
  }
  var nf = function () {
    this.H = new hb();
    mf(this);
  };
  nf.prototype.execute = function (a) {
    return this.H.Qk(a);
  };
  var mf = function (a) {
    var b = function (c, d) {
      var e = new Nd(String(c), d);
      e.Ya();
      var f = String(c);
      a.H.H.set(f, e);
      db.set(f, e);
    };
    b("map", Je);
    b("and", wd);
    b("contains", zd);
    b("equals", xd);
    b("or", yd);
    b("startsWith", Ad);
    b("variable", Bd);
  };
  nf.prototype.Tb = function (a) {
    this.H.Tb(a);
  };
  var pf = function () {
    this.K = !1;
    this.H = new hb();
    of(this);
    this.K = !0;
  };
  pf.prototype.execute = function (a) {
    return qf(this.H.Qk(a));
  };
  var rf = function (a, b, c) {
    return qf(a.H.er(b, c));
  };
  pf.prototype.Ya = function () {
    this.H.Ya();
  };
  var of = function (a) {
    var b = function (c, d) {
      var e = String(c),
        f = new Nd(e, d);
      f.Ya();
      a.H.H.set(e, f);
      db.set(e, f);
    };
    b(0, Zd);
    b(1, $d);
    b(2, ae);
    b(3, be);
    b(56, ff);
    b(57, cf);
    b(58, bf);
    b(59, hf);
    b(60, df);
    b(61, ef);
    b(62, gf);
    b(53, ce);
    b(4, de);
    b(5, ee);
    b(68, kf);
    b(52, fe);
    b(6, ge);
    b(49, he);
    b(7, Ie);
    b(8, Je);
    b(9, ee);
    b(50, ie);
    b(10, je);
    b(12, ke);
    b(13, le);
    b(67, lf);
    b(51, xe);
    b(47, oe);
    b(54, pe);
    b(55, qe);
    b(63, we);
    b(64, re);
    b(65, te);
    b(66, ue);
    b(15, ye);
    b(16, Ae);
    b(17, Ae);
    b(18, Be);
    b(19, Ce);
    b(20, De);
    b(21, Ee);
    b(22, Fe);
    b(23, Ge);
    b(24, He);
    b(25, Ke);
    b(26, Le);
    b(27, Me);
    b(28, Ne);
    b(29, Oe);
    b(45, Pe);
    b(30, Qe);
    b(32, Re);
    b(33, Re);
    b(34, Se);
    b(35, Se);
    b(46, Te);
    b(36, Ue);
    b(43, Ve);
    b(37, We);
    b(38, Xe);
    b(39, Ye);
    b(40, Ze);
    b(44, jf);
    b(41, $e);
    b(42, af);
  };
  pf.prototype.ue = function () {
    return this.H.ue();
  };
  pf.prototype.Tb = function (a) {
    this.H.Tb(a);
  };
  pf.prototype.zd = function (a) {
    this.H.zd(a);
  };
  function qf(a) {
    if (
      a instanceof Ta ||
      a instanceof Md ||
      a instanceof Id ||
      a instanceof kb ||
      a instanceof Td ||
      a instanceof Rd ||
      a === null ||
      a === void 0 ||
      typeof a === "string" ||
      typeof a === "number" ||
      typeof a === "boolean"
    )
      return a;
  }
  var sf = function (a) {
    this.message = a;
  };
  function tf(a) {
    a.Hv = !0;
    return a;
  }
  var uf = tf(function (a) {
      return typeof a === "number";
    }),
    vf = tf(function (a) {
      return typeof a === "string";
    }),
    wf = tf(function (a) {
      return typeof a === "boolean";
    });
  function xf(a) {
    var b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
      a
    ];
    return b === void 0
      ? new sf(
          "Value " + a + " can not be encoded in web-safe base64 dictionary."
        )
      : b;
  }
  function yf(a) {
    switch (a) {
      case 1:
        return "1";
      case 2:
      case 4:
        return "0";
      default:
        return "-";
    }
  }
  var zf = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;
  function Af(a, b) {
    for (var c = "", d = !0; a > 7; ) {
      var e = a & 31;
      a >>= 5;
      d ? (d = !1) : (e |= 32);
      c = "" + xf(e) + c;
    }
    a <<= 2;
    d || (a |= 32);
    return (c = "" + xf(a | b) + c);
  }
  function Bf(a, b) {
    var c;
    var d = a.Oi,
      e = a.Gk;
    d === void 0
      ? (c = "")
      : (e || (e = 0), (c = "" + Af(1, 1) + xf((d << 2) | e)));
    var f = a.Kr,
      g = "4" + c + (f ? "" + Af(2, 1) + xf(f) : ""),
      h,
      l = a.cp;
    h = l && zf.test(l) ? "" + Af(3, 2) + l : "";
    var m,
      p = a.Yo;
    m = p ? "" + Af(4, 1) + xf(p) : "";
    var q;
    var r = a.ctid;
    if (r && b) {
      var t = Af(5, 3),
        v = r.split("-"),
        u = v[0].toUpperCase();
      if (u !== "GTM" && u !== "OPT") q = "";
      else {
        var x = v[1];
        q = "" + t + xf(1 + x.length) + (a.ht || 0) + x;
      }
    } else q = "";
    var y = a.Vt,
      A = a.canonicalId,
      C = a.mb,
      D = a.Rv,
      E =
        g +
        h +
        m +
        q +
        (y ? "" + Af(6, 1) + xf(y) : "") +
        (A ? "" + Af(7, 3) + xf(A.length) + A : "") +
        (C ? "" + Af(8, 3) + xf(C.length) + C : "") +
        (D ? "" + Af(9, 3) + xf(D.length) + D : ""),
      G;
    var I = a.Rr;
    I = I === void 0 ? {} : I;
    for (
      var Q = [], V = n(Object.keys(I)), S = V.next();
      !S.done;
      S = V.next()
    ) {
      var ja = S.value;
      Q[Number(ja)] = I[ja];
    }
    if (Q.length) {
      var fa = Af(10, 3),
        ka;
      if (Q.length === 0) ka = xf(0);
      else {
        for (var Z = [], ia = 0, ya = !1, ra = 0; ra < Q.length; ra++) {
          ya = !0;
          var ua = ra % 6;
          Q[ra] && (ia |= 1 << ua);
          ua === 5 && (Z.push(xf(ia)), (ia = 0), (ya = !1));
        }
        ya && Z.push(xf(ia));
        ka = Z.join("");
      }
      var Oa = ka;
      G = "" + fa + xf(Oa.length) + Oa;
    } else G = "";
    var fb = a.zt,
      Nb = a.Nt,
      rc = a.Wt;
    return (
      E +
      G +
      (fb ? "" + Af(11, 3) + xf(fb.length) + fb : "") +
      (Nb ? "" + Af(13, 3) + xf(Nb.length) + Nb : "") +
      (rc ? "" + Af(14, 1) + xf(rc) : "")
    );
  }
  function Cf(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e < 128
        ? (b[c++] = e)
        : (e < 2048
            ? (b[c++] = (e >> 6) | 192)
            : ((e & 64512) == 55296 &&
              d + 1 < a.length &&
              (a.charCodeAt(d + 1) & 64512) == 56320
                ? ((e =
                    65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023)),
                  (b[c++] = (e >> 18) | 240),
                  (b[c++] = ((e >> 12) & 63) | 128))
                : (b[c++] = (e >> 12) | 224),
              (b[c++] = ((e >> 6) & 63) | 128)),
          (b[c++] = (e & 63) | 128));
    }
    return b;
  }
  function Df(a, b) {
    for (var c = qb(b), d = new Uint8Array(c.length), e = 0; e < c.length; e++)
      d[e] = c.charCodeAt(e);
    if (d.length !== 32) throw Error("Key is not 32 bytes.");
    return Ef(a, d);
  }
  function Ef(a, b) {
    if (a === "") return "";
    var c = $b(a),
      d = b.slice(-2),
      e = [].concat(za(d), za(c)).map(function (g, h) {
        return g ^ b[h % b.length];
      }),
      f = new Uint8Array([].concat(za(e), za(d)));
    return pb(String.fromCharCode.apply(String, za(f))).replace(/\.+$/, "");
  }
  var Ff = (function () {
    function a(b) {
      return {
        toString: function () {
          return b;
        },
      };
    }
    return {
      zp: a("consent"),
      xl: a("convert_case_to"),
      yl: a("convert_false_to"),
      zl: a("convert_null_to"),
      Ap: a("convert_to_boolean"),
      Al: a("convert_to_number"),
      Bl: a("convert_true_to"),
      Cl: a("convert_undefined_to"),
      qu: a("debug_mode_metadata"),
      bc: a("function"),
      nn: a("instance_name"),
      jr: a("live_only"),
      kr: a("malware_disabled"),
      METADATA: a("metadata"),
      nr: a("original_activity_id"),
      mv: a("original_vendor_template_id"),
      lv: a("once_on_load"),
      mr: a("once_per_event"),
      Cn: a("once_per_load"),
      ov: a("priority_override"),
      sv: a("respected_consent_types"),
      Mn: a("setup_tags"),
      Vj: a("tag_id"),
      Xn: a("teardown_tags"),
      ru: a("disabled_in_google_mode"),
      Xq: a("generated_tagging_metadata"),
    };
  })();
  function Gf(a, b) {
    var c = {};
    c[Ff.bc] = "__" + a;
    for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
    return c;
  }
  function Hf(a) {
    var b;
    b = b === void 0 ? !1 : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? !!data.blob[a]
      : b;
  }
  function F(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? String(data.blob[a])
      : b;
  }
  function If(a) {
    var b, c;
    return (
      (b = data) == null ? 0 : (c = b.blob) == null ? 0 : c.hasOwnProperty(a)
    )
      ? Number(data.blob[a])
      : 0;
  }
  function Jf(a) {
    var b;
    b = b === void 0 ? [] : b;
    var c,
      d,
      e = (c = data) == null ? void 0 : (d = c.blob) == null ? void 0 : d[a];
    return Array.isArray(e) ? e : b;
  }
  function Kf(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c = Lf(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? String(c[a]) : b;
  }
  function Mf(a, b) {
    var c = Lf(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? Number(c[a]) : b;
  }
  function Lf(a) {
    var b, c;
    return (b = data) == null ? void 0 : (c = b.blob) == null ? void 0 : c[a];
  }
  var Nf = function (a, b, c) {
    var d;
    d = Error.call(this, c);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.permissionId = a;
    this.parameters = b;
    this.name = "PermissionError";
  };
  va(Nf, Error);
  Nf.prototype.getMessage = function () {
    return this.message;
  };
  function Of(a, b) {
    if (Array.isArray(a)) {
      Object.defineProperty(a, "context", { value: { line: b[0] } });
      for (var c = 1; c < a.length; c++) Of(a[c], b[c]);
    }
  }
  function Pf() {
    return function (a, b) {
      var c;
      var d = Qf;
      a instanceof bb ? ((a.H = d), (c = a)) : (c = new bb(a, d));
      var e = c;
      b && e.debugInfo.push(b);
      throw e;
    };
  }
  function Qf(a) {
    if (!a.length) return a;
    a.push({ id: "main", line: 0 });
    for (var b = a.length - 1; b > 0; b--) Ab(a[b].id) && a.splice(b++, 1);
    for (var c = a.length - 1; c > 0; c--) a[c].line = a[c - 1].line;
    a.splice(0, 1);
    return a;
  }
  var Rf = RegExp("[^0-9\\.+-]", "g"),
    Sf = RegExp("[^0-9\\,+-]", "g");
  function Tf(a, b) {
    var c = b === "COMMA" ? "," : ".",
      d = String(a).replace(b === "COMMA" ? Sf : Rf, "");
    if (d.split(c).length > 2) return a;
    var e = d.replace(/,/g, ".");
    if (e === "") return a;
    var f = Number(e);
    return isNaN(f) ? a : f;
  }
  var Uf = [],
    Vf = {};
  function Wf(a) {
    return Uf[a] === void 0 ? !1 : Uf[a];
  }
  var Xf = function () {
      this.H = {};
    },
    Yf = function (a, b, c) {
      var d;
      (d = a.H)[b] != null || (d[b] = []);
      a.H[b].push(function () {
        return c.apply(null, za(Pa.apply(0, arguments)));
      });
    };
  function Zf(a, b, c, d) {
    if (a)
      for (var e = 0; e < a.length; e++) {
        var f = void 0,
          g = "A policy function denied the permission request";
        try {
          (f = a[e](b, c, d)), (g += ".");
        } catch (h) {
          g =
            typeof h === "string"
              ? g + (": " + h)
              : h instanceof Error
              ? g + (": " + h.message)
              : g + ".";
        }
        if (!f) throw new Nf(c, d, g);
      }
  }
  function $f(a, b) {
    var c = ag(bg.H, b, function () {
      return {};
    });
    try {
      return c(a), !0;
    } catch (d) {
      return !1;
    }
  }
  function ag(a, b, c) {
    return function (d) {
      if (d) {
        var e = a.H[d],
          f = a.H.all;
        if (e || f) {
          var g = c.apply(void 0, [d].concat(za(Pa.apply(1, arguments))));
          Zf(e, b, d, g);
          Zf(f, b, d, g);
        }
      }
    };
  }
  var eg = function (a, b, c) {
      var d = this;
      this.K = {};
      this.H = new Xf();
      var e = {},
        f = {},
        g = ag(this.H, a, function (h) {
          return h && e[h]
            ? e[h].apply(void 0, [h].concat(za(Pa.apply(1, arguments))))
            : {};
        });
      Gb(b, function (h, l) {
        function m(q) {
          var r = Pa.apply(1, arguments);
          if (!p[q])
            throw cg(
              q,
              {},
              "The requested additional permission " + q + " is not configured."
            );
          g.apply(null, [q].concat(za(r)));
        }
        var p = {};
        Gb(l, function (q, r) {
          var t = dg(q, r, c);
          p[q] = t.assert;
          e[q] || (e[q] = t.aa);
          t.jo && !f[q] && (f[q] = t.jo);
        });
        d.K[h] = function (q, r) {
          var t = p[q];
          if (!t)
            throw cg(
              q,
              {},
              "The requested permission " + q + " is not configured."
            );
          var v = Array.prototype.slice.call(arguments, 0);
          t.apply(void 0, v);
          g.apply(void 0, v);
          var u = f[q];
          u && u.apply(null, [m].concat(za(v.slice(1))));
        };
      });
    },
    fg = function (a) {
      return bg.K[a] || function () {};
    };
  function dg(a, b, c) {
    try {
      var d = c["__" + a];
      if (!d) throw Error("No function found for permission: " + a + ".");
      var e = Gf(a, b);
      e.vtp_permissionName = a;
      e.vtp_createPermissionError = cg;
      delete e[Ff.bc];
      return d(e);
    } catch (f) {
      return {
        assert: function (g) {
          throw new Nf(g, {}, "Permission " + g + " is unknown.");
        },
        aa: function () {
          throw new Nf(a, {}, "Permission " + a + " is unknown.");
        },
      };
    }
  }
  function cg(a, b, c) {
    return new Nf(a, b, c);
  }
  var gg = F(5),
    hg = F(20),
    ig = F(1),
    jg = !1;
  var kg = {};
  kg.np = Hf(29);
  kg.ds = Hf(28);
  function lg(a) {
    switch (a) {
      case 0:
        break;
      case 9:
        return "e4";
      case 6:
        return "e5";
      case 14:
        return "e6";
      default:
        return "e7";
    }
  }
  var H = {
    D: {
      Pa: "ad_personalization",
      da: "ad_storage",
      fa: "ad_user_data",
      sa: "analytics_storage",
      vc: "region",
      qa: "consent_updated",
      Eh: "wait_for_update",
      Jf: "endpoint_type",
      Jp: "app_remove",
      Kp: "app_store_refund",
      Lp: "app_store_subscription_cancel",
      Mp: "app_store_subscription_convert",
      Np: "app_store_subscription_renew",
      Op: "consent_update",
      Pp: "conversion",
      Nl: "add_payment_info",
      Ol: "add_shipping_info",
      Ie: "add_to_cart",
      Je: "remove_from_cart",
      Pl: "view_cart",
      Gd: "begin_checkout",
      vu: "generate_lead",
      Ke: "select_item",
      wc: "view_item_list",
      Wc: "select_promotion",
      xc: "view_promotion",
      Kb: "purchase",
      Le: "refund",
      yc: "view_item",
      Ql: "add_to_wishlist",
      Qp: "exception",
      Rp: "first_open",
      Sp: "first_visit",
      xa: "gtag.config",
      Lb: "gtag.get",
      Tp: "in_app_purchase",
      zc: "page_view",
      Up: "screen_view",
      Vp: "session_start",
      Wp: "source_update",
      Xp: "timing_complete",
      Yp: "track_social",
      Kf: "user_engagement",
      Zp: "user_id_update",
      Hh: "braid_link_decoration_source",
      Ih: "braid_storage_source",
      Lf: "gclid_link_decoration_source",
      Mf: "gclid_storage_source",
      Vb: "gclgb",
      yb: "gclid",
      Rl: "gclid_len",
      Me: "gclgs",
      Ne: "gcllp",
      Oe: "gclst",
      pb: "ads_data_redaction",
      Nf: "gad_source",
      Of: "gad_source_src",
      Hd: "gclid_url",
      Sl: "gclsrc",
      Pf: "gbraid",
      Pe: "wbraid",
      Wb: "allow_ad_personalization_signals",
      Zi: "allow_custom_scripts",
      Jh: "allow_display_features",
      aj: "allow_enhanced_conversions",
      Xc: "allow_google_signals",
      bj: "allow_interest_groups",
      aq: "app_id",
      bq: "app_installer_id",
      cq: "app_name",
      fq: "app_version",
      Id: "auid",
      wu: "auto_detection_enabled",
      Tl: "auto_event",
      Ul: "aw_remarketing",
      Kh: "aw_remarketing_only",
      Qf: "discount",
      Rf: "aw_feed_country",
      Sf: "aw_feed_language",
      Ha: "items",
      Tf: "aw_merchant_id",
      cj: "aw_basket_type",
      Uf: "campaign_content",
      Vf: "campaign_id",
      Wf: "campaign_medium",
      Xf: "campaign_name",
      Yf: "campaign",
      Zf: "campaign_source",
      cg: "campaign_term",
      Mb: "client_id",
      Vl: "rnd",
      dj: "consent_update_type",
      gq: "content_group",
      hq: "content_type",
      Jd: "conversion_cookie_prefix",
      Lh: "conversion_id",
      Ac: "conversion_linker",
      dg: "conversion_linker_disabled",
      Qe: "conversion_api",
      ej: "_&rcb",
      Mh: "cookie_deprecation",
      Nb: "cookie_domain",
      Ib: "cookie_expires",
      Xb: "cookie_flags",
      Ld: "cookie_name",
      Bc: "cookie_path",
      qb: "cookie_prefix",
      Md: "cookie_update",
      Yc: "country",
      eb: "currency",
      Nh: "customer_buyer_stage",
      Re: "customer_lifetime_value",
      Oh: "customer_loyalty",
      Ph: "customer_ltv_bucket",
      Se: "custom_map",
      fj: "gcldc_link_decoration_source",
      gj: "gcldc_storage_source",
      eg: "gcldc",
      Nd: "dclid",
      Wl: "debug_mode",
      Qa: "developer_id",
      iq: "disable_merchant_reported_purchases",
      Zc: "dc_custom_params",
      jq: "dc_natural_search",
      kq: "dynamic_event_settings",
      Xl: "affiliation",
      Qh: "checkout_option",
      ij: "checkout_step",
      Yl: "coupon",
      fg: "item_list_name",
      jj: "list_name",
      lq: "promotions",
      Od: "shipping",
      Zl: "tax",
      Rh: "engagement_time_msec",
      Sh: "enhanced_client_id",
      mq: "enhanced_conversions",
      xu: "enhanced_conversions_automatic_settings",
      Te: "estimated_delivery_date",
      gg: "event_callback",
      nq: "event_category",
      Cc: "event_developer_id_string",
      Pd: "event_id",
      oq: "event_label",
      Dc: "event",
      am: "_&ae",
      kj: "event_settings",
      Th: "event_timeout",
      qq: "description",
      rq: "fatal",
      sq: "experiments",
      Qd: "ext_client_id",
      lj: "firebase_id",
      hg: "first_party_collection",
      ig: "_x_20",
      Yb: "_x_19",
      tq: "flight_error_code",
      uq: "flight_error_message",
      mj: "fl_activity_category",
      nj: "fl_activity_group",
      Uh: "fl_advertiser_id",
      oj: "match_id",
      bm: "fl_random_number",
      dm: "tran",
      fm: "u",
      Vh: "gac_gclid",
      Ue: "gac_wbraid",
      gm: "gac_wbraid_multiple_conversions",
      wq: "ga_restrict_domain",
      hm: "ga_temp_client_id",
      xq: "ga_temp_ecid",
      Ve: "gdpr_applies",
      Wh: "_gt_metadata",
      im: "geo_granularity",
      jg: "value_callback",
      kg: "value_key",
      fb: "google_analysis_params",
      We: "_google_ng",
      yq: "_ono",
      lg: "google_signals",
      zq: "google_tld",
      Xh: "gpp_sid",
      Yh: "gpp_string",
      Zh: "groups",
      jm: "gsa_experiment_id",
      mg: "gtag_event_feature_usage",
      km: "gtm_up",
      Rd: "iframe_state",
      ng: "ignore_referrer",
      lm: "internal_traffic_results",
      om: "_is_fpm",
      dd: "is_legacy_converted",
      ed: "is_legacy_loaded",
      pj: "is_passthrough",
      Xe: "_lps",
      zb: "language",
      ai: "legacy_developer_id_string",
      rb: "linker",
      og: "accept_incoming",
      Fc: "decorate_forms",
      za: "domains",
      fd: "url_position",
      Sd: "merchant_feed_label",
      Td: "merchant_feed_language",
      Ud: "merchant_id",
      qm: "method",
      Aq: "name",
      rm: "navigation_type",
      Ye: "new_customer",
      qj: "non_interaction",
      Bq: "optimize_id",
      sm: "page_hostname",
      pg: "page_path",
      hb: "page_referrer",
      Ob: "page_title",
      Cq: "passengers",
      tm: "phone_conversion_callback",
      Dq: "phone_conversion_country_code",
      vm: "phone_conversion_css_class",
      Eq: "phone_conversion_ids",
      wm: "phone_conversion_number",
      xm: "phone_conversion_options",
      Fq: "_platinum_request_status",
      Gq: "_protected_audience_enabled",
      bi: "quantity",
      di: "redact_device_info",
      ym: "referral_exclusion_definition",
      yu: "_request_start_time",
      Zb: "restricted_data_processing",
      Hq: "retoken",
      Iq: "sample_rate",
      rj: "screen_name",
      gd: "screen_resolution",
      zm: "_script_source",
      Jq: "search_term",
      Vd: "send_page_view",
      Wd: "send_to",
      Xd: "server_container_url",
      Kq: "session_attributes_encoded",
      ei: "session_duration",
      fi: "session_engaged",
      sj: "session_engaged_time",
      Gc: "session_id",
      gi: "session_number",
      qg: "_shared_user_id",
      Yd: "delivery_postal_code",
      zu: "_tag_firing_delay",
      Au: "_tag_firing_time",
      Bu: "temporary_client_id",
      tj: "testonly",
      Lq: "_timezone",
      rg: "topmost_url",
      sg: "tracking_id",
      uj: "traffic_type",
      Ra: "transaction_id",
      Am: "transaction_id_source",
      hd: "transport_url",
      Mq: "trip_type",
      Zd: "update",
      Pb: "url_passthrough",
      Bm: "uptgs",
      tg: "_user_agent_architecture",
      ug: "_user_agent_bitness",
      vg: "_user_agent_full_version_list",
      wg: "_user_agent_mobile",
      xg: "_user_agent_model",
      yg: "_user_agent_platform",
      zg: "_user_agent_platform_version",
      Ag: "_user_agent_wow64",
      ac: "user_data",
      Cm: "user_data_auto_latency",
      Dm: "user_data_auto_meta",
      Em: "user_data_auto_multi",
      Fm: "user_data_auto_selectors",
      Gm: "user_data_auto_status",
      ae: "user_data_mode",
      Hm: "user_data_settings",
      Ua: "user_id",
      be: "user_properties",
      Im: "_user_region",
      Bg: "us_privacy_string",
      Sa: "value",
      Jm: "wbraid_multiple_conversions",
      jd: "_fpm_parameters",
      zj: "_host_name",
      rn: "_in_page_command",
      Bj: "_ip_override",
      vn: "_is_passthrough_cid",
      oi: "_measurement_type",
      je: "non_personalized_ads",
      Nj: "_sst_parameters",
      yr: "sgtm_geo_user_country",
      Kd: "conversion_label",
      Ea: "page_location",
      bd: "_extracted_data",
      Ec: "global_developer_id_string",
      Ze: "tc_privacy_string",
    },
  };
  var J = {
    J: {
      Qi: "accept_by_default",
      al: "add_tag_timing",
      He: "ads_event_page_view",
      Cd: "allow_ad_personalization",
      iu: "auto_event",
      ol: "batch_on_navigation",
      Ri: "biscotti_join_id",
      rl: "client_id_source",
      Gf: "consent_event_id",
      Hf: "consent_priority_id",
      ku: "consent_state",
      qa: "consent_updated",
      Fd: "conversion_linker_enabled",
      lu: "conversion_marking_called",
      Da: "cookie_options",
      Il: "dc_random",
      Vc: "em_event",
      tu: "endpoint_for_debug",
      Ml: "enhanced_client_id_source",
      Ip: "enhanced_match_result",
      Km: "euid_logged_in_state",
      Cg: "euid_mode_enabled",
      Nq: "event_provenance",
      Ab: "event_start_timestamp_ms",
      Om: "event_usage",
      ii: "extra_tag_experiment_ids",
      Fu: "add_parameter",
      xj: "counting_method",
      ji: "send_as_iframe",
      Gu: "parameter_order",
      Dg: "parsed_target",
      Sq: "ga4_collection_subdomain",
      yj: "ga4_request_flags",
      kn: "gbraid_cookie_marked",
      mn: "gtm_extracted_data",
      Qb: "handle_internally",
      Ju: "has_ga_conversion_consents",
      ba: "hit_type",
      Hc: "hit_type_override",
      Zq: "ignore_dupe_config",
      gv: "is_config_command",
      li: "is_consent_update",
      Eg: "is_conversion",
      sn: "is_ecommerce",
      tn: "is_ec_cm_split",
      ee: "is_external_event",
      Fg: "is_first_visit",
      un: "is_first_visit_conversion",
      Cj: "is_fl_fallback_conversion_flow_allowed",
      kd: "is_fpm_encryption",
      mi: "is_fpm_split",
      Aa: "is_gcp_conversion",
      Dj: "is_google_measurement_allowed",
      Ej: "is_google_signals_enabled",
      fe: "is_merchant_center",
      ni: "is_new_to_site",
      he: "is_personalization",
      Fj: "is_server_side_destination",
      cf: "is_session_start",
      wn: "is_session_start_conversion",
      hv: "is_sgtm_ga_ads_conversion_study_control_group",
      jv: "is_sgtm_prehit",
      xn: "is_sgtm_service_worker",
      Gg: "is_split_conversion",
      ar: "is_syn",
      Rb: "is_test_event",
      Hg: "join_id",
      Gj: "join_elapsed",
      Ig: "join_timer_sec",
      zn: "local_storage_aw_conversion_counters",
      hf: "tunnel_updated",
      nv: "prehit_for_retry",
      pv: "promises",
      qv: "record_aw_latency",
      md: "redact_ads_data",
      jf: "redact_click_ids",
      In: "remarketing_only",
      ui: "send_ccm_parallel_ping",
      me: "send_doubleclick_join",
      wi: "send_fpm_geo_join",
      xi: "send_fpm_google_join",
      tv: "send_ccm_parallel_test_ping",
      Kn: "send_google_measurement",
      Lg: "send_tld_join",
      Mg: "send_to_destinations",
      Lj: "send_to_targets",
      Ln: "send_user_data_hit",
      Oj: "service_worker_context",
      tb: "source_canonical_id",
      Ka: "speculative",
      Sn: "speculative_in_message",
      Un: "suppress_script_load",
      Vn: "syn_or_mod",
      Wj: "transient_ecsid",
      Ng: "transmission_type",
      ib: "user_data",
      xv: "user_data_from_automatic",
      yv: "user_data_from_automatic_getter",
      Zn: "user_data_from_code",
      Cr: "user_data_from_manual",
      zv: "user_data_mode",
      Og: "user_id_updated",
    },
  };
  var K = {
    U: {
      Ep: 1,
      Gp: 2,
      Yn: 3,
      Gn: 4,
      Jl: 5,
      Kl: 6,
      Wq: 7,
      Hp: 8,
      Vq: 9,
      Dp: 10,
      Cp: 11,
      Rn: 12,
      Nn: 13,
      ql: 14,
      rp: 15,
      up: 16,
      An: 17,
      Ll: 18,
      yn: 19,
      Fp: 20,
      lr: 21,
      xp: 22,
      tp: 23,
      vp: 24,
      Hl: 25,
      pl: 26,
      zr: 27,
      fn: 28,
      qn: 29,
      pn: 30,
      on: 31,
      jn: 32,
      gn: 33,
      hn: 34,
      Zm: 35,
      Ym: 36,
      bn: 37,
      dn: 38,
      Tq: 39,
      Uq: 40,
      ur: 41,
    },
  };
  K.U[K.U.Ep] = "CREATE_EVENT_SOURCE";
  K.U[K.U.Gp] = "EDIT_EVENT";
  K.U[K.U.Yn] = "TRAFFIC_TYPE";
  K.U[K.U.Gn] = "REFERRAL_EXCLUSION";
  K.U[K.U.Jl] = "ECOMMERCE_FROM_GTM_TAG";
  K.U[K.U.Kl] = "ECOMMERCE_FROM_GTM_UA_SCHEMA";
  K.U[K.U.Wq] = "GA_SEND";
  K.U[K.U.Hp] = "EM_FORM";
  K.U[K.U.Vq] = "GA_GAM_LINK";
  K.U[K.U.Dp] = "CREATE_EVENT_AUTO_PAGE_PATH";
  K.U[K.U.Cp] = "CREATED_EVENT";
  K.U[K.U.Rn] = "SIDELOADED";
  K.U[K.U.Nn] = "SGTM_LEGACY_CONFIGURATION";
  K.U[K.U.ql] = "CCD_EM_EVENT";
  K.U[K.U.rp] = "AUTO_REDACT_EMAIL";
  K.U[K.U.up] = "AUTO_REDACT_QUERY_PARAM";
  K.U[K.U.An] = "MULTIPLE_PAGEVIEW_FROM_CONFIG";
  K.U[K.U.Ll] = "EM_EVENT_SENT_BEFORE_CONFIG";
  K.U[K.U.yn] = "LOADED_VIA_CST_OR_SIDELOADING";
  K.U[K.U.Fp] = "DECODED_PARAM_MATCH";
  K.U[K.U.lr] = "NON_DECODED_PARAM_MATCH";
  K.U[K.U.xp] = "CCD_EVENT_SGTM";
  K.U[K.U.tp] = "AUTO_REDACT_EMAIL_SGTM";
  K.U[K.U.vp] = "AUTO_REDACT_QUERY_PARAM_SGTM";
  K.U[K.U.Hl] = "DAILY_LIMIT_REACHED";
  K.U[K.U.pl] = "BURST_LIMIT_REACHED";
  K.U[K.U.zr] = "SHARED_USER_ID_SET_AFTER_REQUEST";
  K.U[K.U.fn] = "GA4_MULTIPLE_SESSION_COOKIES";
  K.U[K.U.qn] = "INVALID_GA4_SESSION_COUNT";
  K.U[K.U.pn] = "INVALID_GA4_LAST_EVENT_TIMESTAMP";
  K.U[K.U.on] = "INVALID_GA4_JOIN_TIMER";
  K.U[K.U.jn] = "GA4_STALE_SESSION_COOKIE_SELECTED";
  K.U[K.U.gn] = "GA4_SESSION_COOKIE_GS1_READ";
  K.U[K.U.hn] = "GA4_SESSION_COOKIE_GS2_READ";
  K.U[K.U.Zm] = "GA4_DL_PARAM_RECOVERY_AVAILABLE";
  K.U[K.U.Ym] = "GA4_DL_PARAM_RECOVERY_APPLIED";
  K.U[K.U.bn] = "GA4_GOOGLE_MEASUREMENT_ALLOWED";
  K.U[K.U.dn] = "GA4_GOOGLE_SIGNALS_ENABLED";
  K.U[K.U.Tq] = "GA4_FALLBACK_REQUEST";
  K.U[K.U.Uq] = "GA_ADS_LINK_BEFORE_CONVERSION_MARKING";
  K.U[K.U.ur] = "PLATINUM_ELIGIBLE";
  var rg = {},
    sg =
      ((rg.uaa = !0),
      (rg.uab = !0),
      (rg.uafvl = !0),
      (rg.uamb = !0),
      (rg.uam = !0),
      (rg.uap = !0),
      (rg.uapv = !0),
      (rg.uaw = !0),
      rg);
  var Ag = function (a, b) {
      for (var c = 0; c < b.length; c++) {
        var d = a,
          e = b[c];
        if (!yg.exec(e)) throw Error("Invalid key wildcard");
        var f = e.indexOf(".*"),
          g = f !== -1 && f === e.length - 2,
          h = g ? e.slice(0, e.length - 2) : e,
          l;
        a: if (d.length === 0) l = !1;
        else {
          for (var m = d.split("."), p = 0; p < m.length; p++)
            if (!zg.exec(m[p])) {
              l = !1;
              break a;
            }
          l = !0;
        }
        if (
          !l || h.length > d.length || (!g && d.length !== e.length)
            ? 0
            : g
            ? Ub(d, h) && (d === h || d.charAt(h.length) === ".")
            : d === h
        )
          return !0;
      }
      return !1;
    },
    zg = /^[a-z$_][\w-$]*$/i,
    yg = /^(?:[a-z_$][a-z-_$0-9]*\.)*[a-z_$][a-z-_$0-9]*(?:\.\*)?$/i;
  var Bg = [
    "matches",
    "webkitMatchesSelector",
    "mozMatchesSelector",
    "msMatchesSelector",
    "oMatchesSelector",
  ];
  function Cg(a, b) {
    var c = String(a),
      d = String(b),
      e = c.length - d.length;
    return e >= 0 && c.indexOf(d, e) === e;
  }
  function Dg(a, b) {
    return String(a).split(",").indexOf(String(b)) >= 0;
  }
  var Eg = new Fb();
  function Fg(a, b, c) {
    var d = c ? "i" : void 0;
    try {
      var e = String(b) + String(d),
        f = Eg.get(e);
      f || ((f = new RegExp(b, d)), Eg.set(e, f));
      return f.test(a);
    } catch (g) {
      return !1;
    }
  }
  function Gg(a, b) {
    return String(a).indexOf(String(b)) >= 0;
  }
  function Hg(a, b) {
    return String(a) === String(b);
  }
  function Ig(a, b) {
    return Number(a) >= Number(b);
  }
  function Jg(a, b) {
    return Number(a) <= Number(b);
  }
  function Kg(a, b) {
    return Number(a) > Number(b);
  }
  function Lg(a, b) {
    return Number(a) < Number(b);
  }
  function Mg(a, b) {
    return Ub(String(a), String(b));
  }
  var Tg =
      /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|PixieMap|List|OpaqueValue)$/i,
    Ug = { Fn: "function", PixieMap: "Object", List: "Array" };
  function Vg(a, b) {
    for (var c = ["input:!*"], d = 0; d < c.length; d++) {
      var e = Tg.exec(c[d]);
      if (!e) throw Error("Internal Error in " + a);
      var f = e[1],
        g = e[2] === "!",
        h = e[3],
        l = b[d];
      if (l == null) {
        if (g)
          throw Error(
            "Error in " + a + ". Required argument " + f + " not supplied."
          );
      } else if (h !== "*") {
        var m = typeof l;
        l instanceof Md
          ? (m = "Fn")
          : l instanceof Id
          ? (m = "List")
          : l instanceof kb
          ? (m = "PixieMap")
          : l instanceof Td
          ? (m = "PixiePromise")
          : l instanceof Rd && (m = "OpaqueValue");
        if (m !== h)
          throw Error(
            "Error in " +
              a +
              ". Argument " +
              f +
              " has type " +
              ((Ug[m] || m) + ", which does not match required type ") +
              ((Ug[h] || h) + ".")
          );
      }
    }
  }
  function L(a, b, c) {
    for (var d = [], e = n(c), f = e.next(); !f.done; f = e.next()) {
      var g = f.value;
      g instanceof Md
        ? d.push("function")
        : g instanceof Id
        ? d.push("Array")
        : g instanceof kb
        ? d.push("Object")
        : g instanceof Td
        ? d.push("Promise")
        : g instanceof Rd
        ? d.push("OpaqueValue")
        : d.push(typeof g);
    }
    return Error(
      "Argument error in " +
        a +
        ". Expected argument types [" +
        (b.join(",") + "], but received [") +
        (d.join(",") + "].")
    );
  }
  function Wg(a) {
    return a instanceof kb;
  }
  function Xg(a) {
    return Wg(a) || a === null || Yg(a);
  }
  function Zg(a) {
    return a instanceof Md;
  }
  function $g(a) {
    return Zg(a) || a === null || Yg(a);
  }
  function ah(a) {
    return a instanceof Id;
  }
  function bh(a) {
    return a instanceof Rd;
  }
  function ch(a) {
    return typeof a === "string";
  }
  function dh(a) {
    return ch(a) || a === null || Yg(a);
  }
  function eh(a) {
    return typeof a === "boolean";
  }
  function fh(a) {
    return eh(a) || Yg(a);
  }
  function gh(a) {
    return eh(a) || a === null || Yg(a);
  }
  function hh(a) {
    return typeof a === "number";
  }
  function Yg(a) {
    return a === void 0;
  }
  function ih(a) {
    return "" + a;
  }
  function jh(a, b) {
    var c = [];
    return c;
  }
  function kh(a, b) {
    var c = new Md(a, function () {
      for (
        var d = Array.prototype.slice.call(arguments, 0), e = 0;
        e < d.length;
        e++
      )
        d[e] = this.evaluate(d[e]);
      try {
        return b.apply(this, d);
      } catch (g) {
        throw cb(g);
      }
    });
    c.Ya();
    return c;
  }
  function lh(a, b) {
    var c = new kb(),
      d;
    for (d in b)
      if (b.hasOwnProperty(d)) {
        var e = b[d];
        yb(e)
          ? c.set(d, kh(a + "_" + d, e))
          : Fd(e)
          ? c.set(d, lh(a + "_" + d, e))
          : (Ab(e) || zb(e) || typeof e === "boolean") && c.set(d, e);
      }
    c.Ya();
    return c;
  }
  function mh(a, b) {
    if (!ch(a)) throw L(this.getName(), ["string"], arguments);
    if (!dh(b)) throw L(this.getName(), ["string", "undefined"], arguments);
    var c = {},
      d = new kb();
    return (d = lh("AssertApiSubject", c));
  }
  function nh(a, b) {
    if (!dh(b)) throw L(this.getName(), ["string", "undefined"], arguments);
    if (a instanceof Td)
      throw Error(
        "Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported."
      );
    var c = {},
      d = new kb();
    return (d = lh("AssertThatSubject", c));
  }
  function oh(a) {
    return function () {
      for (
        var b = Pa.apply(0, arguments), c = [], d = this.T, e = 0;
        e < b.length;
        ++e
      )
        c.push(B(b[e], d));
      return Ud(a.apply(null, c));
    };
  }
  function ph() {
    for (var a = Math, b = qh, c = {}, d = 0; d < b.length; d++) {
      var e = b[d];
      a.hasOwnProperty(e) && (c[e] = oh(a[e].bind(a)));
    }
    return c;
  }
  function rh(a) {
    return a != null && Ub(a, "__cvt_");
  }
  function sh(a) {
    var b;
    return b;
  }
  function th(a) {
    var b;
    if (!ch(a)) throw L(this.getName(), ["string"], arguments);
    try {
      b = decodeURIComponent(a);
    } catch (c) {}
    return b;
  }
  function uh(a) {
    try {
      return encodeURI(a);
    } catch (b) {}
  }
  function vh(a) {
    try {
      return encodeURIComponent(String(a));
    } catch (b) {}
  }
  function Ah(a) {
    if (!dh(a)) throw L(this.getName(), ["string|undefined"], arguments);
  }
  function Bh(a) {
    var b = 1,
      c,
      d,
      e;
    if (a)
      for (b = 0, d = a.length - 1; d >= 0; d--)
        (e = a.charCodeAt(d)),
          (b = ((b << 6) & 268435455) + e + (e << 14)),
          (c = b & 266338304),
          (b = c !== 0 ? b ^ (c >> 21) : b);
    return b;
  }
  function Ch(a) {
    var b = B(a);
    return Bh(b ? "" + b : "");
  }
  function Dh(a, b) {
    if (!hh(a) || !hh(b))
      throw L(this.getName(), ["number", "number"], arguments);
    return Db(a, b);
  }
  function Eh() {
    return new Date().getTime();
  }
  function Fh(a) {
    if (a === null) return "null";
    if (a instanceof Id) return "array";
    if (a instanceof Md) return "function";
    if (a instanceof Rd) {
      var b = a.getValue();
      if (
        (b == null ? void 0 : b.constructor) === void 0 ||
        b.constructor.name === void 0
      ) {
        var c = String(b);
        return c.substring(8, c.length - 1);
      }
      return String(b.constructor.name);
    }
    return typeof a;
  }
  function Gh(a) {
    function b(c) {
      return function (d) {
        try {
          return c(d);
        } catch (e) {
          (jg || kg.np) && a.call(this, e.message);
        }
      };
    }
    return {
      parse: b(function (c) {
        return Ud(JSON.parse(c));
      }),
      stringify: b(function (c) {
        return JSON.stringify(B(c));
      }),
      publicName: "JSON",
    };
  }
  function Hh(a) {
    return Ib(B(a, this.T));
  }
  function Ih(a) {
    return Number(B(a, this.T));
  }
  function Jh(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a.toString();
  }
  function Kh(a, b, c) {
    var d = null,
      e = !1;
    return e ? d : null;
  }
  var qh = "floor ceil round max min abs pow sqrt".split(" ");
  function Lh() {
    var a = {};
    return {
      ys: function (b) {
        return a.hasOwnProperty(b) ? a[b] : void 0;
      },
      fp: function (b, c) {
        a[b] = c;
      },
      reset: function () {
        a = {};
      },
    };
  }
  function Mh(a, b) {
    return function () {
      return Md.prototype.invoke.apply(
        a,
        [b].concat(za(Pa.apply(0, arguments)))
      );
    };
  }
  function Nh(a, b) {
    if (!ch(a)) throw L(this.getName(), ["string", "any"], arguments);
  }
  function Oh(a, b) {
    if (!ch(a) || !Wg(b))
      throw L(this.getName(), ["string", "PixieMap"], arguments);
  }
  var Ph = {};
  Ph.keys = function (a) {
    return new Id();
  };
  Ph.values = function (a) {
    return new Id();
  };
  Ph.entries = function (a) {
    return new Id();
  };
  Ph.freeze = function (a) {
    return a;
  };
  Ph.delete = function (a, b) {
    return !1;
  };
  function M(a, b) {
    var c = Pa.apply(2, arguments),
      d = a.T.Eb();
    if (!d) throw Error("Missing program state.");
    if (d.Kt) {
      try {
        d.ko.apply(null, [b].concat(za(c)));
      } catch (e) {
        throw (sb("TAGGING", 21), e);
      }
      return;
    }
    d.ko.apply(null, [b].concat(za(c)));
  }
  var Rh = function () {
    this.K = {};
    this.H = {};
    this.O = !0;
  };
  Rh.prototype.get = function (a, b) {
    var c = this.contains(a) ? this.K[a] : void 0;
    return c;
  };
  Rh.prototype.contains = function (a) {
    return this.K.hasOwnProperty(a);
  };
  Rh.prototype.add = function (a, b, c) {
    if (this.contains(a))
      throw Error(
        "Attempting to add a function which already exists: " + a + "."
      );
    if (this.H.hasOwnProperty(a))
      throw Error(
        "Attempting to add an API with an existing private API name: " + a + "."
      );
    this.K[a] = c ? void 0 : yb(b) ? kh(a, b) : lh(a, b);
  };
  function Sh(a, b) {
    var c = void 0;
    return c;
  }
  function Th() {
    var a = {};
    return a;
  }
  var Uh = {},
    Vh =
      ((Uh[H.D.qa] = "gcu"),
      (Uh[H.D.Jf] = "ept"),
      (Uh[H.D.Vb] = "gclgb"),
      (Uh[H.D.yb] = "gclaw"),
      (Uh[H.D.Rl] = "gclid_len"),
      (Uh[H.D.Me] = "gclgs"),
      (Uh[H.D.Ne] = "gcllp"),
      (Uh[H.D.Oe] = "gclst"),
      (Uh[H.D.Id] = "auid"),
      (Uh[H.D.Tl] = "ae"),
      (Uh[H.D.Qf] = "dscnt"),
      (Uh[H.D.Rf] = "fcntr"),
      (Uh[H.D.Sf] = "flng"),
      (Uh[H.D.Tf] = "mid"),
      (Uh[H.D.cj] = "bttype"),
      (Uh[H.D.Mb] = "gacid"),
      (Uh[H.D.Kd] = "label"),
      (Uh[H.D.Qe] = "capi"),
      (Uh[H.D.Mh] = "pscdl"),
      (Uh[H.D.eb] = "currency_code"),
      (Uh[H.D.Nh] = "clobs"),
      (Uh[H.D.Re] = "vdltv"),
      (Uh[H.D.Oh] = "clolo"),
      (Uh[H.D.Ph] = "clolb"),
      (Uh[H.D.Wl] = "_dbg"),
      (Uh[H.D.Te] = "oedeld"),
      (Uh[H.D.Cc] = "edid"),
      (Uh[H.D.Pd] = "evnid"),
      (Uh[H.D.Qd] = "excid"),
      (Uh[H.D.Vh] = "gac"),
      (Uh[H.D.Ue] = "gacgb"),
      (Uh[H.D.gm] = "gacmcov"),
      (Uh[H.D.Ve] = "gdpr"),
      (Uh[H.D.Ec] = "gdid"),
      (Uh[H.D.We] = "_ng"),
      (Uh[H.D.yq] = "_ono"),
      (Uh[H.D.Xh] = "gpp_sid"),
      (Uh[H.D.Yh] = "gpp"),
      (Uh[H.D.jm] = "gsaexp"),
      (Uh[H.D.mg] = "_tu"),
      (Uh[H.D.Rd] = "frm"),
      (Uh[H.D.pj] = "gtm_up"),
      (Uh[H.D.Xe] = "lps"),
      (Uh[H.D.ai] = "did"),
      (Uh[H.D.Sd] = "fcntr"),
      (Uh[H.D.Td] = "flng"),
      (Uh[H.D.Ud] = "mid"),
      (Uh[H.D.Ye] = void 0),
      (Uh[H.D.Ob] = "tiba"),
      (Uh[H.D.Zb] = "rdp"),
      (Uh[H.D.Gc] = "ecsid"),
      (Uh[H.D.qg] = "ga_uid"),
      (Uh[H.D.Yd] = "delopc"),
      (Uh[H.D.Ze] = "gdpr_consent"),
      (Uh[H.D.Ra] = "oid"),
      (Uh[H.D.Am] = "oidsrc"),
      (Uh[H.D.Bm] = "uptgs"),
      (Uh[H.D.tg] = "uaa"),
      (Uh[H.D.ug] = "uab"),
      (Uh[H.D.vg] = "uafvl"),
      (Uh[H.D.wg] = "uamb"),
      (Uh[H.D.xg] = "uam"),
      (Uh[H.D.yg] = "uap"),
      (Uh[H.D.zg] = "uapv"),
      (Uh[H.D.Ag] = "uaw"),
      (Uh[H.D.Cm] = "ec_lat"),
      (Uh[H.D.Dm] = "ec_meta"),
      (Uh[H.D.Em] = "ec_m"),
      (Uh[H.D.Fm] = "ec_sel"),
      (Uh[H.D.Gm] = "ec_s"),
      (Uh[H.D.ae] = "ec_mode"),
      (Uh[H.D.Ua] = "userId"),
      (Uh[H.D.Bg] = "us_privacy"),
      (Uh[H.D.Sa] = "value"),
      (Uh[H.D.Jm] = "mcov"),
      (Uh[H.D.zj] = "hn"),
      (Uh[H.D.rn] = "gtm_ee"),
      (Uh[H.D.Bj] = "uip"),
      (Uh[H.D.oi] = "mt"),
      (Uh[H.D.je] = "npa"),
      (Uh[H.D.yr] = "sg_uc"),
      (Uh[H.D.Lh] = null),
      (Uh[H.D.gd] = null),
      (Uh[H.D.zb] = null),
      (Uh[H.D.Ha] = null),
      (Uh[H.D.Ea] = null),
      (Uh[H.D.hb] = null),
      (Uh[H.D.rg] = null),
      (Uh[H.D.jd] = null),
      (Uh[H.D.Wh] = null),
      (Uh[H.D.Lf] = null),
      (Uh[H.D.Mf] = null),
      (Uh[H.D.Hh] = null),
      (Uh[H.D.Ih] = null),
      (Uh[H.D.fb] = null),
      (Uh[H.D.bd] = null),
      Uh);
  function Wh(a, b) {
    if (a) {
      var c = a.split("x");
      c.length === 2 && (Xh(b, "u_w", c[0]), Xh(b, "u_h", c[1]));
    }
  }
  function Yh(a) {
    var b = Zh;
    b = b === void 0 ? $h : b;
    return ai(bi(a, b));
  }
  function ai(a) {
    return (a || [])
      .filter(function (b) {
        return !!b;
      })
      .map(function (b) {
        return (
          "(" +
          [
            ci(b.value),
            ci(b.quantity),
            ci(b.item_id),
            ci(b.start_date),
            ci(b.end_date),
          ].join("*") +
          ")"
        );
      })
      .join("");
  }
  function bi(a, b) {
    return (a || [])
      .filter(function (c) {
        return !!c;
      })
      .map(function (c) {
        return {
          item_id: b(c),
          quantity: c.quantity,
          value: c.price,
          start_date: c.start_date,
          end_date: c.end_date,
        };
      });
  }
  function $h(a) {
    return [a.item_id, a.id, a.item_name].find(function (b) {
      return b != null;
    });
  }
  function di(a) {
    if (a && a.length)
      return a
        .map(function (b) {
          return b && b.estimated_delivery_date
            ? b.estimated_delivery_date
            : "";
        })
        .join(",");
  }
  function Xh(a, b, c) {
    c === void 0 || c === null || (c === "" && !sg[b]) || (a[b] = c);
  }
  function ci(a) {
    return typeof a !== "number" && typeof a !== "string" ? "" : a.toString();
  }
  function ei() {
    this.blockSize = -1;
  }
  function fi(a, b) {
    this.blockSize = -1;
    this.blockSize = 64;
    this.O = Ra.Uint8Array
      ? new Uint8Array(this.blockSize)
      : Array(this.blockSize);
    this.V = this.K = 0;
    this.H = [];
    this.ka = a;
    this.Z = b;
    this.la = Ra.Int32Array ? new Int32Array(64) : Array(64);
    gi === void 0 && (Ra.Int32Array ? (gi = new Int32Array(hi)) : (gi = hi));
    this.reset();
  }
  Sa(fi, ei);
  for (var ii = [], ji = 0; ji < 63; ji++) ii[ji] = 0;
  var ki = [].concat(128, ii);
  fi.prototype.reset = function () {
    this.V = this.K = 0;
    var a;
    if (Ra.Int32Array) a = new Int32Array(this.Z);
    else {
      var b = this.Z,
        c = b.length;
      if (c > 0) {
        for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
        a = d;
      } else a = [];
    }
    this.H = a;
  };
  var li = function (a) {
    for (var b = a.O, c = a.la, d = 0, e = 0; e < b.length; )
      (c[d++] = (b[e] << 24) | (b[e + 1] << 16) | (b[e + 2] << 8) | b[e + 3]),
        (e = d * 4);
    for (var f = 16; f < 64; f++) {
      var g = c[f - 15] | 0,
        h = c[f - 2] | 0;
      c[f] =
        ((((c[f - 16] | 0) +
          (((g >>> 7) | (g << 25)) ^ ((g >>> 18) | (g << 14)) ^ (g >>> 3))) |
          0) +
          (((c[f - 7] | 0) +
            (((h >>> 17) | (h << 15)) ^
              ((h >>> 19) | (h << 13)) ^
              (h >>> 10))) |
            0)) |
        0;
    }
    for (
      var l = a.H[0] | 0,
        m = a.H[1] | 0,
        p = a.H[2] | 0,
        q = a.H[3] | 0,
        r = a.H[4] | 0,
        t = a.H[5] | 0,
        v = a.H[6] | 0,
        u = a.H[7] | 0,
        x = 0;
      x < 64;
      x++
    ) {
      var y =
          ((((l >>> 2) | (l << 30)) ^
            ((l >>> 13) | (l << 19)) ^
            ((l >>> 22) | (l << 10))) +
            ((l & m) ^ (l & p) ^ (m & p))) |
          0,
        A =
          (((u +
            (((r >>> 6) | (r << 26)) ^
              ((r >>> 11) | (r << 21)) ^
              ((r >>> 25) | (r << 7)))) |
            0) +
            ((((((r & t) ^ (~r & v)) + (gi[x] | 0)) | 0) + (c[x] | 0)) | 0)) |
          0;
      u = v;
      v = t;
      t = r;
      r = (q + A) | 0;
      q = p;
      p = m;
      m = l;
      l = (A + y) | 0;
    }
    a.H[0] = (a.H[0] + l) | 0;
    a.H[1] = (a.H[1] + m) | 0;
    a.H[2] = (a.H[2] + p) | 0;
    a.H[3] = (a.H[3] + q) | 0;
    a.H[4] = (a.H[4] + r) | 0;
    a.H[5] = (a.H[5] + t) | 0;
    a.H[6] = (a.H[6] + v) | 0;
    a.H[7] = (a.H[7] + u) | 0;
  };
  fi.prototype.update = function (a, b) {
    b === void 0 && (b = a.length);
    var c = 0,
      d = this.K;
    if (typeof a === "string")
      for (; c < b; )
        (this.O[d++] = a.charCodeAt(c++)),
          d == this.blockSize && (li(this), (d = 0));
    else {
      var e,
        f = typeof a;
      e = f != "object" ? f : a ? (Array.isArray(a) ? "array" : f) : "null";
      if (e == "array" || (e == "object" && typeof a.length == "number"))
        for (; c < b; ) {
          var g = a[c++];
          if (!("number" == typeof g && 0 <= g && 255 >= g && g == (g | 0)))
            throw Error("message must be a byte array");
          this.O[d++] = g;
          d == this.blockSize && (li(this), (d = 0));
        }
      else throw Error("message must be string or array");
    }
    this.K = d;
    this.V += b;
  };
  fi.prototype.digest = function () {
    var a = [],
      b = this.V * 8;
    this.K < 56
      ? this.update(ki, 56 - this.K)
      : this.update(ki, this.blockSize - (this.K - 56));
    for (var c = 63; c >= 56; c--) (this.O[c] = b & 255), (b /= 256);
    li(this);
    for (var d = 0, e = 0; e < this.ka; e++)
      for (var f = 24; f >= 0; f -= 8) a[d++] = (this.H[e] >> f) & 255;
    return a;
  };
  var hi = [
      1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993,
      2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987,
      1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774,
      264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986,
      2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711,
      113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291,
      1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411,
      3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344,
      430227734, 506948616, 659060556, 883997877, 958139571, 1322822218,
      1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424,
      2428436474, 2756734187, 3204031479, 3329325298,
    ],
    gi;
  function mi() {
    fi.call(this, 8, ni);
  }
  Sa(mi, fi);
  var ni = [
    1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924,
    528734635, 1541459225,
  ];
  var oi = /^[0-9A-Fa-f]{64}$/;
  function pi(a) {
    try {
      return new TextEncoder().encode(a);
    } catch (b) {
      return $b(a);
    }
  }
  function qi(a) {
    var b = w;
    if (a === "" || a === "e0") return Promise.resolve(a);
    var c;
    if ((c = b.crypto) == null ? 0 : c.subtle) {
      if (oi.test(a)) return Promise.resolve(a);
      try {
        var d = pi(a);
        return b.crypto.subtle
          .digest("SHA-256", d)
          .then(function (e) {
            return ri(e, b);
          })
          .catch(function () {
            return "e2";
          });
      } catch (e) {
        return Promise.resolve("e2");
      }
    } else return Promise.resolve("e1");
  }
  function si(a) {
    try {
      var b = new mi();
      b.update(pi(a));
      return b.digest();
    } catch (c) {
      return "e2";
    }
  }
  function ti(a) {
    var b = w;
    if (a === "" || a === "e0" || oi.test(a)) return a;
    var c = si(a);
    if (c === "e2") return "e2";
    try {
      return ri(c, b);
    } catch (d) {
      return "e2";
    }
  }
  function ri(a, b) {
    var c = Array.from(new Uint8Array(a))
      .map(function (d) {
        return String.fromCharCode(d);
      })
      .join("");
    return b.btoa(c).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  var ui = {},
    vi = function () {
      for (var a = !1, b = !1, c = 0; a === b; )
        if (((a = Db(0, 1) === 0), (b = Db(0, 1) === 0), c++, c > 30)) return;
      return a;
    },
    xi = { Qt: wi };
  function wi(a, b, c) {
    var d = ui[b];
    if (
      !(
        (c === void 0 ? Db(0, 9999) : c % 1e4) <
        d.probability * (d.controlId2 ? 4 : 2) * 1e4
      )
    )
      return a;
    a: {
      var e = d.studyId,
        f = d.experimentId,
        g = d.controlId,
        h = d.controlId2;
      if (!((a.exp || {})[f] || (a.exp || {})[g] || (h && (a.exp || {})[h]))) {
        var l = c !== void 0 ? c % 2 === 0 : vi();
        if (l !== void 0) {
          var m = l ? 0 : 1;
          if (h) {
            var p = c !== void 0 ? (c >> 1) % 2 === 0 : vi();
            if (p === void 0) break a;
            m |= (p ? 0 : 1) << 1;
          }
          m === 0
            ? yi(a, f, e)
            : m === 1
            ? yi(a, g, e)
            : m === 2 && yi(a, h, e);
        }
      }
    }
    return a;
  }
  function zi(a, b) {
    return ui[b]
      ? !!ui[b].active ||
          ui[b].probability > 0.5 ||
          !!(a.exp || {})[ui[b].experimentId]
      : !1;
  }
  function Ai(a, b) {
    return !ui[b] || !ui[b].controlId || ui[b].active || ui[b].probability > 0.5
      ? !1
      : !!(a.exp || {})[ui[b].controlId];
  }
  function Bi(a, b) {
    return !ui[b] ||
      !ui[b].controlId2 ||
      ui[b].active ||
      ui[b].probability > 0.5
      ? !1
      : !!(a.exp || {})[ui[b].controlId2];
  }
  function Ci(a, b) {
    for (
      var c = a.exp || {}, d = n(Object.keys(c).map(Number)), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = e.value;
      if (c[f] === b) return f;
    }
  }
  function yi(a, b, c) {
    var d = a.exp || {};
    d[b] = c;
    a.exp = d;
  }
  function Di(a, b) {
    var c = Ei(a, H.D.Lh);
    return b + "/" + c + "/";
  }
  var Fi = function (a) {
      switch (a) {
        case 1:
          return 0;
        case 502:
          return 17;
        case 491:
          return 14;
        case 480:
          return 13;
        case 499:
          return 12;
        case 500:
          return 6;
        case 511:
          return 7;
        case 421:
          return 11;
        case 513:
          return 10;
        case 482:
          return 18;
        case 492:
          return 15;
        case 495:
          return 16;
        case 514:
          return 19;
        case 235:
          return 9;
        case 53:
          return 1;
        case 54:
          return 2;
        case 52:
          return 4;
        case 75:
          return 3;
        case 109:
          return 10;
      }
    },
    Gi = function (a, b) {
      a.O[b] = !0;
      var c = Fi(b);
      c !== void 0 && (Uf[c] = !0);
    },
    N = function (a) {
      return !!Hi.O[a];
    },
    Hi = new (function () {
      this.O = [];
      this.K = [];
      this.H = [];
      Gi(this, 132);
      Gi(this, 24);
      var a = Mf(6, 6e4);
      Vf[1] = a;
      var b = Mf(7, 1);
      Vf[3] = b;
      var c = Mf(35, 50);
      Vf[2] = c;
      var d = Mf(69, 1776448920);
      Vf[4] = d;

      Gi(this, 435);

      Gi(this, 141);
    })();
  function Ii(a, b) {
    var c = Ei(a, H.D.Wh);
    if (N(502) && c)
      for (var d = n(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
        var f = e.value,
          g = c[f];
        g !== void 0 && g !== null && (b["gtmd." + f] = String(g));
      }
  }
  var O = {
    R: {
      Si: "call_conversion",
      Uc: "ccm_conversion",
      Ui: "common_aw",
      wa: "conversion",
      Qm: "floodlight",
      de: "ga_conversion",
      fc: "gcp_remarketing",
      Hj: "landing_page",
      Ia: "page_view",
      ef: "fpm_test_hit",
      sb: "remarketing",
      Bb: "user_data_lead",
      Cb: "user_data_web",
    },
  };
  var Ji = function () {
      this.H = new Set();
      this.K = new Set();
    },
    Li = function (a) {
      var b = Ki.H;
      a = a === void 0 ? [] : a;
      var c = []
        .concat(za(b.H))
        .concat([].concat(za(b.K)))
        .concat(a);
      c.sort(function (d, e) {
        return d - e;
      });
      return c;
    },
    Mi = function () {
      var a = [].concat(za(Ki.H.H));
      a.sort(function (b, c) {
        return b - c;
      });
      return a;
    },
    Ni = function () {
      var a = Ki.H,
        b = F(44);
      a.H = new Set();
      if (b !== "")
        for (var c = n(b.split("~")), d = c.next(); !d.done; d = c.next()) {
          var e = Number(d.value);
          isNaN(e) || a.H.add(e);
        }
    };
  var Oi = {},
    Pi = {
      __cl: 1,
      __ecl: 1,
      __ehl: 1,
      __evl: 1,
      __fal: 1,
      __fil: 1,
      __fsl: 1,
      __hl: 1,
      __jel: 1,
      __lcl: 1,
      __sdl: 1,
      __tl: 1,
      __ytl: 1,
    },
    Qi = ma(Object, "assign").call(Object, {}, { __paused: 1, __tg: 1 }, Pi),
    Ri,
    Si = !1;
  Ri = Si;
  var Ti = "";
  Oi.Pj = Ti;
  var Ki = new (function () {
    this.H = new Ji();
  })();
  function Ui(a) {
    a = a === void 0 ? [] : a;
    return Li(a).join("~");
  }
  function Vi() {
    var a = [],
      b = Number("") || 0,
      c = Number("") || 0;
    c || (c = b / 100);
    var d = (function () {
      var t = !1;
      return t;
    })();
    a.push({
      Tk: 228,
      studyId: 228,
      experimentId: 105177154,
      controlId: 105177155,
      controlId2: 105255245,
      probability: c,
      active: d,
      nf: 0,
    });
    var e = Number("") || 0,
      f = Number("") || 0;
    f || (f = e / 100);
    var g = (function () {
      var t = !1;
      return t;
    })();
    a.push({
      Tk: 235,
      studyId: 235,
      experimentId: 105357150,
      controlId: 105357151,
      controlId2: 0,
      probability: f,
      active: g,
      nf: 1,
    });
    var h = Number("") || 0,
      l = Number("") || 0;
    l || (l = h / 100);
    var m = (function () {
      var t = !1;
      return t;
    })();
    a.push({
      Tk: 266,
      studyId: 266,
      experimentId: 115718529,
      controlId: 115718530,
      controlId2: 115718531,
      probability: l,
      active: m,
      nf: 0,
    });
    var p = Number("") || 0,
      q = Number("") || 0;
    q || (q = p / 100);
    var r = (function () {
      var t = !1;
      return t;
    })();
    a.push({
      Tk: 267,
      studyId: 267,
      experimentId: 115718526,
      controlId: 115718527,
      controlId2: 115718528,
      probability: q,
      active: r,
      nf: 0,
    });
    return a;
  }
  var Wi = {
    ia: {
      hu: "aw_user_data_cache",
      Xi: "cookie_deprecation_label",
      Gh: "diagnostics_page_id",
      uu: "em_registry",
      vj: "eab",
      Hu: "fl_user_data_cache",
      Iu: "ga4_user_data_cache",
      bv: "idc_pv_claim",
      bf: "ip_geo_data_cache",
      Aj: "ip_geo_fetch_in_progress",
      Bn: "nb_data",
      rr: "page_experiment_ids",
      Dn: "pld",
      ff: "pt_data",
      En: "pt_listener_set",
      yi: "service_worker_endpoint",
      On: "shared_user_id",
      Pn: "shared_user_id_requested",
      zi: "shared_user_id_source",
      uv: "awh",
      Br: "universal_claim_registry",
    },
  };
  var Xi = (function (a) {
    return tf(function (b) {
      for (var c in a) if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
      return !1;
    });
  })(Wi.ia);
  function Yi(a, b) {
    b = b === void 0 ? !1 : b;
    if (Xi(a)) {
      var c,
        d,
        e =
          (d = (c = Qc("google_tag_data", {})).xcd) != null ? d : (c.xcd = {});
      if (e[a]) return e[a];
      if (b) {
        var f = void 0,
          g = 1,
          h = {},
          l = {
            set: function (m) {
              f = m;
              l.notify();
            },
            get: function () {
              return f;
            },
            subscribe: function (m) {
              h[String(g)] = m;
              return g++;
            },
            unsubscribe: function (m) {
              var p = String(m);
              return h.hasOwnProperty(p) ? (delete h[p], !0) : !1;
            },
            notify: function () {
              for (
                var m = n(Object.keys(h)), p = m.next();
                !p.done;
                p = m.next()
              ) {
                var q = p.value;
                try {
                  h[q](a, f);
                } catch (r) {}
              }
            },
          };
        return (e[a] = l);
      }
    }
  }
  function Zi(a, b) {
    var c = Yi(a, !0);
    c && c.set(b);
  }
  function $i(a) {
    var b;
    return (b = Yi(a)) == null ? void 0 : b.get();
  }
  function aj(a, b) {
    var c = Yi(a);
    if (!c) {
      c = Yi(a, !0);
      if (!c) return;
      c.set(b);
    }
    return c.get();
  }
  function bj(a, b) {
    if (typeof b === "function") {
      var c;
      return (c = Yi(a, !0)) == null ? void 0 : c.subscribe(b);
    }
  }
  function cj(a, b) {
    var c = Yi(a);
    return c ? c.unsubscribe(b) : !1;
  }
  var dj = function () {
      this.K = {};
      this.H = {};
      this.O = {};
      this.V = new Set();
    },
    jj = function (a, b) {
      var c = b,
        d = (b = a.O[c.studyId]
          ? ma(Object, "assign").call(Object, {}, c, { active: !0 })
          : c);
      (d.controlId2 && d.probability <= 0.25) ||
        (d = ma(Object, "assign").call(Object, {}, d, { controlId2: 0 }));
      ui[d.studyId] = d;
      b.focused && (a.K[b.studyId] = !0);
      if (b.nf === 1) {
        var e = b.studyId;
        ej(a, fj(), e);
        gj(a, e)
          ? Gi(Hi, e)
          : hj(a, e)
          ? (Hi.K[e] = !0)
          : ij(a, e) && (Hi.H[e] = !0);
      } else if (b.nf === 0) {
        var f = b.studyId;
        ej(a, a.H, f);
        gj(a, f)
          ? Gi(Hi, f)
          : hj(a, f)
          ? (Hi.K[f] = !0)
          : ij(a, f) && (Hi.H[f] = !0);
      }
    },
    ej = function (a, b, c, d) {
      if (ui[c]) {
        var e = ui[c],
          f = e.experimentId,
          g = e.probability;
        if (!(b.studies || {})[c]) {
          var h = b.studies || {};
          h[c] = !0;
          b.studies = h;
          if (!ui[c].active)
            if (ui[c].probability > 0.5) yi(b, f, c);
            else if (!(g <= 0 || g > 1)) {
              var l = void 0;
              if (d) {
                var m = si(d + "~" + c);
                if (m === "e2") l = -1;
                else {
                  for (
                    var p = new Uint8Array(m),
                      q = BigInt(0),
                      r = n(p),
                      t = r.next();
                    !t.done;
                    t = r.next()
                  )
                    q = (q << BigInt(8)) | BigInt(t.value);
                  l = Number(q % BigInt(Number.MAX_SAFE_INTEGER));
                }
              }
              xi.Qt(b, c, l);
            }
        }
      }
      if (!a.K[c]) {
        var v = Ci(b, c);
        v && Ki.H.K.add(v);
      }
    },
    fj = function () {
      return aj(Wi.ia.rr, {});
    },
    lj = function (a, b) {
      var c = kj;
      ej(c, fj(), a, b);
      gj(c, a)
        ? Gi(Hi, a)
        : hj(c, a)
        ? (Hi.K[a] = !0)
        : ij(c, a) && (Hi.H[a] = !0);
    },
    gj = function (a, b) {
      return zi(fj(), b) || zi(a.H, b);
    },
    hj = function (a, b) {
      return Ai(fj(), b) || Ai(a.H, b);
    },
    ij = function (a, b) {
      return Bi(fj(), b) || Bi(a.H, b);
    },
    kj;
  function mj() {
    if (!kj) {
      var a = (kj = new dj()),
        b,
        c,
        d =
          ((b = w) == null
            ? void 0
            : (c = b.location) == null
            ? void 0
            : c.hash) || "";
      if (
        d[0] === "#" &&
        d[1] === "_" &&
        d[2] === "t" &&
        d[3] === "e" &&
        d[4] === "="
      ) {
        var e = d.substring(5);
        if (e)
          for (var f = n(e.split("~")), g = f.next(); !g.done; g = f.next()) {
            var h = Number(g.value);
            h && ((a.O[h] = !0), Gi(Hi, h));
          }
      }
      for (var l = n(Vi()), m = l.next(); !m.done; m = l.next()) jj(a, m.value);
      for (
        var p = [], q = n(Lf(56) || []), r = q.next();
        !r.done;
        r = q.next()
      ) {
        var t = r.value,
          v = {
            studyId: t[1],
            active: !!t[2],
            probability: t[3] || 0,
            experimentId: t[4] || 0,
            controlId: t[5] || 0,
            controlId2: t[6] || 0,
          },
          u = 0;
        switch (t[7]) {
          case 2:
            u = 1;
            break;
          case 3:
            u = 2;
            break;
          case 1:
          case 4:
          case 5:
          case 0:
            u = 0;
        }
        var x;
        a: switch (v.studyId) {
          case 462:
          case 520:
          case 551:
            x = !0;
            break a;
          default:
            x = !1;
        }
        var y = ma(Object, "assign").call(Object, {}, v, { nf: u, focused: x });
        (y.active || (y.experimentId && y.controlId)) && p.push(y);
      }
      for (var A = n(p), C = A.next(); !C.done; C = A.next()) jj(a, C.value);
    }
  }
  function nj(a) {
    mj();
    var b = kj,
      c = gj(b, a);
    if (b.K[a]) {
      var d;
      (d = Ci(fj(), a) || Ci(b.H, a)) && b.V.add(d);
    }
    return c;
  }
  function oj(a) {
    mj();
    var b = new Set(kj.V);
    if (a)
      for (
        var c = P(a, J.J.ii) || [], d = n(c), e = d.next();
        !e.done;
        e = d.next()
      )
        b.add(e.value);
    return Ui([].concat(za(b)));
  }
  function pj(a, b) {
    b &&
      Gb(b, function (c, d) {
        typeof d !== "object" && d !== void 0 && (a["1p." + c] = String(d));
      });
  }
  var qj = function () {
    this.storage = Ya();
  };
  qj.prototype.set = function (a, b) {
    this.storage.set(String(a), b);
  };
  qj.prototype.get = function (a) {
    return this.storage.get(String(a));
  };
  var rj;
  function sj(a, b) {
    rj || (rj = new qj());
    rj.set(a, b);
  }
  function tj(a) {
    rj || (rj = new qj());
    return rj.get(a);
  }
  function uj(a, b) {
    rj || (rj = new qj());
    var c = rj;
    c.storage.has(String(a)) || c.storage.set(String(a), b());
    return c.storage.get(String(a));
  }
  var vj = {},
    wj =
      ((vj.tdp = 1),
      (vj.exp = 1),
      (vj.gtm = 1),
      (vj.pid = 1),
      (vj.dl = 1),
      (vj.seq = 1),
      (vj.t = 1),
      (vj.v = 1),
      vj),
    yj = function () {
      var a = xj;
      return Object.keys(a.H).filter(function (b) {
        return a.H[b];
      });
    },
    zj = function (a, b, c) {
      if (a.H[b] === void 0 || (c === void 0 ? 0 : c)) a.H[b] = !0;
    },
    Aj = function (a) {
      a.forEach(function (b) {
        wj[b] || (xj.H[b] = !1);
      });
    },
    xj = new (function () {
      this.H = {};
      this.K = {};
    })();
  function Bj(a, b, c) {
    var d = c === void 0 ? !0 : c,
      e = xj;
    e.K[a] = b;
    (d === void 0 || d) && zj(e, a);
  }
  function Cj(a, b) {
    zj(xj, a, b === void 0 ? !1 : b);
  }
  var Dj = /:[0-9]+$/,
    Ej = /^\d+\.fls\.doubleclick\.net$/;
  function Fj(a, b, c, d) {
    var e = Gj(a, !!d, b),
      f,
      g;
    return c
      ? (g = e[b]) != null
        ? g
        : []
      : (f = e[b]) == null
      ? void 0
      : f[0];
  }
  function Gj(a, b, c) {
    for (var d = {}, e = n(a.split("&")), f = e.next(); !f.done; f = e.next()) {
      var g = n(f.value.split("=")),
        h = g.next().value,
        l = xa(g),
        m = decodeURIComponent(h.replace(/\+/g, " "));
      if (c === void 0 || m === c) {
        var p = l.join("=");
        d[m] || (d[m] = []);
        d[m].push(b ? p : decodeURIComponent(p.replace(/\+/g, " ")));
      }
    }
    return d;
  }
  function Hj(a) {
    try {
      return decodeURIComponent(a);
    } catch (b) {}
  }
  function Ij(a, b, c, d, e) {
    b && (b = String(b).toLowerCase());
    if (b === "protocol" || b === "port")
      a.protocol = Jj(a.protocol) || Jj(w.location.protocol);
    b === "port"
      ? (a.port = String(
          Number(a.hostname ? a.port : w.location.port) ||
            (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")
        ))
      : b === "host" &&
        (a.hostname = (a.hostname || w.location.hostname)
          .replace(Dj, "")
          .toLowerCase());
    return Kj(a, b, c, d, e);
  }
  function Kj(a, b, c, d, e) {
    var f,
      g = Jj(a.protocol);
    b && (b = String(b).toLowerCase());
    switch (b) {
      case "url_no_fragment":
        f = Lj(a);
        break;
      case "protocol":
        f = g;
        break;
      case "host":
        f = a.hostname.replace(Dj, "").toLowerCase();
        if (c) {
          var h = /^www\d*\./.exec(f);
          h && h[0] && (f = f.substring(h[0].length));
        }
        break;
      case "port":
        f = String(
          Number(a.port) || (g === "http" ? 80 : g === "https" ? 443 : "")
        );
        break;
      case "path":
        a.pathname || a.hostname || sb("TAGGING", 1);
        f = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" + a.pathname;
        var l = f.split("/");
        (d || []).indexOf(l[l.length - 1]) >= 0 && (l[l.length - 1] = "");
        f = l.join("/");
        break;
      case "query":
        f = a.search.replace("?", "");
        e && (f = Fj(f, e, !1));
        break;
      case "extension":
        var m = a.pathname.split(".");
        f = m.length > 1 ? m[m.length - 1] : "";
        f = f.split("/")[0];
        break;
      case "fragment":
        f = a.hash.replace("#", "");
        break;
      default:
        f = a && a.href;
    }
    return f;
  }
  function Jj(a) {
    return a ? a.replace(":", "").toLowerCase() : "";
  }
  function Lj(a) {
    var b = "";
    if (a && a.href) {
      var c = a.href.indexOf("#");
      b = c < 0 ? a.href : a.href.substring(0, c);
    }
    return b;
  }
  var Mj = {},
    Nj = 0;
  function Oj(a) {
    var b = Mj[a];
    if (!b) {
      var c = z.createElement("a");
      a && (c.href = a);
      var d = c.pathname;
      d[0] !== "/" && (a || sb("TAGGING", 1), (d = "/" + d));
      var e = c.hostname.replace(Dj, "");
      b = {
        href: c.href,
        protocol: c.protocol,
        host: c.host,
        hostname: e,
        pathname: d,
        search: c.search,
        hash: c.hash,
        port: c.port,
      };
      Nj < 5 && ((Mj[a] = b), Nj++);
    }
    return b;
  }
  function Pj(a, b, c) {
    var d = Oj(a);
    return cc(b, d, c);
  }
  function Qj(a) {
    var b = Oj(w.location.href),
      c = Ij(b, "host", !1);
    if (c && c.match(Ej)) {
      var d = Ij(b, "path");
      if (d) {
        var e = d.split(a + "=");
        if (e.length > 1) return e[1].split(";")[0].split("?")[0];
      }
    }
  }
  var Rj = {
      "https://www.google.com": "/g",
      "https://www.googleadservices.com": "/as",
      "https://pagead2.googlesyndication.com": "/gs",
    },
    Sj = [
      "/as/d/ccm/conversion",
      "/g/d/ccm/conversion",
      "/gs/ccm/conversion",
      "/d/ccm/form-data",
    ];
  function Tj() {
    return Hf(47) ? If(54) !== 1 : !1;
  }
  function Uj() {
    var a = F(18),
      b = a.length;
    return a[b - 1] === "/" ? a.substring(0, b - 1) : a;
  }
  function Vj(a, b) {
    if (a) {
      var c = "" + a;
      c.indexOf("http://") !== 0 &&
        c.indexOf("https://") !== 0 &&
        (c = "https://" + c);
      c[c.length - 1] === "/" && (c = c.substring(0, c.length - 1));
      return Oj("" + c + b).href;
    }
  }
  function Wj(a, b) {
    if (Xj()) return Vj(a, b);
  }
  function Xj() {
    return Tj() || Hf(50);
  }
  function Yj() {
    return !!Oi.Pj && Oi.Pj.split("@@").join("") !== "SGTM_TOKEN";
  }
  function Zj(a) {
    for (var b = n([H.D.Xd, H.D.hd]), c = b.next(); !c.done; c = b.next()) {
      var d = R(a, c.value);
      if (d) return d;
    }
  }
  function ak(a, b, c) {
    c = c === void 0 ? "" : c;
    if (!Tj()) return a;
    var d = b ? Rj[a] || "" : "";
    d === "/gs" && (c = "");
    return "" + Uj() + d + c;
  }
  function bk(a) {
    if (Tj())
      for (var b = n(Sj), c = b.next(); !c.done; c = b.next()) {
        var d = c.value;
        if (Ub(a, "" + Uj() + d)) return "::";
      }
  }
  function ck(a) {
    var b = 0;
    a.Ic.forEach(function (c) {
      b |= 1 << c;
    });
    return b;
  }
  function dk() {
    return { total: 0, nb: 0, Ic: new Set(), yf: {} };
  }
  function ek(a, b, c, d) {
    var e = Object.keys(a.zf)
      .sort(function (f, g) {
        return Number(f) - Number(g);
      })
      .map(function (f) {
        return [f, b(a.zf[f])];
      })
      .filter(function (f) {
        return f[1] !== void 0;
      })
      .map(function (f) {
        return f.join(c);
      })
      .join(d);
    return e ? e : void 0;
  }
  function fk(a, b) {
    var c, d, e;
    c = c === void 0 ? "_" : c;
    d = d === void 0 ? ";" : d;
    e = e === void 0 ? "~" : e;
    for (
      var f = [], g = n(Object.keys(a.yf).sort()), h = g.next();
      !h.done;
      h = g.next()
    ) {
      var l = h.value,
        m = ek(a.yf[l], b, c, d);
      if (m) {
        var p = void 0;
        f.push("" + ((p = l) != null ? p : "") + d + m);
      }
    }
    return f.length ? f.join(e) : void 0;
  }
  function gk(a) {
    a.nb = 0;
    a.Ic.clear();
    for (var b = n(Object.keys(a.yf)), c = b.next(); !c.done; c = b.next()) {
      var d = a.yf[c.value];
      d.nb = 0;
      d.Ic.clear();
      for (var e = n(Object.keys(d.zf)), f = e.next(); !f.done; f = e.next()) {
        var g = d.zf[f.value];
        g.nb = 0;
        g.Ic.clear();
      }
    }
  }
  function hk(a, b, c, d, e) {
    d = d === void 0 ? 1 : d;
    a.total += d;
    a.nb += d;
    var f,
      g = b === void 0 ? "" : b;
    f = a.yf[g] || (a.yf[g] = { total: 0, nb: 0, Ic: new Set(), zf: {} });
    f.total += d;
    f.nb += d;
    var h,
      l = String(c);
    h = f.zf[l] || (f.zf[l] = { total: 0, nb: 0, Ic: new Set() });
    h.total += d;
    h.nb += d;
    e !== void 0 && (a.Ic.add(e), f.Ic.add(e), h.Ic.add(e));
  }
  var ik = function () {
    this.H = dk();
  };
  ik.prototype.increment = function (a, b) {
    hk(this.H, a, b);
  };
  var jk = new ik();
  function kk(a) {
    var b = String(a[Ff.bc] || "").replace(/_/g, "");
    return Ub(b, "cvt") ? "cvt" : b;
  }
  var lk =
    w.location.search.indexOf("?gtm_latency=") >= 0 ||
    w.location.search.indexOf("&gtm_latency=") >= 0;
  var nk = function () {
      var a = mk;
      return N(533) ? a.V : N(109) || N(513);
    },
    mk = new (function (a) {
      this.O = a();
      var b = If(27);
      this.K = lk || this.O < b;
      var c = If(42);
      this.H = lk || this.O >= 1 - c;
      var d = If(27),
        e = If(63);
      this.V = lk || e === 1 || (this.O >= d && this.O < d + e);
    })(function () {
      return Math.random();
    });
  var ok = function () {
    var a = {};
    this.H = ((a[1] = {}), (a[2] = {}), (a[3] = {}), (a[4] = {}), a);
  };
  ok.prototype.register = function (a, b, c) {
    if (mk.H) {
      var d = pk(b, c);
      if (d) {
        var e = this.H[b][d];
        e || (e = this.H[b][d] = []);
        e.push(ma(Object, "assign").call(Object, {}, a));
        jk.increment(a.destinationId, a.endpoint);
        a.endpoint !== 56 && a.endpoint !== 61 && Cj("mde", !0);
      }
    }
  };
  var rk = function (a, b) {
      var c = qk,
        d = pk(a, b);
      if (d) {
        var e = c.H[a][d];
        e &&
          (c.H[a][d] = e.filter(function (f) {
            return !f.Zo;
          }));
      }
    },
    sk = function (a) {
      switch (a) {
        case "script-src":
          return { yh: 1, Wg: 4 };
        case "script-src-elem":
          return { yh: 1, Wg: 5 };
        case "frame-src":
          return { yh: 4, Wg: 2 };
        case "connect-src":
          return { yh: 2, Wg: 1 };
        case "img-src":
          return { yh: 3, Wg: 3 };
      }
    },
    pk = function (a, b) {
      var c = b;
      if (b[0] === "/") {
        var d;
        c = ((d = w.location) == null ? void 0 : d.origin) + b;
      }
      try {
        var e = new URL(c);
        return a === 4 ? e.origin : e.origin + e.pathname;
      } catch (f) {}
    },
    qk = new ok();
  function tk(a, b, c) {
    var d,
      e = a.GooglebQhCsO;
    e || ((e = {}), (a.GooglebQhCsO = e));
    d = e;
    if (d[b]) return !1;
    d[b] = [];
    d[b][0] = c;
    return !0;
  }
  var uk, vk;
  a: {
    for (var wk = ["CLOSURE_FLAGS"], xk = Ra, yk = 0; yk < wk.length; yk++)
      if (((xk = xk[wk[yk]]), xk == null)) {
        vk = null;
        break a;
      }
    vk = xk;
  }
  var zk = vk && vk[610401301];
  uk = zk != null ? zk : !1;
  function Ak() {
    var a = Ra.navigator;
    if (a) {
      var b = a.userAgent;
      if (b) return b;
    }
    return "";
  }
  var Bk,
    Ck = Ra.navigator;
  Bk = Ck ? Ck.userAgentData || null : null;
  function Dk(a) {
    if (!uk || !Bk) return !1;
    for (var b = 0; b < Bk.brands.length; b++) {
      var c = Bk.brands[b].brand;
      if (c && c.indexOf(a) != -1) return !0;
    }
    return !1;
  }
  function Ek(a) {
    return Ak().indexOf(a) != -1;
  }
  function Fk() {
    return uk ? !!Bk && Bk.brands.length > 0 : !1;
  }
  function Gk() {
    return Fk() ? !1 : Ek("Opera");
  }
  function Hk() {
    return Ek("Firefox") || Ek("FxiOS");
  }
  function Ik() {
    return Fk()
      ? Dk("Chromium")
      : ((Ek("Chrome") || Ek("CriOS")) && !(Fk() ? 0 : Ek("Edge"))) ||
          Ek("Silk");
  }
  function Jk() {
    return uk ? !!Bk && !!Bk.platform : !1;
  }
  function Kk() {
    return Ek("iPhone") && !Ek("iPod") && !Ek("iPad");
  }
  function Lk() {
    Kk() || Ek("iPad") || Ek("iPod");
  }
  var Mk = function (a) {
    Mk[" "](a);
    return a;
  };
  Mk[" "] = function () {};
  Gk();
  Fk() || Ek("Trident") || Ek("MSIE");
  Ek("Edge");
  !Ek("Gecko") ||
    (Ak().toLowerCase().indexOf("webkit") != -1 && !Ek("Edge")) ||
    Ek("Trident") ||
    Ek("MSIE") ||
    Ek("Edge");
  Ak().toLowerCase().indexOf("webkit") != -1 && !Ek("Edge") && Ek("Mobile");
  Jk() || Ek("Macintosh");
  Jk() || Ek("Windows");
  (Jk() ? Bk.platform === "Linux" : Ek("Linux")) || Jk() || Ek("CrOS");
  Jk() || Ek("Android");
  Kk();
  Ek("iPad");
  Ek("iPod");
  Lk();
  Ak().toLowerCase().indexOf("kaios");
  Hk();
  Kk() || Ek("iPod");
  Ek("iPad");
  !Ek("Android") || Ik() || Hk() || Gk() || Ek("Silk");
  Ik();
  !Ek("Safari") ||
    Ik() ||
    (Fk() ? 0 : Ek("Coast")) ||
    Gk() ||
    (Fk() ? 0 : Ek("Edge")) ||
    (Fk() ? Dk("Microsoft Edge") : Ek("Edg/")) ||
    (Fk() ? Dk("Opera") : Ek("OPR")) ||
    Hk() ||
    Ek("Silk") ||
    Ek("Android") ||
    Lk();
  var Nk = {},
    Ok = null;
  function Pk(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e > 255 && ((b[c++] = e & 255), (e >>= 8));
      b[c++] = e;
    }
    var f = 4;
    f === void 0 && (f = 0);
    if (!Ok) {
      Ok = {};
      for (
        var g =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              ""
            ),
          h = ["+/=", "+/", "-_=", "-_.", "-_"],
          l = 0;
        l < 5;
        l++
      ) {
        var m = g.concat(h[l].split(""));
        Nk[l] = m;
        for (var p = 0; p < m.length; p++) {
          var q = m[p];
          Ok[q] === void 0 && (Ok[q] = p);
        }
      }
    }
    for (
      var r = Nk[f],
        t = Array(Math.floor(b.length / 3)),
        v = r[64] || "",
        u = 0,
        x = 0;
      u < b.length - 2;
      u += 3
    ) {
      var y = b[u],
        A = b[u + 1],
        C = b[u + 2],
        D = r[y >> 2],
        E = r[((y & 3) << 4) | (A >> 4)],
        G = r[((A & 15) << 2) | (C >> 6)],
        I = r[C & 63];
      t[x++] = "" + D + E + G + I;
    }
    var Q = 0,
      V = v;
    switch (b.length - u) {
      case 2:
        (Q = b[u + 1]), (V = r[(Q & 15) << 2] || v);
      case 1:
        var S = b[u];
        t[x] = "" + r[S >> 2] + r[((S & 3) << 4) | (Q >> 4)] + V + v;
    }
    return t.join("");
  }
  var Qk = function (a) {
    return decodeURIComponent(a.replace(/\+/g, " "));
  };
  var Rk = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function Sk(a, b, c, d) {
    for (var e = b, f = c.length; (e = a.indexOf(c, e)) >= 0 && e < d; ) {
      var g = a.charCodeAt(e - 1);
      if (g == 38 || g == 63) {
        var h = a.charCodeAt(e + f);
        if (!h || h == 61 || h == 38 || h == 35) return e;
      }
      e += f + 1;
    }
    return -1;
  }
  var Tk = /#|$/;
  function Uk(a, b) {
    var c = a.search(Tk),
      d = Sk(a, 0, b, c);
    if (d < 0) return null;
    var e = a.indexOf("&", d);
    if (e < 0 || e > c) e = c;
    d += b.length + 1;
    return Qk(a.slice(d, e !== -1 ? e : 0));
  }
  var Vk = /[?&]($|#)/;
  function Wk(a, b, c) {
    for (var d, e = a.search(Tk), f = 0, g, h = []; (g = Sk(a, f, b, e)) >= 0; )
      h.push(a.substring(f, g)), (f = Math.min(a.indexOf("&", g) + 1 || e, e));
    h.push(a.slice(f));
    d = h.join("").replace(Vk, "$1");
    var l,
      m = c != null ? "=" + encodeURIComponent(String(c)) : "";
    var p = b + m;
    if (p) {
      var q,
        r = d.indexOf("#");
      r < 0 && (r = d.length);
      var t = d.indexOf("?"),
        v;
      t < 0 || t > r ? ((t = r), (v = "")) : (v = d.substring(t + 1, r));
      q = [d.slice(0, t), v, d.slice(r)];
      var u = q[1];
      q[1] = p ? (u ? u + "&" + p : p) : u;
      l = q[0] + (q[1] ? "?" + q[1] : "") + q[2];
    } else l = d;
    return l;
  }
  function Xk(a, b, c, d, e, f, g, h) {
    var l = Uk(c, "fmt");
    if (d) {
      var m = Uk(c, "random"),
        p = Uk(c, "label") || "";
      if (!m) return;
      var q = Pk(Qk(p) + ":" + Qk(m));
      if (!tk(a, q, d)) return;
    }
    l && Number(l) !== 4
      ? ((c = Wk(c, "rfmt", l)), (c = Wk(c, "fmt", 4)))
      : l || (c = Wk(c, "fmt", 4));
    Yc(
      c,
      function () {
        g == null || Yk(g);
        h == null || Zk(h, c);
        a.google_noFurtherRedirects &&
          d &&
          ((a.google_noFurtherRedirects = null), d());
      },
      function () {
        g == null || Yk(g);
        h == null || Zk(h, c);
        e == null || e();
      },
      f,
      b.getElementsByTagName("script")[0].parentElement || void 0
    );
    return c;
  }
  function $k(a) {
    var b = Pa.apply(1, arguments);
    qk.register(a, 2, b[0]);
    ld.apply(null, za(b));
  }
  function al(a) {
    var b = Pa.apply(1, arguments);
    qk.register(a, 2, b[0]);
    return md.apply(null, za(b));
  }
  function bl(a) {
    var b = Pa.apply(1, arguments);
    qk.register(a, 3, b[0]);
    ad.apply(null, za(b));
  }
  function cl(a) {
    var b = Pa.apply(1, arguments);
    qk.register(a, 2, b[0]);
    return od.apply(null, za(b));
  }
  function dl(a) {
    var b = Pa.apply(1, arguments);
    qk.register(a, 1, b[0]);
    Yc.apply(null, za(b));
  }
  function el(a) {
    var b = Pa.apply(1, arguments);
    b[0] && qk.register(a, 4, b[0]);
    $c.apply(null, za(b));
  }
  function fl(a) {
    var b = Xk.apply(null, za(Pa.apply(1, arguments)));
    b && qk.register(a, 1, b);
    return b;
  }
  var gl = /gtag[.\/]js/,
    hl = /gtm[.\/]js/,
    jl = function (a) {
      var b = il;
      if ((a.scriptContainerId || "").indexOf("GTM-") >= 0) {
        var c;
        a: {
          var d,
            e = (d = a.scriptElement) == null ? void 0 : d.src;
          if (e) {
            for (
              var f = Hf(47),
                g = Oj(e),
                h = f ? g.pathname : "" + g.hostname + g.pathname,
                l = z.scripts,
                m = "",
                p = 0;
              p < l.length;
              ++p
            ) {
              var q = l[p];
              if (
                !(
                  q.innerHTML.length === 0 ||
                  (!f &&
                    q.innerHTML.indexOf(
                      a.scriptContainerId || "SHOULD_NOT_BE_SET"
                    ) < 0) ||
                  q.innerHTML.indexOf(h) < 0
                )
              ) {
                if (q.innerHTML.indexOf("(function(w,d,s,l,i)") >= 0) {
                  c = String(p);
                  break a;
                }
                m = String(p);
              }
            }
            if (m) {
              c = m;
              break a;
            }
          }
          c = void 0;
        }
        var r = c;
        if (r) return (b.H = !0), r;
      }
      var t = [].slice.call(z.scripts);
      return a.scriptElement ? String(t.indexOf(a.scriptElement)) : "-1";
    },
    kl = function (a) {
      if (il.H) return "1";
      var b,
        c = (b = a.scriptElement) == null ? void 0 : b.src;
      if (c) {
        if (gl.test(c)) return "3";
        if (hl.test(c)) return "2";
      }
      return "0";
    },
    il = new (function () {
      this.H = !1;
    })();
  function T(a) {
    sb("GTM", a);
  }
  function ll(a) {
    var b = ml().destinationArray[a],
      c = ml().destination[a];
    return b && b.length > 0 ? b[0] : c;
  }
  function nl(a, b) {
    var c = ml();
    c.pending || (c.pending = []);
    Cb(c.pending, function (d) {
      return (
        d.target.ctid === a.ctid && d.target.isDestination === a.isDestination
      );
    }) || c.pending.push({ target: a, onLoad: b });
  }
  function ol() {
    var a = w.google_tags_first_party;
    Array.isArray(a) || (a = []);
    for (var b = {}, c = n(a), d = c.next(); !d.done; d = c.next())
      b[d.value] = !0;
    return Object.freeze(b);
  }
  var pl = function () {
    this.container = {};
    this.destination = {};
    this.destinationArray = {};
    this.canonical = {};
    this.pending = [];
    this.injectedFirstPartyContainers = {};
    this.injectedFirstPartyContainers = ol();
  };
  function ml() {
    var a = Qc("google_tag_data", {}),
      b = a.tidr;
    (b && typeof b === "object") || ((b = new pl()), (a.tidr = b));
    var c = b;
    c.container || (c.container = {});
    c.destination || (c.destination = {});
    c.destinationArray || (c.destinationArray = {});
    c.canonical || (c.canonical = {});
    c.pending || (c.pending = []);
    c.injectedFirstPartyContainers || (c.injectedFirstPartyContainers = ol());
    return c;
  }
  function ql() {
    return (
      Hf(7) &&
      rl().some(function (a) {
        return a === F(5);
      })
    );
  }
  function sl() {
    var a;
    return (a = Jf(55)) != null ? a : [];
  }
  function tl() {
    return F(6) || "_" + F(5);
  }
  function ul() {
    var a = F(10);
    return a ? a.split("|") : [F(5)];
  }
  function rl() {
    var a = Jf(59);
    return Array.isArray(a)
      ? a
          .filter(function (b) {
            return typeof b === "string";
          })
          .filter(function (b) {
            return b.indexOf("GTM-") !== 0;
          })
      : [];
  }
  function vl() {
    var a = wl(xl()),
      b = a && a.parent;
    if (b) return wl(b);
  }
  function yl() {
    var a = wl(xl());
    if (a) {
      for (; a.parent; ) {
        var b = wl(a.parent);
        if (!b) break;
        a = b;
      }
      return a;
    }
  }
  function wl(a) {
    var b = ml();
    return a.isDestination ? ll(a.ctid) : b.container[a.ctid];
  }
  function zl() {
    var a = ml();
    if (a.pending) {
      for (
        var b, c = [], d = !1, e = ul(), f = rl(), g = {}, h = 0;
        h < a.pending.length;
        g = { wh: void 0 }, h++
      )
        (g.wh = a.pending[h]),
          Cb(
            g.wh.target.isDestination ? f : e,
            (function (l) {
              return function (m) {
                return m === l.wh.target.ctid;
              };
            })(g)
          )
            ? d || ((b = g.wh.onLoad), (d = !0))
            : c.push(g.wh);
      a.pending = c;
      if (b)
        try {
          b(tl());
        } catch (l) {}
    }
  }
  function Al() {
    for (
      var a = F(5),
        b = ul(),
        c = rl(),
        d = sl(),
        e = function (q, r) {
          var t = {
            canonicalContainerId: F(6),
            scriptContainerId: a,
            state: 2,
            containers: b.slice(),
            destinations: c.slice(),
          };
          Oc && (t.scriptElement = Oc);
          Pc && (t.scriptSource = Pc);
          vl() === void 0 &&
            ((t.htmlLoadOrder = jl(t)), (t.loadScriptType = kl(t)));
          var v, u;
          switch (r) {
            case 0:
              v = function (A) {
                f.container[q] = A;
              };
              u = f.container[q];
              break;
            case 1:
              v = function (A) {
                f.destinationArray[q] = f.destinationArray[q] || [];
                f.destinationArray[q].unshift(A);
              };
              var x,
                y =
                  ((x = f.destinationArray[q]) == null ? void 0 : x[0]) ||
                  f.destination[q];
              !y || (y.state !== 0 && y.state !== 1) || (u = y);
              break;
            case 2:
              (v = function (A) {
                f.destinationArray[q] = f.destinationArray[q] || [];
                f.destinationArray[q].push(A);
              }),
                (u = void 0);
          }
          v &&
            (u
              ? (u.state === 0 && T(93),
                ma(Object, "assign").call(Object, u, t))
              : v(t));
        },
        f = ml(),
        g = n(b),
        h = g.next();
      !h.done;
      h = g.next()
    )
      e(h.value, 0);
    for (var l = n(c), m = l.next(); !m.done; m = l.next()) {
      var p = m.value;
      d.includes(p) ? e(p, 1) : e(p, 2);
    }
    f.canonical[tl()] = {};
    zl();
  }
  function Bl() {
    var a = tl();
    return !!ml().canonical[a];
  }
  function Cl(a) {
    return !!ml().container[a];
  }
  function Dl() {
    var a = xl(),
      b = wl(a);
    return b && b.context;
  }
  function El(a) {
    var b = ll(a);
    return b ? b.state !== 0 : !1;
  }
  function xl() {
    return { ctid: F(5), isDestination: Hf(7) };
  }
  function Gl(a, b, c) {
    var d = xl(),
      e = ml().container[a];
    (e && e.state !== 3) ||
      ((ml().container[a] = { state: 1, context: b, parent: d }),
      nl({ ctid: a, isDestination: !1 }, c));
  }
  function Hl(a, b, c) {
    var d = ml(),
      e = ll(a);
    e
      ? (e.state = 1)
      : ((e = { context: b, state: 1, parent: xl() }),
        (d.destinationArray[a] = [e]));
    nl({ ctid: a, isDestination: !0 }, c);
  }
  function Il(a, b, c, d) {
    var e = ml(),
      f = ll(a);
    f
      ? (f.state = 0)
      : ((f = { state: 0, transportUrl: b, context: c, parent: xl() }),
        (e.destinationArray[a] = [f]));
    nl({ ctid: a, isDestination: !0 }, d);
    T(91);
  }
  function Jl() {
    var a = ml().container,
      b;
    for (b in a) if (a.hasOwnProperty(b) && a[b].state === 1) return !0;
    return !1;
  }
  function Kl() {
    var a = {};
    Gb(ml().destination, function (b, c) {
      (c == null ? void 0 : c.state) === 0 && (a[b] = c);
    });
    Gb(ml().destinationArray, function (b, c) {
      var d = c[0];
      (d == null ? void 0 : d.state) === 0 && (a[b] = d);
    });
    return a;
  }
  function Ll(a) {
    return !!(
      a &&
      a.parent &&
      a.context &&
      a.context.source === 1 &&
      a.parent.ctid.indexOf("GTM-") !== 0
    );
  }
  function Ml() {
    for (var a = ml(), b = n(ul()), c = b.next(); !c.done; c = b.next())
      if (a.injectedFirstPartyContainers[c.value]) return !0;
    return !1;
  }
  var Nl = { La: { af: 0, df: 1, si: 2 } };
  Nl.La[Nl.La.af] = "FULL_TRANSMISSION";
  Nl.La[Nl.La.df] = "LIMITED_TRANSMISSION";
  Nl.La[Nl.La.si] = "NO_TRANSMISSION";
  var Ol = { ja: { ld: 0, cb: 1, Dd: 2, hc: 3 } };
  Ol.ja[Ol.ja.ld] = "NO_QUEUE";
  Ol.ja[Ol.ja.cb] = "ADS";
  Ol.ja[Ol.ja.Dd] = "ANALYTICS";
  Ol.ja[Ol.ja.hc] = "MONITORING";
  function Pl() {
    var a = Qc("google_tag_data", {});
    return (a.ics = a.ics || new Ql());
  }
  var Ql = function () {
    this.entries = {};
    this.waitPeriodTimedOut =
      this.wasSetLate =
      this.accessedAny =
      this.accessedDefault =
      this.usedImplicit =
      this.usedUpdate =
      this.usedDefault =
      this.usedDeclare =
      this.active =
        !1;
    this.H = [];
  };
  Ql.prototype.default = function (a, b, c, d, e, f, g) {
    this.usedDefault ||
      this.usedDeclare ||
      (!this.accessedDefault && !this.accessedAny) ||
      (this.wasSetLate = !0);
    this.usedDefault = this.active = !0;
    sb("TAGGING", 19);
    b == null ? sb("TAGGING", 18) : Rl(this, a, b === "granted", c, d, e, f, g);
  };
  Ql.prototype.waitForUpdate = function (a, b, c) {
    for (var d = 0; d < a.length; d++)
      Rl(this, a[d], void 0, void 0, "", "", b, c);
  };
  var Rl = function (a, b, c, d, e, f, g, h) {
    var l = a.entries,
      m = l[b] || {},
      p = m.region,
      q = d && zb(d) ? d.toUpperCase() : void 0;
    e = e.toUpperCase();
    f = f.toUpperCase();
    if (e === "" || q === f || (q === e ? p !== f : !q && !p)) {
      var r = !!(g && g > 0 && m.update === void 0),
        t = {
          region: q,
          declare_region: m.declare_region,
          implicit: m.implicit,
          default: c !== void 0 ? c : m.default,
          declare: m.declare,
          update: m.update,
          quiet: r,
        };
      if (e !== "" || m.default !== !1) l[b] = t;
      r &&
        w.setTimeout(function () {
          l[b] === t &&
            t.quiet &&
            (sb("TAGGING", 2),
            (a.waitPeriodTimedOut = !0),
            a.clearTimeout(b, void 0, h),
            a.notifyListeners());
        }, g);
    }
  };
  k = Ql.prototype;
  k.clearTimeout = function (a, b, c) {
    var d = [a],
      e = c.delegatedConsentTypes,
      f;
    for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
    var g = this.entries[a] || {},
      h = this.getConsentState(a, c);
    if (g.quiet) {
      g.quiet = !1;
      for (var l = n(d), m = l.next(); !m.done; m = l.next()) Sl(this, m.value);
    } else if (b !== void 0 && h !== b)
      for (var p = n(d), q = p.next(); !q.done; q = p.next()) Sl(this, q.value);
  };
  k.update = function (a, b, c) {
    this.usedDefault ||
      this.usedDeclare ||
      this.usedUpdate ||
      !this.accessedAny ||
      (this.wasSetLate = !0);
    this.usedUpdate = this.active = !0;
    if (b != null) {
      var d = this.getConsentState(a, c),
        e = this.entries;
      (e[a] = e[a] || {}).update = b === "granted";
      this.clearTimeout(a, d, c);
    }
  };
  k.declare = function (a, b, c, d, e) {
    this.usedDeclare = this.active = !0;
    var f = this.entries,
      g = f[a] || {},
      h = g.declare_region,
      l = c && zb(c) ? c.toUpperCase() : void 0;
    d = d.toUpperCase();
    e = e.toUpperCase();
    if (d === "" || l === e || (l === d ? h !== e : !l && !h)) {
      var m = {
        region: g.region,
        declare_region: l,
        declare: b === "granted",
        implicit: g.implicit,
        default: g.default,
        update: g.update,
        quiet: g.quiet,
      };
      if (d !== "" || g.declare !== !1) f[a] = m;
    }
  };
  k.implicit = function (a, b) {
    this.usedImplicit = !0;
    var c = this.entries,
      d = (c[a] = c[a] || {});
    d.implicit !== !1 && (d.implicit = b === "granted");
  };
  k.getConsentState = function (a, b) {
    var c = this.entries,
      d = c[a] || {},
      e = d.update;
    if (e !== void 0) return e ? 1 : 2;
    if (b.usedContainerScopedDefaults) {
      var f = b.containerScopedDefaults[a];
      if (f === 3) return 1;
      if (f === 2) return 2;
    } else if (((e = d.default), e !== void 0)) return e ? 1 : 2;
    if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
      var g = b.delegatedConsentTypes[a],
        h = c[g] || {};
      e = h.update;
      if (e !== void 0) return e ? 1 : 2;
      if (b.usedContainerScopedDefaults) {
        var l = b.containerScopedDefaults[g];
        if (l === 3) return 1;
        if (l === 2) return 2;
      } else if (((e = h.default), e !== void 0)) return e ? 1 : 2;
    }
    e = d.declare;
    if (e !== void 0) return e ? 1 : 2;
    e = d.implicit;
    return e !== void 0 ? (e ? 3 : 4) : 0;
  };
  k.addListener = function (a, b) {
    this.H.push({ consentTypes: a, se: b });
  };
  var Sl = function (a, b) {
    for (var c = 0; c < a.H.length; ++c) {
      var d = a.H[c];
      Array.isArray(d.consentTypes) &&
        d.consentTypes.indexOf(b) !== -1 &&
        (d.So = !0);
    }
  };
  Ql.prototype.notifyListeners = function (a, b) {
    for (var c = 0; c < this.H.length; ++c) {
      var d = this.H[c];
      if (d.So) {
        d.So = !1;
        try {
          d.se({ consentEventId: a, consentPriorityId: b });
        } catch (e) {}
      }
    }
  };
  var Tl = !1,
    Ul = !1,
    Vl = {},
    Wl = {
      delegatedConsentTypes: {},
      corePlatformServices: {},
      usedCorePlatformServices: !1,
      selectedAllCorePlatformServices: !1,
      containerScopedDefaults:
        ((Vl.ad_storage = 1),
        (Vl.analytics_storage = 1),
        (Vl.ad_user_data = 1),
        (Vl.ad_personalization = 1),
        Vl),
      usedContainerScopedDefaults: !1,
    };
  function Xl(a) {
    var b = Pl();
    b.accessedAny = !0;
    return (zb(a) ? [a] : a).every(function (c) {
      switch (b.getConsentState(c, Wl)) {
        case 1:
        case 3:
          return !0;
        case 2:
        case 4:
          return !1;
        default:
          return !0;
      }
    });
  }
  function Yl(a) {
    var b = Pl();
    b.accessedAny = !0;
    return b.getConsentState(a, Wl);
  }
  function Zl(a) {
    var b = Pl();
    b.accessedAny = !0;
    return !(b.entries[a] || {}).quiet;
  }
  function $l() {
    if (!Wf(5)) return !1;
    var a = Pl();
    a.accessedAny = !0;
    if (a.active) return !0;
    if (!Wl.usedContainerScopedDefaults) return !1;
    for (
      var b = n(Object.keys(Wl.containerScopedDefaults)), c = b.next();
      !c.done;
      c = b.next()
    )
      if (Wl.containerScopedDefaults[c.value] !== 1) return !0;
    return !1;
  }
  function am(a, b) {
    Pl().addListener(a, b);
  }
  function bm(a, b) {
    Pl().notifyListeners(a, b);
  }
  function cm(a, b) {
    if (b.every(Zl)) a({});
    else {
      var c = !1;
      am(b, function (d) {
        !c && b.every(Zl) && ((c = !0), a(d));
      });
    }
  }
  function dm(a, b) {
    var c = zb(b) ? [b] : b,
      d = {},
      e = function () {
        return c.filter(function (h) {
          return Xl(h) && !d[h];
        });
      },
      f = e();
    if (f.length !== c.length) {
      var g = function (h) {
        for (var l = n(h), m = l.next(); !m.done; m = l.next()) d[m.value] = !0;
      };
      g(f);
      am(c, function (h) {
        function l(q) {
          q.length !== 0 && (g(q), (h.consentTypes = q), a(h));
        }
        var m = e();
        if (m.length !== 0) {
          var p = Object.keys(d).length;
          m.length + p >= c.length
            ? l(m)
            : w.setTimeout(function () {
                l(e());
              }, 500);
        }
      });
    }
  }
  var em = function (a, b) {
    this.H = a;
    this.consentTypes = b;
  };
  em.prototype.isConsentGranted = function () {
    switch (this.H) {
      case 0:
        return this.consentTypes.every(function (a) {
          return Xl(a);
        });
      case 1:
        return this.consentTypes.some(function (a) {
          return Xl(a);
        });
      default:
        Dc(this.H, "consentsRequired had an unknown type");
    }
  };
  var fm = new (function () {
    var a = {};
    this.H =
      ((a[Ol.ja.ld] = Nl.La.af),
      (a[Ol.ja.cb] = Nl.La.af),
      (a[Ol.ja.Dd] = Nl.La.af),
      (a[Ol.ja.hc] = Nl.La.af),
      a);
    var b = {};
    this.K =
      ((b[Ol.ja.ld] = new em(0, [])),
      (b[Ol.ja.cb] = new em(0, ["ad_storage"])),
      (b[Ol.ja.Dd] = new em(0, ["analytics_storage"])),
      (b[Ol.ja.hc] = new em(1, ["ad_storage", "analytics_storage"])),
      b);
  })();
  var hm = function (a) {
    var b = this;
    this.type = a;
    this.H = [];
    am(fm.K[a].consentTypes, function () {
      gm(b) || b.flush();
    });
  };
  hm.prototype.flush = function () {
    for (var a = n(this.H), b = a.next(); !b.done; b = a.next()) {
      var c = b.value;
      c();
    }
    this.H = [];
  };
  var gm = function (a) {
      return fm.H[a.type] === Nl.La.si && !fm.K[a.type].isConsentGranted();
    },
    im = function (a, b) {
      gm(a) ? a.H.push(b) : b();
    },
    jm = function () {
      this.H = new Map();
    },
    lm = function (a) {
      var b = km;
      b.H.has(a) || b.H.set(a, new hm(a));
      return b.H.get(a);
    };
  jm.prototype.reset = function () {
    this.H.clear();
  };
  var km = new jm();
  var mm = ["fin", "fs", "mcc", "ncc"],
    nm = function (a) {
      a = a === void 0 ? !1 : a;
      var b = yj(),
        c = xj.K,
        d = b.filter(function (e) {
          return c[e] !== void 0 && (a || !mm.includes(e));
        });
      Aj(d);
      return (
        d
          .map(function (e) {
            var f = c[e];
            typeof f === "function" && (f = f());
            return f ? "&" + e + "=" + f : "";
          })
          .join("") + "&z=0"
      );
    },
    pm = function (a) {
      var b = "https://" + F(21),
        c = "/td?id=" + F(5);
      return "" + ak(b) + c + a;
    },
    qm = function (a, b) {
      b = b === void 0 ? !1 : b;
      if (tj(25) && mk.H && F(5)) {
        var c = lm(Ol.ja.hc);
        if (gm(c))
          a.H ||
            ((a.H = !0),
            im(c, function () {
              return qm(a);
            }));
        else {
          b && Bj("fin", "1");
          var d = nm(b),
            e = pm(d),
            f = { destinationId: F(5), endpoint: 61 };
          b
            ? cl(f, e, void 0, { wf: !0 }, void 0, function () {
                bl(f, e + "&img=1");
              })
            : bl(f, e);
          a.H = !1;
          rm(d);
        }
      }
    },
    rm = function (a) {
      if (
        Pc &&
        (Ub(Pc, "https://www.googletagmanager.com/") || Hf(47)) &&
        !(a.indexOf("&csp=") < 0 && a.indexOf("&mde=") < 0)
      ) {
        var b;
        a: {
          try {
            if (Pc) {
              b = new URL(Pc);
              break a;
            }
          } catch (c) {}
          b = void 0;
        }
        b && Yc("" + Pc + (Pc.indexOf("?") >= 0 ? "&" : "?") + "is_td=1" + a);
      }
    },
    sm = function (a) {
      yj().some(function (b) {
        return !wj[b];
      }) && qm(a, !0);
    },
    tm = new (function () {
      var a = this;
      this.H = !1;
      cd(w, "pagehide", function () {
        sm(a);
      });
    })();
  function um(a) {
    qm(tm, a === void 0 ? !1 : a);
  }
  var vm = [
      "ad_storage",
      "analytics_storage",
      "ad_user_data",
      "ad_personalization",
    ],
    wm = [
      H.D.Xd,
      H.D.hd,
      H.D.hg,
      H.D.Mb,
      H.D.Gc,
      H.D.Ua,
      H.D.rb,
      H.D.qb,
      H.D.Nb,
      H.D.Bc,
    ],
    zm = function () {
      var a = xm;
      !a.V &&
        a.H &&
        (vm.some(function (b) {
          return Wl.containerScopedDefaults[b] !== 1;
        }) ||
          ym("mbc"));
      a.V = !0;
    },
    ym = function (a) {
      mk.H && (Bj(a, "1"), um());
    },
    Am = function (a, b) {
      var c = xm;
      if (!c.O[b] && ((c.O[b] = !0), c.K[b]))
        for (var d = n(wm), e = d.next(); !e.done; e = d.next())
          if (R(a, e.value)) {
            ym("erc");
            break;
          }
    },
    xm = new (function () {
      this.V = this.H = !1;
      this.O = {};
      this.K = {};
    })();
  function Bm(a) {
    sb("HEALTH", a);
  }
  var Cm = function () {
    this.H = {};
    this.K = !1;
  };
  Cm.prototype.bind = function () {
    this.K ||
      ((this.H = Dm()), this.H["0"] && aj(Wi.ia.bf, JSON.stringify(this.H)));
  };
  var Hm = function () {
      var a = Em,
        b = Fm,
        c = void 0,
        d = function () {
          c !== void 0 && cj(Wi.ia.bf, c);
          try {
            var f = $i(Wi.ia.bf);
            b.H = JSON.parse(f);
          } catch (g) {
            T(123), Bm(2), (b.H = {});
          }
          b.K = !0;
          a();
        },
        e = $i(Wi.ia.bf);
      e ? d(e) : ((c = bj(Wi.ia.bf, d)), Gm());
    },
    Gm = function () {
      if (!$i(Wi.ia.Aj)) {
        Zi(Wi.ia.Aj, !0);
        var a = function (b) {
          Zi(Wi.ia.bf, b || "{}");
          Zi(Wi.ia.Aj, !1);
        };
        try {
          w.fetch("https://www.google.com/ccm/geo", {
            method: "GET",
            cache: "no-store",
            mode: "cors",
            credentials: "omit",
          }).then(
            function (b) {
              b.ok
                ? b.text().then(
                    function (c) {
                      a(c);
                    },
                    function () {
                      a();
                    }
                  )
                : a();
            },
            function () {
              a();
            }
          );
        } catch (b) {
          a();
        }
      }
    },
    Dm = function () {
      var a = F(22);
      try {
        return JSON.parse(qb(a));
      } catch (b) {
        return T(123), Bm(2), {};
      }
    },
    Im = function () {
      return Fm.H["0"] || "";
    },
    Jm = function () {
      return Fm.H["1"] || "";
    },
    Km = function () {
      var a = Fm,
        b = !1;
      return b;
    },
    Lm = function () {
      return Fm.H["6"] !== !1;
    },
    Mm = function () {
      var a = Fm,
        b = "";
      return b;
    },
    Nm = function () {
      var a = Fm,
        b = "";
      return b;
    },
    Fm = new Cm();
  var Om = {},
    Pm = Object.freeze(
      ((Om[H.D.Wb] = 1),
      (Om[H.D.Jh] = 1),
      (Om[H.D.aj] = 1),
      (Om[H.D.Xc] = 1),
      (Om[H.D.Ha] = 1),
      (Om[H.D.Nb] = 1),
      (Om[H.D.Ib] = 1),
      (Om[H.D.Xb] = 1),
      (Om[H.D.Ld] = 1),
      (Om[H.D.Bc] = 1),
      (Om[H.D.qb] = 1),
      (Om[H.D.Md] = 1),
      (Om[H.D.Se] = 1),
      (Om[H.D.Qa] = 1),
      (Om[H.D.kq] = 1),
      (Om[H.D.gg] = 1),
      (Om[H.D.kj] = 1),
      (Om[H.D.Th] = 1),
      (Om[H.D.bd] = 1),
      (Om[H.D.hg] = 1),
      (Om[H.D.wq] = 1),
      (Om[H.D.fb] = 1),
      (Om[H.D.lg] = 1),
      (Om[H.D.zq] = 1),
      (Om[H.D.Zh] = 1),
      (Om[H.D.lm] = 1),
      (Om[H.D.dd] = 1),
      (Om[H.D.ed] = 1),
      (Om[H.D.rb] = 1),
      (Om[H.D.ym] = 1),
      (Om[H.D.Zb] = 1),
      (Om[H.D.Vd] = 1),
      (Om[H.D.Wd] = 1),
      (Om[H.D.Xd] = 1),
      (Om[H.D.ei] = 1),
      (Om[H.D.sj] = 1),
      (Om[H.D.Yd] = 1),
      (Om[H.D.hd] = 1),
      (Om[H.D.Zd] = 1),
      (Om[H.D.Hm] = 1),
      (Om[H.D.be] = 1),
      (Om[H.D.jd] = 1),
      (Om[H.D.Nj] = 1),
      Om)
    );
  Object.freeze([
    H.D.Ea,
    H.D.hb,
    H.D.Ob,
    H.D.zb,
    H.D.rj,
    H.D.Ua,
    H.D.lj,
    H.D.gq,
  ]);
  var Qm = {},
    Rm = Object.freeze(
      ((Qm[H.D.Jp] = 1),
      (Qm[H.D.Kp] = 1),
      (Qm[H.D.Lp] = 1),
      (Qm[H.D.Mp] = 1),
      (Qm[H.D.Np] = 1),
      (Qm[H.D.Rp] = 1),
      (Qm[H.D.Sp] = 1),
      (Qm[H.D.Tp] = 1),
      (Qm[H.D.Vp] = 1),
      (Qm[H.D.Kf] = 1),
      Qm)
    ),
    Sm = {},
    Tm = Object.freeze(
      ((Sm[H.D.Nl] = 1),
      (Sm[H.D.Ol] = 1),
      (Sm[H.D.Ie] = 1),
      (Sm[H.D.Je] = 1),
      (Sm[H.D.Pl] = 1),
      (Sm[H.D.Gd] = 1),
      (Sm[H.D.Ke] = 1),
      (Sm[H.D.wc] = 1),
      (Sm[H.D.Wc] = 1),
      (Sm[H.D.xc] = 1),
      (Sm[H.D.Kb] = 1),
      (Sm[H.D.Le] = 1),
      (Sm[H.D.yc] = 1),
      (Sm[H.D.Ql] = 1),
      Sm)
    ),
    Um = Object.freeze([
      H.D.Wb,
      H.D.Xc,
      H.D.Md,
      H.D.hg,
      H.D.ng,
      H.D.Vd,
      H.D.Zd,
    ]),
    Vm = Object.freeze([].concat(za(Um))),
    Wm = Object.freeze([H.D.Ib, H.D.Th, H.D.ei, H.D.sj, H.D.Rh]),
    Xm = Object.freeze([].concat(za(Wm))),
    Ym = {},
    Zm =
      ((Ym[H.D.da] = "1"),
      (Ym[H.D.sa] = "2"),
      (Ym[H.D.fa] = "3"),
      (Ym[H.D.Pa] = "4"),
      Ym),
    $m = {},
    an = Object.freeze(
      (($m.search = "s"),
      ($m.youtube = "y"),
      ($m.playstore = "p"),
      ($m.shopping = "h"),
      ($m.ads = "a"),
      ($m.maps = "m"),
      $m)
    );
  function bn(a) {
    return typeof a !== "object" || a === null ? {} : a;
  }
  function cn(a) {
    return a === void 0 || a === null
      ? ""
      : typeof a === "object"
      ? a.toString()
      : String(a);
  }
  function dn(a) {
    if (a !== void 0 && a !== null) return cn(a);
  }
  var An = function () {
      this.H = w.google_tag_manager = w.google_tag_manager || {};
    },
    Bn;
  function Cn(a, b) {
    Dn();
    var c = Bn;
    return (c.H[a] = c.H[a] || b());
  }
  function En(a) {
    Dn();
    return Bn.H[a];
  }
  function Fn(a, b) {
    Dn();
    Bn.H[a] = b;
  }
  function Gn(a) {
    var b = F(5);
    Dn();
    var c = Bn;
    c.H[b] = c.H[b] || a;
  }
  function Hn() {
    var a = F(19);
    Dn();
    var b = Bn;
    return (b.H[a] = b.H[a] || {});
  }
  function In() {
    var a = F(19);
    Dn();
    return Bn.H[a];
  }
  function Jn() {
    Dn();
    var a = Bn,
      b = a.H.sequence || 1;
    a.H.sequence = b + 1;
    return b;
  }
  function Dn() {
    Bn || (Bn = new An());
  }
  var Kn = function () {};
  Kn.prototype.toString = function () {
    return "undefined";
  };
  var Ln = new Kn();
  function Tn(a, b) {
    function c(g) {
      var h = Oj(g),
        l = Ij(h, "protocol"),
        m = Ij(h, "host", !0),
        p = Ij(h, "port"),
        q = Ij(h, "path").toLowerCase().replace(/\/$/, "");
      if (
        l === void 0 ||
        (l === "http" && p === "80") ||
        (l === "https" && p === "443")
      )
        (l = "web"), (p = "default");
      return [l, m, p, q];
    }
    for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
      if (d[f] !== e[f]) return !1;
    return !0;
  }
  function Un(a) {
    return Vn(a) ? 1 : 0;
  }
  function Vn(a) {
    var b = a.arg0,
      c = a.arg1;
    if (a.any_of && Array.isArray(c)) {
      for (var d = 0; d < c.length; d++) {
        var e = Gd(a, {});
        Gd({ arg1: c[d], any_of: void 0 }, e);
        if (Un(e)) return !0;
      }
      return !1;
    }
    switch (a["function"]) {
      case "_cn":
        return Gg(b, c);
      case "_css":
        var f;
        a: {
          if (b)
            try {
              for (var g = 0; g < Bg.length; g++) {
                var h = Bg[g];
                if (b[h] != null) {
                  f = b[h](c);
                  break a;
                }
              }
            } catch (l) {}
          f = !1;
        }
        return f;
      case "_ew":
        return Cg(b, c);
      case "_eq":
        return Hg(b, c);
      case "_ge":
        return Ig(b, c);
      case "_gt":
        return Kg(b, c);
      case "_lc":
        return Dg(b, c);
      case "_le":
        return Jg(b, c);
      case "_lt":
        return Lg(b, c);
      case "_re":
        return Fg(b, c, a.ignore_case);
      case "_sw":
        return Mg(b, c);
      case "_um":
        return Tn(b, c);
    }
    return !1;
  }
  function Wn(a, b, c, d, e) {
    if (Array.isArray(a)) {
      var f;
      switch (a[0]) {
        case "function_id":
          return a[1];
        case "list":
          f = [];
          for (var g = 1; g < a.length; g++) f.push(Wn(a[g], b, c, d, e));
          return f;
        case "macro":
          var h = d[a[1]];
          return h ? h.evaluate(b, e) : void 0;
        case "map":
          f = {};
          for (var l = 1; l < a.length; l += 2)
            f[Wn(a[l], b, c, d, e)] = Wn(a[l + 1], b, c, d, e);
          return f;
        case "template":
          f = [];
          for (var m = !1, p = 1; p < a.length; p++) {
            var q = Wn(a[p], b, c, d, e);
            f.push(q);
          }
          return f.join("");
        case "escape":
          f = Wn(a[1], b, c, d, e);
          f = String(f);
          for (var y = 2; y < a.length; y++) ln[a[y]] && (f = ln[a[y]](f));
          return f;
        case "tag":
          var A = a[1];
          if (!c[A]) throw Error("Unable to resolve tag reference " + A + ".");
          return { uo: a[2], index: A };
        case "zb":
          var C = {},
            D =
              ((C[Ff.bc] = a[1]),
              (C.arg0 = Wn(a[2], b, c, d, e)),
              (C.arg1 = Wn(a[3], b, c, d, e)),
              (C.ignore_case = Wn(a[5], b, c, d, e)),
              C),
            E = Un(D),
            G = !!a[4];
          return G || E !== 2 ? G !== (E === 1) : null;
        default:
          throw Error("Attempting to expand unknown Value type: " + a[0] + ".");
      }
    }
    return a;
  }
  function Xn(a) {
    return a && a.indexOf("pending:") === 0 ? Yn(a.substr(8)) : !1;
  }
  function Yn(a) {
    if (a == null || a.length === 0) return !1;
    var b = Number(a),
      c = Ob();
    return b < c + 3e5 && b > c - 9e5;
  }
  var Zn = !1,
    $n = !1,
    ao = !1,
    bo = 0,
    co = !1,
    eo = [];
  function fo(a) {
    if (bo === 0) co && eo && (eo.length >= 100 && eo.shift(), eo.push(a));
    else if (go()) {
      var b = F(41),
        c = Qc(b, []);
      c.length >= 50 && c.shift();
      c.push(a);
    }
  }
  function ho() {
    io();
    dd(z, "TAProdDebugSignal", ho);
  }
  function io() {
    if (!$n) {
      $n = !0;
      jo();
      var a = eo;
      eo = void 0;
      a == null ||
        a.forEach(function (b) {
          fo(b);
        });
    }
  }
  function jo() {
    var a = z.documentElement.getAttribute("data-tag-assistant-prod-present");
    Yn(a)
      ? (bo = 1)
      : !Xn(a) || Zn || ao
      ? (bo = 2)
      : ((ao = !0),
        cd(z, "TAProdDebugSignal", ho, !1),
        w.setTimeout(function () {
          io();
          Zn = !0;
        }, 200));
  }
  function go() {
    if (!co) return !1;
    switch (bo) {
      case 1:
      case 0:
        return !0;
      case 2:
        return !1;
      default:
        return !1;
    }
  }
  var ko = !1;
  function lo(a, b) {
    var c = ul(),
      d = rl();
    F(26);
    var e = Hf(47) ? 0 : Hf(50) ? 1 : 3,
      f = Uj();
    if (go()) {
      var g = mo("INIT");
      g.containerLoadSource = a != null ? a : 0;
      b && (g.parentTargetReference = b);
      g.aliases = c;
      g.destinations = d;
      e !== void 0 && (g.gtg = { source: e, mPath: f != null ? f : "" });
      fo(g);
    }
  }
  function no(a) {
    var b, c, d, e;
    b = a.targetId;
    c = a.request;
    d = a.kb;
    e = a.isBatched;
    var f;
    if ((f = go())) {
      var g;
      a: switch (c.endpoint) {
        case 68:
        case 69:
        case 19:
        case 62:
        case 47:
          g = !0;
          break a;
        default:
          g = !1;
      }
      f = !g;
    }
    if (f) {
      var h = mo("GTAG_HIT", { eventId: d.eventId, priorityId: d.priorityId });
      h.target = b;
      h.url = c.url;
      c.postBody && (h.postBody = c.postBody);
      h.parameterEncoding = c.parameterEncoding;
      h.endpoint = c.endpoint;
      e !== void 0 && (h.isBatched = e);
      fo(h);
    }
  }
  function oo(a) {
    go() && no(a());
  }
  function mo(a, b) {
    b = b === void 0 ? {} : b;
    b.groupId = po;
    var c,
      d = b,
      e = qo,
      f = { publicId: ro };
    d.eventId != null && (f.eventId = d.eventId);
    d.priorityId != null && (f.priorityId = d.priorityId);
    d.eventName && (f.eventName = d.eventName);
    d.groupId && (f.groupId = d.groupId);
    d.tagName && (f.tagName = d.tagName);
    c = { containerProduct: "GTM", key: f, version: e, messageType: a };
    c.containerProduct = ko ? "OGT" : "GTM";
    c.key.targetRef = so;
    return c;
  }
  var ro = "",
    qo = "",
    so = { ctid: "", isDestination: !1 },
    po;
  function to(a) {
    var b = F(5),
      c = Hf(45),
      d = ql(),
      e = F(6),
      f = F(1);
    F(23);
    bo = 0;
    co = !0;
    jo();
    po = a;
    ro = b;
    qo = f;
    ko = c;
    so = { ctid: b, isDestination: d, canonicalId: e };
  }
  var uo = [H.D.da, H.D.sa, H.D.fa, H.D.Pa];
  function vo(a) {
    for (
      var b = n(a[H.D.vc] || [""]), c = b.next(), d = {};
      !c.done;
      d = { region: void 0 }, c = b.next()
    )
      (d.region = c.value),
        Gb(
          a,
          (function (e) {
            return function (f, g) {
              if (f !== H.D.vc) {
                var h = cn(g),
                  l = e.region,
                  m = Im(),
                  p = Jm();
                Ul = !0;
                Tl && sb("TAGGING", 20);
                Pl().declare(f, h, l, m, p);
              }
            };
          })(d)
        );
  }
  function wo(a) {
    zm();
    var b = uj(16, function () {
        return !1;
      }),
      c = uj(15, function () {
        return !1;
      });
    !b && c && ym("crc");
    sj(16, !0);
    var d = a[H.D.Eh];
    d && T(41);
    var e = a[H.D.vc];
    e ? T(40) : (e = [""]);
    for (
      var f = n(e), g = f.next(), h = {};
      !g.done;
      h = { Wo: void 0 }, g = f.next()
    )
      (h.Wo = g.value),
        Gb(
          a,
          (function (l) {
            return function (m, p) {
              if (m !== H.D.vc && m !== H.D.Eh) {
                var q = dn(p),
                  r = l.Wo,
                  t = Number(d),
                  v = Im(),
                  u = Jm();
                t = t === void 0 ? 0 : t;
                Tl = !0;
                Ul && sb("TAGGING", 20);
                Pl().default(m, q, r, v, u, t, Wl);
              }
            };
          })(h)
        );
  }
  function xo(a) {
    Wl.usedContainerScopedDefaults = !0;
    var b = a[H.D.vc];
    if (b) {
      var c = Array.isArray(b) ? b : [b];
      if (!c.includes(Jm()) && !c.includes(Im())) return;
    }
    Gb(a, function (d, e) {
      switch (d) {
        case "ad_storage":
        case "analytics_storage":
        case "ad_user_data":
        case "ad_personalization":
          break;
        default:
          return;
      }
      Wl.usedContainerScopedDefaults = !0;
      Wl.containerScopedDefaults[d] = e === "granted" ? 3 : 2;
    });
  }
  function yo(a, b) {
    zm();
    sj(15, !0);
    Gb(a, function (c, d) {
      var e = cn(d);
      Tl = !0;
      Ul && sb("TAGGING", 20);
      Pl().update(c, e, Wl);
    });
    bm(b.eventId, b.priorityId);
  }
  function zo(a) {
    a.hasOwnProperty("all") &&
      ((Wl.selectedAllCorePlatformServices = !0),
      Gb(an, function (b) {
        Wl.corePlatformServices[b] = a.all === "granted";
        Wl.usedCorePlatformServices = !0;
      }));
    Gb(a, function (b, c) {
      b !== "all" &&
        ((Wl.corePlatformServices[b] = c === "granted"),
        (Wl.usedCorePlatformServices = !0));
    });
  }
  function Ao(a) {
    Array.isArray(a) || (a = [a]);
    return a.every(function (b) {
      return Xl(b);
    });
  }
  function Bo() {
    var a = Co;
    Array.isArray(a) || (a = [a]);
    return a.some(function (b) {
      return Xl(b);
    });
  }
  function Do(a, b) {
    am(a, b);
  }
  function Eo(a, b) {
    dm(a, b);
  }
  function Fo(a, b) {
    cm(a, b);
  }
  function Go() {
    var a = [H.D.da, H.D.Pa, H.D.fa];
    Pl().waitForUpdate(a, 500, Wl);
  }
  function Ho(a) {
    for (var b = n(a), c = b.next(); !c.done; c = b.next()) {
      var d = c.value;
      Pl().clearTimeout(d, void 0, Wl);
    }
    bm();
  }
  function Io(a) {
    for (var b = {}, c = n(a.split("|")), d = c.next(); !d.done; d = c.next())
      b[d.value] = !0;
    return b;
  }
  var Jo = !1,
    Ko = [];
  function Lo() {
    if (!Jo) {
      Jo = !0;
      for (var a = Ko.length - 1; a >= 0; a--) Ko[a]();
      Ko = [];
    }
  }
  var Mo = /^(?:AW|DC|G|GF|GT|HA|MC|UA)$/,
    No = /\s/;
  function Oo(a, b) {
    if (zb(a)) {
      a = Lb(a);
      var c = a.indexOf("-");
      if (!(c < 0)) {
        var d = a.substring(0, c);
        if (Mo.test(d)) {
          var e = a.substring(c + 1),
            f;
          if (b) {
            var g = function (m) {
              var p = m.indexOf("/");
              return p < 0 ? [m] : [m.substring(0, p), m.substring(p + 1)];
            };
            f = g(e);
            if (d === "DC" && f.length === 2) {
              var h = g(f[1]);
              h.length === 2 && ((f[1] = h[0]), f.push(h[1]));
            }
          } else {
            f = e.split("/");
            for (var l = 0; l < f.length; l++)
              if (!f[l] || (No.test(f[l]) && (d !== "AW" || l !== 1))) return;
          }
          return {
            id: a,
            prefix: d,
            destinationId: d + "-" + f[0],
            ids: f,
            we: function () {
              return this.id !== this.destinationId;
            },
          };
        }
      }
    }
  }
  function Po(a, b) {
    for (var c = {}, d = 0; d < a.length; ++d) {
      var e = Oo(a[d], b);
      e && (c[e.id] = e);
    }
    var f = [],
      g;
    for (g in c)
      if (c.hasOwnProperty(g)) {
        var h = c[g];
        h.prefix === "AW" && h.ids[Qo[1]] && f.push(h.destinationId);
      }
    for (var l = 0; l < f.length; ++l) delete c[f[l]];
    for (var m = [], p = n(Object.keys(c)), q = p.next(); !q.done; q = p.next())
      m.push(c[q.value]);
    return m;
  }
  var Ro = {},
    Qo =
      ((Ro[0] = 0),
      (Ro[1] = 1),
      (Ro[2] = 2),
      (Ro[3] = 0),
      (Ro[4] = 1),
      (Ro[5] = 0),
      (Ro[6] = 0),
      (Ro[7] = 0),
      Ro);
  var So = { initialized: 11, complete: 12, interactive: 13 },
    To = {},
    Uo = Object.freeze(((To[H.D.Vd] = !0), To)),
    Vo = function () {
      this.V = Mf(34, 500);
      this.H = {};
      this.O = {};
      this.K = void 0;
    },
    Wo = function (a, b, c) {
      if (c.length && mk.H) {
        var d;
        (d = a.H)[b] != null || (d[b] = []);
        var e;
        (e = a.O)[b] != null || (e[b] = []);
        var f = c.filter(function (g) {
          return !a.O[b].includes(g);
        });
        a.H[b].push.apply(a.H[b], za(f));
        a.O[b].push.apply(a.O[b], za(f));
        !a.K &&
          f.length > 0 &&
          (Cj("tdc", !0),
          (a.K = w.setTimeout(function () {
            um();
            a.H = {};
            a.K = void 0;
          }, a.V)));
      }
    };
  Vo.prototype.bind = function () {
    var a = this;
    Bj(
      "tdc",
      function () {
        a.K && (w.clearTimeout(a.K), (a.K = void 0));
        var b = [],
          c;
        for (c in a.H)
          a.H.hasOwnProperty(c) && b.push(c + "*" + a.H[c].join("."));
        return b.length ? b.join("!") : void 0;
      },
      !1
    );
  };
  var Xo = function (a, b) {
      var c = {},
        d;
      for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
      for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
      return c;
    },
    Yo = function (a, b, c, d, e) {
      d = d === void 0 ? {} : d;
      e = e === void 0 ? "" : e;
      if (b === c) return [];
      var f = function (t, v) {
          var u;
          Dd(v) === "object" ? (u = v[t]) : Dd(v) === "array" && (u = v[t]);
          return u === void 0 ? Uo[t] : u;
        },
        g = Xo(b, c),
        h;
      for (h in g)
        if (g.hasOwnProperty(h)) {
          var l = (e ? e + "." : "") + h,
            m = f(h, b),
            p = f(h, c),
            q = Dd(m) === "object" || Dd(m) === "array",
            r = Dd(p) === "object" || Dd(p) === "array";
          if (q && r) Yo(a, m, p, d, l);
          else if (q || r || m !== p) d[l] = !0;
        }
      return Object.keys(d);
    },
    Zo = new Vo();
  var $o = {
    X: {
      nl: 1,
      Mj: 2,
      il: 3,
      Fl: 4,
      jl: 5,
      Ed: 6,
      El: 7,
      ir: 8,
      Jn: 9,
      kl: 10,
      ml: 11,
      ki: 12,
      Wm: 13,
      Tm: 14,
      Vm: 15,
      Sm: 16,
      Um: 17,
      Rm: 18,
      qp: 19,
      Pq: 20,
      Qq: 21,
      Ij: 22,
      ao: 23,
    },
  };
  $o.X[$o.X.nl] = "ALLOW_INTEREST_GROUPS";
  $o.X[$o.X.Mj] = "SERVER_CONTAINER_URL";
  $o.X[$o.X.il] = "ADS_DATA_REDACTION";
  $o.X[$o.X.Fl] = "CUSTOMER_LIFETIME_VALUE";
  $o.X[$o.X.jl] = "ALLOW_CUSTOM_SCRIPTS";
  $o.X[$o.X.Ed] = "ANY_COOKIE_PARAMS";
  $o.X[$o.X.El] = "COOKIE_EXPIRES";
  $o.X[$o.X.ir] = "LEGACY_ENHANCED_CONVERSION_JS_VARIABLE";
  $o.X[$o.X.Jn] = "RESTRICTED_DATA_PROCESSING";
  $o.X[$o.X.kl] = "ALLOW_DISPLAY_FEATURES";
  $o.X[$o.X.ml] = "ALLOW_GOOGLE_SIGNALS";
  $o.X[$o.X.ki] = "GENERATED_TRANSACTION_ID";
  $o.X[$o.X.Wm] = "FLOODLIGHT_COUNTING_METHOD_UNKNOWN";
  $o.X[$o.X.Tm] = "FLOODLIGHT_COUNTING_METHOD_STANDARD";
  $o.X[$o.X.Vm] = "FLOODLIGHT_COUNTING_METHOD_UNIQUE";
  $o.X[$o.X.Sm] = "FLOODLIGHT_COUNTING_METHOD_PER_SESSION";
  $o.X[$o.X.Um] = "FLOODLIGHT_COUNTING_METHOD_TRANSACTIONS";
  $o.X[$o.X.Rm] = "FLOODLIGHT_COUNTING_METHOD_ITEMS_SOLD";
  $o.X[$o.X.qp] = "ADS_OGT_V1_USAGE";
  $o.X[$o.X.Pq] = "FORM_INTERACTION_PERMISSION_DENIED";
  $o.X[$o.X.Qq] = "FORM_SUBMIT_PERMISSION_DENIED";
  $o.X[$o.X.Ij] = "MICROTASK_NOT_SUPPORTED";
  $o.X[$o.X.ao] = "USER_DATA_NULL_FROM_GLOBAL";
  var ap = {},
    bp =
      ((ap[H.D.bj] = $o.X.nl),
      (ap[H.D.Xd] = $o.X.Mj),
      (ap[H.D.hd] = $o.X.Mj),
      (ap[H.D.pb] = $o.X.il),
      (ap[H.D.Re] = $o.X.Fl),
      (ap[H.D.Zi] = $o.X.jl),
      (ap[H.D.Md] = $o.X.Ed),
      (ap[H.D.qb] = $o.X.Ed),
      (ap[H.D.Nb] = $o.X.Ed),
      (ap[H.D.Ld] = $o.X.Ed),
      (ap[H.D.Bc] = $o.X.Ed),
      (ap[H.D.Xb] = $o.X.Ed),
      (ap[H.D.Ib] = $o.X.El),
      (ap[H.D.Zb] = $o.X.Jn),
      (ap[H.D.Jh] = $o.X.kl),
      (ap[H.D.Xc] = $o.X.ml),
      ap),
    cp = {},
    dp =
      ((cp.unknown = $o.X.Wm),
      (cp.standard = $o.X.Tm),
      (cp.unique = $o.X.Vm),
      (cp.per_session = $o.X.Sm),
      (cp.transactions = $o.X.Um),
      (cp.items_sold = $o.X.Rm),
      cp);
  var ep = function (a, b, c) {
      c = c === void 0 ? !1 : c;
      sb("GTAG_EVENT_FEATURE_CHANNEL", b);
      c && (a.H[b] = !0);
    },
    vb = new (function () {
      this.H = [];
    })();
  function fp(a, b) {
    ep(vb, a, b === void 0 ? !1 : b);
  }
  function gp(a, b) {
    var c = b === void 0 ? !1 : b,
      d = vb;
    c = c === void 0 ? !1 : c;
    for (
      var e = Object.keys(a), f = n(Object.keys(bp)), g = f.next();
      !g.done;
      g = f.next()
    ) {
      var h = g.value;
      e.includes(h) && ep(d, bp[h], c);
    }
  }
  var hp = function (a, b, c, d) {
      this.K = Ob();
      this.H = b;
      this.args = c;
      this.messageContext = d;
      this.type = a;
    },
    ip = function () {
      this.xb = {};
      this.lb = {};
      this.K = {};
      this.O = null;
      this.jb = {};
      this.H = !1;
      this.status = 1;
    };
  function jp(a, b) {
    return arguments.length === 1 ? kp("set", a) : kp("set", a, b);
  }
  function lp(a, b) {
    return arguments.length === 1 ? kp("config", a) : kp("config", a, b);
  }
  function mp(a, b, c) {
    c = c || {};
    c[H.D.Wd] = a;
    return kp("event", b, c);
  }
  function kp() {
    return arguments;
  }
  var np = function (a, b, c, d, e, f, g, h, l, m, p, q) {
      this.eventId = a;
      this.priorityId = b;
      this.Na = c;
      this.xb = d;
      this.jb = e;
      this.Mc = f;
      this.Xg = g;
      this.lb = h;
      this.eventMetadata = l;
      this.onSuccess = m;
      this.onFailure = p;
      this.isGtmEvent = q;
    },
    op = function (a) {
      var b = { onSuccess: xb, onFailure: xb };
      b = b === void 0 ? {} : b;
      var c,
        d,
        e,
        f,
        g,
        h,
        l,
        m,
        p,
        q,
        r,
        t,
        v,
        u,
        x,
        y,
        A,
        C,
        D,
        E,
        G,
        I,
        Q,
        V;
      return new np(
        (v = (c = b) == null ? void 0 : c.eventId) != null ? v : a.eventId,
        (u = (d = b) == null ? void 0 : d.priorityId) != null
          ? u
          : a.priorityId,
        (x = (e = b) == null ? void 0 : e.Na) != null ? x : a.Na,
        (y = (f = b) == null ? void 0 : f.xb) != null ? y : a.xb,
        (A = (g = b) == null ? void 0 : g.jb) != null ? A : a.jb,
        (C = (h = b) == null ? void 0 : h.Mc) != null ? C : a.Mc,
        (D = (l = b) == null ? void 0 : l.Xg) != null ? D : a.Xg,
        (E = (m = b) == null ? void 0 : m.lb) != null ? E : a.lb,
        (G = (p = b) == null ? void 0 : p.eventMetadata) != null
          ? G
          : a.eventMetadata,
        (I = (q = b) == null ? void 0 : q.onSuccess) != null ? I : a.onSuccess,
        (Q = (r = b) == null ? void 0 : r.onFailure) != null ? Q : a.onFailure,
        (V = (t = b) == null ? void 0 : t.isGtmEvent) != null ? V : a.isGtmEvent
      );
    },
    pp = function (a, b) {
      var c = [];
      switch (b) {
        case 3:
          c.push(a.Na);
          c.push(a.xb);
          c.push(a.jb);
          c.push(a.Mc);
          c.push(a.lb);
          break;
        case 2:
          c.push(a.Na);
          break;
        case 1:
          c.push(a.xb);
          c.push(a.jb);
          c.push(a.Mc);
          c.push(a.lb);
          break;
        case 4:
          c.push(a.Na), c.push(a.xb), c.push(a.jb), c.push(a.Mc);
      }
      return c;
    },
    R = function (a, b, c, d) {
      for (
        var e = n(pp(a, d === void 0 ? 3 : d)), f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = f.value;
        if (g[b] !== void 0) return g[b];
      }
      return c;
    },
    qp = function (a) {
      for (
        var b = {}, c = pp(a, 4), d = n(c), e = d.next();
        !e.done;
        e = d.next()
      )
        for (
          var f = Object.keys(e.value), g = n(f), h = g.next();
          !h.done;
          h = g.next()
        )
          b[h.value] = 1;
      return Object.keys(b);
    };
  np.prototype.getMergedValues = function (a, b, c) {
    b = b === void 0 ? 3 : b;
    var d = {},
      e = !1,
      f = function (m) {
        Fd(m) &&
          Gb(m, function (p, q) {
            e = !0;
            d[p] = q;
          });
      };
    c && f(c);
    var g = pp(this, b);
    g.reverse();
    for (var h = n(g), l = h.next(); !l.done; l = h.next()) f(l.value[a]);
    return e ? d : void 0;
  };
  var rp = function (a) {
      for (
        var b = [H.D.Yf, H.D.Uf, H.D.Vf, H.D.Wf, H.D.Xf, H.D.Zf, H.D.cg],
          c = pp(a, 3),
          d = n(c),
          e = d.next();
        !e.done;
        e = d.next()
      ) {
        for (
          var f = e.value, g = {}, h = !1, l = n(b), m = l.next();
          !m.done;
          m = l.next()
        ) {
          var p = m.value;
          f[p] !== void 0 && ((g[p] = f[p]), (h = !0));
        }
        var q = h ? g : void 0;
        if (q) return q;
      }
      return {};
    },
    sp = function (a, b) {
      this.eventId = a;
      this.priorityId = b;
      this.Na = {};
      this.xb = {};
      this.jb = {};
      this.Mc = {};
      this.Xg = {};
      this.lb = {};
      this.eventMetadata = {};
      this.isGtmEvent = !1;
      this.onSuccess = function () {};
      this.onFailure = function () {};
    },
    tp = function (a, b) {
      a.Na = b;
      return a;
    },
    up = function (a, b) {
      a.xb = b;
      return a;
    },
    vp = function (a, b) {
      a.jb = b;
      return a;
    },
    wp = function (a, b) {
      a.Mc = b;
      return a;
    },
    xp = function (a, b) {
      a.Xg = b;
      return a;
    },
    yp = function (a, b) {
      a.lb = b;
      return a;
    },
    zp = function (a, b) {
      a.eventMetadata = b || {};
      return a;
    },
    Ap = function (a, b) {
      a.onSuccess = b;
      return a;
    },
    Bp = function (a, b) {
      a.onFailure = b;
      return a;
    },
    Cp = function (a, b) {
      a.isGtmEvent = b;
      return a;
    };
  sp.prototype.Ma = function () {
    return new np(
      this.eventId,
      this.priorityId,
      this.Na,
      this.xb,
      this.jb,
      this.Mc,
      this.Xg,
      this.lb,
      this.eventMetadata,
      this.onSuccess,
      this.onFailure,
      this.isGtmEvent
    );
  };
  function Dp(a, b) {
    Gb(a, function (c) {
      var d;
      if ((d = c.charAt(0) === "_")) {
        var e;
        a: switch (c) {
          case H.D.Yb:
          case H.D.ig:
          case H.D.Wh:
            e = !0;
            break a;
          default:
            e = !1;
        }
        d = !e;
      }
      d && (b && b(c), delete a[c]);
    });
  }
  var Fp = function () {
    var a = this;
    this.K = new Fb();
    this.H = {};
    this.O = {};
    this.V = {
      name: F(19),
      set: function (b, c) {
        Gd(Xb(b, c), a.H);
        Ep(a);
      },
      get: function (b) {
        return a.get(b, 2);
      },
      reset: function () {
        a.K = new Fb();
        a.H = {};
        Ep(a);
      },
    };
  };
  Fp.prototype.get = function (a, b) {
    return b != 2 ? this.K.get(a) : Gp(this, a);
  };
  var Gp = function (a, b, c) {
    var d = b.split(".");
    c = c || [];
    for (var e = a.H, f = 0; f < d.length; f++) {
      if (e === null) return !1;
      if (e === void 0) break;
      e = e[d[f]];
      if (c.indexOf(e) !== -1) return;
    }
    return e;
  };
  Fp.prototype.set = function (a, b) {
    this.O.hasOwnProperty(a) ||
      (this.K.set(a, b), Gd(Xb(a, b), this.H), Ep(this));
  };
  var Ip = function () {
      for (
        var a = [
            "gtm.allowlist",
            "gtm.blocklist",
            "gtm.whitelist",
            "gtm.blacklist",
            "tagTypeBlacklist",
          ],
          b = Hp,
          c = 0;
        c < a.length;
        c++
      ) {
        var d = a[c],
          e = b.get(d, 1);
        if (Array.isArray(e) || Fd(e)) e = Gd(e, null);
        b.O[d] = e;
      }
    },
    Ep = function (a, b) {
      Gb(a.O, function (c, d) {
        a.K.set(c, d);
        Gd(Xb(c), a.H);
        Gd(Xb(c, d), a.H);
        b && delete a.O[c];
      });
    },
    Hp = new Fp(),
    Jp = Hp.V;
  function Kp(a, b) {
    return Hp.get(a, b);
  }
  function Lp(a, b) {
    var c = b === void 0 ? 2 : b,
      d = Hp,
      e,
      f = (c === void 0 ? 2 : c) !== 1 ? Gp(d, a) : d.K.get(a);
    Dd(f) === "array" || Dd(f) === "object" ? (e = Gd(f, null)) : (e = f);
    return e;
  }
  var Mp = { UA: 1, AW: 2, DC: 3, G: 4, GF: 5, GT: 12, GTM: 14, HA: 6, MC: 7 };
  function Np(a) {
    a = a === void 0 ? {} : a;
    var b = F(5).split("-")[0].toUpperCase(),
      c,
      d = {
        ctid: F(5),
        Yo: If(15),
        cp: F(14),
        ht: Hf(7) ? 2 : 1,
        Vt: a.yd,
        canonicalId: F(6),
        Nt: (c = yl()) == null ? void 0 : c.canonicalContainerId,
        Wt: a.zh === void 0 ? void 0 : a.zh ? 10 : 12,
      };
    d.canonicalId !== a.mb && (d.mb = a.mb);
    var e = vl();
    d.zt = e ? e.canonicalContainerId : void 0;
    Hf(45) ? ((d.Oi = Mp[b]), d.Oi || (d.Oi = 0)) : (d.Oi = Ri ? 13 : 10);
    Hf(47) ? ((d.Gk = 0), (d.Kr = 2)) : Hf(50) ? (d.Gk = 1) : (d.Gk = 3);
    var f = a,
      g = { 6: !1 };
    If(54) === 2 ? (g[7] = !0) : If(54) === 1 && (g[2] = !0);
    if (Pc) {
      var h = Ij(Oj(Pc), "host");
      h && (g[8] = h.match(/^(www\.)?googletagmanager\.com$/) === null);
    }
    var l;
    g[9] = (l = f.rd) != null ? l : !1;
    var m = Dl(),
      p;
    g[10] =
      (p = m == null ? void 0 : m.fromContainerExecution) != null ? p : !1;
    d.Rr = g;
    return Bf(d, a.dk);
  }
  var Pp = function () {
      var a = 5;
      Op.pp > 0 && (a = Op.pp);
      this.K = a;
      this.H = 0;
      this.O = [];
    },
    Qp = function (a) {
      return a.H < a.K ? !1 : Ob() - a.O[a.H % a.K] < 1e3;
    },
    Rp = function (a) {
      var b = a.H++ % a.K;
      a.O[b] = Ob();
    };
  var Op = { pp: Mf(3, 0) },
    Tp = function () {
      var a = this;
      this.ya = [];
      this.H = void 0;
      this.Z = {};
      this.K = void 0;
      this.la = new Pp();
      this.Va = 1e3;
      this.V = this.O = !1;
      this.ka = Db();
      Sp(this, function () {
        var b = [
            ["v", "3"],
            ["t", "t"],
            ["pid", String(a.ka)],
          ],
          c = Np();
        c && b.push(["gtm", c]);
        return b;
      });
      fd(function () {
        a.ka = Db();
      }, 864e5);
    },
    Sp = function (a, b) {
      a.ya.push(b);
    },
    Up = function (a, b, c) {
      var d = a.H;
      if (d === void 0)
        if (c) d = Jn();
        else return "";
      for (
        var e = [ak("https://" + F(21)), "/a", "?id=" + F(5)],
          f = n(a.ya),
          g = f.next();
        !g.done;
        g = f.next()
      )
        for (
          var h = g.value,
            l = h({ eventId: d, Ff: !!b }),
            m = n(l),
            p = m.next();
          !p.done;
          p = m.next()
        ) {
          var q = n(p.value),
            r = q.next().value,
            t = q.next().value;
          e.push("&" + r + "=" + t);
        }
      e.push("&z=0");
      return e.join("");
    },
    Vp = function (a) {
      if (
        tj(25) &&
        (a.K && (w.clearTimeout(a.K), (a.K = void 0)), a.H !== void 0 && a.V)
      ) {
        var b = lm(Ol.ja.hc);
        if (gm(b))
          a.O ||
            ((a.O = !0),
            im(b, function () {
              return void Vp(a);
            }));
        else if (a.Z[a.H] || Qp(a.la) || a.Va-- <= 0) T(1), (a.Z[a.H] = !0);
        else {
          Rp(a.la);
          var c = Up(a, !0);
          bl({ destinationId: F(5), endpoint: 56, eventId: a.H }, c);
          a.V = !1;
          a.O = !1;
        }
      }
    },
    Wp = function (a) {
      a.K ||
        (a.K = w.setTimeout(function () {
          return void Vp(a);
        }, 500));
    },
    Yp = function (a) {
      var b = Xp;
      b.Z[a] ||
        (a !== b.H && (Vp(b), (b.H = a)),
        (b.V = !0),
        Wp(b),
        Up(b).length >= 2022 && Vp(b));
    },
    Xp;
  function Zp(a) {
    $p();
    Sp(Xp, a);
  }
  function aq() {
    var a;
    a = a === void 0 ? !1 : a;
    $p();
    var b = a,
      c = Xp;
    b = b === void 0 ? !1 : b;
    if (mk.K && tj(25)) {
      var d = Up(c, !0, !0);
      b
        ? $k({ destinationId: F(5), endpoint: 56, eventId: c.H }, d)
        : bl({ destinationId: F(5), endpoint: 56, eventId: c.H }, d);
    }
  }
  function $p() {
    Xp || (Xp = new Tp());
  }
  var bq = function () {
      var a = this;
      this.H = {};
      Zp(function (b) {
        var c = b.eventId,
          d = b.Ff,
          e = [],
          f = a.H[c] || [];
        f.length && e.push(["epr", f.join(".")]);
        d && delete a.H[c];
        return e;
      });
    },
    dq = function (a, b, c) {
      var d = cq;
      mk.K &&
        a !== void 0 &&
        ((d.H[a] = d.H[a] || []), d.H[a].push(c + b), $p(), Yp(a));
    },
    cq;
  function eq() {
    cq || (cq = new bq());
  }
  var fq = function () {
      this.destinations = {};
      this.H = {};
      this.commands = [];
    },
    gq = function (a, b) {
      return (a.destinations[b.destinationId] =
        a.destinations[b.destinationId] || new ip());
    },
    hq = function (a, b, c, d) {
      if (d.H) {
        var e = gq(a, d.H),
          f = e.O;
        if (f) {
          var g = Gd(c, null),
            h = Gd(e.xb[d.H.destinationId], null),
            l = Gd(e.jb, null),
            m = Gd(e.lb, null),
            p = Gd(a.H, null),
            q = {};
          if (mk.K)
            try {
              q = Gd(Hp.H, null);
            } catch (x) {
              T(72);
            }
          var r = d.H.prefix,
            t = function (x) {
              var y = d.messageContext.eventId;
              eq();
              dq(y, r, x);
            },
            v = Cp(
              Bp(
                Ap(
                  zp(
                    xp(
                      wp(
                        yp(
                          vp(
                            up(
                              tp(
                                new sp(
                                  d.messageContext.eventId,
                                  d.messageContext.priorityId
                                ),
                                g
                              ),
                              h
                            ),
                            l
                          ),
                          m
                        ),
                        p
                      ),
                      q
                    ),
                    d.messageContext.eventMetadata
                  ),
                  function () {
                    if (t) {
                      var x = t;
                      t = void 0;
                      x("2");
                      if (d.messageContext.onSuccess)
                        d.messageContext.onSuccess();
                    }
                  }
                ),
                function () {
                  if (t) {
                    var x = t;
                    t = void 0;
                    x("3");
                    if (d.messageContext.onFailure)
                      d.messageContext.onFailure();
                  }
                }
              ),
              !!d.messageContext.isGtmEvent
            ).Ma(),
            u = function () {
              try {
                var x = d.messageContext.eventId;
                eq();
                dq(x, r, "1");
                var y = d.H.id,
                  A = Zo;
                if (mk.H && b === H.D.xa) {
                  var C,
                    D = (C = Oo(y)) == null ? void 0 : C.ids;
                  if (!(D && D.length > 1)) {
                    var E,
                      G = Qc("google_tag_data", {});
                    G.td || (G.td = {});
                    E = G.td;
                    var I = Gd(v.Mc);
                    Gd(v.Na, I);
                    var Q = [],
                      V;
                    for (V in E)
                      E.hasOwnProperty(V) && Yo(A, E[V], I).length && Q.push(V);
                    Q.length &&
                      (Wo(A, y, Q), sb("TAGGING", So[z.readyState] || 14));
                    E[y] = I;
                  }
                }
                f(d.H.id, b, d.K, v);
              } catch (ja) {
                var S = d.messageContext.eventId;
                eq();
                dq(S, r, "4");
              }
            };
          b === "gtag.get" ? u() : im(e.V, u);
        }
      }
    },
    iq = function (a, b) {
      if (b.type !== "require") {
        var c = void 0;
        b.type === "event" && (c = b.args[1]);
        if (b.H)
          for (var d = gq(a, b.H).K[b.type] || [], e = 0; e < d.length; e++)
            d[e](c);
        else
          for (var f in a.destinations)
            if (a.destinations.hasOwnProperty(f)) {
              var g = a.destinations[f];
              if (g && g.K)
                for (var h = g.K[b.type] || [], l = 0; l < h.length; l++)
                  h[l](c);
            }
      }
    };
  fq.prototype.register = function (a, b, c, d) {
    var e = gq(this, a);
    e.status !== 3 &&
      ((e.O = b),
      (e.status = 3),
      (e.V = lm(c)),
      jq(this, a, d || {}),
      this.flush());
  };
  fq.prototype.push = function (a, b, c, d) {
    c !== void 0 &&
      (gq(this, c).status === 1 &&
        ((gq(this, c).status = 2), this.push("require", [{}], c, {})),
      gq(this, c).H && (d.deferrable = !1),
      d.eventMetadata || (d.eventMetadata = {}),
      d.eventMetadata[J.J.Mg] || (d.eventMetadata[J.J.Mg] = [c.destinationId]),
      d.eventMetadata[J.J.Lj] || (d.eventMetadata[J.J.Lj] = [c.id]));
    this.commands.push(new hp(a, c, b, d));
    d.deferrable || this.flush();
  };
  fq.prototype.flush = function (a) {
    for (
      var b = this, c = [], d = !1, e = {};
      this.commands.length;
      e = { ro: void 0 }
    ) {
      var f = this.commands[0],
        g = f.H;
      if (f.messageContext.deferrable)
        !g || gq(this, g).H
          ? ((f.messageContext.deferrable = !1), this.commands.push(f))
          : c.push(f),
          this.commands.shift();
      else {
        switch (f.type) {
          case "require":
            if (gq(this, g).status !== 3 && !a) {
              this.commands.push.apply(this.commands, c);
              return;
            }
            break;
          case "set":
            var h = f.args[0];
            Dp(h);
            Gb(h, function (u, x) {
              Gd(Xb(u, x), b.H);
            });
            gp(h, !0);
            break;
          case "event":
            e.ro = f.args[1];
            var l = kq(
              f.args[0],
              (function () {
                return function () {};
              })(e)
            );
            gp(l);
            hq(this, e.ro, l, f);
            break;
          case "get":
            var m = {},
              p = ((m[H.D.kg] = f.args[0]), (m[H.D.jg] = f.args[1]), m);
            hq(this, H.D.Lb, p, f);
            break;
          case "container_config":
            var q = gq(this, g),
              r = kq(f.args[0], function () {});
            gp(r, !0);
            q.H = !0;
            Gd(r, q.jb);
            d = !0;
            break;
          case "destination_config":
            var t = gq(this, g),
              v = kq(f.args[0], function () {});
            gp(v, !0);
            t.xb[g.id] || (t.xb[g.id] = {});
            t.H = !0;
            Gd(v, t.xb[g.id]);
            d = !0;
            break;
          case "reset_container_config":
            gq(this, g).jb = {};
            break;
          case "reset_target_config":
            gq(this, g).xb[g.id] = {};
        }
        this.commands.shift();
        iq(this, f);
      }
    }
    this.commands.push.apply(this.commands, c);
    d && this.flush();
  };
  var jq = function (a, b, c) {
    var d = Gd(c, null);
    Gd(gq(a, b).lb, d);
    gq(a, b).lb = d;
  };
  function kq(a, b) {
    var c = {};
    Gb(a, function (d, e) {
      Gd(Xb(d, e), c);
    });
    Dp(c, b);
    return c;
  }
  var lq = function () {
    this.H = new fq();
    this.K = !1;
  };
  lq.prototype.flush = function () {
    this.H.flush();
  };
  var mq;
  function nq() {
    mq || (mq = new lq());
    return mq;
  }
  function oq(a, b, c, d) {
    var e = nq(),
      f = Oo(c, d.isGtmEvent);
    f && (e.K && (d.deferrable = !0), e.H.push("event", [b, a], f, d));
  }
  function pq(a, b, c, d) {
    var e = nq(),
      f = Oo(c, d.isGtmEvent);
    f && e.H.push("get", [a, b], f, d);
  }
  function qq(a, b, c) {
    var d = nq(),
      e = Oo(a, c.isGtmEvent);
    e && d.H.push("container_config", [b], e, c);
  }
  function rq(a, b, c) {
    var d = nq(),
      e = Oo(a, c.isGtmEvent);
    e && d.H.push("destination_config", [b], e, c);
  }
  function sq(a) {
    var b = nq(),
      c = Oo(a, !0);
    c && b.H.push("reset_container_config", [], c, {});
  }
  function tq(a) {
    var b = nq(),
      c = Oo(a, !0);
    c && b.H.push("reset_target_config", [], c, {});
  }
  function uq(a) {
    var b = nq(),
      c = Oo(a, !0);
    return c ? gq(b.H, c).lb : {};
  }
  function vq(a) {
    return nq().H.H[a];
  }
  function wq(a) {
    var b = a.location.href;
    if (a === a.top) return { url: b, ct: !0 };
    var c = !1,
      d = a.document;
    d && d.referrer && ((b = d.referrer), a.parent === a.top && (c = !0));
    var e = a.location.ancestorOrigins;
    if (e) {
      var f = e[e.length - 1],
        g;
      f &&
        ((g = b) == null ? void 0 : g.indexOf(f)) === -1 &&
        ((c = !1), (b = f));
    }
    return { url: b, ct: c };
  }
  function xq(a) {
    try {
      var b;
      if ((b = !!a && a.location.href != null))
        a: {
          try {
            Mk(a.foo);
            b = !0;
            break a;
          } catch (c) {}
          b = !1;
        }
      return b;
    } catch (c) {
      return !1;
    }
  }
  function yq() {
    for (var a = w, b = a; a && a !== a.parent; )
      (a = a.parent), xq(a) && (b = a);
    return b;
  }
  var zq = function (a, b) {
      var c = function () {};
      c.prototype = a.prototype;
      var d = new c();
      a.apply(d, Array.prototype.slice.call(arguments, 1));
      return d;
    },
    Aq = function (a) {
      var b = a;
      return function () {
        if (b) {
          var c = b;
          b = null;
          c();
        }
      };
    };
  function Bq(a, b) {
    if (a)
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function Cq(a) {
    var b = a.split(/[?#]/),
      c = /[?]/.test(a) ? "?" + b[1] : "";
    return {
      Yk: b[0],
      params: c,
      fragment: /[#]/.test(a) ? "#" + (c ? b[2] : b[1]) : "",
    };
  }
  function Dq(a) {
    var b = Pa.apply(1, arguments);
    if (b.length === 0) return mc(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return mc(c);
  }
  function Eq(a, b, c, d) {
    function e(g, h) {
      g != null &&
        (Array.isArray(g)
          ? g.forEach(function (l) {
              return e(l, h);
            })
          : ((b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g)),
            (f = "&")));
    }
    var f = b.length ? "&" : "?";
    d.constructor === Object && (d = Object.entries(d));
    Array.isArray(d)
      ? d.forEach(function (g) {
          return e(g[1], g[0]);
        })
      : d.forEach(e);
    return mc(a + b + c);
  }
  function Fq(a, b) {
    var c = Cq(nc(a).toString()),
      d = c.Yk.slice(-1) === "/" ? "" : "/",
      e = c.Yk + d + encodeURIComponent(b);
    return mc(e + c.params + c.fragment);
  }
  var Gq = function (a, b) {
      for (var c = a, d = 0; d < 50; ++d) {
        var e;
        try {
          e = !(!c.frames || !c.frames[b]);
        } catch (h) {
          e = !1;
        }
        if (e) return c;
        var f;
        a: {
          try {
            var g = c.parent;
            if (g && g !== c) {
              f = g;
              break a;
            }
          } catch (h) {}
          f = null;
        }
        if (!(c = f)) break;
      }
      return null;
    },
    Hq = function (a) {
      var b = w;
      if (b.top == b) return 0;
      if (a === void 0 ? 0 : a) {
        var c = b.location.ancestorOrigins;
        if (c) return c[c.length - 1] == b.location.origin ? 1 : 2;
      }
      return xq(b.top) ? 1 : 2;
    },
    Iq = function (a) {
      a = a === void 0 ? document : a;
      return a.createElement("img");
    };
  function Jq(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function Kq(a, b, c) {
    return typeof a.addEventListener === "function"
      ? (a.addEventListener(b, c, !1), !0)
      : !1;
  }
  function Lq(a, b, c) {
    typeof a.removeEventListener === "function" &&
      a.removeEventListener(b, c, !1);
  }
  function Mq(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    a.google_image_requests || (a.google_image_requests = []);
    var e = Iq(a.document);
    if (c) {
      var f = function () {
        if (c) {
          var g = a.google_image_requests,
            h = Ic(g, e);
          h >= 0 && Array.prototype.splice.call(g, h, 1);
        }
        Lq(e, "load", f);
        Lq(e, "error", f);
      };
      Kq(e, "load", f);
      Kq(e, "error", f);
    }
    d && (e.attributionSrc = "");
    e.src = b;
    a.google_image_requests.push(e);
  }
  function Nq(a) {
    var b;
    b = b === void 0 ? !1 : b;
    var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
    Bq(a, function (d, e) {
      if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d));
    });
    Oq(c, b);
  }
  function Oq(a, b) {
    var c = window,
      d;
    b = b === void 0 ? !1 : b;
    d = d === void 0 ? !1 : d;
    if (c.fetch) {
      var e = {
        keepalive: !0,
        credentials: "include",
        redirect: "follow",
        method: "get",
        mode: "no-cors",
      };
      d &&
        ((e.mode = "cors"),
        "setAttributionReporting" in XMLHttpRequest.prototype
          ? (e.attributionReporting = {
              eventSourceEligible: "true",
              triggerEligible: "false",
            })
          : (e.headers = { "Attribution-Reporting-Eligible": "event-source" }));
      c.fetch(a, e);
    } else Mq(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d);
  }
  function Pq() {
    this.ka = this.ka;
    this.V = this.V;
  }
  Pq.prototype.ka = !1;
  Pq.prototype.dispose = function () {
    this.ka || ((this.ka = !0), this.O());
  };
  Pq.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  Pq.prototype.addOnDisposeCallback = function (a, b) {
    this.ka
      ? b !== void 0
        ? a.call(b)
        : a()
      : (this.V || (this.V = []), b && (a = a.bind(b)), this.V.push(a));
  };
  Pq.prototype.O = function () {
    if (this.V) for (; this.V.length; ) this.V.shift()();
  };
  function Qq(a) {
    a.addtlConsent === void 0 ||
      vf(a.addtlConsent) ||
      (a.addtlConsent = void 0);
    a.gdprApplies === void 0 || wf(a.gdprApplies) || (a.gdprApplies = void 0);
    return (a.tcString !== void 0 && !vf(a.tcString)) ||
      (a.listenerId !== void 0 && !uf(a.listenerId))
      ? 2
      : a.cmpStatus && a.cmpStatus !== "error"
      ? 0
      : 3;
  }
  var Rq = function (a, b) {
    b = b === void 0 ? {} : b;
    Pq.call(this);
    this.H = null;
    this.la = {};
    this.ya = 0;
    this.Z = null;
    this.K = a;
    var c;
    this.timeoutMs = (c = b.timeoutMs) != null ? c : 500;
    var d;
    this.fk = (d = b.fk) != null ? d : !1;
  };
  va(Rq, Pq);
  Rq.prototype.O = function () {
    this.la = {};
    this.Z && (Lq(this.K, "message", this.Z), delete this.Z);
    delete this.la;
    delete this.K;
    delete this.H;
    Pq.prototype.O.call(this);
  };
  var Tq = function (a) {
    return typeof a.K.__tcfapi === "function" || Sq(a) != null;
  };
  Rq.prototype.addEventListener = function (a) {
    var b = this,
      c = { internalBlockOnErrors: this.fk },
      d = Aq(function () {
        a(c);
      }),
      e = 0;
    this.timeoutMs !== -1 &&
      (e = setTimeout(function () {
        c.tcString = "tcunavailable";
        c.internalErrorState = 1;
        d();
      }, this.timeoutMs));
    var f = function (g, h) {
      clearTimeout(e);
      g
        ? ((c = g),
          (c.internalErrorState = Qq(c)),
          (c.internalBlockOnErrors = b.fk),
          (h && c.internalErrorState === 0) ||
            ((c.tcString = "tcunavailable"), h || (c.internalErrorState = 3)))
        : ((c.tcString = "tcunavailable"), (c.internalErrorState = 3));
      a(c);
    };
    try {
      Uq(this, "addEventListener", f);
    } catch (g) {
      (c.tcString = "tcunavailable"),
        (c.internalErrorState = 3),
        e && (clearTimeout(e), (e = 0)),
        d();
    }
  };
  Rq.prototype.removeEventListener = function (a) {
    a && a.listenerId && Uq(this, "removeEventListener", null, a.listenerId);
  };
  var Wq = function (a, b, c) {
      var d;
      d = d === void 0 ? "755" : d;
      var e;
      a: {
        if (a.publisher && a.publisher.restrictions) {
          var f = a.publisher.restrictions[b];
          if (f !== void 0) {
            e = f[d === void 0 ? "755" : d];
            break a;
          }
        }
        e = void 0;
      }
      var g = e;
      if (g === 0) return !1;
      var h = c;
      c === 2
        ? ((h = 0), g === 2 && (h = 1))
        : c === 3 && ((h = 1), g === 1 && (h = 0));
      var l;
      if (h === 0)
        if (a.purpose && a.vendor) {
          var m = Vq(a.vendor.consents, d === void 0 ? "755" : d);
          l =
            m && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH"
              ? !0
              : m && Vq(a.purpose.consents, b);
        } else l = !0;
      else
        l =
          h === 1
            ? a.purpose && a.vendor
              ? Vq(a.purpose.legitimateInterests, b) &&
                Vq(a.vendor.legitimateInterests, d === void 0 ? "755" : d)
              : !0
            : !0;
      return l;
    },
    Vq = function (a, b) {
      return !(!a || !a[b]);
    },
    Uq = function (a, b, c, d) {
      c || (c = function () {});
      var e = a.K;
      if (typeof e.__tcfapi === "function") {
        var f = e.__tcfapi;
        f(b, 2, c, d);
      } else if (Sq(a)) {
        Xq(a);
        var g = ++a.ya;
        a.la[g] = c;
        if (a.H) {
          var h = {};
          a.H.postMessage(
            ((h.__tcfapiCall = {
              command: b,
              version: 2,
              callId: g,
              parameter: d,
            }),
            h),
            "*"
          );
        }
      } else c({}, !1);
    },
    Sq = function (a) {
      if (a.H) return a.H;
      a.H = Gq(a.K, "__tcfapiLocator");
      return a.H;
    },
    Xq = function (a) {
      if (!a.Z) {
        var b = function (c) {
          try {
            var d;
            d = (vf(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
            a.la[d.callId](d.returnValue, d.success);
          } catch (e) {}
        };
        a.Z = b;
        Kq(a.K, "message", b);
      }
    },
    Yq = function (a) {
      if (a.gdprApplies === !1) return !0;
      a.internalErrorState === void 0 && (a.internalErrorState = Qq(a));
      return a.cmpStatus === "error" || a.internalErrorState !== 0
        ? a.internalBlockOnErrors
          ? (Nq({ e: String(a.internalErrorState) }), !1)
          : !0
        : a.cmpStatus !== "loaded" ||
          (a.eventStatus !== "tcloaded" &&
            a.eventStatus !== "useractioncomplete")
        ? !1
        : !0;
    };
  var Zq = { 1: 0, 3: 0, 4: 0, 7: 3, 9: 3, 10: 3 };
  function $q() {
    return Cn("tcf", function () {
      return {};
    });
  }
  var ar = function () {
    return new Rq(w, { timeoutMs: -1 });
  };
  function br() {
    var a = $q(),
      b = ar();
    Tq(b) && !cr() && !dr() && T(124);
    if (!a.active && Tq(b)) {
      cr() &&
        ((a.active = !0),
        (a.purposes = {}),
        (a.cmpId = 0),
        (a.tcfPolicyVersion = 0),
        (Pl().active = !0),
        (a.tcString = "tcunavailable"));
      Go();
      try {
        b.addEventListener(function (c) {
          if (c.internalErrorState !== 0)
            er(a), Ho([H.D.da, H.D.Pa, H.D.fa]), (Pl().active = !0);
          else if (
            ((a.gdprApplies = c.gdprApplies),
            (a.cmpId = c.cmpId),
            (a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode),
            dr() && (a.active = !0),
            !fr(c) || cr() || dr())
          ) {
            a.tcfPolicyVersion = c.tcfPolicyVersion;
            var d;
            if (c.gdprApplies === !1) {
              var e = {},
                f;
              for (f in Zq) Zq.hasOwnProperty(f) && (e[f] = !0);
              d = e;
              b.removeEventListener(c);
            } else if (fr(c)) {
              var g = {},
                h;
              for (h in Zq)
                if (Zq.hasOwnProperty(h))
                  if (h === "1") {
                    var l,
                      m = c,
                      p = { xs: !0 };
                    p = p === void 0 ? {} : p;
                    l = Yq(m)
                      ? m.gdprApplies === !1
                        ? !0
                        : m.tcString === "tcunavailable"
                        ? !p.idpcApplies
                        : (p.idpcApplies || m.gdprApplies !== void 0 || p.xs) &&
                          (p.idpcApplies ||
                            (vf(m.tcString) && m.tcString.length))
                        ? Wq(m, "1", 0)
                        : !0
                      : !1;
                    g["1"] = l;
                  } else g[h] = Wq(c, h, Zq[h]);
              d = g;
            }
            if (d) {
              a.tcString = c.tcString || "tcempty";
              a.purposes = d;
              var q = {},
                r = ((q[H.D.da] = a.purposes["1"] ? "granted" : "denied"), q);
              a.gdprApplies !== !0
                ? (Ho([H.D.da, H.D.Pa, H.D.fa]), (Pl().active = !0))
                : ((r[H.D.Pa] =
                    a.purposes["3"] && a.purposes["4"] ? "granted" : "denied"),
                  typeof a.tcfPolicyVersion === "number" &&
                  a.tcfPolicyVersion >= 4
                    ? (r[H.D.fa] =
                        a.purposes["1"] && a.purposes["7"]
                          ? "granted"
                          : "denied")
                    : Ho([H.D.fa]),
                  yo(
                    r,
                    { eventId: 0 },
                    {
                      gdprApplies: a ? a.gdprApplies : void 0,
                      tcString: gr() || "",
                    }
                  ));
            }
          } else Ho([H.D.da, H.D.Pa, H.D.fa]);
        });
      } catch (c) {
        er(a), Ho([H.D.da, H.D.Pa, H.D.fa]), (Pl().active = !0);
      }
    }
  }
  function er(a) {
    a.type = "e";
    a.tcString = "tcunavailable";
  }
  function fr(a) {
    return (
      a.eventStatus === "tcloaded" ||
      a.eventStatus === "useractioncomplete" ||
      a.eventStatus === "cmpuishown"
    );
  }
  function cr() {
    return w.gtag_enable_tcf_support === !0;
  }
  function dr() {
    return $q().enableAdvertiserConsentMode === !0;
  }
  function gr() {
    var a = $q();
    if (a.active) return a.tcString;
  }
  function hr() {
    var a = $q();
    if (a.active && a.gdprApplies !== void 0) return a.gdprApplies ? "1" : "0";
  }
  function ir(a) {
    if (!Zq.hasOwnProperty(String(a))) return !0;
    var b = $q();
    return b.active && b.purposes ? !!b.purposes[String(a)] : !0;
  }
  var jr = [H.D.da, H.D.sa, H.D.fa, H.D.Pa],
    kr = {},
    lr = ((kr[H.D.da] = 1), (kr[H.D.sa] = 2), kr);
  function mr(a) {
    if (a === void 0) return 0;
    switch (R(a, H.D.Wb)) {
      case void 0:
        return 1;
      case !1:
        return 3;
      default:
        return 2;
    }
  }
  function nr() {
    return (
      (N(183) ? Kf(16).split("~") : Kf(17).split("~")).indexOf(Jm()) !== -1 &&
      Mc.globalPrivacyControl === !0
    );
  }
  function or(a) {
    if (nr()) return !1;
    var b = mr(a);
    if (b === 3) return !1;
    switch (Yl(H.D.Pa)) {
      case 1:
      case 3:
        return !0;
      case 2:
        return !1;
      case 4:
        return b === 2;
      case 0:
        return !0;
      default:
        return !1;
    }
  }
  function pr() {
    return $l() || !Xl(H.D.da) || !Xl(H.D.sa);
  }
  function qr() {
    var a = {},
      b;
    for (b in lr) lr.hasOwnProperty(b) && (a[lr[b]] = Yl(b));
    return "G1" + yf(a[1] || 0) + yf(a[2] || 0);
  }
  var rr = {},
    sr =
      ((rr[H.D.da] = 0),
      (rr[H.D.sa] = 1),
      (rr[H.D.fa] = 2),
      (rr[H.D.Pa] = 3),
      rr);
  function tr(a) {
    switch (a) {
      case void 0:
        return 1;
      case !0:
        return 3;
      case !1:
        return 2;
      default:
        return 0;
    }
  }
  function ur(a) {
    for (var b = "1", c = 0; c < jr.length; c++) {
      var d = b,
        e,
        f = jr[c],
        g = Wl.delegatedConsentTypes[f];
      e = g === void 0 ? 0 : sr.hasOwnProperty(g) ? 12 | sr[g] : 8;
      var h = Pl();
      h.accessedAny = !0;
      var l = h.entries[f] || {};
      e = (e << 2) | tr(l.implicit);
      b =
        d +
        ("" +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            e
          ] +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            (tr(l.declare) << 4) | (tr(l.default) << 2) | tr(l.update)
          ]);
    }
    var m = b,
      p = (nr() ? 1 : 0) << 3,
      q = ($l() ? 1 : 0) << 2,
      r = mr(a);
    b =
      m +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        p | q | r
      ];
    return (b +=
      "" +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (Wl.containerScopedDefaults.ad_storage << 4) |
          (Wl.containerScopedDefaults.analytics_storage << 2) |
          Wl.containerScopedDefaults.ad_user_data
      ] +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        ((Wl.usedContainerScopedDefaults ? 1 : 0) << 2) |
          Wl.containerScopedDefaults.ad_personalization
      ]);
  }
  function vr() {
    return Xl(H.D.fa) ? "a" : "-";
  }
  function wr() {
    return Lm() || ((cr() || dr()) && hr() === "1") ? "1" : "0";
  }
  function xr() {
    return (Lm() ? !0 : !(!cr() && !dr()) && hr() === "1") || !Xl(H.D.fa);
  }
  function yr() {
    var a = "0",
      b = "0",
      c;
    var d = $q();
    c = d.active ? d.cmpId : void 0;
    typeof c === "number" &&
      c >= 0 &&
      c <= 4095 &&
      ((a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (c >> 6) & 63
      ]),
      (b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        c & 63
      ]));
    var e = "0",
      f;
    var g = $q();
    f = g.active ? g.tcfPolicyVersion : void 0;
    typeof f === "number" &&
      f >= 0 &&
      f <= 63 &&
      (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        f
      ]);
    var h = 0;
    Lm() && (h |= 1);
    hr() === "1" && (h |= 2);
    cr() && (h |= 4);
    var l;
    var m = $q();
    l =
      m.enableAdvertiserConsentMode !== void 0
        ? m.enableAdvertiserConsentMode
          ? "1"
          : "0"
        : void 0;
    l === "1" && (h |= 8);
    Pl().waitPeriodTimedOut && (h |= 16);
    return (
      "1" +
      a +
      b +
      e +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[h]
    );
  }
  function zr() {
    return Jm() === "US-CO";
  }
  function Ar(a, b, c, d) {
    var e,
      f = Number(a.vd != null ? a.vd : void 0);
    f !== 0 && (e = new Date((b || Ob()) + 1e3 * (f || 7776e3)));
    return {
      path: a.path,
      domain: a.domain,
      flags: a.flags,
      encode: !!c,
      expires: e,
      Sc: d,
    };
  }
  var Br = ["ad_storage", "ad_user_data"];
  function Cr(a, b) {
    if (!a) return sb("TAGGING", 32), 10;
    if (b === null || b === void 0 || b === "") return sb("TAGGING", 33), 11;
    var c = Dr(!1);
    if (c.error !== 0) return sb("TAGGING", 34), c.error;
    if (!c.value) return sb("TAGGING", 35), 2;
    c.value[a] = b;
    var d = Er(c);
    d !== 0 && sb("TAGGING", 36);
    return d;
  }
  function Fr(a) {
    if (!a) return sb("TAGGING", 27), { error: 10 };
    var b = Dr();
    if (b.error !== 0) return sb("TAGGING", 29), b;
    if (!b.value) return sb("TAGGING", 30), { error: 2 };
    if (!(a in b.value)) return sb("TAGGING", 31), { value: void 0, error: 15 };
    var c = b.value[a];
    return c === null || c === void 0 || c === ""
      ? (sb("TAGGING", 28), { value: void 0, error: 11 })
      : { value: c, error: 0 };
  }
  function Gr(a) {
    if (a) {
      var b = Dr(!1);
      b.error !== 0
        ? sb("TAGGING", 38)
        : b.value
        ? a in b.value
          ? (delete b.value[a], Er(b) !== 0 && sb("TAGGING", 41))
          : sb("TAGGING", 40)
        : sb("TAGGING", 39);
    } else sb("TAGGING", 37);
  }
  function Dr(a) {
    a = a === void 0 ? !0 : a;
    if (!Xl(Br)) return sb("TAGGING", 43), { error: 3 };
    try {
      if (!w.localStorage) return sb("TAGGING", 44), { error: 1 };
    } catch (f) {
      return sb("TAGGING", 45), { error: 14 };
    }
    var b = { schema: "gcl", version: 1 },
      c = void 0;
    try {
      c = w.localStorage.getItem("_gcl_ls");
    } catch (f) {
      return sb("TAGGING", 46), { error: 13 };
    }
    try {
      if (c) {
        var d = JSON.parse(c);
        if (d && typeof d === "object") b = d;
        else return sb("TAGGING", 47), { error: 12 };
      }
    } catch (f) {
      return sb("TAGGING", 48), { error: 8 };
    }
    if (b.schema !== "gcl") return sb("TAGGING", 49), { error: 4 };
    if (b.version !== 1) return sb("TAGGING", 50), { error: 5 };
    try {
      var e = Hr(b);
      a && e && Er({ value: b, error: 0 });
    } catch (f) {
      return sb("TAGGING", 48), { error: 8 };
    }
    return { value: b, error: 0 };
  }
  function Hr(a) {
    if (!a || typeof a !== "object") return !1;
    if ("expires" in a && "value" in a) {
      var b;
      typeof a.expires === "number"
        ? (b = a.expires)
        : (b = typeof a.expires === "string" ? Number(a.expires) : NaN);
      if (isNaN(b) || !(Date.now() <= b))
        return (a.value = null), (a.error = 9), sb("TAGGING", 54), !0;
    } else {
      for (
        var c = !1, d = n(Object.keys(a)), e = d.next();
        !e.done;
        e = d.next()
      )
        c = Hr(a[e.value]) || c;
      return c;
    }
    return !1;
  }
  function Er(a) {
    if (a.error) return a.error;
    if (!a.value) return sb("TAGGING", 42), 2;
    var b = a.value,
      c;
    try {
      c = JSON.stringify(b);
    } catch (d) {
      return sb("TAGGING", 52), 6;
    }
    try {
      w.localStorage.setItem("_gcl_ls", c);
    } catch (d) {
      return sb("TAGGING", 53), 7;
    }
    return 0;
  }
  var Ir = { sh: "value", ub: "conversionCount", th: 1 },
    Jr = { sh: "timeouts", ub: "timeouts", th: 0 },
    Kr = { sh: "eopCount", ub: "endOfPageCount", th: 0 },
    Lr = { sh: "errors", ub: "errors", th: 0 },
    Mr = [Ir, Jr, Lr, Kr];
  function Nr(a, b) {
    b = b === void 0 ? 1 : b;
    if (!Or(a)) return {};
    var c = Pr(Mr),
      d = c[a.ub];
    if (d === void 0 || d === -1) return c;
    var e = {},
      f = ma(Object, "assign").call(Object, {}, c, ((e[a.ub] = d + b), e));
    return Qr(f) ? f : c;
  }
  function Pr(a) {
    var b;
    a: {
      var c = Fr("gcl_ctr");
      if (c.error === 0 && c.value && typeof c.value === "object") {
        var d = c.value;
        try {
          b = "value" in d && typeof d.value === "object" ? d.value : void 0;
          break a;
        } catch (p) {}
      }
      b = void 0;
    }
    for (var e = b, f = {}, g = n(a), h = g.next(); !h.done; h = g.next()) {
      var l = h.value;
      if (e && Or(l)) {
        var m = e[l.sh];
        m === void 0 || Number.isNaN(m)
          ? (f[l.ub] = -1)
          : (f[l.ub] = Number(m));
      } else f[l.ub] = -1;
    }
    return f;
  }
  function Qr(a, b) {
    b = b || {};
    for (
      var c = Ob(), d = Ar(b, c, !0), e = {}, f = n(Mr), g = f.next();
      !g.done;
      g = f.next()
    ) {
      var h = g.value,
        l = a[h.ub];
      l !== void 0 && l !== -1 && (e[h.sh] = l);
    }
    e.creationTimeMs = c;
    return Cr("gcl_ctr", { value: e, expires: Number(d.expires) }) === 0
      ? !0
      : !1;
  }
  function Or(a) {
    return Xl(["ad_storage", "ad_user_data"]) ? !a.It || Wf(a.It) : !1;
  }
  function Rr(a) {
    return Xl(["ad_storage", "ad_user_data"]) ? !a.Us || Wf(a.Us) : !1;
  }
  function Sr() {
    if (Tr()) {
      var a = Fr("last_convs");
      if (a.error === 0 && a.value && typeof a.value === "object") {
        var b = a.value;
        if (b.value && Array.isArray(b.value)) {
          var c = b.value;
          if (!(c.length > 1)) {
            for (var d = [], e = n(c), f = e.next(); !f.done; f = e.next()) {
              var g = f.value;
              if (
                typeof g !== "object" ||
                g === null ||
                typeof g.random !== "number" ||
                typeof g.label !== "string" ||
                g.label.length > 200
              )
                return;
              d.push({ random: g.random, label: g.label });
            }
            return d;
          }
        }
      }
    }
  }
  function Ur(a, b) {
    !Tr() ||
      a.length > 1 ||
      (a.length === 1 && a[0].label.length > 200) ||
      ((b = b || {}),
      Cr("last_convs", { value: a, expires: Number(Ar(b).expires) }));
  }
  function Tr() {
    return Xl(["ad_storage", "ad_user_data"]) && Wf(13);
  }
  var Yr = {
    W: {
      wr: 0,
      fl: 1,
      Fh: 2,
      vl: 3,
      Vi: 4,
      sl: 5,
      tl: 6,
      wl: 7,
      Wi: 8,
      Mm: 9,
      Lm: 10,
      wj: 11,
      Nm: 12,
      hi: 13,
      Xm: 14,
      Jg: 15,
      qr: 16,
      kf: 17,
      Rj: 18,
      Sj: 19,
      Tj: 20,
      Wn: 21,
      Uj: 22,
      Yi: 23,
      Gl: 24,
    },
  };
  Yr.W[Yr.W.wr] = "RESERVED_ZERO";
  Yr.W[Yr.W.fl] = "ADS_CONVERSION_HIT";
  Yr.W[Yr.W.Fh] = "CONTAINER_EXECUTE_START";
  Yr.W[Yr.W.vl] = "CONTAINER_SETUP_END";
  Yr.W[Yr.W.Vi] = "CONTAINER_SETUP_START";
  Yr.W[Yr.W.sl] = "CONTAINER_BLOCKING_END";
  Yr.W[Yr.W.tl] = "CONTAINER_EXECUTE_END";
  Yr.W[Yr.W.wl] = "CONTAINER_YIELD_END";
  Yr.W[Yr.W.Wi] = "CONTAINER_YIELD_START";
  Yr.W[Yr.W.Mm] = "EVENT_EXECUTE_END";
  Yr.W[Yr.W.Lm] = "EVENT_EVALUATION_END";
  Yr.W[Yr.W.wj] = "EVENT_EVALUATION_START";
  Yr.W[Yr.W.Nm] = "EVENT_SETUP_END";
  Yr.W[Yr.W.hi] = "EVENT_SETUP_START";
  Yr.W[Yr.W.Xm] = "GA4_CONVERSION_HIT";
  Yr.W[Yr.W.Jg] = "PAGE_LOAD";
  Yr.W[Yr.W.qr] = "PAGEVIEW";
  Yr.W[Yr.W.kf] = "SNIPPET_LOAD";
  Yr.W[Yr.W.Rj] = "TAG_CALLBACK_ERROR";
  Yr.W[Yr.W.Sj] = "TAG_CALLBACK_FAILURE";
  Yr.W[Yr.W.Tj] = "TAG_CALLBACK_SUCCESS";
  Yr.W[Yr.W.Wn] = "TAG_EXECUTE_END";
  Yr.W[Yr.W.Uj] = "TAG_EXECUTE_START";
  Yr.W[Yr.W.Yi] = "CUSTOM_PERFORMANCE_START";
  Yr.W[Yr.W.Gl] = "CUSTOM_PERFORMANCE_END";
  var Zr = [],
    $r = {},
    as = {};
  function bs(a) {
    if (Wf(10) && Zr.includes(a)) {
      var b;
      (b = ud()) == null || b.mark(a + "-" + Yr.W.Yi + "-" + (as[a] || 0));
    }
  }
  function cs(a) {
    if (Wf(10) && Zr.includes(a)) {
      var b = a + "-" + Yr.W.Gl + "-" + (as[a] || 0),
        c = { start: a + "-" + Yr.W.Yi + "-" + (as[a] || 0), end: b },
        d;
      (d = ud()) == null || d.mark(b);
      var e,
        f,
        g =
          (f = (e = ud()) == null ? void 0 : e.measure(b, c)) == null
            ? void 0
            : f.duration;
      g !== void 0 && ((as[a] = (as[a] || 0) + 1), ($r[a] = g + ($r[a] || 0)));
    }
  }
  var ds = ["3", "4"];
  function es(a) {
    return a.origin !== "null";
  }
  function fs(a, b, c, d) {
    try {
      bs("3");
      var e;
      return (e = gs(
        function (f) {
          return f === a;
        },
        b,
        c,
        d
      )[a]) != null
        ? e
        : [];
    } finally {
      cs("3");
    }
  }
  function gs(a, b, c, d) {
    var e;
    if (hs(d)) {
      for (
        var f = {}, g = String(b || is()).split(";"), h = 0;
        h < g.length;
        h++
      ) {
        var l = g[h].split("="),
          m = l[0].trim();
        if (m && a(m)) {
          var p = l.slice(1).join("=").trim();
          p && c && (p = decodeURIComponent(p));
          var q = void 0,
            r = void 0;
          ((q = f)[(r = m)] || (q[r] = [])).push(p);
        }
      }
      e = f;
    } else e = {};
    return e;
  }
  function js(a, b, c, d, e) {
    if (hs(e)) {
      var f = ks(a, d, e);
      if (f.length === 1) return f[0];
      if (f.length !== 0) {
        f = ls(
          f,
          function (g) {
            return g.bs;
          },
          b
        );
        if (f.length === 1) return f[0];
        f = ls(
          f,
          function (g) {
            return g.Bt;
          },
          c
        );
        return f[0];
      }
    }
  }
  function ms(a, b, c, d) {
    var e = is(),
      f = w;
    es(f) && (f.document.cookie = a);
    var g = is();
    return e !== g || (c !== void 0 && fs(b, g, !1, d).indexOf(c) >= 0);
  }
  function ns(a, b, c, d) {
    function e(x, y, A) {
      if (A == null) return delete h[y], x;
      h[y] = A;
      return x + "; " + y + "=" + A;
    }
    function f(x, y) {
      if (y == null) return x;
      h[y] = !0;
      return x + "; " + y;
    }
    if (!hs(c.Sc)) return 2;
    var g;
    b == null
      ? (g = a + "=deleted; expires=" + new Date(0).toUTCString())
      : (c.encode && (b = encodeURIComponent(b)),
        (b = os(b)),
        (g = a + "=" + b));
    var h = {};
    g = e(g, "path", c.path);
    var l;
    c.expires instanceof Date
      ? (l = c.expires.toUTCString())
      : c.expires != null && (l = "" + c.expires);
    g = e(g, "expires", l);
    g = e(g, "max-age", c.mt);
    g = e(g, "samesite", c.Pt);
    c.secure && (g = f(g, "secure"));
    var m = c.domain;
    if (m && m.toLowerCase() === "auto") {
      for (var p = ps(), q = void 0, r = !1, t = 0; t < p.length; ++t) {
        var v = p[t] !== "none" ? p[t] : void 0,
          u = e(g, "domain", v);
        u = f(u, c.flags);
        try {
          d && d(a, h);
        } catch (x) {
          q = x;
          continue;
        }
        r = !0;
        if (!qs(v, c.path) && ms(u, a, b, c.Sc)) return 0;
      }
      if (q && !r) throw q;
      return 1;
    }
    m && m.toLowerCase() !== "none" && (g = e(g, "domain", m));
    g = f(g, c.flags);
    d && d(a, h);
    return qs(m, c.path) ? 1 : ms(g, a, b, c.Sc) ? 0 : 1;
  }
  function rs(a, b, c) {
    c.path == null && (c.path = "/");
    c.domain || (c.domain = "auto");
    bs("2");
    var d = ns(a, b, c);
    cs("2");
    return d;
  }
  function ls(a, b, c) {
    for (var d = [], e = [], f, g = 0; g < a.length; g++) {
      var h = a[g],
        l = b(h);
      l === c
        ? d.push(h)
        : f === void 0 || l < f
        ? ((e = [h]), (f = l))
        : l === f && e.push(h);
    }
    return d.length > 0 ? d : e;
  }
  function ks(a, b, c) {
    for (var d = [], e = fs(a, void 0, void 0, c), f = 0; f < e.length; f++) {
      var g = e[f].split("."),
        h = g.shift();
      if (!b || !h || b.indexOf(h) !== -1) {
        var l = g.shift();
        if (l) {
          var m = l.split("-");
          d.push({
            Tr: e[f],
            Ur: g.join("."),
            bs: Number(m[0]) || 1,
            Bt: Number(m[1]) || 1,
          });
        }
      }
    }
    return d;
  }
  function os(a) {
    a && a.length > 1200 && (a = a.substring(0, 1200));
    return a;
  }
  var ss = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
    ts = /(^|\.)doubleclick\.net$/i;
  function qs(a, b) {
    return (
      a !== void 0 &&
      (ts.test(w.document.location.hostname) || (b === "/" && ss.test(a)))
    );
  }
  function us(a) {
    if (!a) return 1;
    var b = a;
    Wf(4) && a === "none" && (b = w.document.location.hostname);
    b = b.indexOf(".") === 0 ? b.substring(1) : b;
    return b.split(".").length;
  }
  function vs(a) {
    if (!a || a === "/") return 1;
    a[0] !== "/" && (a = "/" + a);
    a[a.length - 1] !== "/" && (a += "/");
    return a.split("/").length - 1;
  }
  function ws(a, b) {
    var c = "" + us(a),
      d = vs(b);
    d > 1 && (c += "-" + d);
    return c;
  }
  var is = function () {
      var a = w;
      return es(a) ? a.document.cookie : "";
    },
    hs = function (a) {
      return a && Wf(5)
        ? (Array.isArray(a) ? a : [a]).every(function (b) {
            return Zl(b) && Xl(b);
          })
        : !0;
    },
    ps = function () {
      var a = [],
        b = w.document.location.hostname.split(".");
      if (b.length === 4) {
        var c = b[b.length - 1];
        if (Number(c).toString() === c) return ["none"];
      }
      for (var d = b.length - 2; d >= 0; d--) a.push(b.slice(d).join("."));
      var e = w.document.location.hostname;
      ts.test(e) || ss.test(e) || a.push("none");
      return a;
    };
  function xs(a) {
    var b = Math.round(Math.random() * 2147483647);
    return a ? String(b ^ (Bh(a) & 2147483647)) : String(b);
  }
  function ys(a) {
    return [xs(a), Math.round(Ob() / 1e3)].join(".");
  }
  function zs(a, b, c, d, e) {
    var f = us(b),
      g;
    return (g = js(a, f, vs(c), d, e)) == null ? void 0 : g.Ur;
  }
  var As;
  function Bs() {
    function a(g) {
      c(g.target || g.srcElement || {});
    }
    function b(g) {
      d(g.target || g.srcElement || {});
    }
    var c = Cs,
      d = Ds,
      e = Es();
    if (!e.init) {
      cd(z, "mousedown", a);
      cd(z, "keyup", a);
      cd(z, "submit", b);
      var f = HTMLFormElement.prototype.submit;
      HTMLFormElement.prototype.submit = function () {
        d(this);
        f.call(this);
      };
      e.init = !0;
    }
  }
  function Fs(a, b, c, d, e) {
    var f = {
      callback: a,
      domains: b,
      fragment: c === 2,
      placement: c,
      forms: d,
      sameHost: e,
    };
    Es().decorators.push(f);
  }
  function Gs(a, b, c) {
    for (var d = Es().decorators, e = {}, f = 0; f < d.length; ++f) {
      var g = d[f],
        h;
      if ((h = !c || g.forms))
        a: {
          var l = g.domains,
            m = a,
            p = !!g.sameHost;
          if (l && (p || m !== z.location.hostname))
            for (var q = 0; q < l.length; q++)
              if (l[q] instanceof RegExp) {
                if (l[q].test(m)) {
                  h = !0;
                  break a;
                }
              } else if (m.indexOf(l[q]) >= 0 || (p && l[q].indexOf(m) >= 0)) {
                h = !0;
                break a;
              }
          h = !1;
        }
      if (h) {
        var r = g.placement;
        r === void 0 && (r = g.fragment ? 2 : 1);
        r === b && Sb(e, g.callback());
      }
    }
    return e;
  }
  function Es() {
    var a = Qc("google_tag_data", {}),
      b = a.gl;
    (b && b.decorators) || ((b = { decorators: [] }), (a.gl = b));
    return b;
  }
  var Hs = /(.*?)\*(.*?)\*(.*)/,
    Is = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
    Js = /^(?:www\.|m\.|amp\.)+/,
    Ks = /([^?#]+)(\?[^#]*)?(#.*)?/;
  function Ls(a) {
    var b = Ks.exec(a);
    if (b) return { Lk: b[1], query: b[2], fragment: b[3] };
  }
  function Ms(a) {
    return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)");
  }
  function Ns(a, b) {
    var c = [
        Mc.userAgent,
        new Date().getTimezoneOffset(),
        Mc.userLanguage || Mc.language,
        Math.floor(Ob() / 60 / 1e3) - (b === void 0 ? 0 : b),
        a,
      ].join("*"),
      d;
    if (!(d = As)) {
      for (var e = Array(256), f = 0; f < 256; f++) {
        for (var g = f, h = 0; h < 8; h++)
          g = g & 1 ? (g >>> 1) ^ 3988292384 : g >>> 1;
        e[f] = g;
      }
      d = e;
    }
    As = d;
    for (var l = 4294967295, m = 0; m < c.length; m++)
      l = (l >>> 8) ^ As[(l ^ c.charCodeAt(m)) & 255];
    return ((l ^ -1) >>> 0).toString(36);
  }
  function Os(a) {
    return function (b) {
      var c = Oj(w.location.href),
        d = c.search.replace("?", ""),
        e = Fj(d, "_gl", !1, !0) || "";
      b.query = Ps(e) || {};
      var f = Ij(c, "fragment"),
        g;
      var h = -1;
      if (Ub(f, "_gl=")) h = 4;
      else {
        var l = f.indexOf("&_gl=");
        l > 0 && (h = l + 3 + 2);
      }
      if (h < 0) g = void 0;
      else {
        var m = f.indexOf("&", h);
        g = m < 0 ? f.substring(h) : f.substring(h, m);
      }
      b.fragment = Ps(g || "") || {};
      a && Qs(c, d, f);
    };
  }
  function Rs(a, b) {
    var c = Ms(a).exec(b),
      d = b;
    if (c) {
      var e = c[2],
        f = c[4];
      d = c[1];
      f && (d = d + e + f);
    }
    return d;
  }
  function Qs(a, b, c) {
    function d(g, h) {
      var l = Rs("_gl", g);
      l.length && (l = h + l);
      return l;
    }
    if (Lc && Lc.replaceState) {
      var e = Ms("_gl");
      if (e.test(b) || e.test(c)) {
        var f = Ij(a, "path");
        b = d(b, "?");
        c = d(c, "#");
        Lc.replaceState({}, "", "" + f + b + c);
      }
    }
  }
  function Ss(a, b) {
    var c = Os(!!b),
      d = Es();
    d.data || ((d.data = { query: {}, fragment: {} }), c(d.data));
    var e = {},
      f = d.data;
    f && (Sb(e, f.query), a && Sb(e, f.fragment));
    return e;
  }
  var Ps = function (a) {
    try {
      var b = Ts(a, 3);
      if (b !== void 0) {
        for (
          var c = {}, d = b ? b.split("*") : [], e = 0;
          e + 1 < d.length;
          e += 2
        ) {
          var f = d[e],
            g = qb(d[e + 1]);
          c[f] = g;
        }
        sb("TAGGING", 6);
        return c;
      }
    } catch (h) {
      sb("TAGGING", 8);
    }
  };
  function Ts(a, b) {
    if (a) {
      var c;
      a: {
        for (var d = a, e = 0; e < 3; ++e) {
          var f = Hs.exec(d);
          if (f) {
            c = f;
            break a;
          }
          d = Hj(d) || "";
        }
        c = void 0;
      }
      var g = c;
      if (g && g[1] === "1") {
        var h = g[3],
          l;
        a: {
          for (var m = g[2], p = 0; p < b; ++p)
            if (m === Ns(h, p)) {
              l = !0;
              break a;
            }
          l = !1;
        }
        if (l) return h;
        sb("TAGGING", 7);
      }
    }
  }
  function Us(a, b, c, d, e) {
    function f(p) {
      p = Rs(a, p);
      var q = p.charAt(p.length - 1);
      p && q !== "&" && (p += "&");
      return p + m;
    }
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var g = Ls(c);
    if (!g) return "";
    var h = g.query || "",
      l = g.fragment || "",
      m = a + "=" + b;
    d
      ? (l.substring(1).length !== 0 && e) || (l = "#" + f(l.substring(1)))
      : (h = "?" + f(h.substring(1)));
    return "" + g.Lk + h + l;
  }
  function Vs(a, b) {
    function c(m, p, q) {
      var r;
      a: {
        for (var t in m)
          if (m.hasOwnProperty(t)) {
            r = !0;
            break a;
          }
        r = !1;
      }
      if (r) {
        var v,
          u = [],
          x;
        for (x in m)
          if (m.hasOwnProperty(x)) {
            var y = m[x];
            y !== void 0 &&
              y === y &&
              y !== null &&
              y.toString() !== "[object Object]" &&
              (u.push(x), u.push(pb(String(y))));
          }
        var A = u.join("*");
        v = ["1", Ns(A), A].join("*");
        d
          ? (Wf(3) || Wf(1) || !p) && Ws("_gl", v, a, p, q)
          : Xs("_gl", v, a, p, q);
      }
    }
    var d = (a.tagName || "").toUpperCase() === "FORM",
      e = Gs(b, 1, d),
      f = Gs(b, 2, d),
      g = Gs(b, 4, d),
      h = Gs(b, 3, d);
    c(e, !1, !1);
    c(f, !0, !1);
    Wf(1) && c(g, !0, !0);
    for (var l in h) h.hasOwnProperty(l) && Ys(l, h[l], a);
  }
  function Ys(a, b, c) {
    c.tagName.toLowerCase() === "a"
      ? Xs(a, b, c)
      : c.tagName.toLowerCase() === "form" && Ws(a, b, c);
  }
  function Xs(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var f;
    if ((f = c.href)) {
      var g;
      if (!(g = d)) {
        var h = w.location.href,
          l = Ls(c.href),
          m = Ls(h);
        g = !(l && m && l.Lk === m.Lk && l.query === m.query && l.fragment);
      }
      f = g;
    }
    if (f) {
      var p = Us(a, b, c.href, d, e);
      Ac.test(p) && (c.href = p);
    }
  }
  function Ws(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    if (c) {
      var f = c.getAttribute("action") || "";
      if (f) {
        var g = (c.method || "").toLowerCase();
        if (g !== "get" || d) {
          if (g === "get" || g === "post") {
            var h = Us(a, b, f, d, e);
            Ac.test(h) && (c.action = h);
          }
        } else {
          for (var l = c.childNodes || [], m = !1, p = 0; p < l.length; p++) {
            var q = l[p];
            if (q.name === a) {
              q.setAttribute("value", b);
              m = !0;
              break;
            }
          }
          if (!m) {
            var r = z.createElement("input");
            r.setAttribute("type", "hidden");
            r.setAttribute("name", a);
            r.setAttribute("value", b);
            c.appendChild(r);
          }
        }
      }
    }
  }
  function Cs(a) {
    try {
      var b;
      a: {
        for (var c = a, d = 100; c && d > 0; ) {
          if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
            b = c;
            break a;
          }
          c = c.parentNode;
          d--;
        }
        b = null;
      }
      var e = b;
      if (e) {
        var f = e.protocol;
        (f !== "http:" && f !== "https:") || Vs(e, e.hostname);
      }
    } catch (g) {}
  }
  function Ds(a) {
    try {
      var b = a.getAttribute("action");
      if (b) {
        var c = Ij(Oj(b), "host");
        Vs(a, c);
      }
    } catch (d) {}
  }
  function Zs(a, b, c, d) {
    Bs();
    var e = c === "fragment" ? 2 : 1;
    d = !!d;
    Fs(a, b, e, d, !1);
    e === 2 && sb("TAGGING", 23);
    d && sb("TAGGING", 24);
  }
  function $s(a, b) {
    Bs();
    Fs(a, [Kj(w.location, "host", !0)], b, !0, !0);
  }
  function at() {
    var a = z.location.hostname,
      b = Is.exec(z.referrer);
    if (!b) return !1;
    var c = b[2],
      d = b[1],
      e = "";
    if (c) {
      var f = c.split("/"),
        g = f[1];
      e = g === "s" ? Hj(f[2]) || "" : Hj(g) || "";
    } else if (d) {
      if (d.indexOf("xn--") === 0) return !1;
      e = d.replace(/-/g, ".").replace(/\.\./g, "-");
    }
    var h = a.replace(Js, ""),
      l = e.replace(Js, "");
    return h === l || Vb(h, "." + l);
  }
  function bt(a, b) {
    return a === !1 ? !1 : a || b || at();
  }
  var ct = ["1"],
    dt = {},
    et = {};
  function ft(a, b) {
    b = b === void 0 ? !0 : b;
    var c = gt(a.prefix);
    if (dt[c]) ht(a), it(a);
    else if (jt(c, a.path, a.domain)) {
      var d = et[gt(a.prefix)] || { id: void 0, Li: void 0 };
      b && kt(a, d.id, d.Li);
      ht(a);
      it(a);
    } else {
      var e = Qj("auiddc");
      if (e) sb("TAGGING", 17), (dt[c] = e);
      else if (b) {
        var f = gt(a.prefix),
          g = ys();
        lt(f, g, a);
        jt(c, a.path, a.domain);
        ht(a, !0);
        it(a, !0);
      }
    }
  }
  function ht(a, b) {
    (b === void 0 ? 0 : b) && Or(Ir) && Gr("gcl_ctr");
    if (Rr(Ir) && Pr([Ir])[Ir.ub] === -1) {
      for (
        var c = {}, d = ((c[Ir.ub] = 0), c), e = n(Mr), f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = f.value;
        g !== Ir && Rr(g) && (d[g.ub] = 0);
      }
      Qr(d, a);
    }
  }
  function it(a, b) {
    (b === void 0 ? 0 : b) && Tr() && Gr("last_convs");
    !Xl(["ad_storage", "ad_user_data"]) || !Wf(14) || Sr() || Ur([], a);
  }
  function kt(a, b, c) {
    var d = gt(a.prefix),
      e = dt[d];
    if (e) {
      var f = e.split(".");
      if (f.length === 2) {
        var g = Number(f[1]) || 0;
        if (g) {
          var h = e;
          b && (h = e + "." + b + "." + (c ? c : Math.floor(Ob() / 1e3)));
          lt(d, h, a, g * 1e3);
        }
      }
    }
  }
  function lt(a, b, c, d) {
    var e;
    e = ["1", ws(c.domain, c.path), b].join(".");
    var f = Ar(c, d);
    f.Sc = mt();
    rs(a, e, f);
  }
  function jt(a, b, c) {
    var d = zs(a, b, c, ct, mt());
    if (!d) return !1;
    nt(a, d);
    return !0;
  }
  function nt(a, b) {
    var c = b.split(".");
    c.length === 5
      ? ((dt[a] = c.slice(0, 2).join(".")),
        (et[a] = { id: c.slice(2, 4).join("."), Li: Number(c[4]) || 0 }))
      : c.length === 3
      ? (et[a] = { id: c.slice(0, 2).join("."), Li: Number(c[2]) || 0 })
      : (dt[a] = b);
  }
  function gt(a) {
    return (a || "_gcl") + "_au";
  }
  function ot(a) {
    function b() {
      Xl(c) && a();
    }
    var c = mt();
    cm(function () {
      b();
      Xl(c) || dm(b, c);
    }, c);
  }
  function pt(a) {
    var b = Ss(!0),
      c = gt(a.prefix);
    ot(function () {
      var d = b[c];
      if (d) {
        nt(c, d);
        var e = Number(dt[c].split(".")[1]) * 1e3;
        if (e) {
          sb("TAGGING", 16);
          var f = Ar(a, e);
          f.Sc = mt();
          var g = ["1", ws(a.domain, a.path), d].join(".");
          rs(c, g, f);
        }
      }
    });
  }
  function qt(a, b, c, d, e) {
    e = e || {};
    var f = function () {
      var g = {},
        h = zs(a, e.path, e.domain, ct, mt());
      h && (g[a] = h);
      return g;
    };
    ot(function () {
      Zs(f, b, c, d);
    });
  }
  function mt() {
    return ["ad_storage", "ad_user_data"];
  }
  var rt = function (a) {
    this.value = 0;
    this.value = a === void 0 ? 0 : a;
  };
  rt.prototype.set = function (a) {
    return (this.value |= 1 << a);
  };
  var st = function (a, b) {
    b <= 0 || (a.value |= 1 << (b - 1));
  };
  rt.prototype.get = function () {
    return this.value;
  };
  rt.prototype.clear = function (a) {
    this.value &= ~(1 << a);
  };
  rt.prototype.clearAll = function () {
    this.value = 0;
  };
  rt.prototype.equals = function (a) {
    return this.value === a.value;
  };
  function tt(a) {
    for (
      var b = [],
        c = z.cookie.split(";"),
        d = new RegExp(
          "^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"
        ),
        e = 0;
      e < c.length;
      e++
    ) {
      var f = c[e].match(d);
      f &&
        b.push({
          Ge: f[1],
          value: f[2],
          timestamp: Number(f[2].split(".")[1]) || 0,
        });
    }
    b.sort(function (g, h) {
      return h.timestamp - g.timestamp;
    });
    return b;
  }
  function ut(a, b) {
    var c = tt(a),
      d = {};
    if (!c || !c.length) return d;
    for (var e = 0; e < c.length; e++) {
      var f = c[e].value.split(".");
      if (
        !(f[0] !== "1" || (b && f.length < 3) || (!b && f.length !== 3)) &&
        Number(f[1])
      ) {
        d[c[e].Ge] || (d[c[e].Ge] = []);
        var g = { version: f[0], timestamp: Number(f[1]) * 1e3, gclid: f[2] };
        b && f.length > 3 && (g.labels = f.slice(3));
        d[c[e].Ge].push(g);
      }
    }
    return d;
  }
  var vt = {},
    wt =
      ((vt.k = { na: /^[\w-]+$/ }),
      (vt.b = { na: /^[\w-]+$/, Ok: !0 }),
      (vt.i = { na: /^[1-9]\d*$/ }),
      (vt.h = { na: /^\d+$/ }),
      (vt.t = { na: /^[1-9]\d*$/ }),
      (vt.d = { na: /^[A-Za-z0-9_-]+$/ }),
      (vt.j = { na: /^\d+$/ }),
      (vt.u = { na: /^[1-9]\d*$/ }),
      (vt.l = { na: /^[01]$/ }),
      (vt.o = { na: /^[1-9]\d*$/ }),
      (vt.g = { na: /^[01]$/ }),
      (vt.s = { na: /^.+$/ }),
      (vt.m = { na: /^[01]$/ }),
      vt);
  var xt = {},
    Ct =
      ((xt[5] = { Pi: { 2: zt }, Fk: "2", Bi: ["k", "i", "b", "u"] }),
      (xt[4] = { Pi: { 2: zt, GCL: At }, Fk: "2", Bi: ["k", "i", "b", "m"] }),
      (xt[2] = {
        Pi: { GS2: zt, GS1: Bt },
        Fk: "GS2",
        Bi: "sogtjlhd".split(""),
      }),
      xt);
  function Dt(a, b, c) {
    var d = Ct[b];
    if (d) {
      var e = a.split(".")[0];
      c == null || c(e);
      if (e) {
        var f = d.Pi[e];
        if (f) return f(a, b);
      }
    }
  }
  function zt(a, b) {
    var c = a.split(".");
    if (c.length === 3) {
      var d = c[2];
      if (d.indexOf("$") === -1 && d.indexOf("%24") !== -1)
        try {
          d = decodeURIComponent(d);
        } catch (t) {}
      var e = {},
        f = Ct[b];
      if (f) {
        for (
          var g = f.Bi, h = n(d.split("$")), l = h.next();
          !l.done;
          l = h.next()
        ) {
          var m = l.value,
            p = m[0];
          if (g.indexOf(p) !== -1)
            try {
              var q = decodeURIComponent(m.substring(1)),
                r = wt[p];
              r && (r.Ok ? ((e[p] = e[p] || []), e[p].push(q)) : (e[p] = q));
            } catch (t) {}
        }
        return e;
      }
    }
  }
  function Et(a, b, c) {
    var d = Ct[b];
    if (d) return [d.Fk, c || "1", Ft(a, b)].join(".");
  }
  function Ft(a, b) {
    var c = Ct[b];
    if (c) {
      for (var d = [], e = n(c.Bi), f = e.next(); !f.done; f = e.next()) {
        var g = f.value,
          h = wt[g];
        if (h) {
          var l = a[g];
          if (l !== void 0)
            if (h.Ok && Array.isArray(l))
              for (var m = n(l), p = m.next(); !p.done; p = m.next())
                d.push(encodeURIComponent("" + g + p.value));
            else d.push(encodeURIComponent("" + g + l));
        }
      }
      return d.join("$");
    }
  }
  function At(a) {
    var b = a.split(".");
    b.shift();
    var c = b.shift(),
      d = b.shift(),
      e = {};
    return (e.k = d), (e.i = c), (e.b = b), e;
  }
  function Bt(a) {
    var b = a.split(".").slice(2);
    if (!(b.length < 5 || b.length > 7)) {
      var c = {};
      return (
        (c.s = b[0]),
        (c.o = b[1]),
        (c.g = b[2]),
        (c.t = b[3]),
        (c.j = b[4]),
        (c.l = b[5]),
        (c.h = b[6]),
        c
      );
    }
  }
  var Gt = new Map([
    [5, "ad_storage"],
    [4, ["ad_storage", "ad_user_data"]],
    [2, "analytics_storage"],
  ]);
  function Ht(a, b, c) {
    if (Ct[b]) {
      for (
        var d = [],
          e = fs(a, void 0, void 0, Gt.get(b)),
          f = n(e),
          g = f.next();
        !g.done;
        g = f.next()
      ) {
        var h = Dt(g.value, b, c);
        h && d.push(It(h));
      }
      return d;
    }
  }
  function Jt(a) {
    var b = Kt;
    if (Ct[2]) {
      for (
        var c = {},
          d = gs(a, void 0, void 0, Gt.get(2)),
          e = Object.keys(d).sort(),
          f = n(e),
          g = f.next();
        !g.done;
        g = f.next()
      )
        for (
          var h = g.value, l = n(d[h]), m = l.next();
          !m.done;
          m = l.next()
        ) {
          var p = Dt(m.value, 2, b);
          p && (c[h] || (c[h] = []), c[h].push(It(p)));
        }
      return c;
    }
  }
  function Lt(a, b, c, d, e) {
    d = d || {};
    var f = ws(d.domain, d.path),
      g = Et(b, c, f);
    if (!g) return 1;
    var h = Ar(d, e, void 0, Gt.get(c));
    return rs(a, g, h);
  }
  function Mt(a, b) {
    var c = b.na;
    return typeof c === "function" ? c(a) : c.test(a);
  }
  function It(a) {
    for (
      var b = n(Object.keys(a)), c = b.next(), d = {};
      !c.done;
      d = { Vg: void 0 }, c = b.next()
    ) {
      var e = c.value,
        f = a[e];
      d.Vg = wt[e];
      d.Vg
        ? d.Vg.Ok
          ? (a[e] = Array.isArray(f)
              ? f.filter(
                  (function (g) {
                    return function (h) {
                      return Mt(h, g.Vg);
                    };
                  })(d)
                )
              : void 0)
          : (typeof f === "string" && Mt(f, d.Vg)) || (a[e] = void 0)
        : (a[e] = void 0);
    }
    return a;
  }
  function Nt(a) {
    if (a)
      try {
        return new Uint8Array(
          atob(a.replace(/-/g, "+").replace(/_/g, "/"))
            .split("")
            .map(function (b) {
              return b.charCodeAt(0);
            })
        );
      } catch (b) {}
  }
  function Ot(a, b) {
    var c = 0,
      d = 0,
      e,
      f = b;
    do {
      if (f >= a.length) return;
      e = a[f++];
      c |= (e & 127) << d;
      d += 7;
    } while (e & 128);
    return [c, f];
  }
  function Pt() {
    var a = String,
      b = w.location.hostname,
      c = w.location.pathname,
      d = (b = dc(b));
    d.split(".").length > 2 &&
      (d = d.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
    b = d;
    c = dc(c);
    var e = c.split(";")[0];
    e = e.replace(/\/(ar|slp|web|index)?\/?$/, "");
    return a(Bh(("" + b + e).toLowerCase()));
  }
  var Qt = {},
    Rt =
      ((Qt.gclid = !0),
      (Qt.dclid = !0),
      (Qt.gbraid = !0),
      (Qt.wbraid = !0),
      Qt),
    St = /^\w+$/,
    Tt = /^[\w-]+$/,
    Ut = {},
    Vt = ((Ut.aw = "FPGCLAW"), Ut),
    Wt = {},
    Xt =
      ((Wt.ag = "_ag"),
      (Wt.gb = "_gb"),
      (Wt.aw = "_aw"),
      (Wt.dc = "_dc"),
      (Wt.gf = "_gf"),
      (Wt.ha = "_ha"),
      (Wt.gp = "_gp"),
      (Wt.gs = "_gs"),
      Wt),
    Yt = /^(?:www\.)?google(?:\.com?)?(?:\.[a-z]{2}t?)?$/,
    Zt = /^www\.googleadservices\.com$/;
  function $t() {
    return ["ad_storage", "ad_user_data"];
  }
  function au(a) {
    return !Wf(5) || Xl(a);
  }
  function bu(a, b) {
    function c() {
      var d = au(b);
      d && a();
      return d;
    }
    cm(function () {
      c() || dm(c, b);
    }, b);
  }
  function cu(a) {
    return du(a).map(function (b) {
      return b.gclid;
    });
  }
  function eu(a) {
    return fu(a)
      .filter(function (b) {
        return b.gclid;
      })
      .map(function (b) {
        return b.gclid;
      });
  }
  function fu(a, b) {
    b = b === void 0 ? !1 : b;
    var c = gu(a.prefix),
      d = hu("gb", c),
      e = hu("ag", c);
    if (!e || !d) return [];
    var f = function (l) {
        return function (m) {
          m.Ug = l;
          return m;
        };
      },
      g = du(d, b).map(f("gb")),
      h = iu(e).map(f("ag"));
    return g.concat(h).sort(function (l, m) {
      return m.timestamp - l.timestamp;
    });
  }
  function ju(a, b, c, d, e) {
    var f = Cb(a, function (g) {
      return g.gclid === b;
    });
    f
      ? (f.timestamp < c && ((f.timestamp = c), (f.ud = e)),
        (f.labels = ku(f.labels || [], d || [])))
      : a.push({ version: "2", gclid: b, timestamp: c, labels: d, ud: e });
  }
  function lu(a) {
    for (
      var b = Ht(a, 5) || [], c = [], d = n(b), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = e.value,
        g = f,
        h = mu(f);
      h && ju(c, g.k, h, g.b || [], f.u);
    }
    return c.sort(function (l, m) {
      return m.timestamp - l.timestamp;
    });
  }
  function du(a, b) {
    b = b === void 0 ? !1 : b;
    var c = [];
    nu(c, a, 1);
    if (b)
      if (Vb(a, "_aw")) {
        var d = ou();
        d && ((d.ud = void 0), (d.oa = d.oa || [2]), pu(c, d));
        nu(c, "gcl_aw", 2);
      } else Vb(a, "_gb") && Wf(6) && nu(c, "gcl_gb", 2);
    c.sort(function (e, f) {
      return f.timestamp - e.timestamp;
    });
    return qu(c);
  }
  function ru(a, b) {
    for (var c = [], d = n(a), e = d.next(); !e.done; e = d.next()) {
      var f = e.value;
      c.includes(f) || c.push(f);
    }
    for (var g = n(b), h = g.next(); !h.done; h = g.next()) {
      var l = h.value;
      c.includes(l) || c.push(l);
    }
    return c;
  }
  function pu(a, b, c) {
    c = c === void 0 ? !1 : c;
    for (var d, e, f = n(a), g = f.next(); !g.done; g = f.next()) {
      var h = g.value;
      if (h.gclid === b.gclid) {
        d = h;
        break;
      }
      h.ra && b.ra && h.ra.equals(b.ra) && (e = h);
    }
    if (d) {
      var l,
        m,
        p = (l = d.ra) != null ? l : new rt(),
        q = (m = b.ra) != null ? m : new rt();
      p.value |= q.value;
      d.ra = p;
      d.timestamp < b.timestamp && ((d.timestamp = b.timestamp), (d.ud = b.ud));
      d.labels = ru(d.labels || [], b.labels || []);
      d.oa = ru(d.oa || [], b.oa || []);
    } else c && e ? ma(Object, "assign").call(Object, e, b) : a.push(b);
  }
  function su(a) {
    if (!a) return new rt();
    var b = new rt();
    if (a === 1) return st(b, 2), st(b, 3), b;
    st(b, a);
    return b;
  }
  function ou() {
    var a = Fr("gclid");
    if (!a || a.error || !a.value || typeof a.value !== "object") return null;
    var b = a.value;
    try {
      if (!("value" in b && b.value) || typeof b.value !== "object")
        return null;
      var c = b.value,
        d = c.value;
      if (!d || !d.match(Tt)) return null;
      var e = c.linkDecorationSource,
        f = c.linkDecorationSources,
        g = new rt();
      typeof e === "number"
        ? (g = su(e))
        : typeof f === "number" && (g.value = f);
      return {
        version: "",
        gclid: d,
        timestamp: Number(c.creationTimeMs) || 0,
        labels: [],
        ra: g,
        oa: [2],
      };
    } catch (h) {
      return null;
    }
  }
  function tu(a) {
    var b = Fr(a);
    if (b.error !== 0) return null;
    try {
      return b.value.reduce(function (c, d) {
        if (!d.value || typeof d.value !== "object") return c;
        var e = d.value,
          f = e.value;
        if (!f || !f.match(Tt)) return c;
        var g = new rt(),
          h = e.linkDecorationSources;
        typeof h === "number" && (g.value = h);
        var l;
        c.push({
          version: "",
          gclid: f,
          timestamp: Number(e.creationTimeMs) || 0,
          expires: Number(d.expires) || 0,
          labels: (l = e.labels) != null ? l : [],
          ra: g,
          oa: [2],
        });
        return c;
      }, []);
    } catch (c) {
      return null;
    }
  }
  function nu(a, b, c) {
    if (c === 1)
      for (
        var d = fs(b, z.cookie, void 0, $t()), e = n(d), f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = uu(f.value.split(".")),
          h =
            g.length === 0
              ? null
              : {
                  version: g[0],
                  gclid: g[2],
                  timestamp: (Number(g[1]) || 0) * 1e3,
                  labels: g.slice(3),
                };
        h != null &&
          ((h.ud = void 0), (h.ra = new rt()), (h.oa = [c]), pu(a, h));
      }
    else if (c === 2) {
      var l = tu(b);
      if (l)
        for (var m = n(l), p = m.next(); !p.done; p = m.next()) {
          var q = p.value;
          q.ud = void 0;
          q.oa = q.oa;
          pu(a, q);
        }
    }
  }
  function vu(a) {
    var b = du(a),
      c = tu("gcl_dc");
    if (c)
      for (var d = n(c), e = d.next(); !e.done; e = d.next()) {
        var f = e.value;
        f.ud = void 0;
        f.oa = f.oa || [2];
        pu(b, f);
      }
    b.sort(function (g, h) {
      var l = g.oa && g.oa.includes(1),
        m = h.oa && h.oa.includes(1);
      return l && !m ? -1 : !l && m ? 1 : h.timestamp - g.timestamp;
    });
    return qu(b);
  }
  function iu(a) {
    return lu(a).map(function (b) {
      b.ra = new rt();
      b.oa = [1];
      return b;
    });
  }
  function ku(a, b) {
    if (!a.length) return b;
    if (!b.length) return a;
    var c = {};
    return a.concat(b).filter(function (d) {
      return c.hasOwnProperty(d) ? !1 : (c[d] = !0);
    });
  }
  function gu(a) {
    return a && typeof a === "string" && a.match(St) ? a : "_gcl";
  }
  function wu(a, b) {
    if (a) {
      var c = { value: a, ra: new rt() };
      st(c.ra, b);
      return c;
    }
  }
  function xu(a, b, c) {
    var d = Oj(a),
      e = Ij(d, "query", !1, void 0, "gclsrc"),
      f = wu(Ij(d, "query", !1, void 0, "gclid"), c ? 4 : 2);
    if (b && (!f || !e)) {
      var g = d.hash.replace("#", "");
      f || (f = wu(Fj(g, "gclid", !1), 3));
      e || (e = Fj(g, "gclsrc", !1));
    }
    return f &&
      (e === void 0 || e === "aw" || e === "aw.ds" || (Wf(9) && e === "aw.dv"))
      ? [f]
      : [];
  }
  function yu(a, b) {
    var c = Oj(a),
      d = Ij(c, "query", !1, void 0, "gclid"),
      e = Ij(c, "query", !1, void 0, "gclsrc"),
      f = Ij(c, "query", !1, void 0, "wbraid");
    f = bc(f);
    var g = Ij(c, "query", !1, void 0, "gbraid"),
      h = Ij(c, "query", !1, void 0, "gad_source"),
      l = Ij(c, "query", !1, void 0, "dclid");
    if (b && !(d && e && f && g)) {
      var m = c.hash.replace("#", "");
      d = d || Fj(m, "gclid", !1);
      e = e || Fj(m, "gclsrc", !1);
      f = f || Fj(m, "wbraid", !1);
      g = g || Fj(m, "gbraid", !1);
      h = h || Fj(m, "gad_source", !1);
    }
    return zu(d, e, l, f, g, h);
  }
  function Au(a, b, c) {
    var d = Oj(a),
      e = Ij(d, "query", !1, void 0, "gclsrc"),
      f = wu(Ij(d, "query", !1, void 0, "gclid"), c ? 4 : 2),
      g = wu(Ij(d, "query", !1, void 0, "dclid"), c ? 4 : 2);
    if (b && (!e || !f)) {
      var h = d.hash.replace("#", "");
      f || (f = wu(Fj(h, "gclid", !1), 3));
      e || (e = Fj(h, "gclsrc", !1));
    }
    return f &&
      e &&
      (e === "aw.ds" || e === "aw.dv" || e === "3p.ds" || e === "ds")
      ? [f]
      : g
      ? [g]
      : [];
  }
  function Bu() {
    return yu(w.location.href, !0);
  }
  function zu(a, b, c, d, e, f) {
    var g = {},
      h = function (l, m) {
        g[m] || (g[m] = []);
        g[m].push(l);
      };
    g.gclid = a;
    g.gclsrc = b;
    g.dclid = c;
    if (a !== void 0 && a.match(Tt))
      switch (b) {
        case void 0:
          h(a, "aw");
          break;
        case "aw.ds":
          h(a, "aw");
          h(a, "dc");
          break;
        case "aw.dv":
          Wf(9) && (h(a, "aw"), h(a, "dc"));
          break;
        case "ds":
          h(a, "dc");
          break;
        case "3p.ds":
          h(a, "dc");
          break;
        case "gf":
          h(a, "gf");
          break;
        case "ha":
          h(a, "ha");
      }
    c && h(c, "dc");
    d !== void 0 && Tt.test(d) && ((g.wbraid = d), h(d, "gb"));
    e !== void 0 && Tt.test(e) && ((g.gbraid = e), h(e, "ag"));
    f !== void 0 && Tt.test(f) && ((g.gad_source = f), h(f, "gs"));
    return g;
  }
  function Cu() {
    for (
      var a = Bu(), b = !0, c = n(Object.keys(a)), d = c.next();
      !d.done;
      d = c.next()
    )
      if (a[d.value] !== void 0) {
        b = !1;
        break;
      }
    b && ((a = yu(w.document.referrer, !1)), (a.gad_source = void 0));
    return a;
  }
  function Du(a) {
    var b = Cu();
    Eu(b, !1, a);
  }
  function Fu(a) {
    var b = xu(w.location.href, !0, !1);
    b.length || (b = xu(w.document.referrer, !1, !0));
    a = a || {};
    Gu(a);
    if (b.length) {
      var c = b[0],
        d = Ob(),
        e = Ar(a, d, !0),
        f = $t(),
        g = function () {
          au(f) &&
            e.expires !== void 0 &&
            Cr("gclid", {
              value: {
                value: c.value,
                creationTimeMs: d,
                linkDecorationSources: c.ra.get(),
              },
              expires: Number(e.expires),
            });
        };
      cm(function () {
        g();
        au(f) || dm(g, f);
      }, f);
    }
  }
  function Hu(a) {
    var b = Au(w.location.href, !0, !1);
    b.length || (b = Au(w.document.referrer, !1, !0));
    if (b.length) {
      a = a || {};
      var c = b[0];
      c.value &&
        Iu(
          "gcl_dc",
          [{ version: "", gclid: c.value, timestamp: Ob(), ra: c.ra }],
          a
        );
    }
  }
  function Gu(a) {
    var b = Ju();
    if (Yt.test(b) || Zt.test(b) || Ku()) {
      var c;
      a: {
        for (
          var d = Oj(w.location.href),
            e = Gj(Ij(d, "query")),
            f = n(Object.keys(e)),
            g = f.next();
          !g.done;
          g = f.next()
        ) {
          var h = g.value;
          if (!Rt[h]) {
            var l = e[h][0] || "",
              m;
            if (!l || l.length < 50 || l.length > 200) m = !1;
            else {
              var p = Nt(l),
                q;
              if (p)
                c: {
                  var r = p;
                  if (r && r.length !== 0) {
                    var t = 0;
                    try {
                      for (var v = 10; t < r.length && !(v-- <= 0); ) {
                        var u = Ot(r, t);
                        if (u === void 0) break;
                        var x = n(u),
                          y = x.next().value,
                          A = x.next().value,
                          C = y,
                          D = A,
                          E = C & 7;
                        if (C >> 3 === 16382) {
                          if (E !== 0) break;
                          var G = Ot(r, D);
                          if (G === void 0) break;
                          q = n(G).next().value === 1;
                          break c;
                        }
                        var I;
                        d: {
                          var Q = void 0,
                            V = r,
                            S = D;
                          switch (E) {
                            case 0:
                              I = (Q = Ot(V, S)) == null ? void 0 : Q[1];
                              break d;
                            case 1:
                              I = S + 8;
                              break d;
                            case 2:
                              var ja = Ot(V, S);
                              if (ja === void 0) break;
                              var fa = n(ja),
                                ka = fa.next().value;
                              I = fa.next().value + ka;
                              break d;
                            case 5:
                              I = S + 4;
                              break d;
                          }
                          I = void 0;
                        }
                        if (I === void 0 || I > r.length || I <= t) break;
                        t = I;
                      }
                    } catch (ia) {}
                  }
                  q = !1;
                }
              else q = !1;
              m = q;
            }
            if (m) {
              c = l;
              break a;
            }
          }
        }
        c = void 0;
      }
      var Z = c;
      Z && Lu("gcl_aw", Z, 7, a);
    }
  }
  function Lu(a, b, c, d) {
    Iu(a, [{ version: "", gclid: b, timestamp: Ob(), ra: su(c) }], d);
  }
  function Iu(a, b, c) {
    c = c || {};
    var d = $t(),
      e = function () {
        if (au(d) && b.length > 0) {
          var f = tu(a) || [];
          b.forEach(function (g) {
            var h = Ar(c, g.timestamp, !0);
            h.expires !== void 0 &&
              pu(
                f,
                {
                  version: "",
                  gclid: g.gclid,
                  timestamp: g.timestamp,
                  expires: Number(h.expires),
                  ra: g.ra,
                  labels: g.labels,
                },
                !0
              );
          });
          f.length &&
            Cr(
              a,
              f.map(function (g) {
                var h = {
                    value: g.gclid,
                    creationTimeMs: g.timestamp,
                    linkDecorationSources: g.ra ? g.ra.get() : 0,
                  },
                  l;
                if ((l = g.labels) == null ? 0 : l.length) h.labels = g.labels;
                return { value: h, expires: Number(g.expires) };
              })
            );
        }
      };
    cm(function () {
      au(d) ? e() : dm(e, d);
    }, d);
  }
  function Eu(a, b, c, d, e) {
    c = c || {};
    e = e || [];
    var f = gu(c.prefix),
      g = d || Ob(),
      h = Math.round(g / 1e3),
      l = $t(),
      m = !1,
      p = !1,
      q = Wf(11),
      r = function () {
        if (au(l)) {
          var t = Ar(c, g, !0);
          t.Sc = l;
          for (
            var v = function (V, S) {
                var ja = hu(V, f);
                ja && (rs(ja, S, t), V !== "gb" && (m = !0));
              },
              u = function (V) {
                var S = ["GCL", h, V];
                e.length > 0 && S.push(e.join("."));
                return S.join(".");
              },
              x = n(["aw", "dc", "gf", "ha", "gp"]),
              y = x.next();
            !y.done;
            y = x.next()
          ) {
            var A = y.value;
            a[A] && v(A, u(a[A][0]));
          }
          if ((!m || q) && a.gb) {
            var C = a.gb[0],
              D = hu("gb", f);
            (!b &&
              du(D).some(function (V) {
                return V.gclid === C && V.labels && V.labels.length > 0;
              })) ||
              v("gb", u(C));
          }
        }
        if (!p && a.gbraid && au("ad_storage") && ((p = !0), !m || q)) {
          var E = a.gbraid,
            G = hu("ag", f);
          if (
            b ||
            !iu(G).some(function (V) {
              return V.gclid === E && V.labels && V.labels.length > 0;
            })
          ) {
            var I = {},
              Q = ((I.k = E), (I.i = "" + h), (I.b = e), I);
            Lt(G, Q, 5, c, g);
          }
        }
        Mu(a, f, g, c);
      };
    cm(function () {
      r();
      au(l) || dm(r, l);
    }, l);
  }
  function Mu(a, b, c, d) {
    if (a.gad_source !== void 0 && au("ad_storage")) {
      var e = td();
      if (e !== "r" && e !== "h") {
        var f = a.gad_source,
          g = hu("gs", b);
        if (g) {
          var h = Math.floor((Ob() - (sd() || 0)) / 1e3),
            l,
            m = Pt(),
            p = {};
          l = ((p.k = f), (p.i = "" + h), (p.u = m), p);
          Lt(g, l, 5, d, c);
        }
      }
    }
  }
  function Nu(a, b, c) {
    for (var d = Ht(b, c), e = 0; e < d.length; ++e)
      if (mu(d[e]) > a) return !0;
    return !1;
  }
  function Ou(a, b) {
    var c = Pu(b.prefix);
    bu(function () {
      for (
        var d = gu(b.prefix), e = n(a), f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = f.value,
          h = c[g];
        if (h) {
          var l = Math.min(Qu(h), Ob()),
            m = Ar(b, l, !0);
          m.Sc = $t();
          var p = hu(g, d);
          p && rs(p, h, m);
        }
      }
      var q = Ss(!0);
      Eu(zu(q.gclid, q.gclsrc), !1, b);
    }, $t());
  }
  function Pu(a) {
    var b = Ss(!0),
      c = gu(a),
      d = {},
      e;
    for (e in Xt)
      if (Xt.hasOwnProperty(e)) {
        var f = e,
          g = hu(f, c);
        if (g !== void 0) {
          var h = b[g];
          if (h) {
            var l = Qu(h),
              m;
            a: {
              for (
                var p = Math.min(l, Ob()) || Ob(),
                  q = fs(g, z.cookie, void 0, $t()),
                  r = 0;
                r < q.length;
                ++r
              )
                if (Qu(q[r]) > p) {
                  m = !0;
                  break a;
                }
              m = !1;
            }
            m || (d[f] = h);
          }
        }
      }
    return d;
  }
  function Ru(a) {
    var b = ["ag"],
      c = Ss(!0),
      d = gu(a.prefix);
    bu(
      function () {
        for (var e = 0; e < b.length; ++e) {
          var f = hu(b[e], d);
          if (f) {
            var g = c[f];
            if (g) {
              var h = Dt(g, 5);
              if (h) {
                var l = mu(h);
                l || (l = Ob());
                if (Nu(l, f, 5)) break;
                h.i = "" + Math.round(l / 1e3);
                Lt(f, h, 5, a, l);
              }
            }
          }
        }
      },
      ["ad_storage"]
    );
  }
  function hu(a, b) {
    var c = Xt[a];
    if (c !== void 0) return b + c;
  }
  function Qu(a) {
    return uu(a.split(".")).length !== 0
      ? (Number(a.split(".")[1]) || 0) * 1e3
      : 0;
  }
  function mu(a) {
    return a ? (Number(a.i) || 0) * 1e3 : 0;
  }
  function uu(a) {
    return a.length < 3 ||
      (a[0] !== "GCL" && a[0] !== "1") ||
      !/^\d+$/.test(a[1]) ||
      !Tt.test(a[2])
      ? []
      : a;
  }
  function Su(a, b, c, d, e) {
    if (Array.isArray(b) && es(w)) {
      var f = gu(e),
        g = function () {
          for (var h = {}, l = 0; l < a.length; ++l) {
            var m = hu(a[l], f);
            if (m) {
              var p = fs(m, z.cookie, void 0, $t());
              p.length && (h[m] = p.sort()[p.length - 1]);
            }
          }
          return h;
        };
      bu(function () {
        Zs(g, b, c, d);
      }, $t());
    }
  }
  function Tu(a, b, c) {
    var d = Uu;
    if (Wf(16) && Array.isArray(a) && es(w)) {
      var e = function () {
        for (var f = {}, g = 0; g < d.length; ++g) {
          var h = Vt[d[g]];
          if (h) {
            var l = fs(h, z.cookie, void 0, $t());
            if (l.length) {
              for (
                var m = void 0, p = 0, q = n(l), r = q.next();
                !r.done;
                r = q.next()
              ) {
                var t = r.value,
                  v = Dt(t, 4);
                if (v && (v.m === "1" || Wf(19))) {
                  var u = mu(v);
                  u >= p && ((p = u), (m = t));
                }
              }
              m && (f[h] = m);
            }
          }
        }
        return f;
      };
      bu(function () {
        Zs(e, a, b, c);
      }, $t());
    }
  }
  function Vu(a, b, c, d) {
    if (Array.isArray(a) && es(w)) {
      var e = ["ag"],
        f = gu(d),
        g = function () {
          for (var h = {}, l = 0; l < e.length; ++l) {
            var m = hu(e[l], f);
            if (!m) return {};
            var p = Ht(m, 5);
            if (p.length) {
              var q = p.sort(function (r, t) {
                return mu(t) - mu(r);
              })[0];
              h[m] = Et(q, 5);
            }
          }
          return h;
        };
      bu(
        function () {
          Zs(g, a, b, c);
        },
        ["ad_storage"]
      );
    }
  }
  function qu(a) {
    return a.filter(function (b) {
      return Tt.test(b.gclid);
    });
  }
  function Wu(a, b) {
    if (es(w)) {
      for (var c = gu(b.prefix), d = {}, e = 0; e < a.length; e++)
        Xt[a[e]] && (d[a[e]] = Xt[a[e]]);
      bu(function () {
        Gb(d, function (f, g) {
          var h = fs(c + g, z.cookie, void 0, $t());
          h.sort(function (t, v) {
            return Qu(v) - Qu(t);
          });
          if (h.length) {
            var l = h[0],
              m = Qu(l),
              p = uu(l.split(".")).length !== 0 ? l.split(".").slice(3) : [],
              q = {},
              r;
            r = uu(l.split(".")).length !== 0 ? l.split(".")[2] : void 0;
            q[f] = [r];
            Eu(q, !0, b, m, p);
          }
        });
      }, $t());
    }
  }
  function Xu(a) {
    var b = ["ag"],
      c = ["gbraid"];
    bu(
      function () {
        for (var d = gu(a.prefix), e = 0; e < b.length; ++e) {
          var f = hu(b[e], d);
          if (!f) break;
          var g = Ht(f, 5);
          if (g.length) {
            var h = g.sort(function (q, r) {
                return mu(r) - mu(q);
              })[0],
              l = mu(h),
              m = h.b,
              p = {};
            p[c[e]] = h.k;
            Eu(p, !0, a, l, m);
          }
        }
      },
      ["ad_storage"]
    );
  }
  function Yu(a, b) {
    for (var c = 0; c < b.length; ++c) if (a[b[c]]) return !0;
    return !1;
  }
  function Zu(a) {
    function b(h, l, m) {
      m && (h[l] = m);
    }
    if ($l()) {
      var c = Bu(),
        d;
      a.includes("gad_source") &&
        (d = c.gad_source !== void 0 ? c.gad_source : Ss(!1)._gs);
      if (Yu(c, a) || d) {
        var e = {};
        b(e, "gclid", c.gclid);
        b(e, "dclid", c.dclid);
        b(e, "gclsrc", c.gclsrc);
        b(e, "wbraid", c.wbraid);
        b(e, "gbraid", c.gbraid);
        $s(function () {
          return e;
        }, 3);
        var f = {},
          g = ((f._up = "1"), f);
        b(g, "_gs", d);
        $s(function () {
          return g;
        }, 1);
      }
    }
  }
  function Ku() {
    var a = Oj(w.location.href);
    return Ij(a, "query", !1, void 0, "gad_source");
  }
  function $u(a) {
    if (!Wf(1)) return null;
    var b = Ss(!0).gad_source;
    if (b != null) return (w.location.hash = ""), b;
    if (Wf(2)) {
      b = Ku();
      if (b != null) return b;
      var c = Bu();
      if (Yu(c, a)) return "0";
    }
    return null;
  }
  function av(a) {
    var b = $u(a);
    b != null &&
      $s(function () {
        var c = {};
        return (c.gad_source = b), c;
      }, 4);
  }
  function bv(a, b, c) {
    var d = [];
    if (b.length === 0) return d;
    for (var e = {}, f = 0; f < b.length; f++) {
      var g = b[f],
        h = g.Ug ? g.Ug : "gcl";
      if ((g.labels || []).indexOf(c) === -1) {
        a.push(0);
        var l = !1,
          m = void 0;
        if ((m = g.oa) == null ? 0 : m.includes(2)) l = !0;
        var p = void 0;
        ((p = g.oa) == null ? 0 : p.includes(1)) &&
          !e[h] &&
          ((l = !0), (e[h] = !0));
        l && d.push(g);
      } else {
        a.push(1);
        var q = void 0;
        if ((q = g.oa) == null ? 0 : q.includes(1)) e[h] = !0;
      }
    }
    return d;
  }
  function cv(a, b, c, d, e) {
    e = e === void 0 ? !1 : e;
    var f = [];
    c = c || {};
    if (!au($t())) return f;
    var g = du(a, e),
      h = bv(f, g, b);
    if (h.length && !d) {
      for (var l = [], m = !1, p = n(h), q = p.next(); !q.done; q = p.next()) {
        var r = q.value,
          t = r,
          v = t.version,
          u = t.gclid,
          x = t.timestamp,
          y = t.oa,
          A = (t.labels || []).concat([b]),
          C = void 0;
        if (((C = y) == null ? 0 : C.includes(1)) && !m) {
          var D = [v, Math.round(x / 1e3), u].concat(A).join("."),
            E = Ar(c, x, !0);
          E.Sc = $t();
          rs(a, D, E);
          m = !0;
        }
        var G = void 0;
        e &&
          ((G = y) == null ? 0 : G.includes(2)) &&
          l.push(ma(Object, "assign").call(Object, {}, r, { labels: A }));
      }
      l.length && Iu("gcl_gb", l, c);
    }
    return f;
  }
  function dv(a, b, c) {
    c = c === void 0 ? !1 : c;
    var d = [];
    b = b || {};
    var e = fu(b, c),
      f = bv(d, e, a);
    if (f.length) {
      for (var g = [], h = {}, l = n(f), m = l.next(); !m.done; m = l.next()) {
        var p = m.value,
          q = gu(b.prefix),
          r = hu(p.Ug, q);
        if (!r) return d;
        var t = p,
          v = t.version,
          u = t.gclid,
          x = t.timestamp,
          y = t.oa,
          A = Math.round(x / 1e3),
          C = ku(t.labels || [], [a]),
          D = void 0;
        if ((D = y) == null ? 0 : D.includes(1))
          if (p.Ug === "ag" && !h.ag) {
            var E = {},
              G = ((E.k = u), (E.i = "" + A), (E.b = C), E);
            Lt(r, G, 5, b, x);
            h.ag = !0;
          } else if (p.Ug === "gb" && !h.gb) {
            var I = [v, A, u].concat(C).join("."),
              Q = Ar(b, x, !0);
            Q.Sc = $t();
            rs(r, I, Q);
            h.gb = !0;
          }
        var V = void 0;
        c &&
          ((V = y) == null ? 0 : V.includes(2)) &&
          g.push(ma(Object, "assign").call(Object, {}, p, { labels: C }));
      }
      g.length && Iu("gcl_gb", g, b);
    }
    return d;
  }
  function ev(a, b) {
    var c = gu(b),
      d = hu(a, c);
    if (!d) return 0;
    var e;
    e = a === "ag" ? iu(d) : du(d);
    for (var f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
    return f;
  }
  function fv(a) {
    for (var b = 0, c = n(Object.keys(a)), d = c.next(); !d.done; d = c.next())
      for (var e = a[d.value], f = 0; f < e.length; f++)
        b = Math.max(b, Number(e[f].timestamp));
    return b;
  }
  function gv(a) {
    var b = Math.max(ev("aw", a), fv(au($t()) ? ut() : {})),
      c = Math.max(ev("gb", a), fv(au($t()) ? ut("_gac_gb", !0) : {}));
    c = Math.max(c, ev("ag", a));
    return c > b;
  }
  function Ju() {
    return z.referrer ? Ij(Oj(z.referrer), "host") : "";
  }
  var hv = RegExp(
      "^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"
    ),
    iv = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
    jv = /^\d+\.fls\.doubleclick\.net$/,
    kv = /;gac=([^;?]+)/,
    lv = /;gacgb=([^;?]+)/;
  function mv(a, b) {
    if (jv.test(z.location.host)) {
      var c = z.location.href.match(b);
      return c && c.length === 2 && c[1].match(hv) ? Hj(c[1]) || "" : "";
    }
    for (
      var d = [], e = n(Object.keys(a)), f = e.next();
      !f.done;
      f = e.next()
    ) {
      for (var g = f.value, h = [], l = a[g], m = 0; m < l.length; m++)
        h.push(l[m].gclid);
      d.push(g + ":" + h.join(","));
    }
    return d.length > 0 ? d.join(";") : "";
  }
  function nv(a, b, c) {
    for (
      var d = au($t()) ? ut("_gac_gb", !0) : {},
        e = [],
        f = !1,
        g = n(Object.keys(d)),
        h = g.next();
      !h.done;
      h = g.next()
    ) {
      var l = h.value,
        m = cv("_gac_gb_" + l, a, b, c);
      f =
        f ||
        (m.length !== 0 &&
          m.some(function (p) {
            return p === 1;
          }));
      e.push(l + ":" + m.join(","));
    }
    return { vs: f ? e.join(";") : "", us: mv(d, lv) };
  }
  function ov(a) {
    var b = z.location.href.match(new RegExp(";" + a + "=([^;?]+)"));
    return b && b.length === 2 && b[1].match(iv) ? b[1] : void 0;
  }
  function pv(a) {
    var b = {},
      c,
      d,
      e;
    jv.test(z.location.host) &&
      ((c = ov("gclgs")), (d = ov("gclst")), (e = ov("gcllp")));
    if (c && d && e) (b.eh = c), (b.Fi = d), (b.Ei = e);
    else {
      var f = Ob(),
        g = lu((a || "_gcl") + "_gs"),
        h = g.map(function (p) {
          return p.gclid;
        }),
        l = g.map(function (p) {
          return f - p.timestamp;
        }),
        m = g.map(function (p) {
          return p.ud;
        });
      h.length > 0 &&
        l.length > 0 &&
        m.length > 0 &&
        ((b.eh = h.join(".")), (b.Fi = l.join(".")), (b.Ei = m.join(".")));
    }
    return b;
  }
  function qv(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    if (jv.test(z.location.host)) {
      var e = ov(c);
      if (e) {
        if (d) {
          var f = new rt();
          st(f, 2);
          st(f, 3);
          return e.split(".").map(function (q) {
            return { gclid: q, ra: f, oa: [1] };
          });
        }
        return e.split(".").map(function (q) {
          return { gclid: q, ra: new rt(), oa: [1] };
        });
      }
    } else {
      if (b === "gclid") {
        for (
          var g = du((a || "_gcl") + "_aw", d),
            h = Number(Vf[4] === void 0 ? 0 : Vf[4]),
            l = n(rv()),
            m = l.next();
          !m.done;
          m = l.next()
        ) {
          var p = m.value;
          p.timestamp > h && pu(g, p);
        }
        return g;
      }
      if (b === "wbraid") return du((a || "_gcl") + "_gb", d);
      if (b === "braids") return fu({ prefix: a }, d);
    }
    return [];
  }
  function rv() {
    return (Ht(Vt.aw, 4) || [])
      .filter(function (a) {
        return a.m === "1";
      })
      .map(function (a) {
        return { gclid: a.k, timestamp: Number(a.i), version: "", oa: [5] };
      });
  }
  function sv(a) {
    for (var b = 0, c = n(a), d = c.next(); !d.done; d = c.next()) {
      var e = d.value;
      e > 0 && (b |= 1 << (e - 1));
    }
    return b.toString();
  }
  function tv(a) {
    return jv.test(z.location.host) ? !(ov("gclaw") || ov("gac")) : gv(a);
  }
  function uv(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    var e;
    e = c
      ? dv(a, b, d)
      : cv(((b && b.prefix) || "_gcl") + "_gb", a, b, void 0, d);
    return e.length === 0 ||
      e.every(function (f) {
        return f === 0;
      })
      ? ""
      : e.join(".");
  }
  function Iv(a, b) {
    var c = Ei(a, H.D.fb);
    if (c && typeof c === "object")
      for (var d = n(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
        var f = e.value,
          g = c[f];
        g !== void 0 && (g === null && (g = ""), (b["gap." + f] = String(g)));
      }
  }
  var Vv =
      "email email_address sha256_email_address phone_number sha256_phone_number first_name last_name".split(
        " "
      ),
    Wv =
      "first_name sha256_first_name last_name sha256_last_name street sha256_street city region country postal_code".split(
        " "
      );
  function Xv(a, b) {
    if (!b._tag_metadata) {
      for (var c = {}, d = 0, e = 0; e < a.length; e++)
        d += Yv(a[e], b, c) ? 1 : 0;
      d > 0 && (b._tag_metadata = c);
    }
  }
  function Yv(a, b, c) {
    var d = b[a];
    if (d === void 0 || d === null) return !1;
    c[a] = Array.isArray(d)
      ? d.map(function () {
          return { mode: "c" };
        })
      : { mode: "c" };
    return !0;
  }
  function Zv(a) {
    if (N(523) && a) {
      Xv(Vv, a);
      for (var b = Bb(a.address), c = 0; c < b.length; c++) {
        var d = b[c];
        d && Xv(Wv, d);
      }
      var e = a.home_address;
      e && Xv(Wv, e);
    }
  }
  function $v(a, b, c) {
    function d(f, g) {
      g = String(g).substring(0, 100);
      e.push("" + f + encodeURIComponent(g));
    }
    if (!c) return "";
    var e = [];
    d("i", String(a));
    d("f", b);
    c.mode && d("m", c.mode);
    c.isPreHashed && d("p", "1");
    c.rawLength && d("r", String(c.rawLength));
    c.normalizedLength && d("n", String(c.normalizedLength));
    c.location && d("l", c.location);
    c.selector && d("s", c.selector);
    return e.join(".");
  }
  var Mw = {},
    Nw =
      ((Mw[5] = function () {
        return "https://www.googleadservices.com/pagead/conversion";
      }),
      (Mw[6] = function () {
        return Tj()
          ? Uj() + "/gs/pagead/conversion"
          : "https://pagead2.googlesyndication.com/pagead/conversion";
      }),
      (Mw[66] = function () {
        return "https://www.google.com/pagead/uconversion";
      }),
      (Mw[8] = function () {
        return "https://www.google.com/pagead/1p-conversion";
      }),
      (Mw[63] = function () {
        return "https://www.googleadservices.com/pagead/conversion";
      }),
      (Mw[64] = function () {
        return Tj()
          ? Uj() + "/gs/pagead/conversion"
          : "https://pagead2.googlesyndication.com/pagead/conversion";
      }),
      (Mw[65] = function () {
        return "https://www.google.com/pagead/1p-conversion";
      }),
      Mw),
    Ow = {},
    Pw =
      ((Ow[5] = function () {
        return Uj() + "/as/d/pagead/conversion";
      }),
      (Ow[63] = function () {
        return Uj() + "/as/d/pagead/conversion";
      }),
      (Ow[6] = function () {
        return Uj() + "/gs/pagead/conversion";
      }),
      (Ow[8] = function () {
        return Uj() + "/g/d/pagead/1p-conversion";
      }),
      (Ow[65] = function () {
        return Uj() + "/g/d/pagead/1p-conversion";
      }),
      Ow);
  var Qw = {},
    Rw =
      ((Qw[1] = function () {
        return "https://ad.doubleclick.net/activity;";
      }),
      (Qw[2] = function () {
        return (
          (Tj() ? Uj() : "https://ade.googlesyndication.com") +
          "/ddm/activity" +
          (N(467) ? ";" : "/")
        );
      }),
      (Qw[3] = function (a) {
        return "https://" + a.Gr + ".fls.doubleclick.net/activityi;";
      }),
      Qw);
  var Sw = {},
    Tw =
      ((Sw[45] = function () {
        return "https://www.google.com/ccm/collect";
      }),
      (Sw[46] = function () {
        return Tj()
          ? Uj() + "/gs/ccm/collect"
          : "https://pagead2.googlesyndication.com/ccm/collect";
      }),
      (Sw[69] = function () {
        return "https://ad.doubleclick.net/ccm/s/collect";
      }),
      Sw);
  var Uw = {},
    Vw =
      ((Uw[9] = function () {
        return "https://googleads.g.doubleclick.net/pagead/viewthroughconversion";
      }),
      (Uw[68] = function () {
        return "https://www.google.com/rmkt/collect";
      }),
      Uw);
  var Ww = {},
    Xw =
      ((Ww[22] = function () {
        return Tj()
          ? Uj() + "/as/d/ccm/conversion"
          : "https://www.googleadservices.com/ccm/conversion";
      }),
      (Ww[60] = function () {
        return Tj()
          ? Uj() + "/gs/ccm/conversion"
          : "https://pagead2.googlesyndication.com/ccm/conversion";
      }),
      (Ww[23] = function () {
        return Tj()
          ? Uj() + "/g/d/ccm/conversion"
          : "https://www.google.com/ccm/conversion";
      }),
      Ww);
  var Yw = {},
    Zw =
      ((Yw[51] = function () {
        return "https://www.google.com/travel/flights/click/conversion";
      }),
      Yw);
  var bx = {},
    cx =
      ((bx[55] = function () {
        return Mm()
          ? ax("measurement/conversion")
          : Tj()
          ? Uj() + "/gs/measurement/conversion"
          : "https://pagead2.googlesyndication.com/measurement/conversion";
      }),
      (bx[54] = function () {
        return Mm()
          ? $w("measurement/conversion")
          : Tj()
          ? Uj() + "/g/measurement/conversion"
          : "https://www.google.com/measurement/conversion";
      }),
      bx);
  var dx = {},
    ex =
      ((dx[17] = function () {
        return Tj() && !Mm() ? "" + Uj() + "/ag/g/c" : $w();
      }),
      (dx[16] = function () {
        return Tj() && !Mm() ? "" + Uj() + "/ga/g/c" : ax();
      }),
      (dx[67] = function () {
        var a;
        a = a === void 0 ? "g/collect" : a;
        return Mm() ? "" : "https://www.google.com/" + a;
      }),
      dx);
  var fx = {},
    gx =
      ((fx[11] = function () {
        return Tj()
          ? Uj() + "/d/pagead/form-data"
          : (N(141) ? "https://www.google.com" : "https://google.com") +
              "/pagead/form-data";
      }),
      (fx[21] = function () {
        return Tj()
          ? Uj() + "/d/ccm/form-data"
          : (N(141) ? "https://www.google.com" : "https://google.com") +
              "/ccm/form-data";
      }),
      fx);
  var hx = ma(Object, "assign").call(
    Object,
    {},
    Nw,
    Tw,
    Vw,
    Xw,
    Zw,
    Rw,
    cx,
    ex,
    gx
  );
  var ix = [H.D.da, H.D.fa];
  var jx = Object.freeze({ gcp: "1", sscte: "1", ct_cookie_present: "1" });
  function kx(a, b) {
    return hx[a](void 0) + "/" + b + "/";
  }
  function lx() {
    return Tj() && N(515) && Ao(ix);
  }
  function mx(a, b) {
    return a.replace(RegExp("([?&])fmt=[^&]*(&|$)"), "$1fmt=" + b + "$2");
  }
  var nx = function (a) {
    this.methodName = a;
  };
  nx.prototype.getName = function () {
    return this.methodName;
  };
  nx.prototype.sendRequest = function (a, b, c) {
    if (this.isSupported())
      if ((c == null ? void 0 : c.body) === void 0 || this.H())
        try {
          this.K(a, b, c);
        } catch (d) {
          a.Pc(d);
        }
      else
        a.Pc(
          "Request method " +
            this.getName() +
            " does not support a request body."
        );
    else a.Pc("Request method " + this.getName() + " is not supported.");
  };
  var ox = function () {
    this.methodName = "ImagePixel";
  };
  va(ox, nx);
  ox.prototype.isSupported = function () {
    return !0;
  };
  ox.prototype.H = function () {
    return !1;
  };
  ox.prototype.K = function (a, b, c) {
    bl(
      a.Rc,
      b,
      function () {
        a.xf();
      },
      function () {
        a.onFailure(void 0);
      },
      c == null ? void 0 : c.pf
    );
  };
  var px = function () {
    this.methodName = "SendBeacon";
  };
  va(px, nx);
  px.prototype.isSupported = function () {
    return Mc.sendBeacon !== void 0;
  };
  px.prototype.H = function () {
    return !0;
  };
  px.prototype.K = function (a, b, c) {
    al(a.Rc, b, c == null ? void 0 : c.body) ? a.xf() : a.Pc(void 0);
  };
  var qx = function () {
    this.methodName = "Fetch";
  };
  va(qx, nx);
  qx.prototype.isSupported = function () {
    return yb(w.fetch);
  };
  qx.prototype.H = function () {
    return !0;
  };
  qx.prototype.K = function (a, b, c) {
    qk.register(a.Rc, 2, b);
    w.fetch(b, c == null ? void 0 : c.Kc)
      .then(function (d) {
        if (d.ok) a.ze(d);
        else if (d.status === 0) a.xf();
        else a.onFailure("Fetch failed with status code " + d.status + ".");
      })
      .catch(function (d) {
        a.Pc(d);
      });
  };
  var rx = new ox(),
    sx = new px(),
    tx = new qx();
  var ux = {
      Ma: function (a, b, c, d, e) {
        Jw(a, function (f) {
          P(a, J.J.mi) && delete f.item;
          P(a, J.J.Aa) && ma(Object, "assign").call(Object, f, jx);
          var g = bk(c);
          g && (f._uip = g);
          var h = "?" + Qv(f);
          e(h);
        });
      },
    },
    vx = Object.freeze({
      xd: !0,
      Jc: !1,
      hk: void 0,
      parameterEncoding: 3,
      isSupported: function () {
        return !0;
      },
      qc: function () {
        return ux;
      },
      pe: function (a, b, c) {
        return Di(a, c);
      },
    }),
    xx = Object.freeze(
      ma(Object, "assign").call(Object, {}, vx, {
        endpoint: 22,
        Za: ["ad_storage", "ad_user_data"],
        Xa: function () {
          return wx(22);
        },
      })
    ),
    yx = Object.freeze(
      ma(Object, "assign").call(Object, {}, vx, {
        endpoint: 23,
        Za: ["ad_storage", "ad_user_data"],
        Xa: function () {
          return wx(23);
        },
      })
    ),
    zx = Object.freeze(
      ma(Object, "assign").call(Object, {}, vx, {
        endpoint: 60,
        Za: [],
        Xa: function () {
          return wx(60);
        },
      })
    );
  function wx(a) {
    var b = hx[a](void 0);
    return Ub(b, "https://") ? b.substring(8) : b;
  }
  var Ax = Object.freeze({
    te: function (a) {
      return P(a, J.J.ba) === O.R.Uc && P(a, J.J.ui)
        ? [{ endpoint: Ao(ix) ? (P(a, J.J.Aa) ? yx : xx) : zx, method: rx }]
        : [];
    },
  });
  var Ox = Object.freeze({ attributionsrc: "" }),
    Px = Object.freeze({ eventSourceEligible: !1, triggerEligible: !0 });
  function Qx() {
    var a = XMLHttpRequest.prototype;
    return a && yb(a.setAttributionReporting);
  }
  var Rx = Object.freeze({
    cache: "no-store",
    credentials: "include",
    method: "GET",
    keepalive: !0,
    redirect: "follow",
  });
  function Sx(a, b, c, d, e, f, g, h, l) {
    if (w.fetch) {
      a && qk.register(a, 2, b);
      var m = ma(Object, "assign").call(Object, {}, Rx);
      c && ((m.body = c), (m.method = "POST"));
      ma(Object, "assign").call(Object, m, e);
      var p = function () {
        h == null || Yk(h);
        l == null || Zk(l, b);
      };
      w.fetch(b, m)
        .then(function (q) {
          p();
          if (q.ok) {
            if (q.body) {
              var r = q.body.getReader(),
                t = new TextDecoder();
              return new Promise(function (v) {
                function u() {
                  r.read()
                    .then(function (x) {
                      var y;
                      y = x.done;
                      var A = t.decode(x.value, { stream: !y });
                      A = d.V + A;
                      for (var C = A.indexOf("\n\n"); C !== -1; ) {
                        var D = Tx,
                          E;
                        a: {
                          var G = n(A.substring(0, C).split("\n")),
                            I = G.next().value,
                            Q = G.next().value;
                          if (Ub(I, "event: message") && Ub(Q, "data: ")) {
                            var V = Q.substring(6);
                            try {
                              E = JSON.parse(V);
                              break a;
                            } catch (S) {}
                          }
                          E = void 0;
                        }
                        D(d, E);
                        A = A.substring(C + 2);
                        C = A.indexOf("\n\n");
                      }
                      d.V = A;
                      y ? (f == null || f(q), v()) : u();
                    })
                    .catch(function () {
                      f == null || f(q);
                      v();
                    });
                }
                u();
              });
            }
            f == null || f(q);
          } else g == null || g(q, void 0);
        })
        .catch(function (q) {
          p();
          g == null || g(void 0, q);
        });
    } else g == null || g(void 0, void 0);
  }
  var Ux = function (a) {
    this.methodName = "FetchRichResponse";
    this.O = a;
  };
  va(Ux, nx);
  Ux.prototype.isSupported = function () {
    return yb(w.fetch);
  };
  Ux.prototype.H = function () {
    return !0;
  };
  Ux.prototype.K = function (a, b, c) {
    Sx(
      a.Rc,
      b,
      c == null ? void 0 : c.body,
      this.O,
      c == null ? void 0 : c.Kc,
      a.ze,
      function (d, e) {
        a.onFailure(e);
      }
    );
  };
  var Vx = {
    Ma: function (a, b, c, d, e) {
      var f = P(a, J.J.ba);
      if (f !== O.R.wa) throw Error("Unexpected hit type: " + f);
      Jw(a, function (g) {
        var h = P(a, J.J.Aa),
          l = Ao(ix);
        g.fmt =
          d instanceof ox
            ? 3
            : d instanceof Mx
            ? b === 5 || b === 8
              ? 3
              : 4
            : d instanceof qx
            ? !h && l
              ? 3
              : 8
            : d instanceof Ux
            ? 7
            : -1;
        ma(Object, "assign").call(
          Object,
          g,
          b === 66 ? { gcp: "4" } : h || b === 8 || b === 65 ? jx : {}
        );
        lx() && (g.exp_1p = "1");
        if (N(548)) {
          var m = Vh[H.D.Jf];
          m && (g[m] = b);
        }
        var p = "?" + Qv(g),
          q,
          r = void 0;
        d instanceof qx
          ? (r = ma(Object, "assign").call(Object, {}, nd))
          : d instanceof Ux &&
            ((r = {}), Qx() && (r.attributionReporting = Px));
        !l && r && ((r.credentials = "omit"), (r.mode = "cors"));
        q = r;
        var t;
        t =
          (d instanceof ox || d instanceof Mx) && Ao("ad_user_data")
            ? Ox
            : void 0;
        e(p, { Kc: q, pf: t });
      });
    },
  };
  var Wx = Object.freeze({
      xd: !0,
      Jc: !1,
      hk: void 0,
      parameterEncoding: 3,
      isSupported: function () {
        return !0;
      },
      qc: function () {
        return Vx;
      },
      pe: function (a, b, c) {
        return Di(a, c);
      },
      lk: function (a, b, c, d, e) {
        if (d instanceof Mx && e.indexOf("&fmt=3") > 0)
          return (e = mx(e, 4)), e + "&rfmt=3";
      },
    }),
    Yx = Object.freeze(
      ma(Object, "assign").call(Object, {}, Wx, {
        endpoint: 5,
        Za: ["ad_storage", "ad_user_data"],
        Xa: function () {
          return Xx(5);
        },
      })
    ),
    Zx = Object.freeze(
      ma(Object, "assign").call(Object, {}, Wx, {
        endpoint: 6,
        Za: [],
        Xa: function () {
          return Xx(6);
        },
      })
    ),
    $x = Object.freeze(
      ma(Object, "assign").call(Object, {}, Wx, {
        endpoint: 63,
        Za: ["ad_storage", "ad_user_data"],
        Xa: function () {
          return Xx(63);
        },
      })
    ),
    ay = Object.freeze(
      ma(Object, "assign").call(Object, {}, Wx, {
        endpoint: 65,
        Za: ["ad_storage", "ad_user_data"],
        Xa: function () {
          return Xx(65);
        },
      })
    ),
    by = Object.freeze(
      ma(Object, "assign").call(Object, {}, Wx, {
        endpoint: 8,
        Za: ["ad_storage", "ad_user_data"],
        Xa: function () {
          return Xx(8);
        },
      })
    ),
    cy = Object.freeze(
      ma(Object, "assign").call(Object, {}, Wx, {
        endpoint: 66,
        Za: [],
        Xa: function () {
          return Xx(66);
        },
      })
    );
  function Xx(a, b) {
    if (a === 66) return "www.google.com/pagead/uconversion";
    var c;
    c =
      (b === void 0 ? 0 : b) &&
      (a === 5 || a === 6 || a === 8 || a === 63 || a === 65)
        ? Pw[a]()
        : hx[a](void 0);
    return Ub(c, "https://") ? c.substring(8) : c;
  }
  function dy(a) {
    return ma(Object, "assign").call(Object, {}, a, {
      Xa: function () {
        return Xx(a.endpoint, !0);
      },
      lk: function (b, c, d, e, f) {
        var g;
        f = ((g = a.lk) == null ? void 0 : g.call(a, b, c, d, e, f)) || f;
        return f + "&gap.1pfb=1";
      },
    });
  }
  function ey(a) {
    var b = a.search;
    return (
      a.protocol +
      "//" +
      a.hostname +
      a.pathname +
      (b ? b + "&richsstsse" : "?richsstsse")
    );
  }
  var fy = function () {
      this.V = "";
    },
    gy = function (a, b) {
      return function () {
        var c = b.fallback_url,
          d = b.fallback_url_method;
        if (c && d) {
          var e = {};
          Tx(a, ((e[d] = [c]), (e.options = {}), e));
        }
      };
    },
    hy = function (a, b, c) {
      if (Array.isArray(a))
        for (var d = n(a), e = d.next(); !e.done; e = d.next()) {
          var f = e.value;
          typeof f === "string" && c(f, b);
        }
    },
    Tx = function (a, b) {
      if (b)
        for (
          var c = Fd(b.options) ? b.options : {},
            d = n(Object.keys(b)),
            e = d.next();
          !e.done;
          e = d.next()
        ) {
          var f = e.value,
            g = b[f];
          switch (f) {
            case "send_pixel":
              hy(g, c, function (h, l) {
                return void a.K(h, l);
              });
              break;
            case "fetch":
              hy(g, c, function (h, l) {
                return void a.H(h, l);
              });
          }
        }
    };
  var iy = function () {
    fy.apply(this, arguments);
  };
  va(iy, fy);
  iy.prototype.K = function (a, b) {
    bd(a, void 0, gy(this, b), b.attribution_reporting && Qx() ? Ox : {});
  };
  iy.prototype.H = function (a, b) {
    var c = b.attribution_reporting && Qx() ? { attributionReporting: Px } : {},
      d = gy(this, b);
    b.process_response
      ? Sx(void 0, a, void 0, this, c, void 0, d)
      : od(a, void 0, c, void 0, d);
  };
  var ky = Object.freeze({
    te: function (a) {
      if (P(a, J.J.ba) !== O.R.wa) return [];
      var b = Ao(ix),
        c = !!P(a, J.J.Aa),
        d = !!P(a, J.J.he),
        e = b ? (d ? (c ? ay : $x) : c ? by : Yx) : Zx,
        f = [
          {
            endpoint: e,
            method: pd()
              ? b
                ? N(490)
                  ? c
                    ? tx
                    : new Ux(new jy())
                  : Nx
                : tx
              : rx,
          },
        ],
        g = b ? (c ? void 0 : by) : cy;
      g && f.push({ endpoint: g, method: tx });
      Tj() && N(496) && f.push({ endpoint: dy(e), method: tx });
      return f;
    },
  });
  var ly = {
    Ma: function (a, b, c, d, e) {
      var f = Rv(a),
        g = "?" + Qv(f);
      e(g, { Kc: nd });
    },
  };
  function my(a) {
    return function () {
      var b = hx[a](void 0),
        c = b;
      Ub(b, "https://") && (c = b.substring(8));
      return c;
    };
  }
  var ny = {
      endpoint: 54,
      Za: ["ad_user_data", "ad_storage"],
      xd: !0,
      Jc: !1,
      hk: void 0,
      parameterEncoding: 3,
      isSupported: function () {
        return N(539);
      },
      Xa: my(54),
      qc: function () {
        return ly;
      },
    },
    oy = {
      endpoint: 55,
      Za: [],
      xd: !0,
      Jc: !1,
      hk: void 0,
      parameterEncoding: 3,
      isSupported: function () {
        return N(539);
      },
      Xa: my(55),
      qc: function () {
        return ly;
      },
    },
    py = {
      te: function () {
        return [
          { endpoint: ny, method: tx },
          { endpoint: oy, method: tx },
        ];
      },
    };
  var qy = {
      Ma: function (a, b, c, d, e) {
        Jw(a, function (f) {
          if (N(548)) {
            var g = Vh[H.D.Jf];
            g && (f[g] = b);
          }
          f.gcp = 1;
          f.ct_cookie_present = 1;
          f.fmt = d instanceof qx ? 8 : 3;
          var h = "?" + Qv(f);
          e(h, { Kc: nd });
        });
      },
    },
    ry = {
      endpoint: 9,
      Za: ["ad_storage", "ad_user_data"],
      xd: !0,
      Jc: !1,
      parameterEncoding: 3,
      isSupported: function (a) {
        return P(a, J.J.ba) === O.R.fc && N(557);
      },
      Xa: function () {
        return "googleads.g.doubleclick.net/pagead/viewthroughconversion";
      },
      qc: function () {
        return qy;
      },
      pe: function (a, b, c) {
        return Di(a, c);
      },
    },
    sy = {
      te: function () {
        return [
          { endpoint: ry, method: tx },
          { endpoint: ry, method: rx },
        ];
      },
    };
  var ty = [68];
  function uy(a, b, c) {
    if (!ty.includes(c)) {
      var d = b.M;
      no({
        targetId: b.target.destinationId,
        request: { url: a, parameterEncoding: 3, endpoint: c },
        kb: { eventId: d.eventId, priorityId: d.priorityId },
        Ci: { eventId: P(b, J.J.Gf), priorityId: P(b, J.J.Hf) },
      });
      P(b, J.J.ba);
    }
  }
  function vy(a) {
    return Ao(ix)
      ? P(a, J.J.he)
        ? P(a, J.J.Aa)
          ? 65
          : 63
        : P(a, J.J.Aa)
        ? 8
        : 5
      : 6;
  }
  var wy = {},
    xy =
      ((wy[O.R.Si] = void 0),
      (wy[O.R.Uc] = function (a, b) {
        if (P(a, J.J.ui)) {
          var c = Ao(ix) ? (P(a, J.J.Aa) ? 23 : 22) : 60,
            d = {};
          P(a, J.J.mi) && (d.item = void 0);
          P(a, J.J.Aa) && ma(Object, "assign").call(Object, d, jx);
          var e = kx(c, b),
            f = bk(e);
          f && (d._uip = f);
          return { baseUrl: e, Nc: d, format: 1, endpoint: c };
        }
      }),
      (wy[O.R.Ui] = void 0),
      (wy[O.R.wa] = function (a, b) {
        var c = Ao(ix),
          d = P(a, J.J.Aa) ? ma(Object, "assign").call(Object, {}, jx) : {},
          e = {};
        lx() && ((d.exp_1p = e.exp_1p = "1"), (e.exp_ph = "1"));
        var f;
        c && !P(a, J.J.Aa)
          ? ((f = 8), ma(Object, "assign").call(Object, e, jx))
          : c || ((f = 66), (e.gcp = "4"));
        var g = vy(a),
          h = kx(g, b),
          l;
        if (c)
          if (N(490)) {
            var m = !P(a, J.J.Aa);
            l = pd() ? (m ? 4 : 3) : 1;
          } else l = 2;
        else l = pd() ? 3 : 1;
        var p = { baseUrl: h, Nc: d, format: l, endpoint: g };
        Ao(H.D.fa) && (p.attributes = Ox);
        var q = p;
        f !== void 0 &&
          ((q.qe = ma(Object, "assign").call(Object, {}, p, {
            baseUrl: kx(f, b),
            Nc: e,
            format: 3,
            endpoint: f,
          })),
          (q = q.qe));
        var r;
        a: if (Tj() && N(496))
          switch (g) {
            case 5:
            case 63:
            case 8:
            case 65:
              r = !0;
              break a;
            default:
              r = !1;
          }
        else r = !1;
        if (r) {
          var t = {};
          q.qe = ma(Object, "assign").call(Object, {}, q, {
            baseUrl: Pw[g]() + "/" + b + "/",
            Nc: ma(Object, "assign").call(
              Object,
              {},
              d,
              ((t["gap.1pfb"] = "1"), t)
            ),
            format: 3,
            endpoint: g,
          });
        }
        return p;
      }),
      (wy[O.R.Qm] = void 0),
      (wy[O.R.de] = function () {
        var a = Ao(ix) ? 54 : 55;
        return { baseUrl: hx[a](void 0), Nc: {}, format: 3, endpoint: a };
      }),
      (wy[O.R.fc] = function (a, b) {
        if (P(a, J.J.Aa) && Ao(ix)) {
          var c = pd() ? 3 : 1,
            d = {
              baseUrl: kx(9, b),
              format: c != null ? c : 2,
              endpoint: 9,
              Nc: { gcp: "1", ct_cookie_present: "1" },
            };
          c === 3 &&
            (d.qe = ma(Object, "assign").call(Object, {}, d, { format: 1 }));
          return d;
        }
      }),
      (wy[O.R.Hj] = void 0),
      (wy[O.R.Ia] = void 0),
      (wy[O.R.ef] = function (a, b, c) {
        if (lx()) {
          var d = vy(a),
            e = { random: c + 1, adtest: "on", exp_1p: "1" };
          P(a, J.J.Aa) && ma(Object, "assign").call(Object, e, jx);
          return {
            baseUrl: Pw[d]() + "/" + b + "/",
            Nc: e,
            format: 2,
            endpoint: d,
          };
        }
      }),
      (wy[O.R.sb] = void 0),
      (wy[O.R.Bb] = void 0),
      (wy[O.R.Cb] = function (a, b) {
        var c = kx(21, b).slice(0, -1),
          d = bk(c),
          e = {};
        d && (e._uip = d);
        return { baseUrl: c, Nc: e, format: 3, endpoint: 21 };
      }),
      wy);
  function yy(a) {
    var b = P(a, J.J.ba),
      c = Ei(a, H.D.Lh),
      d = P(a, J.J.Ab),
      e,
      f = (e = xy[b]) == null ? void 0 : e.call(xy, a, c, d);
    return (Array.isArray(f) ? f : [f]).filter(function (g) {
      return g !== void 0;
    });
  }
  var zy = function (a, b) {
      this.xt = a;
      this.timeoutMs = b;
      this.ab = void 0;
    },
    Ay = function (a) {
      a.ab ||
        (a.ab = setTimeout(function () {
          a.xt();
          a.ab = void 0;
        }, a.timeoutMs));
    },
    Yk = function (a) {
      a.ab && (clearTimeout(a.ab), (a.ab = void 0));
    };
  var By = function () {
      var a = Mf(66, 0);
      this.Ko = [];
      this.kt = a;
      this.Bd = Ya();
    },
    Dy = function (a) {
      var b = Cy;
      b.Ko.push(a);
      b.No ||
        ((b.No = function () {
          for (var c = n(b.Ko), d = c.next(); !d.done; d = c.next()) {
            var e = d.value;
            try {
              e();
            } catch (l) {}
          }
          for (var f = n(b.Bd.values()), g = f.next(); !g.done; g = f.next()) {
            var h = void 0;
            (h = g.value.uc) == null || Yk(h);
          }
          b.Bd.clear();
        }),
        cd(w, "pagehide", b.No));
    },
    Ey = function (a) {
      var b = a.match(Rk)[3] || null,
        c = (b ? decodeURI(b) : b) || "",
        d = Uk(a, "label") || "",
        e = Uk(a, "random") || "";
      return c + ":" + Qk(d) + ":" + Qk(e);
    };
  By.prototype.Rg = function (a, b, c) {
    var d = Ey(a);
    if (!(this.Bd.has(d) || this.Bd.size >= this.kt)) {
      var e = {};
      b && b > 0 && c && (e.uc = new zy(c, b));
      this.Bd.set(d, e);
      var f;
      (f = e.uc) == null || Ay(f);
    }
  };
  var Zk = function (a, b) {
    var c = Ey(b),
      d,
      e;
    (d = a.Bd.get(c)) == null || (e = d.uc) == null || Yk(e);
    a.Bd.delete(c);
  };
  By.prototype.getSize = function () {
    return this.Bd.size;
  };
  var Iy = function (a) {
      this.H = 1;
      this.H > 0 || (this.H = 1);
      this.onSuccess = a.M.onSuccess;
    },
    Jy = function (a, b) {
      return ac(
        function () {
          a.H--;
          if (yb(a.onSuccess) && a.H === 0) a.onSuccess();
        },
        b > 0 ? b : 1
      );
    };
  function Ky(a, b, c, d, e, f) {
    var g = Rv(a);
    f && ma(Object, "assign").call(Object, g, f);
    if (N(548)) {
      var h = Vh[H.D.Jf];
      h && (g[h] = "" + b);
    }
    b !== 68 && (delete g.gclaw, delete g.gclaw_src);
    var l = void 0;
    P(a, J.J.Aa)
      ? ((g.gcp = 1), (g.ct_cookie_present = 1))
      : b === 68 && ((g.gcp = 5), d instanceof qx && ((g.fmt = 8), (l = nd)));
    var m = "?" + Qv(g);
    e(m, l ? { Kc: l } : {});
  }
  var Ly = { Ma: Ky },
    My = {
      endpoint: 9,
      Za: ["ad_storage", "ad_user_data"],
      xd: !0,
      Jc: !0,
      parameterEncoding: 3,
      isSupported: function () {
        return !0;
      },
      Xa: function () {
        return "googleads.g.doubleclick.net/pagead/viewthroughconversion";
      },
      qc: function () {
        return Ly;
      },
      pe: function (a, b, c) {
        return Di(a, c);
      },
    },
    Ny = {
      endpoint: 68,
      Za: ["ad_storage", "ad_user_data"],
      xd: !0,
      Jc: !1,
      parameterEncoding: 3,
      isSupported: function (a) {
        return N(458) && !P(a, J.J.Aa);
      },
      Xa: function () {
        return "www.google.com/rmkt/collect";
      },
      qc: function () {
        return Ly;
      },
      pe: function (a, b, c) {
        return Di(a, c);
      },
    };
  function Oy(a, b, c) {
    return ma(Object, "assign").call(Object, {}, a, {
      qc: function () {
        return {
          Ma: function (d, e, f, g, h) {
            Ky(d, e, f, g, h, { data: b, random: c });
          },
        };
      },
    });
  }
  function Py(a, b, c, d, e) {
    e = e === void 0 ? 0 : e;
    if (d) {
      var f = P(a, J.J.Ab);
      b = Oy(b, d, f + e);
    }
    return [
      { endpoint: b, method: c },
      { endpoint: b, method: rx },
    ];
  }
  var Qy = {
    te: function (a) {
      var b = Mv(a);
      return Py(a, My, P(a, J.J.Aa) ? tx : Nx, b == null ? void 0 : b[0]);
    },
    zs: function (a) {
      var b = Mv(a),
        c = [];
      Ny.isSupported(a) && c.push(Py(a, Ny, tx, b == null ? void 0 : b[0]));
      if (b && b.length > 1)
        for (var d = P(a, J.J.Aa) ? tx : Nx, e = 1; e < b.length; ++e)
          c.push(Py(a, My, d, b[e], e));
      return c.length > 0 ? c : void 0;
    },
  };
  function Ry(a, b) {
    a ? a.then(b) : b(void 0);
  }
  function Sy(a) {
    return Promise.allSettled(a).then(function (b) {
      return b
        .filter(function (c) {
          return c.status === "fulfilled";
        })
        .map(function (c) {
          return c.value;
        });
    });
  }
  function Ty() {
    var a, b;
    return {
      promise: new Promise(function (c, d) {
        a = c;
        b = d;
      }),
      resolve: a,
      reject: b,
    };
  }
  var bg;
  function Wy(a, b) {
    var c;
    (c = bg) == null || Yf(c.H, a, b);
  }
  var Xy = Ba(["/"]),
    Yy = function (a) {
      this.H = a;
      this.failureType = void 0;
    };
  Yy.prototype.Bo = function (a, b, c) {
    try {
      var d = this.H.active;
      d
        ? (d.postMessage({ type: 1, command: a }), b({ data: "" }))
        : c({ failureType: 13, data: "" });
    } catch (e) {
      c({ failureType: 11, data: e.message });
    }
  };
  var Zy = function (a, b) {
    this.failureType = a;
    this.H = b;
  };
  Zy.prototype.Bo = function (a, b, c) {
    c({
      failureType: this.failureType,
      data: "f" + this.failureType + ("t" + (new Date().getTime() - this.H)),
    });
  };
  var bz = function (a) {
      var b = this;
      this.initTime = new Date().getTime();
      this.H = new Zy(15, this.initTime);
      var c = new Promise(function (e) {
          w.setTimeout(function () {
            e();
          }, 20);
        }),
        d = $y(a)
          .then(function (e) {
            b.H = new Yy(e);
            az(b, e);
          })
          .catch(function () {
            b.H = new Zy(4, b.initTime);
          });
      this.K = Promise.race([c, d]);
    },
    az = function (a, b) {
      var c = function (d) {
        d &&
          d.addEventListener("statechange", function () {
            if (d.state === "redundant") {
              var e = b.active;
              (e && e.state !== "redundant") || (a.H = new Zy(10, a.initTime));
            }
          });
      };
      c(b.active);
      c(b.waiting);
      c(b.installing);
      b.addEventListener("updatefound", function () {
        c(b.installing);
      });
    };
  bz.prototype.delegate = function (a, b, c) {
    var d = this;
    this.K.then(function () {
      d.H.Bo(a, b, c);
    });
  };
  bz.prototype.getState = function () {
    return 2;
  };
  var $y = function (a) {
    var b,
      c = Kf(11);
    c = Kf(10);
    b = c;
    var d = {
      scope:
        (Vb(a.href, "/") ? a.href.slice(0, -1) : a.href) + "/_/service_worker",
    };
    b && (d.updateViaCache = "all");
    var e = cz(a, b),
      f = Nc(),
      g,
      h = new Map([["path", a.pathname]]),
      l = Cq(nc(e).toString());
    g = Eq(l.Yk, l.params, l.fragment, h);
    return f.register(nc(g), d);
  };
  function cz(a, b) {
    for (
      var c = Dq(Xy),
        d = a.pathname.split("/").filter(function (h) {
          return h.length > 0;
        }),
        e = [].concat(za(d), ["_", "service_worker", b, "sw.js"]),
        f = n(e),
        g = f.next();
      !g.done;
      g = f.next()
    )
      c = Fq(c, g.value);
    return c;
  }
  function dz(a) {
    var b = $i(Wi.ia.yi),
      c = b == null ? void 0 : b[a];
    c || a !== "lite" || (c = b == null ? void 0 : b.full);
    return c;
  }
  var ez = function (a, b, c) {
    var d = dz("full");
    d ? d.delegate(a, b, c) : c({ failureType: 16 });
  };
  function fz(a, b, c, d, e) {
    ez(
      {
        commandType: 0,
        params: {
          url: a,
          method: 1,
          templates: b,
          body: "",
          processResponse: !1,
          reportEarlySuccess: !0,
          encryptionKeyString: e,
          soReferrer: w.location.href,
        },
      },
      c,
      function (f) {
        d(f.failureType, f.data);
      }
    );
  }
  var hz = {
      Ma: function (a, b, c, d, e) {
        var f = P(a, J.J.Oj),
          g = function (h) {
            var l = Qv(h);
            f && d instanceof gz && (l += f.mp.join(""));
            e(l, { Kc: nd });
          };
        Jw(a, function (h) {
          if (b === 21) {
            var l = bk(c);
            l && (h._uip = l);
          }
          if (
            f &&
            ((h = ma(Object, "assign").call(Object, {}, h, Uy(a, f))),
            !(d instanceof gz))
          ) {
            var m;
            f.yd = (m = f.yd) != null ? m : 17;
            f.zo(function (p) {
              g(ma(Object, "assign").call(Object, {}, h, p));
            });
            return;
          }
          g(h);
        });
      },
    },
    iz = {
      endpoint: 11,
      Za: ["ad_user_data", "ad_storage"],
      xd: !0,
      Jc: !1,
      parameterEncoding: 3,
      isSupported: function () {
        return !0;
      },
      Xa: function () {
        return Tj()
          ? Uj() + "/d/pagead/form-data"
          : N(141)
          ? "www.google.com/pagead/form-data"
          : "google.com/pagead/form-data";
      },
      qc: function () {
        return hz;
      },
      pe: function (a, b, c) {
        return Di(a, c).slice(0, -1);
      },
    },
    jz = {
      te: function (a) {
        var b = [],
          c = P(a, J.J.Oj);
        c !== void 0 && b.push({ endpoint: iz, method: new gz(c) });
        tx.isSupported()
          ? b.push({ endpoint: iz, method: tx })
          : b.push({ endpoint: iz, method: sx }, { endpoint: iz, method: rx });
        return b;
      },
    },
    kz = {
      endpoint: 21,
      Za: ["ad_user_data", "ad_storage"],
      xd: !0,
      Jc: !1,
      parameterEncoding: 3,
      isSupported: function () {
        return N(541);
      },
      Xa: function () {
        return Tj()
          ? Uj() + "/d/ccm/form-data"
          : N(141)
          ? "www.google.com/ccm/form-data"
          : "google.com/ccm/form-data";
      },
      qc: function () {
        return hz;
      },
      pe: function (a, b, c) {
        return Di(a, c).slice(0, -1);
      },
    },
    lz = {
      te: function () {
        return tx.isSupported()
          ? [{ endpoint: kz, method: tx }]
          : [
              { endpoint: kz, method: sx },
              { endpoint: kz, method: rx },
            ];
      },
    };
  var mz = function () {
      var a = this;
      this.H = 0;
      this.K = !1;
      N(462) &&
        Bj(
          "fs",
          function () {
            return a.H > 0 && a.H < 5 ? String(a.H) : void 0;
          },
          !1
        );
    },
    nz;
  function oz(a, b) {
    nz || (nz = new mz());
    var c = nz;
    N(462) &&
      mk.H &&
      (b === "gtm.formSubmit" || (b === "form_submit" && Hf(45))) &&
      (a === 1 || c.K) &&
      ((c.K = !0), (c.H = a), a !== 5 ? Cj("fs") : (xj.H.fs = !1));
  }
  function pz(a, b, c, d) {
    if (go()) {
      var e = b.M;
      no({
        targetId: d || [b.target.destinationId],
        request: { url: a, parameterEncoding: 2, endpoint: c },
        kb: { eventId: e.eventId, priorityId: e.priorityId },
        Ci: { eventId: P(b, J.J.Gf), priorityId: P(b, J.J.Hf) },
      });
    }
  }
  var Iz = {};
  Iz.W = Yr.W;
  var Jz = {
      kv: "L",
      xr: "S",
      Av: "Y",
      ju: "B",
      Du: "E",
      fv: "I",
      wv: "TC",
      Ku: "HTC",
      Eu: "F",
      dv: "C",
    },
    Kz = { xr: "S", Cu: "V", su: "E", vv: "tag" },
    Lz = {},
    Mz = ((Lz[Iz.W.Sj] = "6"), (Lz[Iz.W.Tj] = "5"), (Lz[Iz.W.Rj] = "7"), Lz);
  function Nz() {
    function a(c, d) {
      var e = wb(rb[d] || []);
      e && b.push([c, e]);
    }
    var b = [];
    a("u", "GTM");
    a("ut", "TAGGING");
    a("h", "HEALTH");
    return b;
  }
  var Oz = !1,
    Pz = "https://" + F(21),
    Qz = {};
  function Rz(a, b) {
    if (!Oz && Sz()) {
      var c;
      try {
        var d;
        c = (d = ud()) == null ? void 0 : d.mark(a, b);
        if (!c) return;
        Qz[a] = c;
      } catch (e) {
        Oz = !0;
        return;
      }
      return c;
    }
  }
  var Tz = {};
  function Uz(a, b) {
    if (!Oz && Sz()) {
      var c;
      try {
        var d;
        c = (d = ud()) == null ? void 0 : d.measure(a, b);
        if (!c) return;
        Tz[a] = c;
      } catch (e) {
        Oz = !0;
        return;
      }
      return c;
    }
  }
  function Vz(a) {
    var b = F(5),
      c = Number(a.eventId),
      d = Number(a.tagId);
    return (
      (Ub(b, "GTM-") ? b : "GTM-" + b) +
      ":" +
      (Ab(c) ? c + ":" : "") +
      (Ab(d) ? d + ":" : "") +
      a.stage
    );
  }
  function Wz(a) {
    return Vz({ stage: a });
  }
  function Sz() {
    var a = ud();
    return !!(
      a &&
      a.mark instanceof Function &&
      a.measure instanceof Function &&
      a.clearMeasures instanceof Function &&
      a.clearMarks instanceof Function
    );
  }
  var Xz = [],
    Yz = [],
    Zz = { TC: 0, HTC: 0 },
    $z = {};
  function aA(a, b, c) {
    $z[a] || ($z[a] = {});
    $z[a][b] = c;
  }
  function bA() {
    var a = "",
      b = "",
      c = cA();
    Ab(c) && (Zz.I = Math.floor(c));
    b = dA(Zz, Jz).toString();
    for (var d = n(Object.keys($z)), e = d.next(); !e.done; e = d.next()) {
      var f = e.value,
        g = $z[f].name,
        h = "",
        l = dA($z[f], Kz);
      l && ((h = g + "." + l.toString()), (a += "~" + h));
    }
    var m = "~AWCT" + Xz.join("."),
      p = "~GA" + Yz.join("."),
      q =
        "&ccid=" +
        tl().toString() +
        "&cid=" +
        F(5).toString() +
        "&l=" +
        b +
        a +
        (Xz.length ? m : "") +
        (Yz.length ? p : "");
    if (N(214)) {
      var r,
        t =
          (r = ud()) == null
            ? void 0
            : r
                .getEntriesByName(Pc)
                .map(function (v) {
                  return String(v.duration);
                })
                .join(".");
      t && (q += "~SS" + t);
    }
    return q;
  }
  function cA() {
    try {
      var a;
      return ((a = ud()) == null ? void 0 : a.getEntriesByType("navigation")[0])
        .domInteractive;
    } catch (b) {}
  }
  function dA(a, b) {
    return Object.keys(b)
      .map(function (c) {
        return b[c];
      })
      .filter(function (c) {
        return a[c] !== void 0;
      })
      .map(function (c) {
        return ("" + (c === "tag" ? "" : c)).concat(a[c].toString());
      })
      .join(".");
  }
  function eA(a) {
    a.entry = Vz(a);
    if (!a.stage || Oz || !Sz() || Qz[a.entry]) return !1;
    var b,
      c = (b = ud()) == null ? void 0 : b.timeOrigin;
    if (Ab(c)) {
      var d = Wz(Iz.W.kf);
      if (Ab(tj(24)) && !Qz[d])
        try {
          var e = Number(tj(24));
          Rz(d, { startTime: Math.max(e - c, 0) });
          var f = Wz(Iz.W.Jg);
          Rz(f, { startTime: 0 });
          var g,
            h =
              (g = Uz(Wz(Iz.W.Jg + ":" + Iz.W.kf), { start: f, end: d })) ==
              null
                ? void 0
                : g.duration;
          h && (Zz.L = Math.floor(h));
          var l = ds.length,
            m = [];
          if (l <= 2) m = ds;
          else {
            var p = Db(0, l - 1);
            m.push(ds[p]);
            var q = 0,
              r;
            do (r = Db(0, l - 1)), q++;
            while (p === r && q < 30);
            m.push(ds[r]);
          }
          Zr = m;
        } catch (t) {
          Oz = !0;
        }
    } else Oz = !0;
    return Oz || !Rz(a.entry) ? !1 : !0;
  }
  function fA(a, b) {
    if (eA(a)) {
      var c;
      a: {
        if (!Oz && Sz()) {
          a.entry = Vz(a);
          var d = Gd(a, null);
          d.stage = b;
          delete d.sent;
          var e = b === Iz.W.kf ? Wz(b) : Vz(d),
            f = Qz[e],
            g = Qz[a.entry];
          if (f && g && !(f.startTime > g.startTime)) {
            d.stage = b + ":" + a.stage;
            var h = Vz(d),
              l;
            c =
              (l = Uz(h, { start: f.name, end: g.name })) == null
                ? void 0
                : l.duration;
            break a;
          }
        }
        c = void 0;
      }
      var m = c;
      if (m) return Math.floor(m);
    }
  }
  function gA(a) {
    var b = fA({ stage: Iz.W.Xm, eventId: a }, Iz.W.kf);
    b !== void 0 && Yz.push(b);
  }
  function hA(a) {
    var b = fA({ stage: Iz.W.fl, eventId: a }, Iz.W.kf);
    b !== void 0 && Xz.push(b);
  }
  function iA() {
    var a = fA({ stage: Iz.W.vl }, Iz.W.Vi);
    a !== void 0 && (Zz.S = a);
  }
  function jA(a) {
    var b = fA({ stage: Iz.W.Nm, eventId: a }, Iz.W.hi);
    b !== void 0 && aA(a, "S", b);
  }
  function kA(a) {
    var b = fA({ stage: Iz.W.Lm, eventId: a }, Iz.W.wj);
    b !== void 0 && aA(a, "V", b);
  }
  function lA() {
    try {
      var a, b;
      return (b =
        (a = ud()) == null
          ? void 0
          : a.getEntriesByType("paint").find(function (c) {
              return c.name === "first-contentful-paint";
            })) == null
        ? void 0
        : b.startTime;
    } catch (c) {}
  }
  function mA() {
    if (!Oz && Sz() && F(5)) {
      var a = lA();
      a !== void 0 && (Zz.F = Math.floor(a));
      try {
        for (
          var b, c = Nz({ eventId: 0, Ff: !1 }), d = [], e = n(c), f = e.next();
          !f.done;
          f = e.next()
        ) {
          var g = n(f.value),
            h = g.next().value,
            l = g.next().value;
          d.push("&" + h + "=" + l);
        }
        var m = oj();
        b = [
          ak(Pz),
          "/a?v=3&t=l",
          "&pid=" + Db().toString(),
          "&rv=" + F(14),
          m ? "&tag_exp=" + m : "",
          d.join(""),
        ].join("");
        for (
          var p = Np(),
            q = $r,
            r = as,
            t = [],
            v = n(Object.keys(q)),
            u = v.next();
          !u.done;
          u = v.next()
        ) {
          var x = u.value,
            y = Math.floor(q[x]),
            A = r[x];
          y !== void 0 && A !== void 0 && t.push("" + x + "." + A + "." + y);
        }
        var C = t.join("~"),
          D = [b, "&gtm=", p, C ? "&cl=" + C : "", bA()].join("");
        if (D.length > 2022) {
          var E = Math.max(
            D.lastIndexOf(".TS", 2022),
            D.lastIndexOf("~", 2022)
          );
          D = D.slice(0, E);
        }
        bl({ destinationId: F(5), endpoint: 56 }, D);
      } catch (G) {}
    }
  }
  function nA(a, b, c) {
    var d = kk(b),
      e = Number(b[Ff.Vj]),
      f = fA({ stage: c, eventId: a.id, tagId: e }, Iz.W.Uj);
    if (f !== void 0 && $z[a.id]) {
      var g = $z[a.id].tag || "",
        h,
        l = (h = Mz[c]) != null ? h : "1",
        m = new RegExp("TS\\d" + d + ".TI" + e),
        p = "TS" + l + d + ".TI" + e + ".TE" + f;
      g.search(m) >= 0
        ? l !== "1" && aA(a.id, "tag", g.replace(m, p.replace(".TE" + f, "")))
        : (aA(a.id, "tag", (g ? g + "." : "") + p),
          d === "html" && (Zz.HTC += 1),
          (Zz.TC += 1));
    }
  }
  function oA() {
    var a = Wz("PAGEVIEW");
    if (Qz[a]) {
      delete Qz[a];
      var b;
      (b = ud()) == null || b.clearMarks(a);
      var c = Wz(Iz.W.Jg + ":PAGEVIEW");
      delete Tz[c];
      var d;
      (d = ud()) == null || d.clearMeasures(c);
    }
    fA({ stage: "PAGEVIEW" }, Iz.W.Jg);
  }
  function pA(a, b, c, d, e) {
    var f;
    d == null || (f = d.Lv) == null || f.call(d, a, b, c, e);
    var g = Ty(),
      h = g.promise,
      l = g.resolve,
      m = [],
      p = function () {
        l(m);
        var t;
        d == null || (t = d.rt) == null || t.call(d, a, b, c, e, m);
      },
      q = c.slice(),
      r = function () {
        var t = q.shift();
        t
          ? t.method.isSupported()
            ? qA(a, b, t.endpoint, d, m, t.method, e, r, p)
            : r()
          : p();
      };
    r();
    return h;
  }
  function qA(a, b, c, d, e, f, g, h, l) {
    var m = c.Xa(a),
      p = !1,
      q = function (r, t) {
        if (p) T(187);
        else {
          p = !0;
          var v = t || {},
            u = v.body,
            x = v.Kc,
            y = v.pf;
          t = Object.freeze(
            ma(Object, "assign").call(
              Object,
              {},
              u ? { body: u } : {},
              x ? { Kc: x } : {},
              y ? { pf: y } : {}
            )
          );
          if (u && !f.H()) h();
          else {
            var A = rA(r),
              C,
              D =
                (C = c.lk) == null ? void 0 : C.call(c, a, c.endpoint, m, f, r);
            D != null && (A = rA(D));
            var E,
              G =
                ((E = c.pe) == null
                  ? void 0
                  : E.call(c, a, c.endpoint, m, f, A)) || m,
              I = G[0] === "/" ? "" + G + A : "https://" + G + A,
              Q = {
                Sk: b,
                endpoint: c,
                isPrimary: g,
                Lt: I,
                Pv: f,
                Qv: t,
                status: void 0,
              };
            e.push(Q);
            var V;
            d == null || (V = d.vt) == null || V.call(d, a, b, c, g, I, f, t);
            var S = function (fa, ka) {
                if (Q.status !== void 0) return T(192), !1;
                Q.status = fa;
                var Z;
                d == null ||
                  (Z = d.st) == null ||
                  Z.call(d, a, b, c, g, I, f, t, Q.status, ka);
                return !0;
              },
              ja = {
                Rc: {
                  destinationId: a.target.destinationId,
                  endpoint: c.endpoint,
                  eventId: a.M.eventId,
                  priorityId: a.M.priorityId,
                },
                Pc: function () {
                  S(3) && h();
                },
                onFailure: function () {
                  S(4) && h();
                },
                ze: function (fa) {
                  S(fa.status === 0 ? 1 : fa.ok ? 0 : 4, fa) && l();
                },
                xf: function () {
                  S(1) && l();
                },
              };
            sA(c, a, I, u);
            f.sendRequest(
              ja,
              I,
              ma(Object, "assign").call(
                Object,
                {},
                u && { body: u },
                x && { Kc: x },
                y && { pf: y }
              )
            );
          }
        }
      };
    try {
      c.qc(a).Ma(a, c.endpoint, m, f, q);
    } catch (r) {
      T(188), h();
    }
  }
  function sA(a, b, c, d) {
    a.Jc &&
      no({
        targetId: b.target.destinationId,
        request: ma(Object, "assign").call(
          Object,
          {},
          {
            url: c,
            parameterEncoding: a.parameterEncoding,
            endpoint: a.endpoint,
          },
          d ? { postBody: d } : {}
        ),
        kb: { eventId: b.M.eventId, priorityId: b.M.priorityId },
        Ci: { eventId: P(b, J.J.Gf), priorityId: P(b, J.J.Hf) },
      });
  }
  function rA(a) {
    return a && a !== "?" ? (a[0] !== "?" ? "?".concat(a) : a) : "";
  }
  function tA(a, b) {
    var c = function (l) {
        return (
          l.method.isSupported() &&
          l.endpoint.isSupported(a) &&
          Ao(l.endpoint.Za)
        );
      },
      d,
      e = ((d = b.te(a)) == null ? void 0 : d.filter(c)) || [];
    if (!e.length) return { Sk: b, Ro: e, Oo: [] };
    var f,
      g,
      h =
        ((f = b.zs) == null
          ? void 0
          : (g = f.call(b, a)) == null
          ? void 0
          : g
              .map(function (l) {
                return l.filter(c);
              })
              .filter(function (l) {
                return l.length > 0;
              })) || [];
    return { Sk: b, Ro: e, Oo: h };
  }
  function uA(a, b) {
    for (
      var c = Pa.apply(2, arguments), d = [], e = n(c), f = e.next();
      !f.done;
      f = e.next()
    )
      d.push(tA(a, f.value));
    var g;
    b == null || (g = b.Nv) == null || g.call(b, a, d);
    for (
      var h = [], l = n(d), m = l.next(), p = {};
      !m.done;
      p = { Bf: void 0 }, m = l.next()
    ) {
      var q = m.value;
      p.Bf = q.Sk;
      var r = q.Ro,
        t = q.Oo,
        v = void 0,
        u = void 0,
        x = void 0;
      (v = b) == null || (x = (u = v).Mv) == null || x.call(u, a, p.Bf);
      if (r.length) {
        var y = [];
        y.push(pA(a, p.Bf, r, b, !0));
        for (var A = n(t), C = A.next(); !C.done; C = A.next())
          y.push(pA(a, p.Bf, C.value, b, !1));
        h.push.apply(h, za(y));
        Sy(y).then(
          (function (I) {
            return function (Q) {
              for (var V = [], S = n(Q), ja = S.next(); !ja.done; ja = S.next())
                V.push.apply(V, za(ja.value));
              var fa;
              b == null || (fa = b.wt) == null || fa.call(b, a, I.Bf, V);
            };
          })(p)
        );
      } else {
        var D = void 0,
          E = void 0,
          G = void 0;
        (D = b) == null || (G = (E = D).wt) == null || G.call(E, a, p.Bf, []);
      }
    }
    Sy(h).then(function (I) {
      for (var Q = [], V = n(I), S = V.next(); !S.done; S = V.next())
        Q.push.apply(Q, za(S.value));
      var ja;
      b == null || (ja = b.ot) == null || ja.call(b, a, c, Q);
    });
  }
  function DA() {
    return Cn("dedupe_gclid", function () {
      return ys();
    });
  }
  var IA = { Jj: { yp: "1", Oq: "2", vr: "3" } };
  var NA, OA;
  function PA(a, b) {
    var c = a[Ff.bc],
      d = b && b.event;
    if (!c) throw Error("Error: No function name given for function call.");
    var e = OA[c],
      f = {},
      g;
    for (g in a)
      a.hasOwnProperty(g) &&
        (Ub(g, "vtp_")
          ? (f[e !== void 0 ? g : g.substring(4)] = a[g])
          : Wf(17) &&
            g === Ff.Xq.toString() &&
            (f[e !== void 0 ? "vtp_gtmGeneratedTaggingMetadata" : g] = a[g]));
    Hf(61) && e && (f.vtp_extraExperimentIds = !0);
    e &&
      d &&
      d.cachedModelValues &&
      (f.vtp_gtmCachedValues = d.cachedModelValues);
    b &&
      e &&
      ((f.vtp_gtmEntityIndex = b.index), (f.vtp_gtmEntityName = b.name));
    return e !== void 0 ? e(f) : NA(c, f, b);
  }
  var QA = function (a, b, c, d) {
    this.H = a;
    this.index = b;
    this.tags = c;
    this.macros = d;
    this.name = String(this.H[Ff.nn] || "");
  };
  QA.prototype.evaluate = function (a, b) {
    if (!b[this.index] && !a.isBlocked(this.H)) {
      b[this.index] = !0;
      var c = this.name,
        d;
      try {
        var e = {},
          f;
        for (f in this.H)
          this.H.hasOwnProperty(f) &&
            (e[f] = Wn(this.H[f], a, this.tags, this.macros, b));
        e.vtp_gtmEventId = a.id;
        a.priorityId && (e.vtp_gtmPriorityId = a.priorityId);
        var g = (d = PA(e, { event: a, index: this.index, type: 2, name: c }));
        e[Ff.xl] &&
          typeof g === "string" &&
          (g = e[Ff.xl] === 1 ? g.toLowerCase() : g.toUpperCase());
        Wf(15) &&
          e.hasOwnProperty(Ff.Al) &&
          (g = e[Ff.Al] === 1 ? Tf(g, "PERIOD") : Tf(g, "COMMA"));
        e.hasOwnProperty(Ff.zl) && g === null && (g = e[Ff.zl]);
        e.hasOwnProperty(Ff.Cl) && g === void 0 && (g = e[Ff.Cl]);
        Wf(15) && e.hasOwnProperty(Ff.Ap) && (g = Jb(g));
        e.hasOwnProperty(Ff.Bl) && g === !0 && (g = e[Ff.Bl]);
        e.hasOwnProperty(Ff.yl) && g === !1 && (g = e[Ff.yl]);
        d = g;
      } catch (h) {
        a.logMacroError && a.logMacroError(h, Number(this.index), c), (d = !1);
      }
      b[this.index] = !1;
      return d;
    }
  };
  QA.prototype.fh = function () {
    return ma(Object, "assign").call(Object, {}, this.H);
  };
  var RA = function (a, b, c) {
    this.H = a;
    this.tags = b;
    this.macros = c;
  };
  RA.prototype.evaluate = function (a, b) {
    try {
      for (
        var c = {}, d = n(Object.keys(this.H)), e = d.next();
        !e.done;
        e = d.next()
      ) {
        var f = e.value;
        c[f] =
          f === "function"
            ? this.H[f]
            : Wn(this.H[f], a, this.tags, this.macros, b);
      }
      return Un(c);
    } catch (g) {
      JSON.stringify(this.H);
    }
    return 2;
  };
  RA.prototype.fh = function () {
    return ma(Object, "assign").call(Object, {}, this.H);
  };
  var SA = function (a, b) {
    this.index = b;
    this.O = [];
    this.V = [];
    this.K = [];
    this.H = [];
    this.name = "";
    for (var c = n(a), d = c.next(); !d.done; d = c.next()) {
      var e = n(d.value),
        f = e.next().value,
        g = xa(e),
        h = f,
        l = g;
      h === "if"
        ? (this.O = l)
        : h === "unless"
        ? (this.V = l)
        : h === "add"
        ? (this.K = l)
        : h === "block"
        ? (this.H = l)
        : h === "ruleName" && (this.name = l[0]);
    }
  };
  SA.prototype.evaluate = function (a, b) {
    var c = TA(this, b),
      d = [],
      e = [];
    c
      ? (d.push.apply(d, za(this.K)), e.push.apply(e, za(this.H)))
      : c === null && e.push.apply(e, za(this.H));
    return { firingTags: d, blockingTags: e };
  };
  var TA = function (a, b) {
    for (var c = n(a.O), d = c.next(); !d.done; d = c.next()) {
      var e = b(d.value);
      if (e === 0) return !1;
      if (e === 2) return null;
    }
    for (var f = n(a.V), g = f.next(); !g.done; g = f.next()) {
      var h = b(g.value);
      if (h === 2) return null;
      if (h === 1) return !1;
    }
    return !0;
  };
  SA.prototype.getName = function () {
    return this.name;
  };
  var UA = function (a, b, c, d) {
    this.Ja = a;
    this.index = b;
    this.tags = c;
    this.macros = d;
    this.N = String(this.Ja[Ff.bc]);
    this.name = String(this.Ja[Ff.nn] || "");
    this.tagId = Number(this.Ja[Ff.Vj]);
  };
  UA.prototype.evaluate = function (a, b, c) {
    c = c === void 0 ? {} : c;
    var d,
      e = c;
    e = e === void 0 ? {} : e;
    var f = {},
      g;
    for (g in this.Ja)
      this.Ja.hasOwnProperty(g) &&
        (f[g] = Wn(this.Ja[g], a, this.tags, this.macros, []));
    d = ma(Object, "assign").call(Object, {}, f, e);
    d.vtp_gtmTagId = this.tagId;
    PA(d, { event: a, index: this.index, type: 1, name: this.name });
  };
  UA.prototype.fh = function () {
    return ma(Object, "assign").call(Object, {}, this.Ja);
  };
  var VA = function (a, b) {
      if (a.Ja[Ff.Mn]) return Wn(a.Ja[Ff.Mn], b, a.tags, a.macros, []);
    },
    WA = function (a, b) {
      if (a.Ja[Ff.Xn]) return Wn(a.Ja[Ff.Xn], b, a.tags, a.macros, []);
    },
    XA = function (a, b) {
      var c = a.Ja[Ff.zp];
      if (c) return Wn(c, b, a.tags, a.macros, []);
    };
  UA.prototype.getMetadata = function (a) {
    return Wn(this.Ja[Ff.METADATA], a, this.tags, this.macros, []);
  };
  UA.prototype.getName = function () {
    return this.name;
  };
  var YA = function () {
    this.macros = [];
    this.rules = [];
    this.predicates = [];
    this.tags = [];
    this.Uk = [];
  };
  YA.prototype.getRules = function () {
    return this.rules;
  };
  var ZA = new YA();
  function $A(a, b, c, d) {
    var e = Zc(),
      f;
    if (e === 1)
      a: {
        var g = F(3);
        g = g.toLowerCase();
        for (
          var h = "https://" + g,
            l = "http://" + g,
            m = 1,
            p = z.getElementsByTagName("script"),
            q = 0;
          q < p.length && q < 100;
          q++
        ) {
          var r = p[q].src;
          if (r) {
            r = r.toLowerCase();
            if (r.indexOf(l) === 0) {
              f = 3;
              break a;
            }
            m === 1 && r.indexOf(h) === 0 && (m = 2);
          }
        }
        f = m;
      }
    else f = e;
    return (f === 2 || d || "http:" !== w.location.protocol ? a : b) + c;
  }
  var aB = function () {
      var a = this;
      this.K = {};
      this.H = {};
      Zp(function (b) {
        var c = [],
          d;
        for (d in a.K)
          Object.prototype.hasOwnProperty.call(a.K, d) &&
            c.push(d + "~" + a.K[d]);
        var e = [],
          f;
        for (f in a.H)
          Object.prototype.hasOwnProperty.call(a.H, f) &&
            e.push(f + "~" + a.H[f]);
        b.Ff && ((a.K = {}), (a.H = {}));
        var g = [];
        c.length > 0 && g.push(["bcs", c.join(".")]);
        e.length > 0 && g.push(["bet", e.join(".")]);
        return g;
      });
    },
    bB;
  function cB() {
    bB || (bB = new aB());
  }
  function dB(a, b, c, d, e) {
    if (!Cl(a)) {
      d.loadExperiments = Mi();
      Gl(a, d, e);
      var f = eB(a),
        g = function () {
          ml().container[a] && (ml().container[a].state = 3);
          fB();
        },
        h = { destinationId: a, endpoint: 0 };
      if (Tj()) {
        var l = Uj(),
          m = l + "/" + gB(f, a);
        dl(h, m, void 0, function () {
          hB(a, m, l + "/" + f, h, g);
        });
      } else {
        var p = Ub(a, "GTM-"),
          q = Yj(),
          r = c ? "/gtag/js" : "/gtm.js",
          t = iB(b, r + f, a);
        if (!t) {
          var v = F(3) + r;
          q &&
            Pc &&
            p &&
            (v = Pc.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]);
          t = $A("https://", "http://", v + f);
        }
        dl(h, t, void 0, g);
      }
    }
  }
  function fB() {
    Jl() ||
      Gb(Kl(), function (a, b) {
        jB(a, b.transportUrl, b.context);
        T(92);
      });
  }
  function jB(a, b, c, d) {
    if (!El(a))
      if ((c.loadExperiments || (c.loadExperiments = Mi()), Jl()))
        Il(a, b, c, d);
      else {
        Hl(a, c, d);
        var e = { destinationId: a, endpoint: 0 };
        if (Tj()) {
          var f = Uj(),
            g = "gtd" + eB(a, !0),
            h = f + "/" + gB(g, a);
          dl(e, h, void 0, function () {
            hB(a, h, f + "/" + g, e);
          });
        } else {
          var l = "/gtag/destination" + eB(a, !0),
            m = iB(b, l, a);
          m || (m = $A("https://", "http://", F(3) + l));
          dl(e, m);
        }
      }
  }
  function hB(a, b, c, d, e) {
    if (N(413)) {
      cB();
      var f = bB;
      if (mk.K) {
        var g = w.performance,
          h = -1;
        if (g && g.getEntriesByType) {
          var l = Oj(b).href,
            m = g.getEntriesByName(l).pop();
          if (!m)
            for (
              var p = g.getEntriesByType("resource"), q = 0;
              q < p.length;
              q++
            ) {
              var r = p[q];
              if (r.name && r.name.indexOf(b) !== -1) {
                m = r;
                break;
              }
            }
          m && m.responseStatus !== void 0 && (h = m.responseStatus);
        }
        f.K[a] = h;
      }
      T(190);
      e ? dl(d, c, void 0, e) : dl(d, c);
    } else e && e();
  }
  function eB(a, b) {
    b = b === void 0 ? !1 : b;
    var c = "?id=" + encodeURIComponent(a),
      d = F(19);
    d !== "dataLayer" && (c += "&l=" + d);
    var e = Ub(a, "GTM-");
    if (!e || b) c += "&cx=c";
    e && Hf(62) && (c += "&google_only=true");
    var f = c,
      g,
      h = { Yo: If(15), cp: F(14) };
    g = Bf(h);
    c = f + ("&gtm=" + g);
    Yj() && (c += "&sign=" + Oi.Pj);
    var l = c,
      m = If(54);
    if (m === 1) {
      l += "&fps=fc";
      var p = F(60);
      p && (l += "&gdev=" + p);
    } else m === 2 && (l += "&fps=fe");
    return l;
  }
  function gB(a, b) {
    if (!N(413) || !Uj()) return a;
    var c = F(58);
    if (!c) return T(182), a;
    try {
      var d = Ob(),
        e = Df(a, c),
        f = Ob() - d;
      cB();
      var g = bB;
      mk.K && (g.H[b] = f);
      return e;
    } catch (h) {
      return T(183), a;
    }
  }
  function iB(a, b, c) {
    if (!N(419)) return Wj(a, b);
    if (Xj() && a) {
      var d = F(58),
        e = Uj();
      if (d && e)
        try {
          var f = Ob();
          b = e + "/" + Df(b, d);
          var g = Ob() - f;
          cB();
          var h = bB;
          mk.K && (h.H[c] = g);
        } catch (l) {
          T(183);
        }
      return Vj(a, b);
    }
  }
  var kB = new RegExp(
      /^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/
    ),
    lB = {
      cl: ["ecl"],
      customPixels: ["nonGooglePixels"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: [
        "customScripts",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      customScripts: [
        "html",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGooglePixels: [],
      nonGoogleScripts: ["nonGooglePixels"],
      nonGoogleIframes: ["nonGooglePixels"],
    },
    mB = {
      cl: ["ecl"],
      customPixels: ["customScripts", "html"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: ["customScripts"],
      customScripts: ["html"],
      nonGooglePixels: [
        "customPixels",
        "customScripts",
        "html",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGoogleScripts: ["customScripts", "html"],
      nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"],
    },
    nB =
      "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(
        " "
      );
  function oB() {
    var a = Kp("gtm.allowlist") || Kp("gtm.whitelist");
    a && T(9);
    var b = Lf(62) === void 0;
    if (Hf(62) || (b && Hf(45))) a = void 0;
    kB.test(w.location && w.location.hostname) &&
      (Hf(62) || (b && Hf(45))
        ? T(116)
        : (T(117),
          Hf(48) &&
            ((a = []),
            window.console &&
              window.console.log &&
              window.console.log("GTM blocked. See go/13687728."))));
    var c = a && Tb(Kb(a), lB),
      d = Kp("gtm.blocklist") || Kp("gtm.blacklist");
    d || ((d = Kp("tagTypeBlacklist")) && T(3));
    d ? T(8) : (d = []);
    kB.test(w.location && w.location.hostname) &&
      ((d = Kb(d)),
      d.push("nonGooglePixels", "nonGoogleScripts", "sandboxedScripts"));
    Kb(d).indexOf("google") >= 0 && T(2);
    var e = d && Tb(Kb(d), mB),
      f = {};
    return function (g) {
      var h = g && g[Ff.bc];
      if (!h || typeof h !== "string") return !0;
      h = h.replace(/^_*/, "");
      if (f[h] !== void 0) return f[h];
      var l =
          uj(26, function () {
            return {};
          })[h] || [],
        m = !0;
      a && (m = m && pB(h, l, c));
      var p = !1;
      d && (p = qB(h, l, e));
      var q = !m || p;
      !q &&
        (l.indexOf("sandboxedScripts") === -1 ||
        (c && c.indexOf("sandboxedScripts") !== -1)
          ? 0
          : Eb(e, nB)) &&
        (q = !0);
      return (f[h] = q);
    };
  }
  function pB(a, b, c) {
    if (c.indexOf(a) < 0)
      if (b && b.length > 0)
        for (var d = 0; d < b.length; d++) {
          if (c.indexOf(b[d]) < 0) return T(11), !1;
        }
      else return !1;
    return !0;
  }
  function qB(a, b, c) {
    var d = c.indexOf(a) >= 0;
    if (d) return d;
    var e = Eb(c, b || []);
    e && T(10);
    return e;
  }
  function rB(a) {
    for (
      var b = [], c = [], d = sB(a), e = n(ZA.getRules()), f = e.next();
      !f.done;
      f = e.next()
    ) {
      for (
        var g = f.value.evaluate(a, d),
          h = g.firingTags,
          l = g.blockingTags,
          m = 0;
        m < h.length;
        m++
      )
        b[h[m]] = !0;
      for (var p = 0; p < l.length; p++) c[l[p]] = !0;
    }
    for (var q = [], r = 0; r < ZA.tags.length; r++)
      b[r] && !c[r] && (q[r] = !0);
    return q;
  }
  function sB(a) {
    var b = [];
    return function (c) {
      b[c] === void 0 && (b[c] = ZA.predicates[c].evaluate(a, []));
      return b[c];
    };
  }
  var tB = function () {
    this.K = 0;
    this.H = {};
  };
  tB.prototype.addListener = function (a, b, c) {
    var d = ++this.K;
    this.H[a] = this.H[a] || {};
    this.H[a][String(d)] = { listener: b, Df: c };
    return d;
  };
  tB.prototype.removeListener = function (a, b) {
    var c = this.H[a],
      d = String(b);
    if (!c || !c[d]) return !1;
    delete c[d];
    return !0;
  };
  var vB = function (a, b) {
    var c = [];
    Gb(uB.H[a], function (d, e) {
      c.indexOf(e.listener) < 0 &&
        (e.Df === void 0 || b.indexOf(e.Df) >= 0) &&
        c.push(e.listener);
    });
    return c;
  };
  function wB(a, b, c) {
    return {
      entityType: a,
      indexInOriginContainer: b,
      nameInOriginContainer: c,
      originContainerId: F(5),
      originCId: tl(),
    };
  }
  function xB(a, b) {
    if (data.entities) {
      var c = data.entities[a];
      if (c) return c[b];
    }
  }
  var zB = function (a, b) {
      this.H = !1;
      this.V = [];
      this.eventData = { tags: [] };
      this.Z = !1;
      this.K = this.O = 0;
      yB(this, a, b);
    },
    AB = function (a, b, c, d) {
      if (Qi.hasOwnProperty(b) || b === "__zone") return -1;
      var e = {};
      Fd(d) && (e = Gd(d, e));
      e.id = c;
      e.status = "timeout";
      return a.eventData.tags.push(e) - 1;
    },
    BB = function (a, b, c, d) {
      var e = a.eventData.tags[b];
      e && ((e.status = c), (e.executionTime = d));
    },
    CB = function (a) {
      if (!a.H) {
        for (var b = a.V, c = 0; c < b.length; c++) b[c]();
        a.H = !0;
        a.V.length = 0;
      }
    },
    yB = function (a, b, c) {
      b !== void 0 && a.Qg(b);
      c &&
        w.setTimeout(function () {
          CB(a);
        }, Number(c));
    };
  zB.prototype.Qg = function (a) {
    var b = this,
      c = Rb(function () {
        ed(function () {
          a(F(5), b.eventData);
        });
      });
    this.H ? c() : this.V.push(c);
  };
  var DB = function (a) {
      a.O++;
      return Rb(function () {
        a.K++;
        a.Z && a.K >= a.O && CB(a);
      });
    },
    EB = function (a) {
      a.Z = !0;
      a.K >= a.O && CB(a);
    };
  function FB() {
    return w[GB()];
  }
  function GB() {
    return w.GoogleAnalyticsObject || "ga";
  }
  var JB = new (function () {
    this.H = {};
  })();
  function KB() {
    a: {
      var a = F(5);
    }
  }
  function LB(a, b) {
    return function () {
      var c = FB(),
        d = c && c.getByName && c.getByName(a);
      if (d) {
        var e = d.get("sendHitTask");
        d.set("sendHitTask", function (f) {
          var g = f.get("hitPayload"),
            h = f.get("hitCallback"),
            l = g.indexOf("&tid=" + b) < 0;
          l &&
            (f.set(
              "hitPayload",
              g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b),
              !0
            ),
            f.set("hitCallback", void 0, !0));
          e(f);
          l &&
            (f.set("hitPayload", g, !0),
            f.set("hitCallback", h, !0),
            f.set("_x_19", void 0, !0),
            e(f));
        });
      }
    };
  }
  var OB = ["es", "1"],
    PB = function () {
      var a = this;
      this.eventData = {};
      this.H = {};
      Zp(function (b) {
        var c;
        var d = b.eventId,
          e = b.Ff;
        if (a.eventData[d]) {
          var f = [];
          a.H[d] || f.push(OB);
          f.push.apply(f, za(a.eventData[d]));
          e && (a.H[d] = !0);
          c = f;
        } else c = [];
        return c;
      });
    },
    QB;
  function RB(a, b) {
    var c;
    if ((c = QB) != null && mk.K) {
      var d = c.eventData,
        e;
      e = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
      d[a] = [
        ["e", e],
        ["eid", String(a)],
      ];
      $p();
      Yp(a);
    }
  }
  var SB = function () {
      var a = this;
      this.H = {};
      this.K = {};
      Zp(function (b) {
        var c = b.eventId,
          d = b.Ff,
          e = [],
          f = a.H[c] || [];
        f.length && e.push(["tr", f.join(".")]);
        var g = a.K[c] || [];
        g.length && e.push(["ti", g.join(".")]);
        d && (delete a.H[c], delete a.K[c]);
        return e;
      });
    },
    TB;
  function UB(a, b, c) {
    TB || (TB = new SB());
    var d = TB;
    if (mk.K && b) {
      var e = kk(b);
      d.H[a] = d.H[a] || [];
      d.H[a].push(c + e);
      var f = b[Ff.bc];
      if (!f) throw Error("Error: No function name given for function call.");
      var g = (OA[f] ? "1" : "2") + e;
      d.K[a] = d.K[a] || [];
      d.K[a].push(g);
      $p();
      Yp(a);
    }
  }
  function VB(a, b, c) {
    c = c === void 0 ? !1 : c;
    WB().addRestriction(0, a, b, c);
  }
  function XB() {
    var a = tl();
    return WB().getRestrictions(0, a);
  }
  function YB(a, b, c) {
    c = c === void 0 ? !1 : c;
    WB().addRestriction(1, a, b, c);
  }
  function ZB() {
    var a = tl();
    return WB().getRestrictions(1, a);
  }
  var $B = function () {
      this.container = {};
      this.H = {};
    },
    aC = function (a, b) {
      var c = a.container[b];
      c ||
        ((c = {
          _entity: { internal: [], external: [] },
          _event: { internal: [], external: [] },
        }),
        (a.container[b] = c));
      return c;
    };
  $B.prototype.addRestriction = function (a, b, c, d) {
    d = d === void 0 ? !1 : d;
    if (!d || !this.H[b]) {
      var e = aC(this, b);
      a === 0
        ? d
          ? e._entity.external.push(c)
          : e._entity.internal.push(c)
        : a === 1 &&
          (d ? e._event.external.push(c) : e._event.internal.push(c));
    }
  };
  $B.prototype.getRestrictions = function (a, b) {
    var c = aC(this, b);
    if (a === 0) {
      var d, e;
      return [].concat(
        za(
          (c == null
            ? void 0
            : (d = c._entity) == null
            ? void 0
            : d.internal) || []
        ),
        za(
          (c == null
            ? void 0
            : (e = c._entity) == null
            ? void 0
            : e.external) || []
        )
      );
    }
    if (a === 1) {
      var f, g;
      return [].concat(
        za(
          (c == null ? void 0 : (f = c._event) == null ? void 0 : f.internal) ||
            []
        ),
        za(
          (c == null ? void 0 : (g = c._event) == null ? void 0 : g.external) ||
            []
        )
      );
    }
    return [];
  };
  $B.prototype.getExternalRestrictions = function (a, b) {
    var c = aC(this, b),
      d,
      e;
    return a === 0
      ? (c == null ? void 0 : (d = c._entity) == null ? void 0 : d.external) ||
          []
      : (c == null ? void 0 : (e = c._event) == null ? void 0 : e.external) ||
          [];
  };
  $B.prototype.removeExternalRestrictions = function (a) {
    var b = aC(this, a);
    b._event && (b._event.external = []);
    b._entity && (b._entity.external = []);
    this.H[a] = !0;
  };
  function WB() {
    return Cn("r", function () {
      return new $B();
    });
  }
  function bC(a, b, c, d) {
    var e = ZA.tags[a],
      f = cC(a, b, c, d);
    if (!f) return null;
    var g = VA(e, c);
    if (g && g.length) {
      var h = g[0];
      f = bC(
        h.index,
        {
          onSuccess: f,
          onFailure: h.uo === 1 ? b.terminate : f,
          terminate: b.terminate,
        },
        c,
        d
      );
    }
    return f;
  }
  function cC(a, b, c, d) {
    function e() {
      function y() {
        Bm(3);
        var Q = Ob() - I;
        wB(1, a, f.getName());
        UB(c.id, g, "7");
        BB(c.od, D, "exception", Q);
        nk() && nA(c, g, Iz.W.Rj);
        E || ((E = !0), l());
      }
      if (f.Ja[Ff.kr]) l();
      else {
        var A = XA(f, c);
        if (A != null)
          for (var C = 0; C < A.length; C++)
            if (!Ao(A[C])) {
              l();
              return;
            }
        var D = AB(c.od, f.N, f.tagId, f.getMetadata(c)),
          E = !1,
          G = {
            vtp_gtmOnSuccess: function () {
              if (!E) {
                E = !0;
                var Q = Ob() - I;
                UB(c.id, g, "5");
                BB(c.od, D, "success", Q);
                nk() && nA(c, g, Iz.W.Tj);
                h();
              }
            },
            vtp_gtmOnFailure: function () {
              if (!E) {
                E = !0;
                var Q = Ob() - I;
                UB(c.id, g, "6");
                BB(c.od, D, "failure", Q);
                nk() && nA(c, g, Iz.W.Sj);
                l();
              }
            },
          };
        G.vtp_gtmEventId = c.id;
        c.priorityId && (G.vtp_gtmPriorityId = c.priorityId);
        UB(c.id, g, "1");
        nk() && eA({ stage: Iz.W.Uj, eventId: c.id, tagId: Number(g[Ff.Vj]) });
        var I = Ob();
        try {
          f.evaluate(c, d, G);
        } catch (Q) {
          y(Q);
        }
        nk() && nA(c, g, Iz.W.Wn);
      }
    }
    var f = ZA.tags[a],
      g = f.fh(),
      h = b.onSuccess,
      l = b.onFailure,
      m = b.terminate;
    if (c.isBlocked(g)) return null;
    var p = WA(f, c);
    if (p && p.length) {
      var q = p[0],
        r = bC(q.index, { onSuccess: h, onFailure: l, terminate: m }, c, d);
      if (!r) return null;
      h = r;
      l = q.uo === 2 ? m : r;
    }
    if (f.Ja[Ff.Cn] || f.Ja[Ff.mr]) {
      var t = f.Ja[Ff.Cn] ? ZA.Uk : c.Uk,
        v = h,
        u = l;
      if (!t[a]) {
        var x = dC(a, t, Rb(e));
        h = x.onSuccess;
        l = x.onFailure;
      }
      return function () {
        t[a](v, u);
      };
    }
    return e;
  }
  function dC(a, b, c) {
    var d = [],
      e = [];
    b[a] = eC(d, e, c);
    return {
      onSuccess: function () {
        b[a] = fC;
        for (var f = 0; f < d.length; f++) d[f]();
      },
      onFailure: function () {
        b[a] = gC;
        for (var f = 0; f < e.length; f++) e[f]();
      },
    };
  }
  function eC(a, b, c) {
    return function (d, e) {
      a.push(d);
      b.push(e);
      c();
    };
  }
  function fC(a) {
    a();
  }
  function gC(a, b) {
    b();
  }
  var jC = function (a, b) {
    for (var c = [], d = 0; d < ZA.tags.length; d++)
      if (a[d]) {
        var e = ZA.tags[d];
        var f = DB(b.od);
        try {
          var g = bC(d, { onSuccess: f, onFailure: f, terminate: f }, b, d);
          if (g) {
            var h = OA[e.N];
            c.push({
              kp: d,
              priorityOverride:
                (h ? h.priorityOverride || 0 : 0) || xB(e.N, 1) || 0,
              execute: g,
            });
          } else hC(d, b), f();
        } catch (m) {
          f();
        }
      }
    c.sort(iC);
    for (var l = 0; l < c.length; l++) c[l].execute();
    return c.length > 0;
  };
  function kC(a, b) {
    if (!uB) return !1;
    var c = a["gtm.triggers"] && String(a["gtm.triggers"]),
      d = vB(a.event, c ? String(c).split(",") : []);
    if (!d.length) return !1;
    for (var e = 0; e < d.length; ++e) {
      var f = DB(b);
      try {
        d[e](a, f);
      } catch (g) {
        f();
      }
    }
    return !0;
  }
  function iC(a, b) {
    var c,
      d = b.priorityOverride,
      e = a.priorityOverride;
    c = d > e ? 1 : d < e ? -1 : 0;
    var f;
    if (c !== 0) f = c;
    else {
      var g = a.kp,
        h = b.kp;
      f = g > h ? 1 : g < h ? -1 : 0;
    }
    return f;
  }
  function hC(a, b) {
    if (mk.K) {
      var c = function (d) {
        var e = b.isBlocked(ZA.tags[d].fh()) ? "3" : "4",
          f = VA(ZA.tags[d], b);
        f && f.length && c(f[0].index);
        UB(b.id, ZA.tags[d].fh(), e);
        var g = WA(ZA.tags[d], b);
        g && g.length && c(g[0].index);
      };
      c(a);
    }
  }
  var uB;
  function lC() {
    uB || (uB = new tB());
    return uB;
  }
  function mC(a) {
    var b = a["gtm.uniqueEventId"],
      c = a["gtm.priorityId"],
      d = a.event;
    nk() &&
      (eA({ stage: Iz.W.hi, eventId: b }),
      aA(b, "name", Ub(d, "gtm.") ? d : "*"));
    if (d === "gtm.js") {
      if (tj(12)) return !1;
      sj(12, !0);
    }
    var e = !1,
      f = ZB(),
      g = Gd(a, null);
    if (
      !f.every(function (t) {
        return t({ originalEventData: g });
      })
    ) {
      if (d !== "gtm.js" && d !== "gtm.init" && d !== "gtm.init_consent")
        return !1;
      e = !0;
    }
    RB(b, d);
    var h = a.eventCallback,
      l = a.eventTimeout,
      m = {
        id: b,
        priorityId: c,
        name: d,
        isBlocked: nC(g, e),
        Uk: [],
        logMacroError: function (t, v, u) {
          T(6);
          Bm(4);
          wB(2, v, u);
        },
        cachedModelValues: oC(),
        od: new zB(function () {
          if (nk()) {
            var t = fA({ stage: Iz.W.Mm, eventId: b }, Iz.W.hi);
            t !== void 0 && aA(b, "E", t);
            if (d === "gtm.load") {
              var v = fA({ stage: Iz.W.tl }, Iz.W.Fh);
              v !== void 0 && (Zz.E = v);
              im(lm(Ol.ja.hc), mA);
            }
          }
          oz(5, d);
          h && h.apply(h, Array.prototype.slice.call(arguments, 0));
        }, l),
        originalEventData: g,
      };
    nk() && eA({ stage: Iz.W.wj, eventId: m.id });
    var p = rB(m);
    nk() && kA(m.id);
    oz(2, d);
    ZA.getRules();
    e && (p = pC(p));
    nk() && jA(b);
    var q = jC(p, m);
    q && oz(4, d);
    var r = kC(a, m.od);
    EB(m.od);
    (d !== "gtm.js" && d !== "gtm.sync") || KB();
    return qC(p, q) || r;
  }
  function oC() {
    var a = {};
    a.event = Lp("event", 1);
    a.ecommerce = Lp("ecommerce", 1);
    a.gtm = Lp("gtm");
    a.eventModel = Lp("eventModel");
    return a;
  }
  function nC(a, b) {
    var c = oB();
    return function (d) {
      var e = c(d);
      if (e) return !0;
      var f = d && d[Ff.bc];
      if (!f || typeof f !== "string") return !0;
      f = f.replace(/^_*/, "");
      var g = XB(),
        h = a;
      b &&
        ((h = Gd(a, null)), (h["gtm.uniqueEventId"] = Number.MAX_SAFE_INTEGER));
      for (
        var l = !1,
          m =
            uj(26, function () {
              return {};
            })[f] || [],
          p = n(g),
          q = p.next();
        !q.done;
        q = p.next()
      ) {
        var r = q.value;
        try {
          r({ entityId: f, securityGroups: m, originalEventData: h }) ||
            (l = !0);
        } catch (t) {
          l = !0;
        }
      }
      return l || e;
    };
  }
  function pC(a) {
    for (var b = [], c = 0; c < a.length; c++)
      if (a[c]) {
        var d = ZA.tags[c].N;
        if (Pi[d] || ZA.tags[c].Ja[Ff.nr] !== void 0 || xB(d, 2)) b[c] = !0;
      }
    return b;
  }
  function qC(a, b) {
    if (!b) return b;
    for (var c = 0; c < a.length; c++)
      if (a[c] && ZA.tags[c] && !Qi[ZA.tags[c].N]) return !0;
    return !1;
  }
  var rC = Mf(61, 1e3),
    sC = Mf(68, 2e3),
    Co = ["ad_storage", "analytics_storage"];
  function tC(a, b) {
    if (a) {
      var c = Cn("gth", function () {
          return {};
        }),
        d;
      a !== 2 ||
        ((d = uC()) == null ? void 0 : d.status) !== 3 ||
        (b !== void 0 && b <= sC) ||
        ((a = 3), (c.dl = b ? Math.floor(b / 1e3) : void 0));
      c.s = a;
      vC(c);
    }
  }
  function vC(a) {
    if (a.s) {
      var b = function () {
        var c = { status: a.s, expires: Date.now() + 864e5 };
        a.dl !== void 0 && (c.delay = a.dl);
        Cr("gtg_load_status", c);
      };
      Fo(function () {
        if (Bo()) b();
        else
          for (var c = Rb(b), d = n(Co), e = d.next(); !e.done; e = d.next())
            dm(c, e.value);
      }, Co);
    }
  }
  function wC(a) {
    a = a === void 0 ? !1 : a;
    if (Xj()) {
      var b = Fr("gtg_load_status"),
        c = b.value,
        d =
          a &&
          Ab(c == null ? void 0 : c.expires) &&
          (c == null ? void 0 : c.expires) < Date.now() + 36e5;
      if (b.error === 0 && Ab(c == null ? void 0 : c.status) && !d) {
        var e = { status: c.status };
        (c == null ? void 0 : c.delay) !== void 0 && (e.delay = c.delay);
        return e;
      }
      return uC();
    }
  }
  function uC() {
    var a = En("gth");
    if (a != null && a.s) {
      var b = { status: a.s };
      a.dl !== void 0 && (b.delay = a.dl);
      return b;
    }
  }
  function xC() {
    var a;
    ((a = uC()) == null ? void 0 : a.status) === 1 && tC(3);
  }
  function yC() {
    if (!wC(!0)) {
      var a = Date.now();
      Fn("gth", {
        l: function () {
          tC(2, Date.now() - a);
        },
        s: 1,
      });
      var b = F(5),
        c = Ub(b, "GTM-") ? "/gtm.js" : "/gtag/js",
        d = "https://" + F(3) + c + "?id=" + b + "&gtg_health=1";
      Yc(d, xC, xC);
      w.setTimeout(xC, rC);
    }
  }
  function zC() {
    lC().addListener("gtm.init", function (a, b) {
      sj(25, !0);
      N(556) && Xj() && !Hf(45) && (fm.H[Ol.ja.hc] = Nl.La.si);
      if (Xj()) {
        var c = lm(Ol.ja.hc);
        gm(c) ? im(c, yC) : yC();
      }
      um();
      b();
    });
  }
  function AC() {
    if (En("pscdl") !== void 0)
      $i(Wi.ia.Xi) === void 0 && Zi(Wi.ia.Xi, En("pscdl"));
    else {
      var a = function (c) {
          Fn("pscdl", c);
          Zi(Wi.ia.Xi, c);
        },
        b = function () {
          a("error");
        };
      try {
        Mc.cookieDeprecationLabel
          ? (a("pending"),
            Mc.cookieDeprecationLabel.getValue().then(a).catch(b))
          : a("noapi");
      } catch (c) {
        b(c);
      }
    }
  }
  var CC = function () {
    var a = this;
    this.ready = !1;
    this.K = 0;
    this.H = [];
    var b = w;
    if (
      (z.readyState === "interactive" && !z.createEventObject) ||
      z.readyState === "complete"
    )
      this.onReady();
    else {
      cd(z, "DOMContentLoaded", function (d) {
        return void a.onReady(d);
      });
      cd(z, "readystatechange", function (d) {
        return void a.onReady(d);
      });
      if (z.createEventObject && z.documentElement.doScroll) {
        var c = !0;
        try {
          c = !b.frameElement;
        } catch (d) {}
        c && BC(this);
      }
      cd(b, "load", function (d) {
        return void a.onReady(d);
      });
    }
  };
  CC.prototype.isReady = function () {
    return this.ready;
  };
  CC.prototype.onReady = function (a) {
    if (!this.ready) {
      var b = z.createEventObject,
        c = z.readyState === "complete",
        d = z.readyState === "interactive";
      if (!a || a.type !== "readystatechange" || c || (!b && d)) {
        this.ready = !0;
        for (var e = 0; e < this.H.length; e++) ed(this.H[e]);
      }
      this.H.push = function () {
        for (var f = Pa.apply(0, arguments), g = 0; g < f.length; g++) ed(f[g]);
        return 0;
      };
    }
  };
  var BC = function (a) {
      if (!a.ready && a.K < 140) {
        a.K++;
        try {
          var b, c;
          (c = (b = z.documentElement).doScroll) == null || c.call(b, "left");
          a.onReady();
        } catch (d) {
          w.setTimeout(function () {
            return void BC(a);
          }, 50);
        }
      }
    },
    DC;
  function EC() {
    DC || (DC = new CC());
  }
  function FC() {
    EC();
    var a;
    return (a = DC) == null ? void 0 : a.isReady();
  }
  function GC(a) {
    EC();
    var b;
    (b = DC) != null && (b.ready ? ed(a) : b.H.push(a));
  }
  var IC = function (a, b, c) {
      var d = HC,
        e;
      if ((e = d.H) == null || !e.qs) {
        var f = Object.keys(b).length > 0 ? 2 : 1,
          g,
          h,
          l =
            (c == null
              ? void 0
              : (h = c.originatingEntity) == null
              ? void 0
              : h.originContainerId) || "";
        g = l ? (Ub(l, "GTM-") ? 3 : 2) : 1;
        if (!a) d.H = { type: f, source: g, params: b };
        else if (d.H) {
          T(184);
          var m = !1;
          d.H.source === g ||
            (d.H.source !== 3 && g !== 3) ||
            (Bj("idcs", "1"), (m = !0));
          (d.H.type !== 2 && f !== 2) || T(186);
          var p;
          if ((p = d.H.type === 2 && f === 2))
            a: {
              var q = d.H.params,
                r = Object.keys(q),
                t = Object.keys(b);
              if (r.length !== t.length) p = !0;
              else {
                for (var v = n(r), u = v.next(); !u.done; u = v.next()) {
                  var x = u.value;
                  if (!b.hasOwnProperty(x) || q[x] !== b[x]) {
                    p = !0;
                    break a;
                  }
                }
                p = !1;
              }
            }
          p && (Bj("idcc", "1"), (m = !0));
          m && (um(), (d.H.qs = !0));
        }
      }
    },
    HC = new (function () {
      this.H = void 0;
    })();
  var KC = function (a) {
      var b = JC;
      (!mk.H || Ub(F(5), "GTM-") ? 0 : a === void 0) &&
        b.H === 0 &&
        (Bj("mcc", "1"), (b.H = 1));
    },
    JC = new (function () {
      var a = this;
      this.H = 0;
      Bj("ncc", function () {
        if (N(545) && Hf(45) && a.H !== 2) return "1";
      });
    })();
  function LC(a, b) {
    a.hasOwnProperty("gtm.uniqueEventId") ||
      Object.defineProperty(a, "gtm.uniqueEventId", { value: Jn() });
    b.eventId = a["gtm.uniqueEventId"];
    b.priorityId = a["gtm.priorityId"];
    return { eventId: b.eventId, priorityId: b.priorityId };
  }
  function MC(a) {
    for (var b = n([H.D.Xd, H.D.hd]), c = b.next(); !c.done; c = b.next()) {
      var d = c.value,
        e = (a && a[d]) || vq(d);
      if (e) return e;
    }
  }
  function NC(a) {
    return !a.isGtmEvent ||
      (a.eventMetadata &&
        a.eventMetadata[J.J.Qb] &&
        a.eventMetadata[J.J.tb] !== tl())
      ? !1
      : !0;
  }
  var OC = new (function () {
    this.H = !1;
  })();
  var PC = function () {
    this.messages = [];
    this.H = [];
  };
  PC.prototype.enqueue = function (a, b, c) {
    var d = this.messages.length + 1;
    a["gtm.uniqueEventId"] = b;
    a["gtm.priorityId"] = d;
    var e = ma(Object, "assign").call(Object, {}, c, {
        eventId: b,
        priorityId: d,
        fromContainerExecution: !0,
      }),
      f = { message: a, notBeforeEventId: b, priorityId: d, messageContext: e };
    this.messages.push(f);
    for (var g = 0; g < this.H.length; g++)
      try {
        this.H[g](f);
      } catch (h) {}
  };
  PC.prototype.listen = function (a) {
    this.H.push(a);
  };
  PC.prototype.get = function () {
    for (var a = {}, b = 0; b < this.messages.length; b++) {
      var c = this.messages[b],
        d = a[c.notBeforeEventId];
      d || ((d = []), (a[c.notBeforeEventId] = d));
      d.push(c);
    }
    return a;
  };
  PC.prototype.prune = function (a) {
    for (var b = [], c = [], d = 0; d < this.messages.length; d++) {
      var e = this.messages[d];
      e.notBeforeEventId === a ? b.push(e) : c.push(e);
    }
    this.messages = c;
    return b;
  };
  function QC(a, b, c) {
    c.eventMetadata = c.eventMetadata || {};
    c.eventMetadata[J.J.tb] = F(6);
    RC().enqueue(a, b, c);
  }
  function RC() {
    return Cn("mb", function () {
      return new PC();
    });
  }
  var TC = function (a, b) {
      for (
        var c = SC, d = [], e = [], f = {}, g = 0;
        g < a.length;
        f = { Nk: void 0, uk: void 0 }, g++
      ) {
        var h = a[g];
        if (h.indexOf("-") >= 0) {
          if (((f.Nk = Oo(h, b)), f.Nk)) {
            var l = rl();
            Cb(
              l,
              (function (t) {
                return function (v) {
                  return t.Nk.destinationId === v;
                };
              })(f)
            )
              ? d.push(h)
              : e.push(h);
          }
        } else {
          var m = c.H[h] || [];
          f.uk = {};
          m.forEach(
            (function (t) {
              return function (v) {
                t.uk[v] = !0;
              };
            })(f)
          );
          for (var p = ul(), q = 0; q < p.length; q++)
            if (f.uk[p[q]]) {
              d = d.concat(rl());
              break;
            }
          var r = c.K[h] || [];
          r.length && (d = d.concat(r));
        }
      }
      return { Ik: d, nt: e };
    },
    UC = function (a) {
      Gb(SC.H, function (b, c) {
        var d = c.indexOf(a);
        d >= 0 && c.splice(d, 1);
      });
    },
    VC = function (a) {
      Gb(SC.K, function (b, c) {
        var d = c.indexOf(a);
        d >= 0 && c.splice(d, 1);
      });
    },
    SC = new (function () {
      this.H = {};
      this.K = {};
    })();
  function WC(a, b, c) {
    var d = Gd(a, null);
    d.eventId = void 0;
    d.inheritParentConfig = void 0;
    Object.keys(b).some(function (f) {
      return b[f] !== void 0;
    }) && T(136);
    var e = Gd(b, null);
    Gd(c, e);
    QC(lp(ul()[0], e), a.eventId, d);
  }
  function XC(a, b, c) {
    if (Hf(11) && !c && !a[H.D.Zd]) {
      var d = uj(9, function () {
        return !1;
      });
      sj(9, !0);
      IC(d, a, b);
      if (d) return !0;
    }
    return !1;
  }
  function YC(a, b) {
    var c = {},
      d = ((c.event = a), c);
    b &&
      ((d.eventModel = Gd(b, null)),
      b[H.D.gg] && (d.eventCallback = b[H.D.gg]),
      b[H.D.Th] && (d.eventTimeout = b[H.D.Th]));
    return d;
  }
  function ZC(a, b) {
    var c = a && a[H.D.Wd];
    c === void 0 && ((c = Kp(H.D.Wd, 2)), c === void 0 && (c = "default"));
    if (zb(c) || Array.isArray(c)) {
      var d;
      d = b.isGtmEvent
        ? zb(c)
          ? [c]
          : c
        : c.toString().replace(/\s+/g, "").split(",");
      var e = TC(d, b.isGtmEvent),
        f = e.Ik,
        g = e.nt;
      if (g.length)
        for (var h = MC(a), l = 0; l < g.length; l++) {
          var m = Oo(g[l], b.isGtmEvent);
          if (m) {
            var p = m.destinationId,
              q = void 0;
            ((q = ll(m.destinationId)) == null ? void 0 : q.state) === 0 ||
              jB(p, h, {
                source: 3,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      var r = f.concat(g);
      return { Ik: Po(f, b.isGtmEvent), Hr: Po(r, b.isGtmEvent) };
    }
  }
  var $C = {},
    aD =
      (($C.config = function (a, b) {
        var c = LC(a, b),
          d;
        a: {
          if (!(a.length < 2) && zb(a[1])) {
            var e = {};
            if (a.length > 2) {
              if ((a[2] !== void 0 && !Fd(a[2])) || a.length > 3) {
                d = void 0;
                break a;
              }
              e = a[2];
            }
            var f = Oo(a[1], b.isGtmEvent);
            if (f) {
              d = { target: f, params: e };
              break a;
            }
          }
          d = void 0;
        }
        var g = d;
        if (g) {
          var h = g.target,
            l = g.params,
            m;
          a: {
            if (!Hf(7)) {
              var p = wl(xl());
              if (Ll(p)) {
                var q = p.parent,
                  r = q.isDestination;
                m = { At: wl(q), it: r };
                break a;
              }
            }
            m = void 0;
          }
          var t = m,
            v = t == null ? void 0 : t.At,
            u = t == null ? void 0 : t.it;
          RB(c.eventId, "gtag.config");
          var x = h.destinationId;
          if (h.we() ? rl().indexOf(x) !== -1 : ul().indexOf(x) !== -1)
            a: {
              if (v && (T(128), u && T(130), b.inheritParentConfig)) {
                var y;
                var A = tj(11);
                if (A) WC(b, A, l), (y = !1);
                else {
                  var C = tj(10);
                  (!l[H.D.Zd] && Hf(11) && C) || sj(10, Gd(l, null));
                  y = !0;
                }
                y && v.containers && v.containers.join(",");
                break a;
              }
              var D = JC;
              mk.H && (D.H === 1 && (xj.H.mcc = !1), (D.H = 2));
              if (!XC(l, b, h.we())) {
                OC.H || T(43);
                if (!b.noTargetGroup) {
                  var E = h.id;
                  if (h.we()) {
                    VC(E);
                    var G = l[H.D.Zh] || "default",
                      I = SC;
                    G = String(G).split(",");
                    for (var Q = 0; Q < G.length; Q++) {
                      var V = I.K[G[Q]] || [];
                      I.K[G[Q]] = V;
                      V.indexOf(E) < 0 && V.push(E);
                    }
                  } else {
                    UC(E);
                    var S = l[H.D.Zh] || "default",
                      ja = SC;
                    S = S.toString().split(",");
                    for (var fa = 0; fa < S.length; fa++) {
                      var ka = ja.H[S[fa]] || [];
                      ja.H[S[fa]] = ka;
                      ka.indexOf(E) < 0 && ka.push(E);
                    }
                  }
                }
                delete l[H.D.Zh];
                var Z = b.eventMetadata || {};
                Z.hasOwnProperty(J.J.ee) ||
                  (Z[J.J.ee] = !b.fromContainerExecution);
                b.eventMetadata = Z;
                delete l[H.D.gg];
                var ia = !!l[H.D.Zd];
                delete l[H.D.Zd];
                var ya = rl(),
                  ra = sq,
                  ua = qq;
                h.we() && ((ya = [h.id]), (ra = tq), (ua = rq));
                for (var Oa = 0; Oa < ya.length; Oa++) {
                  ia || ra(ya[Oa]);
                  var fb = ya[Oa],
                    Nb = nq(),
                    rc = Oo(fb, !0),
                    jc = rc ? gq(Nb.H, rc).H : !1;
                  ua(ya[Oa], Gd(l, null), Gd(b, null));
                  (jc && ia) || oq(H.D.xa, Gd(l, null), ya[Oa], Gd(b, null));
                }
              }
            }
          else if (!b.inheritParentConfig && !l[H.D.ed]) {
            var Qb = MC(l),
              wc = h.destinationId;
            if (h.we())
              jB(wc, Qb, {
                source: 2,
                fromContainerExecution: b.fromContainerExecution,
              });
            else if (v !== void 0 && v.containers.indexOf(wc) !== -1) {
              var ve = tj(10),
                Fl = tj(11);
              ve ? WC(b, l, ve) : Fl || sj(11, Gd(l, null));
            } else
              dB(wc, Qb, !0, {
                source: 2,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      }),
      ($C.consent = function (a, b) {
        if (a.length === 3) {
          T(39);
          var c = LC(a, b),
            d = a[1],
            e = {},
            f = bn(a[2]),
            g;
          for (g in f)
            if (f.hasOwnProperty(g)) {
              var h = f[g];
              e[g] =
                g === H.D.Eh
                  ? Array.isArray(h)
                    ? NaN
                    : Number(h)
                  : g === H.D.vc
                  ? (Array.isArray(h) ? h : [h]).map(cn)
                  : dn(h);
            }
          b.fromContainerExecution ||
            (e[H.D.fa] && T(139), e[H.D.Pa] && T(140));
          d === "default"
            ? wo(e)
            : d === "update"
            ? yo(e, c)
            : d === "declare" && b.fromContainerExecution && vo(e);
        }
      }),
      ($C.container_config = function (a, b) {
        if (NC(b) && a.length === 3 && zb(a[1]) && Fd(a[2])) {
          var c = a[2],
            d = Oo(a[1], !0);
          d && qq(d.destinationId, c, Gd(b, null));
        }
      }),
      ($C.destination_config = function (a, b) {
        if (NC(b) && a.length === 3 && zb(a[1]) && Fd(a[2])) {
          var c = a[2],
            d = Oo(a[1], !0);
          d && rq(d.destinationId, c, Gd(b, null));
        }
      }),
      ($C.event = function (a, b) {
        var c = a[1];
        if (!(a.length < 2) && zb(c)) {
          var d = void 0;
          if (a.length > 2) {
            if ((!Fd(a[2]) && a[2] !== void 0) || a.length > 3) return;
            d = a[2];
          }
          var e = YC(c, d),
            f = LC(a, b),
            g = f.eventId,
            h = f.priorityId;
          e["gtm.uniqueEventId"] = g;
          h && (e["gtm.priorityId"] = h);
          if (c === "optimize.callback")
            return (e.eventModel = e.eventModel || {}), e;
          var l = ZC(d, b);
          if (l) {
            for (
              var m = l.Ik,
                p = l.Hr,
                q = p.map(function (I) {
                  return I.id;
                }),
                r = p.map(function (I) {
                  return I.destinationId;
                }),
                t = m.map(function (I) {
                  return I.id;
                }),
                v = n(rl()),
                u = v.next();
              !u.done;
              u = v.next()
            ) {
              var x = u.value;
              r.indexOf(x) < 0 && t.push(x);
            }
            RB(g, c);
            for (var y = n(t), A = y.next(); !A.done; A = y.next()) {
              var C = A.value,
                D = Gd(b, null),
                E = Gd(d, null);
              delete E[H.D.gg];
              var G = D.eventMetadata || {};
              G.hasOwnProperty(J.J.ee) ||
                (G[J.J.ee] = !D.fromContainerExecution);
              G[J.J.Lj] = q.slice();
              G[J.J.Mg] = r.slice();
              D.eventMetadata = G;
              oq(c, E, C, D);
            }
            e.eventModel = e.eventModel || {};
            q.length > 0
              ? (e.eventModel[H.D.Wd] = q.join(","))
              : delete e.eventModel[H.D.Wd];
            OC.H || T(43);
            b.noGtmEvent === void 0 &&
              b.eventMetadata &&
              b.eventMetadata[J.J.Vn] &&
              (b.noGtmEvent = !0);
            e.eventModel[H.D.dd] && (b.noGtmEvent = !0);
            return b.noGtmEvent ? void 0 : e;
          }
        }
      }),
      ($C.get = function (a, b) {
        T(53);
        if (a.length === 4 && zb(a[1]) && zb(a[2]) && yb(a[3])) {
          var c = Oo(a[1], b.isGtmEvent),
            d = String(a[2]),
            e = a[3];
          if (c) {
            OC.H || T(43);
            var f = MC();
            if (
              Cb(rl(), function (h) {
                return c.destinationId === h;
              })
            ) {
              LC(a, b);
              var g = {};
              Gd(((g[H.D.kg] = d), (g[H.D.jg] = e), g), null);
              pq(
                d,
                function (h) {
                  ed(function () {
                    e(h);
                  });
                },
                c.id,
                b
              );
            } else
              jB(c.destinationId, f, {
                source: 4,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      }),
      ($C.js = function (a, b) {
        var c;
        if (a.length === 2 && a[1].getTime) {
          OC.H = !0;
          var d = LC(a, b),
            e = d.eventId,
            f = d.priorityId,
            g = {};
          c =
            ((g.event = "gtm.js"),
            (g["gtm.start"] = a[1].getTime()),
            (g["gtm.uniqueEventId"] = e),
            (g["gtm.priorityId"] = f),
            g);
        } else c = void 0;
        return c;
      }),
      ($C.policy = function (a) {
        if (a.length === 3 && zb(a[1]) && yb(a[2])) {
          if ((Wy(a[1], a[2]), T(74), a[1] === "all")) {
            T(75);
            var b = !1;
            try {
              b = a[2](F(5), "unknown", {});
            } catch (c) {}
            b || T(76);
          }
        } else T(73);
      }),
      ($C.reset_target_config = function (a, b) {
        if (NC(b) && a.length === 2 && zb(a[1])) {
          var c = Oo(a[1], !0);
          c && tq(c.destinationId);
        }
      }),
      ($C.set = function (a, b) {
        var c = void 0;
        a.length === 2 && Fd(a[1])
          ? (c = Gd(a[1], null))
          : a.length === 3 &&
            zb(a[1]) &&
            ((c = {}),
            Fd(a[2]) || Array.isArray(a[2])
              ? (c[a[1]] = Gd(a[2], null))
              : (c[a[1]] = a[2]));
        if (c) {
          var d = LC(a, b),
            e = d.eventId,
            f = d.priorityId;
          Gd(c, null);
          F(5);
          var g = Gd(c, null);
          nq().H.push("set", [g], void 0, b);
          c["gtm.uniqueEventId"] = e;
          f && (c["gtm.priorityId"] = f);
          delete c.event;
          b.overwriteModelFields = !0;
          return c;
        }
      }),
      $C),
    bD = {},
    cD = ((bD.policy = !0), bD);
  var eD = function (a) {
    if (dD(a)) return a;
    this.value = a;
  };
  eD.prototype.getUntrustedMessageValue = function () {
    return this.value;
  };
  var dD = function (a) {
    return !a || Dd(a) !== "object" || Fd(a)
      ? !1
      : "getUntrustedMessageValue" in a;
  };
  eD.prototype.getUntrustedMessageValue = eD.prototype.getUntrustedMessageValue;
  var fD = function () {
    var a = this;
    this.loaded = !1;
    this.H = [];
    if (z.readyState === "complete") this.onLoad();
    else
      cd(w, "load", function () {
        return void a.onLoad();
      });
  };
  fD.prototype.onLoad = function () {
    if (!this.loaded) {
      this.loaded = !0;
      for (var a = 0; a < this.H.length; a++) ed(this.H[a]);
    }
  };
  var hD = function (a) {
      var b = gD;
      b.loaded ? ed(a) : b.H.push(a);
    },
    gD = new fD();
  var iD = function () {
      this.Z = 0;
      this.la = [];
      this.K = {};
      this.H = [];
      this.O = [];
      this.ka = this.V = this.ya = !1;
    },
    kD = function (a, b, c) {
      var d = jD;
      a.eventCallback = b;
      c && (a.eventTimeout = c);
      return d.push(a);
    },
    lD = function (a, b) {
      if (!Ab(b) || b < 0) b = 0;
      var c = In(),
        d = 0,
        e = !1,
        f = void 0;
      f = w.setTimeout(function () {
        e || ((e = !0), a());
        f = void 0;
      }, b);
      return function () {
        var g = c ? c.subscribers : 1;
        ++d === g &&
          (f && (w.clearTimeout(f), (f = void 0)), e || (a(), (e = !0)));
      };
    },
    nD = function (a) {
      var b;
      if (a.O.length) b = a.O.shift();
      else if (a.H.length) b = a.H.shift();
      else return;
      var c;
      var d = b;
      if (a.ya || !mD(d.message)) c = d;
      else {
        a.ya = !0;
        var e = d.message["gtm.uniqueEventId"],
          f,
          g;
        typeof e === "number"
          ? ((f = e - 2), (g = e - 1))
          : ((f = Jn()), (g = Jn()), (d.message["gtm.uniqueEventId"] = Jn()));
        var h = {},
          l = {
            message:
              ((h.event = "gtm.init_consent"), (h["gtm.uniqueEventId"] = f), h),
            messageContext: { eventId: f },
          },
          m = {},
          p = {
            message: ((m.event = "gtm.init"), (m["gtm.uniqueEventId"] = g), m),
            messageContext: { eventId: g },
          };
        a.H.unshift(p, d);
        c = l;
      }
      return c;
    },
    qD = function (a) {
      a.ka || T(196);
      for (var b = !1, c; !a.V && (c = nD(a)); ) {
        a.V = !0;
        var d = Hp;
        delete d.H.eventModel;
        Ep(d);
        var e = c,
          f = e.message,
          g = e.messageContext;
        if (f == null) a.V = !1;
        else {
          g.fromContainerExecution && Ip();
          try {
            if (yb(f))
              try {
                f.call(Jp);
              } catch (Q) {}
            else if (Array.isArray(f)) {
              if (zb(f[0])) {
                var h = f[0].split("."),
                  l = h.pop(),
                  m = f.slice(1),
                  p = Kp(h.join("."), 2);
                if (p != null)
                  try {
                    p[l].apply(p, m);
                  } catch (Q) {}
              }
            } else {
              var q = void 0;
              if (Hb(f))
                a: {
                  if (f.length && zb(f[0])) {
                    var r = aD[f[0]];
                    if (r && (!g.fromContainerExecution || !cD[f[0]])) {
                      q = r(f, g);
                      break a;
                    }
                  }
                  q = void 0;
                }
              else q = f;
              if (q) {
                var t;
                for (
                  var v = q,
                    u = v._clear || g.overwriteModelFields,
                    x = n(Object.keys(v)),
                    y = x.next();
                  !y.done;
                  y = x.next()
                ) {
                  var A = y.value;
                  A !== "_clear" && (u && Hp.set(A, void 0), Hp.set(A, v[A]));
                }
                tj(24) || sj(24, v["gtm.start"]);
                var C = v["gtm.uniqueEventId"];
                v.event
                  ? (typeof C !== "number" &&
                      ((C = Jn()),
                      (v["gtm.uniqueEventId"] = C),
                      Hp.set("gtm.uniqueEventId", C)),
                    (t = mC(v)))
                  : (t = !1);
                b = t || b;
              }
            }
          } finally {
            g.fromContainerExecution && Ep(Hp, !0);
            var D = f["gtm.uniqueEventId"];
            if (typeof D === "number") {
              for (
                var E = a, G = E.K[String(D)] || [], I = 0;
                I < G.length;
                I++
              )
                E.O.push(oD(G[I]));
              G.length && E.O.sort(pD);
              delete E.K[String(D)];
              D > a.Z && (a.Z = D);
            }
            a.V = !1;
          }
        }
      }
      return !b;
    },
    rD = function (a) {
      a.ka && T(195);
      a.ka = !0;
      if (nk()) {
        var b = !Hf(51);
        eA({ stage: Iz.W.Fh });
        if (b) {
          var c = fA({ stage: Iz.W.wl }, Iz.W.Wi);
          c !== void 0 && (Zz.Y = c);
        }
        Zz.C = a.H.length;
      }
      qD(a);
      if (nk()) {
        var d = fA({ stage: Iz.W.sl }, Iz.W.Fh);
        d !== void 0 && (Zz.B = d);
      }
      try {
        var e = w[F(19)],
          f = F(5),
          g = e.hide;
        if (g && g[f] !== void 0 && g.end) {
          g[f] = !1;
          var h = !0,
            l;
          for (l in g)
            if (g.hasOwnProperty(l) && g[l] === !0) {
              h = !1;
              break;
            }
          h && (g.end(), (g.end = null));
        }
      } catch (m) {
        F(5);
      }
    },
    sD = function () {
      var a = jD;
      if (a.la.length === 0) rD(a);
      else {
        var b = w;
        yb(b.Promise) && b.Promise.allSettled
          ? b.Promise.allSettled(a.la).then(function () {
              rD(a);
            })
          : (T(191),
            ed(function () {
              return void rD(a);
            }));
      }
    },
    tD = function (a, b) {
      if (a.Z < b.notBeforeEventId) {
        var c = String(b.notBeforeEventId);
        a.K[c] = a.K[c] || [];
        a.K[c].push(b);
      } else {
        a.O.push(oD(b));
        a.O.sort(pD);
        var d = function () {
          a.V || qD(a);
        };
        mk.H && nj(462) ? gd(d) : ed(d);
      }
    };
  iD.prototype.bind = function () {
    function a(h) {
      var l = {};
      if (dD(h)) {
        var m = h;
        h = dD(m) ? m.getUntrustedMessageValue() : void 0;
        l.fromContainerExecution = !0;
      }
      return { message: h, messageContext: l };
    }
    var b = this,
      c = Qc(F(19), []),
      d = Hn();
    d.pruned === !0 && T(83);
    this.K = RC().get();
    RC().listen(function (h) {
      tD(b, h);
    });
    d.subscribers = (d.subscribers || 0) + 1;
    var e = c.push,
      f = this;
    c.push = function () {
      var h;
      Dn();
      if (Bn.H.SANDBOXED_JS_SEMAPHORE > 0) {
        h = [];
        for (var l = 0; l < arguments.length; l++) h[l] = new eD(arguments[l]);
      } else h = [].slice.call(arguments, 0);
      var m = h.map(function (t) {
        return a(t);
      });
      f.H.push.apply(f.H, m);
      var p = e.apply(c, h),
        q = Math.max(100, Mf(1, 300));
      if (this.length > q)
        for (T(4), d.pruned = !0; this.length > q; ) this.shift();
      var r = typeof p !== "boolean" || p;
      return qD(f) && r;
    };
    var g = c.slice(0).map(function (h) {
      return a(h);
    });
    this.H.push.apply(this.H, g);
    Hf(51) ||
      (nk()
        ? (eA({ stage: Iz.W.Wi }), nj(520) ? gd(uD) : ed(vD))
        : nj(551)
        ? gd(uD)
        : ed(vD));
    GC(function () {
      if (!d.gtmDom) {
        d.gtmDom = !0;
        var h = {};
        c.push(((h.event = "gtm.dom"), h));
      }
    });
    hD(function () {
      if (!d.gtmLoad) {
        d.gtmLoad = !0;
        var h = {};
        c.push(((h.event = "gtm.load"), h));
      }
    });
  };
  iD.prototype.push = function (a) {
    return w[F(19)].push(a);
  };
  var jD = new iD();
  function pD(a, b) {
    return (
      a.messageContext.eventId - b.messageContext.eventId ||
      a.messageContext.priorityId - b.messageContext.priorityId
    );
  }
  function mD(a) {
    if (a == null || typeof a !== "object") return !1;
    if (a.event) return !0;
    if (Hb(a)) {
      var b = a[0];
      if (b === "config" || b === "event" || b === "js" || b === "get")
        return !0;
    }
    return !1;
  }
  function oD(a) {
    return { message: a.message, messageContext: a.messageContext };
  }
  function wD() {
    var a = xD(),
      b = jD;
    a && b.la.push(a);
  }
  function yD(a, b, c) {
    return kD(a, b, c);
  }
  function zD(a, b) {
    return lD(a, b);
  }
  function vD() {
    rD(jD);
  }
  function uD() {
    sD();
  }
  function AD(a) {
    return jD.push(a);
  }
  var BD = function () {};
  BD.prototype.bind = function () {
    var a,
      b = Oj(w.location.href);
    (a = b.hostname + b.pathname) && Bj("dl", encodeURIComponent(a));
    var c;
    var d = F(5);
    if (d) {
      var e = Hf(7) ? 1 : 0,
        f = Dl(),
        g = f && f.fromContainerExecution ? 1 : 0,
        h = (f && f.source) || 0,
        l = F(6);
      c = d + ";" + l + ";" + g + ";" + h + ";" + e;
    } else c = void 0;
    var m = c;
    m && Bj("tdp", m);
    var p = Hq(!0);
    p !== void 0 && Bj("frm", String(p));
  };
  var CD = new BD();
  var DD = function () {
      this.H = dk();
      this.K = void 0;
    },
    ED = function (a, b) {
      return fk(a, function (c) {
        return c.nb > 0 ? (b ? c.nb + "_" + ck(c) : String(c.nb)) : void 0;
      });
    };
  DD.prototype.bind = function () {
    var a = this;
    if (go() || mk.H)
      Bj(
        "csp",
        function () {
          var b = ED(a.H, N(535));
          gk(a.H);
          return b;
        },
        !1
      ),
        Bj(
          "mde",
          function () {
            var b = jk.H,
              c = ED(b, !1);
            gk(b);
            return c;
          },
          !1
        ),
        w.addEventListener("securitypolicyviolation", function (b) {
          if (b.disposition === "enforce") {
            T(179);
            var c = sk(b.effectiveDirective);
            if (c) {
              var d = c.yh,
                e = c.Wg,
                f;
              a: {
                var g = b.blockedURI,
                  h = qk;
                if (mk.H && g) {
                  var l = pk(d, g);
                  if (l) {
                    f = h.H[d][l];
                    break a;
                  }
                }
                f = void 0;
              }
              var m = f;
              if (m) {
                var p;
                a: {
                  try {
                    var q = new URL(b.blockedURI),
                      r = q.pathname.indexOf(";");
                    p =
                      r >= 0
                        ? q.origin + q.pathname.substring(0, r)
                        : q.origin + q.pathname;
                    break a;
                  } catch (E) {}
                  p = void 0;
                }
                var t = p;
                if (t) {
                  for (var v = n(m), u = v.next(); !u.done; u = v.next()) {
                    var x = u.value;
                    if (!x.Zo) {
                      x.Zo = !0;
                      var y = { eventId: x.eventId, priorityId: x.priorityId };
                      if (go()) {
                        var A = y,
                          C = {
                            type: 1,
                            blockedUrl: t,
                            endpoint: x.endpoint,
                            violation: b.effectiveDirective,
                          };
                        if (go()) {
                          var D = mo("TAG_DIAGNOSTICS", {
                            eventId: A == null ? void 0 : A.eventId,
                            priorityId: A == null ? void 0 : A.priorityId,
                          });
                          D.tagDiagnostics = C;
                          fo(D);
                        }
                      }
                      FD(a, x.destinationId, x.endpoint, e);
                    }
                  }
                  rk(d, b.blockedURI);
                }
              }
            }
          }
        });
  };
  var FD = function (a, b, c, d) {
      hk(a.H, b, c, 1, d);
      Cj("csp", !0);
      Cj("mde", !0);
      c !== 61 &&
        c !== 56 &&
        a.K === void 0 &&
        (a.K = w.setTimeout(function () {
          a.H.nb > 0 && um(!1);
          a.K = void 0;
        }, 500));
    },
    GD = new DD();
  var HD = function () {
    this.sequenceNumber = 0;
  };
  HD.prototype.bind = function () {
    var a = this;
    ID(this);
    Bj("v", "3");
    Bj("t", "t");
    Bj("pid", function () {
      return String($i(Wi.ia.Gh));
    });
    Bj("gtm", function () {
      return Np();
    });
    Bj("seq", function () {
      return String(++a.sequenceNumber);
    });
    Bj("exp", function () {
      return oj();
    });
  };
  var ID = function (a) {
      if ($i(Wi.ia.Gh) === void 0) {
        var b = function () {
          Zi(Wi.ia.Gh, Db());
          a.sequenceNumber = 0;
        };
        b();
        fd(b, 864e5);
      } else
        bj(Wi.ia.Gh, function () {
          a.sequenceNumber = 0;
        });
      a.sequenceNumber = 0;
    },
    JD = new HD();
  function KD(a) {
    return function () {
      return w[a];
    };
  }
  var LD = {},
    MD =
      ((LD[14] = function () {
        var a;
        return (a = w.crypto) == null ? void 0 : a.getRandomValues;
      }),
      (LD[15] = function () {
        var a, b;
        return (a = w.crypto) == null
          ? void 0
          : (b = a.subtle) == null
          ? void 0
          : b.digest;
      }),
      (LD[1] = KD("fetch")),
      (LD[6] = KD("Map")),
      (LD[2] = function () {
        return Math.random;
      }),
      (LD[8] = function () {
        return ma(Object, "assign");
      }),
      (LD[9] = function () {
        return Object.entries;
      }),
      (LD[10] = function () {
        return Object.fromEntries;
      }),
      (LD[5] = KD("Promise")),
      (LD[13] = KD("RegExp")),
      (LD[3] = function () {
        return Mc.sendBeacon;
      }),
      (LD[7] = KD("Set")),
      (LD[12] = function () {
        return String.prototype.endsWith;
      }),
      (LD[11] = function () {
        return String.prototype.startsWith;
      }),
      (LD[4] = KD("XMLHttpRequest")),
      LD),
    ND = {},
    OD = ((ND[15] = !0), ND);
  var PD = /^(https?:)?\/\//;
  function jE() {}
  function kE() {
    var a = Lf(62) === void 0;
    if (Hf(62) || (a && F(5).indexOf("GTM-") !== 0))
      Wy("detect_link_click_events", function (b, c, d) {
        var e;
        return ((e = d.options) == null ? void 0 : e.waitForTags) !== !0;
      }),
        Wy("detect_form_submit_events", function (b, c, d) {
          var e;
          return ((e = d.options) == null ? void 0 : e.waitForTags) !== !0;
        }),
        Wy("detect_youtube_activity_events", function (b, c, d) {
          var e;
          return ((e = d.options) == null ? void 0 : e.fixMissingApi) !== !0;
        });
    a &&
      Hf(45) &&
      VB(tl(), function (b) {
        var c;
        c = b.entityId;
        if (c === "fls" || c === "flc" || c === "dest_dc") return !1;
        var d = "__" + c;
        return xB(d, 5) || !(!OA[d] || !OA[d][5]);
      });
  }
  var lE = function () {
    this.H = this.gppString = void 0;
  };
  lE.prototype.reset = function () {
    this.H = this.gppString = void 0;
  };
  var mE = new lE();
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  Jq({
    Vu: 0,
    Uu: 1,
    Ru: 2,
    Mu: 3,
    Su: 4,
    Nu: 5,
    Tu: 6,
    Pu: 7,
    Qu: 8,
    Lu: 9,
    Ou: 10,
    Wu: 11,
  }).map(function (a) {
    return Number(a);
  });
  Jq({ Yu: 0, Zu: 1, Xu: 2 }).map(function (a) {
    return Number(a);
  });
  var nE = function (a, b, c, d) {
    Pq.call(this);
    this.ne = b;
    this.nd = c;
    this.jc = d;
    this.Va = new Map();
    this.oe = 0;
    this.la = new Map();
    this.ya = new Map();
    this.Z = void 0;
    this.K = a;
  };
  va(nE, Pq);
  nE.prototype.O = function () {
    delete this.H;
    this.Va.clear();
    this.la.clear();
    this.ya.clear();
    this.Z && (Lq(this.K, "message", this.Z), delete this.Z);
    delete this.K;
    delete this.jc;
    Pq.prototype.O.call(this);
  };
  var oE = function (a) {
      if (a.H) return a.H;
      a.nd && a.nd(a.K) ? (a.H = a.K) : (a.H = Gq(a.K, a.ne));
      var b;
      return (b = a.H) != null ? b : null;
    },
    qE = function (a, b, c) {
      if (oE(a))
        if (a.H === a.K) {
          var d = a.Va.get(b);
          d && d(a.H, c);
        } else {
          var e = a.la.get(b);
          if (e && e.Hk) {
            pE(a);
            var f = ++a.oe;
            a.ya.set(f, {
              ze: e.ze,
              Zr: e.Fo(c),
              persistent: b === "addEventListener",
            });
            a.H.postMessage(e.Hk(c, f), "*");
          }
        }
    },
    pE = function (a) {
      a.Z ||
        ((a.Z = function (b) {
          try {
            var c;
            c = a.jc ? a.jc(b) : void 0;
            if (c) {
              var d = c.Dt,
                e = a.ya.get(d);
              if (e) {
                e.persistent || a.ya.delete(d);
                var f;
                (f = e.ze) == null || f.call(e, e.Zr, c.payload);
              }
            }
          } catch (g) {}
        }),
        Kq(a.K, "message", a.Z));
    };
  var rE = function (a, b) {
      var c = b.listener,
        d = (0, a.__gpp)("addEventListener", c);
      d && c(d, !0);
    },
    sE = function (a, b) {
      (0, a.__gpp)("removeEventListener", b.listener, b.listenerId);
    },
    tE = {
      Fo: function (a) {
        return a.listener;
      },
      Hk: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "addEventListener",
            version: "1.1",
          }),
          c
        );
      },
      ze: function (a, b) {
        var c = b.__gppReturn;
        a(c.returnValue, c.success);
      },
    },
    uE = {
      Fo: function (a) {
        return a.listener;
      },
      Hk: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "removeEventListener",
            version: "1.1",
            parameter: a.listenerId,
          }),
          c
        );
      },
      ze: function (a, b) {
        var c = b.__gppReturn,
          d = c.returnValue.data;
        a == null || a(d, c.success);
      },
    };
  function vE(a) {
    var b = {};
    vf(a.data) ? (b = JSON.parse(a.data)) : (b = a.data);
    return { payload: b, Dt: b.__gppReturn.callId };
  }
  var wE = function (a, b) {
    var c;
    c = (b === void 0 ? {} : b).timeoutMs;
    Pq.call(this);
    this.caller = new nE(
      a,
      "__gppLocator",
      function (d) {
        return typeof d.__gpp === "function";
      },
      vE
    );
    this.caller.Va.set("addEventListener", rE);
    this.caller.la.set("addEventListener", tE);
    this.caller.Va.set("removeEventListener", sE);
    this.caller.la.set("removeEventListener", uE);
    this.timeoutMs = c != null ? c : 500;
  };
  va(wE, Pq);
  wE.prototype.O = function () {
    this.caller.dispose();
    Pq.prototype.O.call(this);
  };
  wE.prototype.addEventListener = function (a) {
    var b = this,
      c = Aq(function () {
        a(xE, !0);
      }),
      d =
        this.timeoutMs === -1
          ? void 0
          : setTimeout(function () {
              c();
            }, this.timeoutMs);
    qE(this.caller, "addEventListener", {
      listener: function (e, f) {
        clearTimeout(d);
        try {
          var g;
          var h;
          ((h = e.pingData) == null ? void 0 : h.gppVersion) === void 0 ||
          e.pingData.gppVersion === "1" ||
          e.pingData.gppVersion === "1.0"
            ? (b.removeEventListener(e.listenerId),
              (g = {
                eventName: "signalStatus",
                data: "ready",
                pingData: {
                  internalErrorState: 1,
                  gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                  applicableSections: [-1],
                },
              }))
            : Array.isArray(e.pingData.applicableSections)
            ? (g = e)
            : (b.removeEventListener(e.listenerId),
              (g = {
                eventName: "signalStatus",
                data: "ready",
                pingData: {
                  internalErrorState: 2,
                  gppString:
                    "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                  applicableSections: [-1],
                },
              }));
          a(g, f);
        } catch (l) {
          if (e == null ? 0 : e.listenerId)
            try {
              b.removeEventListener(e.listenerId);
            } catch (m) {
              a(yE, !0);
              return;
            }
          a(zE, !0);
        }
      },
    });
  };
  wE.prototype.removeEventListener = function (a) {
    qE(this.caller, "removeEventListener", {
      listener: function () {},
      listenerId: a,
    });
  };
  var zE = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        internalErrorState: 2,
        gppString: "GPP_ERROR_STRING_UNAVAILABLE",
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    xE = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    yE = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    };
  function AE(a) {
    var b;
    if (!(b = a.pingData.signalStatus === "ready")) {
      var c = a.pingData.applicableSections;
      b = !c || (c.length === 1 && c[0] === -1);
    }
    if (b) {
      mE.gppString = a.pingData.gppString;
      var d = a.pingData.applicableSections.join(",");
      mE.H = d;
    }
  }
  function BE() {
    try {
      var a = new wE(w, { timeoutMs: -1 });
      oE(a.caller) && a.addEventListener(AE);
    } catch (b) {}
  }
  function CE() {
    var a = [
        ["cv", F(1)],
        ["rv", F(14)],
        [
          "tc",
          ZA.tags.filter(function (d) {
            return d;
          }).length,
        ],
      ],
      b = If(15);
    b && a.push(["x", b]);
    var c = oj();
    c && a.push(["tag_exp", c]);
    return a;
  }
  var DE = function () {
      var a = this;
      this.H = {};
      this.K = {};
      Zp(function (b) {
        var c = b.eventId,
          d = b.Ff,
          e = [],
          f = a.H[c] || [];
        f.length && e.push(["hf", f.join(".")]);
        var g = a.K[c] || [];
        g.length && e.push(["ht", g.join(".")]);
        d && (delete a.H[c], delete a.K[c]);
        return e;
      });
    },
    EE = function () {
      var a = 0;
      return function (b) {
        switch (b) {
          case 1:
            a |= 1;
            break;
          case 2:
            a |= 2;
            break;
          case 3:
            a |= 4;
        }
        return a;
      };
    },
    FE;
  var GE = function () {
      var a = this;
      this.H = "";
      mk.K &&
        N(516) &&
        Zp(function () {
          var b = [];
          a.H && b.push(["psd", a.H]);
          return b;
        });
    },
    HE;
  function IE() {
    return !1;
  }
  function JE() {
    var a = {};
    return function (b, c, d) {};
  }
  function KE() {
    var a = LE;
    return function (b, c, d) {
      var e = d && d.event;
      ME(c);
      var f = rh(b) ? void 0 : 1,
        g = new kb();
      Gb(c, function (r, t) {
        var v = Ud(t, void 0, f);
        v === void 0 && t !== void 0 && T(44);
        g.set(r, v);
      });
      a.Tb(Pf());
      var h = {
        ko: fg(b),
        eventId: e == null ? void 0 : e.id,
        priorityId: e !== void 0 ? e.priorityId : void 0,
        Qg:
          e !== void 0
            ? function (r) {
                e.od.Qg(r);
              }
            : void 0,
        Sb: function () {
          return b;
        },
        log: function () {},
        ks: {
          index: d == null ? void 0 : d.index,
          type: d == null ? void 0 : d.type,
          name: d == null ? void 0 : d.name,
        },
        Kt: !!xB(b, 3),
        originalEventData: e == null ? void 0 : e.originalEventData,
      };
      e &&
        e.cachedModelValues &&
        (h.cachedModelValues = {
          gtm: e.cachedModelValues.gtm,
          ecommerce: e.cachedModelValues.ecommerce,
        });
      if (IE()) {
        var l = JE(),
          m,
          p;
        h.Hb = {
          Vk: [],
          Tg: {},
          rc: function (r, t, v) {
            t === 1 && (m = r);
            t === 7 && (p = v);
            l(r, t, v);
          },
          Mi: Lh(),
        };
        h.log = function (r) {
          var t = Pa.apply(1, arguments);
          m && l(m, 4, { level: r, source: p, message: t });
        };
      }
      var q = rf(a, h, [b, g]);
      a.Tb();
      q instanceof Ta && (q.type === "return" ? (q = q.data) : (q = void 0));
      return B(q, void 0, f);
    };
  }
  function ME(a) {
    var b = a.gtmOnSuccess,
      c = a.gtmOnFailure;
    yb(b) &&
      (a.gtmOnSuccess = function () {
        ed(b);
      });
    yb(c) &&
      (a.gtmOnFailure = function () {
        ed(c);
      });
  }
  function NE() {
    return Math.floor(Math.random() * 20);
  }
  var OE = [H.D.ej].map(function (a) {
    return a.slice(2);
  });
  function QE(a) {}
  QE.P = "internal.addAdsClickIds";
  function RE(a, b) {
    var c = this;
  }
  RE.publicName = "addConsentListener";
  var SE = !1;
  function WE(a) {
    for (var b = 0; b < a.length; ++b)
      if (SE)
        try {
          a[b]();
        } catch (c) {
          T(77);
        }
      else a[b]();
  }
  function XE(a, b, c) {
    var d = this,
      e;
    return e;
  }
  XE.P = "internal.addDataLayerEventListener";
  function YE(a, b, c) {}
  YE.publicName = "addDocumentEventListener";
  function ZE(a, b, c, d) {}
  ZE.publicName = "addElementEventListener";
  function $E(a) {
    return a.T.Eb();
  }
  function aF(a) {}
  aF.publicName = "addEventCallback";
  function lF(a) {
    if (a.form) {
      var b;
      return ((b = a.form) == null ? 0 : b.tagName)
        ? a.form
        : z.getElementById(a.form);
    }
    return kd(a, ["form"], 100);
  }
  function pF(a) {}
  pF.P = "internal.addFormAbandonmentListener";
  function qF(a, b, c, d) {}
  qF.P = "internal.addFormData";
  var rF = {},
    sF = [],
    tF = {},
    uF = 0,
    vF = 0;
  function CF(a, b) {}
  CF.P = "internal.addFormInteractionListener";
  function JF(a, b) {}
  JF.P = "internal.addFormSubmitListener";
  function OF(a) {}
  OF.P = "internal.addGaSendListener";
  function PF(a) {
    if (!a) return {};
    var b = a.ks;
    return wB(b.type, b.index, b.name);
  }
  function QF(a) {
    return a ? { originatingEntity: PF(a) } : {};
  }
  function YF(a) {
    var b = En("zones");
    return b
      ? b.getIsAllowedFn(ul(), a)
      : function () {
          return !0;
        };
  }
  function ZF() {
    var a = En("zones");
    a && a.unregisterChild(ul());
  }
  function $F() {
    YB(tl(), function (a) {
      var b = a.originalEventData["gtm.uniqueEventId"],
        c = En("zones");
      return c ? c.isActive(ul(), b) : !0;
    });
    VB(tl(), function (a) {
      var b, c;
      b = a.entityId;
      c = a.securityGroups;
      return YF(Number(a.originalEventData["gtm.uniqueEventId"]))(b, c);
    });
  }
  var aG = function (a, b) {
    this.tagId = a;
    this.canonicalId = b;
  };
  function bG(a, b) {
    var c = this;
    return a;
  }
  bG.P = "internal.loadGoogleTag";
  function cG(a) {
    return new Md("", function (b) {
      var c = this.evaluate(b);
      if (c instanceof Md)
        return new Md("", function () {
          var d = Pa.apply(0, arguments),
            e = this,
            f = Gd($E(this), null);
          f.eventId = a.eventId;
          f.priorityId = a.priorityId;
          f.originalEventData = a.originalEventData;
          var g = d.map(function (l) {
              return e.evaluate(l);
            }),
            h = this.T.Db();
          h.Ee(f);
          return c.Tc.apply(c, [h].concat(za(g)));
        });
    });
  }
  function dG(a, b, c) {
    var d = this;
  }
  dG.P = "internal.addGoogleTagRestriction";
  function kG(a, b) {}
  kG.P = "internal.addHistoryChangeListener";
  function lG(a, b, c) {}
  lG.publicName = "addWindowEventListener";
  function mG(a, b) {
    return !0;
  }
  mG.publicName = "aliasInWindow";
  function nG(a, b, c) {}
  nG.P = "internal.appendRemoteConfigParameter";
  function oG(a) {
    var b;
    return b;
  }
  oG.publicName = "callInWindow";
  function pG(a) {}
  pG.publicName = "callLater";
  function qG(a) {}
  qG.P = "callOnDomReady";
  function rG(a) {}
  rG.P = "callOnWindowLoad";
  function uG(a, b) {
    return c;
  }
  uG.P = "internal.claimDestination";
  function vG(a, b) {
    var c;
    return c;
  }
  vG.P = "internal.computeGtmParameter";
  function wG(a, b) {
    var c = this;
  }
  wG.P = "internal.consentScheduleFirstTry";
  function xG(a, b) {
    var c = this;
  }
  xG.P = "internal.consentScheduleRetry";
  function yG(a) {
    var b;
    return b;
  }
  yG.P = "internal.copyFromCrossContainerData";
  function zG(a, b) {
    var c;
    if (!ch(a) || (!hh(b) && b !== null && !Yg(b)))
      throw L(this.getName(), ["string", "number|undefined"], arguments);
    M(this, "read_data_layer", a);
    var d;
    (b || 2) !== 2 ? (d = Kp(a, 1)) : (d = Gp(Hp, a, [w, z]));
    c = d;
    var e = Ud(c, this.T, rh($E(this).Sb()) ? 2 : 1);
    e === void 0 && c !== void 0 && T(45);
    return e;
  }
  zG.publicName = "copyFromDataLayer";
  function AG(a) {
    var b = void 0;
    return b;
  }
  AG.P = "internal.copyFromDataLayerCache";
  function BG(a) {
    var b;
    return b;
  }
  BG.publicName = "copyFromWindow";
  function CG(a) {
    var b = void 0;
    return Ud(b, this.T, 1);
  }
  CG.P = "internal.copyKeyFromWindow";
  var DG = function (a) {
    return a === Ol.ja.cb && fm.H[a] === Nl.La.df && !Ao(H.D.da);
  };
  var EG = function () {
      return "0";
    },
    FG = function (a) {
      if (typeof a !== "string") return "";
      var b = ["gclid", "dclid", "wbraid", "_gl"];
      N(102) && b.push("gbraid");
      return Pj(a, b, "0");
    };
  var GG = {},
    HG = {},
    IG = {},
    JG = {},
    KG = {},
    LG = {},
    MG = {},
    NG = {},
    OG = {},
    PG = {},
    QG = {},
    RG = {},
    SG = {},
    TG = {},
    UG = {},
    VG = {},
    WG = {},
    XG = {},
    YG = {},
    ZG = {},
    $G = {},
    aH = {},
    bH = {},
    cH = {},
    dH = {},
    eH = {},
    fH =
      ((eH[H.D.Ua] = ((GG[2] = [DG]), GG)),
      (eH[H.D.qg] = ((HG[2] = [DG]), HG)),
      (eH[H.D.oj] = ((IG[2] = [DG]), IG)),
      (eH[H.D.Cm] = ((JG[2] = [DG]), JG)),
      (eH[H.D.Dm] = ((KG[2] = [DG]), KG)),
      (eH[H.D.Em] = ((LG[2] = [DG]), LG)),
      (eH[H.D.Fm] = ((MG[2] = [DG]), MG)),
      (eH[H.D.Gm] = ((NG[2] = [DG]), NG)),
      (eH[H.D.ae] = ((OG[2] = [DG]), OG)),
      (eH[H.D.tg] = ((PG[2] = [DG]), PG)),
      (eH[H.D.ug] = ((QG[2] = [DG]), QG)),
      (eH[H.D.vg] = ((RG[2] = [DG]), RG)),
      (eH[H.D.wg] = ((SG[2] = [DG]), SG)),
      (eH[H.D.xg] = ((TG[2] = [DG]), TG)),
      (eH[H.D.yg] = ((UG[2] = [DG]), UG)),
      (eH[H.D.zg] = ((VG[2] = [DG]), VG)),
      (eH[H.D.Ag] = ((WG[2] = [DG]), WG)),
      (eH[H.D.yb] = ((XG[1] = [DG]), XG)),
      (eH[H.D.Hd] = ((YG[1] = [DG]), YG)),
      (eH[H.D.Nd] = ((ZG[1] = [DG]), ZG)),
      (eH[H.D.Pe] = (($G[1] = [DG]), $G)),
      (eH[H.D.Pf] =
        ((aH[1] = [
          function (a) {
            return N(102) && DG(a);
          },
        ]),
        aH)),
      (eH[H.D.Zc] = ((bH[1] = [DG]), bH)),
      (eH[H.D.Ea] = ((cH[1] = [DG]), cH)),
      (eH[H.D.hb] = ((dH[1] = [DG]), dH)),
      eH),
    gH = {},
    hH =
      ((gH[H.D.yb] = EG),
      (gH[H.D.Hd] = EG),
      (gH[H.D.Nd] = EG),
      (gH[H.D.Pe] = EG),
      (gH[H.D.Pf] = EG),
      (gH[H.D.Zc] = function (a) {
        if (!Fd(a)) return {};
        var b = Gd(a, null);
        delete b.match_id;
        return b;
      }),
      (gH[H.D.Ea] = FG),
      (gH[H.D.hb] = FG),
      gH),
    iH = {},
    jH = {},
    kH = ((jH[J.J.ib] = ((iH[2] = [DG]), iH)), jH),
    lH = {};
  var mH = function (a, b, c, d) {
    this.H = a;
    this.O = b;
    this.V = c;
    this.Z = d;
  };
  mH.prototype.getValue = function (a) {
    a = a === void 0 ? Ol.ja.ld : a;
    if (
      !this.O.some(function (b) {
        return b(a);
      })
    )
      return this.V.some(function (b) {
        return b(a);
      })
        ? this.Z(this.H)
        : this.H;
  };
  mH.prototype.K = function () {
    return Dd(this.H) === "array" || Fd(this.H) ? Gd(this.H, null) : this.H;
  };
  var nH = function () {},
    oH = function (a, b) {
      this.conditions = a;
      this.H = b;
    };
  oH.prototype.Ma = function (a, b) {
    var c,
      d = ((c = this.conditions[a]) == null ? void 0 : c[2]) || [],
      e,
      f = ((e = this.conditions[a]) == null ? void 0 : e[1]) || [];
    return new mH(b, d, f, this.H[a] || nH);
  };
  var pH, qH;
  var sH = function (a) {
      a.K = !0;
      a.H = !1;
      if (Hf(52)) {
        if (N(516) && rH()) {
          var b;
          a.settings = (b = data.productSettings) != null ? b : {};
          a.H = !0;
        } else {
          var c;
          a.settings = (c = productSettings) != null ? c : {};
        }
        productSettings = void 0;
        data.productSettings = void 0;
        var d;
        (d = HE) != null && mk.K && N(516) && (d.H = a.H ? "1" : "0");
      }
    },
    uH = function (a) {
      var b = tH;
      b.K || sH(b);
      return b.settings[a];
    },
    tH = new (function () {
      this.settings = {};
      this.K = this.H = !1;
    })();
  function rH() {
    if (!data.productSettings && !productSettings) return !0;
    if (
      !data.productSettings ||
      !productSettings ||
      Object.keys(data.productSettings).length !==
        Object.keys(productSettings).length
    )
      return !1;
    for (var a in productSettings)
      if (
        !data.productSettings.hasOwnProperty(a) ||
        data.productSettings[a].preAutoPii !== productSettings[a].preAutoPii
      )
        return !1;
    return !0;
  }
  var vH = function (a, b, c) {
      this.eventName = b;
      this.M = c;
      this.H = {};
      this.isAborted = !1;
      this.target = a;
      this.metadata = {};
      for (
        var d = c.eventMetadata || {}, e = n(Object.keys(d)), f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = f.value;
        U(this, g, d[g]);
      }
    },
    Ei = function (a, b) {
      var c, d;
      return (c = a.H[b]) == null
        ? void 0
        : (d = c.getValue) == null
        ? void 0
        : d.call(c, P(a, J.J.Ng));
    },
    Sv = function (a) {
      return Object.keys(a.H);
    },
    W = function (a, b, c) {
      var d = a.H,
        e;
      c === void 0
        ? (e = void 0)
        : (pH != null || (pH = new oH(fH, hH)), (e = pH.Ma(b, c)));
      d[b] = e;
    };
  vH.prototype.mergeHitDataForKey = function (a, b) {
    var c, d, e;
    c =
      (d = this.H[a]) == null ? void 0 : (e = d.K) == null ? void 0 : e.call(d);
    if (!c) return W(this, a, b), !0;
    if (!Fd(c)) return !1;
    W(this, a, ma(Object, "assign").call(Object, c, b));
    return !0;
  };
  var wH = function (a, b) {
    b = b === void 0 ? {} : b;
    for (var c = n(Object.keys(a.H)), d = c.next(); !d.done; d = c.next()) {
      var e = d.value,
        f = void 0,
        g = void 0,
        h = void 0;
      b[e] =
        (f = a.H[e]) == null
          ? void 0
          : (h = (g = f).K) == null
          ? void 0
          : h.call(g);
    }
    return b;
  };
  vH.prototype.copyToHitData = function (a, b, c) {
    var d = R(this.M, a);
    d === void 0 && (d = b);
    if (zb(d) && c !== void 0)
      try {
        d = c(d);
      } catch (e) {}
    d !== void 0 && W(this, a, d);
  };
  var P = function (a, b) {
      var c = a.metadata[b];
      if (b === J.J.Ng) {
        var d;
        return c == null ? void 0 : (d = c.K) == null ? void 0 : d.call(c);
      }
      var e;
      return c == null
        ? void 0
        : (e = c.getValue) == null
        ? void 0
        : e.call(c, P(a, J.J.Ng));
    },
    U = function (a, b, c) {
      var d = a.metadata,
        e;
      c === void 0
        ? (e = c)
        : (qH != null || (qH = new oH(kH, lH)), (e = qH.Ma(b, c)));
      d[b] = e;
    },
    xH = function (a, b) {
      b = b === void 0 ? {} : b;
      for (
        var c = n(Object.keys(a.metadata)), d = c.next();
        !d.done;
        d = c.next()
      ) {
        var e = d.value,
          f = void 0,
          g = void 0,
          h = void 0;
        b[e] =
          (f = a.metadata[e]) == null
            ? void 0
            : (h = (g = f).K) == null
            ? void 0
            : h.call(g);
      }
      return b;
    },
    yH = function (a, b, c) {
      var d = uH(a.target.destinationId);
      return d && d[b] !== void 0 ? d[b] : c;
    },
    zH = function (a, b) {
      for (
        var c = new vH(a.target, a.eventName, b || a.M),
          d = wH(a),
          e = n(Object.keys(d)),
          f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = f.value;
        W(c, g, d[g]);
      }
      for (
        var h = xH(a), l = n(Object.keys(h)), m = l.next();
        !m.done;
        m = l.next()
      ) {
        var p = m.value;
        U(c, p, h[p]);
      }
      c.isAborted = a.isAborted;
      return c;
    },
    AH = function (a) {
      var b = a.M,
        c = b.eventId,
        d = b.priorityId;
      return d ? c + "_" + d : String(c);
    };
  vH.prototype.accept = function () {
    var a = aj(Wi.ia.vj, {}),
      b = AH(this),
      c = this.target.destinationId;
    a[b] || (a[b] = {});
    a[b][c] = tl();
    var d = Wi.ia.vj;
    if (Xi(d)) {
      var e;
      (e = Yi(d)) == null || e.notify();
    }
  };
  vH.prototype.canBeAccepted = function (a) {
    var b = $i(Wi.ia.vj);
    if (!b) return !0;
    var c = b[AH(this)];
    if (!c) return !0;
    var d = c[a != null ? a : this.target.destinationId];
    return d === void 0 || d === tl();
  };
  function BH(a) {
    return {
      getDestinationId: function () {
        return a.target.destinationId;
      },
      getEventName: function () {
        return a.eventName;
      },
      setEventName: function (b) {
        a.eventName = b;
      },
      getHitData: function (b) {
        return Ei(a, b);
      },
      setHitData: function (b, c) {
        W(a, b, c);
      },
      setHitDataIfNotDefined: function (b, c) {
        Ei(a, b) === void 0 && W(a, b, c);
      },
      copyToHitData: function (b, c) {
        a.copyToHitData(b, c);
      },
      getMetadata: function (b) {
        return P(a, b);
      },
      setMetadata: function (b, c) {
        U(a, b, c);
      },
      isAborted: function () {
        return a.isAborted;
      },
      abort: function () {
        a.isAborted = !0;
      },
      getFromEventContext: function (b) {
        return R(a.M, b);
      },
      wb: function () {
        return a;
      },
      getHitKeys: function () {
        return Sv(a);
      },
      getMergedValues: function (b) {
        return a.M.getMergedValues(b, 3);
      },
      mergeHitDataForKey: function (b, c) {
        return Fd(c) ? a.mergeHitDataForKey(b, c) : !1;
      },
      accept: function () {
        a.accept();
      },
      canBeAccepted: function (b) {
        return a.canBeAccepted(b);
      },
    };
  }
  function CH(a, b) {
    var c;
    return c;
  }
  CH.P = "internal.copyPreHit";
  function DH(a, b) {
    var c = null;
    return Ud(c, this.T, 2);
  }
  DH.publicName = "createArgumentsQueue";
  function EH(a) {
    return Ud(
      function (c) {
        var d = FB();
        if (typeof c === "function")
          d(function () {
            c(function (f, g, h) {
              var l = FB(),
                m = l && l.getByName && l.getByName(f);
              return new w.gaplugins.Linker(m).decorate(g, h);
            });
          });
        else if (Array.isArray(c)) {
          var e = String(c[0]).split(".");
          b[e.length === 1 ? e[0] : e[1]] && d.apply(null, c);
        } else if (c === "isLoaded") return !!d.loaded;
      },
      this.T,
      1
    );
  }
  EH.P = "internal.createGaCommandQueue";
  function FH(a) {
    return Ud(
      function () {
        if (!yb(e.push))
          throw Error("Object at " + a + " in window is not an array.");
        e.push.apply(e, Array.prototype.slice.call(arguments, 0));
      },
      this.T,
      rh($E(this).Sb()) ? 2 : 1
    );
  }
  FH.publicName = "createQueue";
  function GH(a, b) {
    var c = null;
    if (!ch(a) || !dh(b))
      throw L(this.getName(), ["string", "string|undefined"], arguments);
    try {
      var d = (b || "")
        .split("")
        .filter(function (e) {
          return "ig".indexOf(e) >= 0;
        })
        .join("");
      c = new Rd(new RegExp(a, d));
    } catch (e) {}
    return c;
  }
  GH.P = "internal.createRegex";
  function HH(a) {}
  HH.P = "internal.declareConsentState";
  function IH(a) {
    var b = "";
    return b;
  }
  IH.P = "internal.decodeUrlHtmlEntities";
  function JH(a, b, c) {
    var d;
    return d;
  }
  JH.P = "internal.decorateUrlWithGaCookies";
  function KH() {}
  KH.P = "internal.deferCustomEvents";
  function LH(a, b) {
    try {
      return a.closest(b);
    } catch (c) {
      return null;
    }
  }
  function MH() {
    var a = w.screen;
    return { width: a ? a.width : 0, height: a ? a.height : 0 };
  }
  function NH(a) {
    if (z.hidden) return !0;
    var b = a.getBoundingClientRect();
    if (b.top === b.bottom || b.left === b.right || !w.getComputedStyle)
      return !0;
    var c = w.getComputedStyle(a, null);
    if (c.visibility === "hidden") return !0;
    for (var d = a, e = c; d; ) {
      if (e.display === "none") return !0;
      var f = e.opacity,
        g = e.filter;
      if (g) {
        var h = g.indexOf("opacity(");
        h >= 0 &&
          ((g = g.substring(h + 8, g.indexOf(")", h))),
          g.charAt(g.length - 1) === "%" && (g = g.substring(0, g.length - 1)),
          (f = String(Math.min(Number(g), Number(f)))));
      }
      if (f !== void 0 && Number(f) <= 0) return !0;
      (d = d.parentElement) && (e = w.getComputedStyle(d, null));
    }
    return !1;
  }
  function QI(a) {
    var b;
    return b;
  }
  QI.P = "internal.detectUserProvidedData";
  function VI(a, b) {
    return f;
  }
  VI.P = "internal.enableAutoEventOnClick";
  function bJ(a, b) {
    return p;
  }
  bJ.P = "internal.enableAutoEventOnElementVisibility";
  function cJ() {}
  cJ.P = "internal.enableAutoEventOnError";
  function iJ(a, b) {
    var c = this;
    return d;
  }
  iJ.P = "internal.enableAutoEventOnFormInteraction";
  function nJ(a, b) {
    var c = this;
    return f;
  }
  nJ.P = "internal.enableAutoEventOnFormSubmit";
  function sJ() {
    var a = this;
  }
  sJ.P = "internal.enableAutoEventOnGaSend";
  function zJ(a, b) {
    var c = this;
    return f;
  }
  zJ.P = "internal.enableAutoEventOnHistoryChange";
  var AJ = ["http://", "https://", "javascript:", "file://"];
  function EJ(a, b) {
    var c = this;
    return h;
  }
  EJ.P = "internal.enableAutoEventOnLinkClick";
  function PJ(a, b) {
    var c = this;
    return g;
  }
  PJ.P = "internal.enableAutoEventOnScroll";
  function QJ(a) {
    return function () {
      if (a.limit && a.Kk >= a.limit) a.Ii && w.clearInterval(a.Ii);
      else {
        a.Kk++;
        var b = Ob();
        AD({
          event: a.eventName,
          "gtm.timerId": a.Ii,
          "gtm.timerEventNumber": a.Kk,
          "gtm.timerInterval": a.interval,
          "gtm.timerLimit": a.limit,
          "gtm.timerStartTime": a.jp,
          "gtm.timerCurrentTime": b,
          "gtm.timerElapsedTime": b - a.jp,
          "gtm.triggers": a.du,
        });
      }
    };
  }
  function RJ(a, b) {
    return f;
  }
  RJ.P = "internal.enableAutoEventOnTimer";
  var Fc = Ba(["data-gtm-yt-inspected-"]),
    TJ = ["www.youtube.com", "www.youtube-nocookie.com"],
    UJ;
  function dK(a, b) {
    var c = this;
    return e;
  }
  dK.P = "internal.enableAutoEventOnYouTubeActivity";
  function eK(a, b) {
    if (!ch(a) || !Xg(b))
      throw L(this.getName(), ["string", "Object|undefined"], arguments);
    var c = b ? B(b) : {},
      d = a,
      e = !1;
    return e;
  }
  eK.P = "internal.evaluateBooleanExpression";
  function fK(a) {
    var b = !1;
    return b;
  }
  fK.P = "internal.evaluateMatchingRules";
  var gK = new Map([["aw", 4]]);
  function hK(a) {
    var b = Vt[a],
      c = gK.get(a);
    return c
      ? (Ht(b, c) || []).some(function (d) {
          return d.m === "0" || d.m === void 0;
        })
      : !1;
  }
  function iK(a, b) {
    if (N(495)) {
      for (var c = new Map(), d = n(gK), e = d.next(); !e.done; e = d.next()) {
        var f = n(e.value),
          g = f.next().value,
          h = f.next().value,
          l = g,
          m = a[l],
          p = Array.isArray(m) ? m[0] : m;
        if (p !== void 0) {
          var q = {},
            r =
              ((q.k = p),
              (q.i = String(Math.floor(Date.now() / 1e3))),
              (q.b = []),
              (q.m = "1"),
              q),
            t = Et(r, h);
          t && (hK(l) || c.set(l, t));
        }
      }
      if (c.size) {
        var v,
          u = new URLSearchParams();
        b.path ? u.set("p", b.path) : u.set("p", "/");
        b.Sr && u.set("ce", String(b.Sr));
        b.domain && b.domain !== "auto"
          ? u.set("d", b.domain)
          : u.set("d", "auto:" + w.location.hostname);
        for (var x = n(c), y = x.next(); !y.done; y = x.next()) {
          var A = n(y.value),
            C = A.next().value,
            D = A.next().value;
          u.set(C, D);
        }
        v = "_/set_cookie?" + u.toString();
        var E,
          G = F(58);
        E = Df(v, G);
        var I = Uj() + "/" + E;
        od(I);
      }
    }
  }
  function jK(a) {
    return "CWVWebViewMessage" in a;
  }
  function kK(a) {
    var b = window,
      c = b.webkit;
    delete b.webkit;
    a(b.webkit);
    b.webkit = c;
  }
  function lK(a, b) {
    var c = { action: "gcl_setup" };
    if (jK(a.messageHandlers))
      return (
        a.messageHandlers.CWVWebViewMessage.postMessage({
          command: b,
          payload: c,
        }),
        !0
      );
    var d = a.messageHandlers[b];
    return d ? (d.postMessage(c), !0) : !1;
  }
  var mK = {},
    nK = ((mK.awb = { notFound: 178 }), (mK.ytb = { notFound: 194 }), mK);
  function oK() {
    return ["ad_storage", "ad_user_data"];
  }
  function pK(a) {
    var b,
      c = (b = nK[a]) == null ? void 0 : b.notFound;
    c && T(c);
  }
  function qK(a) {
    if (!$i(Wi.ia.Bn) && "webkit" in window && window.webkit.messageHandlers) {
      var b = function () {
        try {
          kK(function (c) {
            if (c) {
              var d;
              d =
                jK(c.messageHandlers) || "awb" in c.messageHandlers
                  ? { command: "awb", source: 5 }
                  : (jK(c.messageHandlers) || "ytb" in c.messageHandlers) &&
                    N(499)
                  ? { command: "ytb", source: 8 }
                  : void 0;
              d &&
                (Zi(Wi.ia.Bn, function (e) {
                  var f = d.source;
                  e.gclid && Lu("gcl_aw", e.gclid, f, a);
                  e.wbraid && Lu("gcl_gb", e.wbraid, f, a);
                }),
                lK(c, d.command) || pK(d.command));
            }
          });
        } catch (c) {
          T(193);
        }
      };
      cm(function () {
        au(oK()) ? b() : dm(b, oK());
      }, oK());
    }
  }
  var rK = [
    "https://www.google.com",
    "https://www.youtube.com",
    "https://m.youtube.com",
  ];
  function sK(a) {
    return a.data.action !== "gcl_transfer"
      ? (T(173), !0)
      : a.data.gadSource
      ? a.data.gclid
        ? !1
        : (T(181), !0)
      : (T(180), !0);
  }
  function tK(a, b) {
    if (!a || N(a)) {
      if ($i(Wi.ia.ff)) return T(176), Wi.ia.ff;
      if ($i(Wi.ia.En)) return T(170), Wi.ia.ff;
      var c = yq();
      if (!c) T(171);
      else if (c.opener) {
        var d = function (g) {
          if (!rK.includes(g.origin)) T(172);
          else if (!sK(g)) {
            var h = { gadSource: g.data.gadSource };
            h.gclid = g.data.gclid;
            Zi(Wi.ia.ff, h);
            b && g.data.gclid && Lu("gcl_aw", String(g.data.gclid), 6, b);
            var l;
            (l = g.stopImmediatePropagation) == null || l.call(g);
            Lq(c, "message", d);
          }
        };
        if (Kq(c, "message", d)) {
          Zi(Wi.ia.En, !0);
          for (var e = n(rK), f = e.next(); !f.done; f = e.next())
            c.opener.postMessage({ action: "gcl_setup" }, f.value);
          T(174);
          return Wi.ia.ff;
        }
        T(175);
      }
    }
  }
  function GK() {
    return ir(7) && ir(9) && ir(10);
  }
  var MK = function (a, b) {
      a &&
        (LK("sid", a.targetId, b),
        LK("cc", a.clientCount, b),
        LK("tl", a.totalLifeMs, b),
        LK("hc", a.heartbeatCount, b),
        LK("cl", a.clientLifeMs, b));
    },
    LK = function (a, b, c) {
      b != null && c.push(a + "=" + b);
    },
    NK = function () {
      var a = z.referrer;
      if (a) {
        var b;
        return Ij(Oj(a), "host") ===
          ((b = w.location) == null ? void 0 : b.host)
          ? 1
          : 2;
      }
      return 0;
    },
    PK = function () {
      this.la = OK;
      this.O = 0;
      this.ya = Mf(57, 5);
      this.V = Mf(58, 50);
      this.ka = Db();
      this.Va = "https://" + F(21) + "/a?";
    };
  PK.prototype.K = function (a, b, c, d) {
    var e = NK(),
      f,
      g = [];
    f =
      w === w.top && e !== 0 && b
        ? (b == null ? void 0 : b.clientCount) > 1
          ? e === 2
            ? 1
            : 2
          : e === 2
          ? 0
          : 3
        : 4;
    a && LK("si", a.nh, g);
    LK("m", 0, g);
    LK("iss", f, g);
    LK("if", c, g);
    MK(b, g);
    d && LK("fm", encodeURIComponent(d.substring(0, this.V)), g);
    this.Z(g);
  };
  PK.prototype.H = function (a, b, c, d, e) {
    var f = [];
    LK("m", 1, f);
    LK("s", a, f);
    LK("po", NK(), f);
    b && (LK("st", b.state, f), LK("si", b.nh, f), LK("sm", b.Ah, f));
    MK(c, f);
    LK("c", d, f);
    e && LK("fm", encodeURIComponent(e.substring(0, this.V)), f);
    this.Z(f);
  };
  PK.prototype.Z = function (a) {
    a = a === void 0 ? [] : a;
    !mk.K ||
      this.O >= this.ya ||
      (LK("pid", this.ka, a),
      LK("bc", ++this.O, a),
      a.unshift("ctid=" + F(5) + "&t=s"),
      this.la("" + this.Va + a.join("&")));
  };
  function QK(a) {
    return (a.performance && a.performance.now()) || Date.now();
  }
  var RK = function (a, b) {
    var c = w,
      d = Mf(53, 500),
      e = Mf(54, 5e3),
      f = Mf(8, 20),
      g = Mf(55, 5e3),
      h;
    var l = function (m, p, q) {
      q =
        q === void 0
          ? {
              Io: function () {},
              Lo: function () {},
              Ho: function () {},
              onFailure: function () {},
            }
          : q;
      this.ek = m;
      this.H = p;
      this.O = q;
      this.ka = this.la = this.heartbeatCount = this.Yj = 0;
      this.nd = !1;
      this.K = {};
      this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
      this.state = 0;
      this.nh = QK(this.H);
      this.Ah = QK(this.H);
      this.Z = 10;
    };
    l.prototype.init = function () {
      this.V(1);
      this.ya();
    };
    l.prototype.getState = function () {
      return {
        state: this.state,
        nh: Math.round(QK(this.H) - this.nh),
        Ah: Math.round(QK(this.H) - this.Ah),
      };
    };
    l.prototype.V = function (m) {
      this.state !== m && ((this.state = m), (this.Ah = QK(this.H)));
    };
    l.prototype.oe = function () {
      return String(this.Yj++);
    };
    l.prototype.ya = function () {
      var m = this;
      this.heartbeatCount++;
      this.Rg(
        {
          type: 0,
          clientId: this.id,
          requestId: this.oe(),
          maxDelay: this.ne(),
        },
        function (p) {
          if (p.type === 0) {
            var q;
            if (((q = p.failure) == null ? void 0 : q.failureType) != null)
              if (
                (p.stats && (m.stats = p.stats), m.ka++, p.isDead || m.ka > f)
              ) {
                var r = p.isDead && p.failure.failureType;
                m.Z = r || 10;
                m.V(4);
                m.Xj();
                var t, v;
                (v = (t = m.O).Ho) == null ||
                  v.call(t, { failureType: r || 10, data: p.failure.data });
              } else m.V(3), m.Pg();
            else {
              if (m.heartbeatCount > p.stats.heartbeatCount + f) {
                m.heartbeatCount = p.stats.heartbeatCount;
                var u, x;
                (x = (u = m.O).onFailure) == null ||
                  x.call(u, { failureType: 13 });
              }
              m.stats = p.stats;
              var y = m.state;
              m.V(2);
              if (y !== 2)
                if (m.nd) {
                  var A, C;
                  (C = (A = m.O).Lo) == null || C.call(A);
                } else {
                  m.nd = !0;
                  var D, E;
                  (E = (D = m.O).Io) == null || E.call(D);
                }
              m.ka = 0;
              m.kk();
              m.Pg();
            }
          }
        }
      );
    };
    l.prototype.ne = function () {
      return this.state === 2 ? e : d;
    };
    l.prototype.Pg = function () {
      var m = this;
      this.H.setTimeout(function () {
        m.ya();
      }, Math.max(0, this.ne() - (QK(this.H) - this.la)));
    };
    l.prototype.Er = function (m, p, q) {
      var r = this;
      this.Rg(
        { type: 1, clientId: this.id, requestId: this.oe(), command: m },
        function (t) {
          if (t.type === 1)
            if (t.result) p(t.result);
            else {
              var v,
                u,
                x,
                y = {
                  failureType:
                    (x = (v = t.failure) == null ? void 0 : v.failureType) !=
                    null
                      ? x
                      : 12,
                  data: (u = t.failure) == null ? void 0 : u.data,
                },
                A,
                C;
              (C = (A = r.O).onFailure) == null || C.call(A, y);
              q(y);
            }
        }
      );
    };
    l.prototype.Rg = function (m, p) {
      var q = this;
      if (this.state === 4) (m.failure = { failureType: this.Z }), p(m);
      else {
        var r = this.state !== 2 && m.type !== 0,
          t = m.requestId,
          v,
          u = this.H.setTimeout(
            function () {
              var y = q.K[t];
              y && (Bm(6), q.jc(y, 7));
            },
            (v = m.maxDelay) != null ? v : g
          ),
          x = { request: m, bp: p, Uo: r, jt: u };
        this.K[t] = x;
        r || this.sendRequest(x);
      }
    };
    l.prototype.sendRequest = function (m) {
      this.la = QK(this.H);
      m.Uo = !1;
      this.ek(m.request);
    };
    l.prototype.kk = function () {
      for (
        var m = n(Object.keys(this.K)), p = m.next();
        !p.done;
        p = m.next()
      ) {
        var q = this.K[p.value];
        q.Uo && this.sendRequest(q);
      }
    };
    l.prototype.Xj = function () {
      for (var m = n(Object.keys(this.K)), p = m.next(); !p.done; p = m.next())
        this.jc(this.K[p.value], this.Z);
    };
    l.prototype.jc = function (m, p) {
      this.Va(m);
      var q = m.request;
      q.failure = { failureType: p };
      m.bp(q);
    };
    l.prototype.Va = function (m) {
      delete this.K[m.request.requestId];
      this.H.clearTimeout(m.jt);
    };
    l.prototype.Hs = function (m) {
      this.la = QK(this.H);
      var p = this.K[m.requestId];
      if (p) this.Va(p), p.bp(m);
      else {
        var q, r;
        (r = (q = this.O).onFailure) == null || r.call(q, { failureType: 14 });
      }
    };
    h = new l(a, c, b);
    return h;
  };
  var SK = function () {
      return uj(17, function () {
        return new PK();
      });
    },
    OK = function (a) {
      im(lm(Ol.ja.hc), function () {
        bd(a);
      });
    },
    TK = function (a) {
      var b = a.substring(0, a.indexOf("/_/service_worker"));
      return "&1p=1" + (b ? "&path=" + encodeURIComponent(b) : "");
    },
    UK = function (a) {
      var b = w.location.origin;
      if (!b) return null;
      (N(432) ? Tj() : Tj() && !a) && (a = "" + b + Uj() + "/_/service_worker");
      var c = a,
        d,
        e = Kf(11);
      e = Kf(10);
      d = e;
      c
        ? (c.charAt(c.length - 1) !== "/" && (c += "/"), (a = c + d))
        : (a =
            "https://www.googletagmanager.com/static/service_worker/" +
            d +
            "/");
      var f;
      try {
        f = new URL(a);
      } catch (g) {
        return null;
      }
      return f.protocol !== "https:" ? null : f;
    },
    VK = function (a) {
      var b = $i(Wi.ia.yi);
      return b && b[a];
    },
    WK = function (a) {
      var b = this;
      this.K = SK();
      this.Z = this.V = !1;
      this.ka = null;
      this.initTime = Math.round(Ob());
      this.H = 15;
      this.O = this.Wr(a);
      w.setTimeout(function () {
        b.initialize();
      }, 1e3);
      ed(function () {
        b.Ts(a);
      });
    };
  k = WK.prototype;
  k.delegate = function (a, b, c) {
    this.getState() !== 2
      ? (this.K.H(
          this.H,
          {
            state: this.getState(),
            nh: this.initTime,
            Ah: Math.round(Ob()) - this.initTime,
          },
          void 0,
          a.commandType
        ),
        c({ failureType: this.H }))
      : this.O.Er(a, b, c);
  };
  k.getState = function () {
    return this.O.getState().state;
  };
  k.Ts = function (a) {
    var b = w.location.origin,
      c = this,
      d = $c();
    try {
      var e = d.contentDocument.createElement("iframe"),
        f = a.pathname,
        g = f[f.length - 1] === "/" ? a.toString() : a.toString() + "/",
        h = a.origin !== "https://www.googletagmanager.com" ? TK(f) : "",
        l;
      N(133) && (l = { sandbox: "allow-same-origin allow-scripts" });
      $c(
        g + "sw_iframe.html?origin=" + encodeURIComponent(b) + h,
        void 0,
        l,
        void 0,
        e
      );
      var m = function () {
        d.contentDocument.body.appendChild(e);
        e.addEventListener("load", function () {
          c.ka = e.contentWindow;
          d.contentWindow.addEventListener("message", function (p) {
            p.origin === a.origin && c.O.Hs(p.data);
          });
          c.initialize();
        });
      };
      d.contentDocument.readyState === "complete"
        ? m()
        : d.contentWindow.addEventListener("load", function () {
            m();
          });
    } catch (p) {
      d.parentElement.removeChild(d),
        (this.H = 11),
        this.K.K(void 0, void 0, this.H, p.toString());
    }
  };
  k.Wr = function (a) {
    var b = this,
      c = RK(
        function (d) {
          var e;
          (e = b.ka) == null || e.postMessage(d, a.origin);
        },
        {
          Io: function () {
            b.V = !0;
            b.K.K(c.getState(), c.stats);
          },
          Lo: function () {},
          Ho: function (d) {
            b.V
              ? ((b.H = (d == null ? void 0 : d.failureType) || 10),
                b.K.H(
                  b.H,
                  c.getState(),
                  c.stats,
                  void 0,
                  d == null ? void 0 : d.data
                ))
              : ((b.H = (d == null ? void 0 : d.failureType) || 4),
                b.K.K(c.getState(), c.stats, b.H, d == null ? void 0 : d.data));
          },
          onFailure: function (d) {
            b.H = d.failureType;
            b.K.H(b.H, c.getState(), c.stats, d.command, d.data);
          },
        }
      );
    return c;
  };
  k.initialize = function () {
    this.Z || this.O.init();
    this.Z = !0;
  };
  var XK = function (a, b, c, d) {
    var e;
    if ((e = VK(a)) == null || !e.delegate) {
      var f = Nc() ? 16 : 6;
      SK().H(f, void 0, void 0, b.commandType);
      d({ failureType: f });
      return;
    }
    VK(a).delegate(b, c, d);
  };
  function YK(a, b, c, d) {
    var e = UK(a);
    if (e === null) {
      d("_is_sw=f" + (Nc() ? 16 : 6) + "te");
      return;
    }
    var f = b ? 1 : 0,
      g = Math.round(Ob()),
      h,
      l = (h = VK(e.origin)) == null ? void 0 : h.initTime,
      m = l ? g - l : void 0,
      p;
    N(432) ? (p = Tj() ? void 0 : w.location.href) : (p = w.location.href);
    XK(
      e.origin,
      {
        commandType: 0,
        params: {
          url: a,
          method: f,
          templates: c,
          body: b || "",
          processResponse: !0,
          reportEarlySuccess: !0,
          sinceInit: m,
          attributionReporting: !0,
          referer: p,
        },
      },
      function () {},
      function (q) {
        var r = "_is_sw=f" + q.failureType,
          t,
          v = (t = VK(e.origin)) == null ? void 0 : t.getState();
        v !== void 0 && (r += "s" + v);
        d(m ? r + ("t" + m) : r + "te");
      }
    );
  }
  function ZK(a) {
    if (Hf(47) && yH(a, "ccd_add_1p_data", !1) && Tj() && N(431)) {
      var b = a.M;
      if (Nc() && $f("internal_sw_allowed", "")) {
        var c = Zj(b),
          d = Tj() ? Uj() : void 0,
          e;
        e = d ? { path: d, wo: "full" } : c ? { path: c, wo: "lite" } : void 0;
        if (e) {
          var f = e.wo,
            g = new URL(e.path, w.location.origin);
          if (g.origin === w.location.origin && dz(f) === void 0) {
            var h = aj(Wi.ia.yi, {});
            h[f] || (h[f] = new bz(g));
          }
        }
      }
    }
  }
  function dL() {
    var a;
    a = a === void 0 ? document : a;
    var b;
    return !(
      (b = a.featurePolicy) == null ||
      !b.allowedFeatures().includes("attribution-reporting")
    );
  }
  function hL(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    var e = yq(),
      f = wq(e);
    if (f.url)
      if (d) {
        var g = c(f.url);
        b !== g && W(a, H.D.rg, g);
      } else {
        var h = f.url;
        b !== h && W(a, H.D.rg, c(h));
      }
  }
  function lL(a) {
    U(a, J.J.Ka, !0);
    U(a, J.J.Ab, Ob());
    U(a, J.J.Sn, a.M.eventMetadata[J.J.Ka]);
  }
  var EL = new (function () {
    this.H = {};
  })();
  function HL(a) {
    var b = wC(!1);
    if (b != null && b.status) {
      var c = { gtb: b.status };
      b.delay && (c.gtbd = b.delay);
      a.mergeHitDataForKey(H.D.fb, c);
    }
  }
  var JL = { Ta: { bl: 1, Tn: 2, bo: 3, co: 4, eo: 5, Qn: 6 } };
  JL.Ta[JL.Ta.bl] = "ADOBE_COMMERCE";
  JL.Ta[JL.Ta.Tn] = "SQUARESPACE";
  JL.Ta[JL.Ta.bo] = "WOO_COMMERCE";
  JL.Ta[JL.Ta.co] = "WOO_COMMERCE_LEGACY";
  JL.Ta[JL.Ta.eo] = "WORD_PRESS";
  JL.Ta[JL.Ta.Qn] = "SHOPIFY";
  function KL(a) {
    var b = w;
    return Hj(b.escape(b.atob(a)));
  }
  function LL() {
    try {
      if (!N(498) && !N(425)) return [];
      var a = $i(Wi.ia.Dn);
      if (Array.isArray(a)) return a;
      bs("4");
      var b = [],
        c;
      a: {
        try {
          c = !!z.querySelector('script[data-requiremodule^="mage/"]');
          break a;
        } catch (y) {}
        c = !1;
      }
      c && b.push(JL.Ta.bl);
      var d;
      a: {
        try {
          var e = KL("YXNzZXRzLnNxdWFyZXNwYWNlLmNvbS8=");
          d = e ? !!z.querySelector('script[src^="//' + e + '"]') : !1;
          break a;
        } catch (y) {}
        d = !1;
      }
      d && b.push(JL.Ta.Tn);
      var f;
      a: {
        if (N(425))
          try {
            var g = KL("c2hvcGlmeS5jb20="),
              h = KL("c2hvcGlmeWNkbi5jb20=");
            f =
              g && h
                ? !!z.querySelector(
                    'script[src*="cdn.' +
                      g +
                      '"],meta[property="og:image"][content*="cdn.' +
                      (g + '"],link[rel="preconnect"][href*="cdn.') +
                      (g + '"],link[rel="preconnect"][href*="fonts.') +
                      (h +
                        '"],link[rel="preconnect"][href*="iterable-shopify"],link[rel="preconnect"][href*="v.') +
                      (g + '"]')
                  )
                : !1;
            break a;
          } catch (y) {}
        f = !1;
      }
      f && b.push(JL.Ta.Qn);
      var l;
      a: {
        try {
          l = !!z.querySelector(
            'script[src*="woocommerce"],link[href*="woocommerce"],[class|="woocommerce"]'
          );
          break a;
        } catch (y) {}
        l = !1;
      }
      l && b.push(JL.Ta.co);
      var m;
      a: {
        try {
          var p,
            q = ((p = z.location) == null ? void 0 : p.hostname) || "",
            r,
            t = ((r = z.location) == null ? void 0 : r.origin) || "",
            v = KL("LndvcmRwcmVzcy5jb20="),
            u = KL("Ly9zLncub3Jn");
          m =
            v && u
              ? Vb(q, v) ||
                !!z.querySelector(
                  '[src^="' +
                    t +
                    '/wp-content"],meta[name="generator"][content^="WordPress "],link[rel="dns-prefetch"][href="' +
                    (u + '"]')
                )
              : !1;
          break a;
        } catch (y) {}
        m = !1;
      }
      m && b.push(JL.Ta.eo);
      var x;
      a: {
        try {
          x = !!z.querySelector(
            '[class*="woocommerce"],meta[name="generator"][content^="WooCommerce "]'
          );
          break a;
        } catch (y) {}
        x = !1;
      }
      x && b.push(JL.Ta.bo);
      cs("4");
      FC() && Zi(Wi.ia.Dn, b);
      return b;
    } catch (y) {}
    return [];
  }
  function fM(a) {
    if (N(425) && P(a, J.J.Rb)) {
      var b = Mf(67, 1500),
        c = a.mergeHitDataForKey,
        d = H.D.fb,
        e = {};
      c.call(a, d, e);
    }
  }
  var gM =
    "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(
      " "
    );
  function hM(a) {
    var b;
    return (b = a.google_tag_data) != null ? b : (a.google_tag_data = {});
  }
  function iM(a) {
    var b = a.google_tag_data,
      c;
    if (b != null && b.uach) {
      var d = b.uach,
        e = ma(Object, "assign").call(Object, {}, d);
      d.fullVersionList && (e.fullVersionList = d.fullVersionList.slice(0));
      c = e;
    } else c = null;
    return c;
  }
  function jM(a) {
    var b, c;
    return (c = (b = a.google_tag_data) == null ? void 0 : b.uach_promise) !=
      null
      ? c
      : null;
  }
  function kM(a) {
    var b, c;
    return (
      typeof ((b = a.navigator) == null
        ? void 0
        : (c = b.userAgentData) == null
        ? void 0
        : c.getHighEntropyValues) === "function"
    );
  }
  function lM(a) {
    if (!kM(a)) return null;
    var b = hM(a);
    if (b.uach_promise) return b.uach_promise;
    var c = a.navigator.userAgentData
      .getHighEntropyValues(gM)
      .then(function (d) {
        b.uach != null || (b.uach = d);
        return d;
      });
    return (b.uach_promise = c);
  }
  function qM(a, b) {
    b = b === void 0 ? !1 : b;
    var c = P(a, J.J.Mg),
      d = yH(a, "custom_event_accept_rules", !1) && !b;
    if (c) {
      var e = c.indexOf(a.target.destinationId) >= 0,
        f = !0;
      P(a, J.J.Qb) && (f = P(a, J.J.tb) === tl());
      e && f ? U(a, J.J.Qi, !0) : (U(a, J.J.Qi, !1), d || (a.isAborted = !0));
      if (a.canBeAccepted()) {
        var g = sl().indexOf(a.target.destinationId) >= 0,
          h = !1;
        if (!g) {
          var l,
            m =
              (l = ll(a.target.destinationId)) == null
                ? void 0
                : l.canonicalContainerId;
          m && (h = tl() === m);
        }
        g || h ? P(a, J.J.Qi) && a.accept() : (a.isAborted = !0);
      } else a.isAborted = !0;
    }
  }
  var xM = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
    yM = /^www.googleadservices.com$/;
  function zM(a) {
    a || (a = AM());
    return a.fu
      ? !1
      : a.Js ||
        a.Ks ||
        a.Ns ||
        a.Ls ||
        a.rf ||
        a.Di ||
        a.ws ||
        a.nc === "aw.ds" ||
        (N(235) && a.nc === "aw.dv") ||
        a.Bs
      ? !0
      : !1;
  }
  function AM() {
    var a = {},
      b = Ss(!0);
    a.fu = !!b._up;
    var c = Bu(),
      d = xv();
    a.Js = c.aw !== void 0;
    a.Ks = c.dc !== void 0;
    a.Ns = c.wbraid !== void 0;
    a.Ls = c.gbraid !== void 0;
    a.nc = typeof c.gclsrc === "string" ? c.gclsrc : void 0;
    a.rf = d.rf;
    a.Di = d.Di;
    var e = z.referrer ? Ij(Oj(z.referrer), "host") : "";
    a.Bs = xM.test(e);
    a.ws = yM.test(e);
    return a;
  }
  function BM() {
    var a = w.__uspapi;
    if (yb(a)) {
      var b = "";
      try {
        a("getUSPData", 1, function (c, d) {
          if (d && c) {
            var e = c.uspString;
            e && RegExp("^[\\da-zA-Z-]{1,20}$").test(e) && (b = e);
          }
        });
      } catch (c) {}
      return b;
    }
  }
  function FM(a) {
    if (mk.H)
      if (((xm.H = !0), a.eventName === H.D.xa)) Am(a.M, a.target.id);
      else {
        P(a, J.J.Vc) || (xm.K[a.target.id] = !0);
        var b = P(a, J.J.tb);
        KC(b);
      }
  }
  function KM(a, b) {
    return Cr("gsid_dc", {
      value: { joinId: a, lastJoinedTimeMs: b },
      expires: b + 3e5,
    }) === 0
      ? !0
      : !1;
  }
  var NM = { Rq: { mu: "cd", Bp: "ce", nu: "cf", ou: "cpf", pu: "cu" } };
  function PM(a, b) {
    b = b === void 0 ? !0 : b;
    var c = wb(rb.GTAG_EVENT_FEATURE_CHANNEL || []);
    c && (W(a, H.D.mg, c), b && ub());
  }
  function nO(a, b, c, d) {}
  nO.P = "internal.executeEventProcessor";
  function oO(a) {
    var b;
    return Ud(b, this.T, 1);
  }
  oO.P = "internal.executeJavascriptString";
  function pO(a) {
    var b;
    return b;
  }
  function qO(a) {
    var b = "";
    return b;
  }
  qO.P = "internal.generateClientId";
  function rO(a) {
    var b = {};
    return Ud(b);
  }
  rO.P = "internal.getAdsCookieWritingOptions";
  function sO(a, b) {
    var c = !1;
    return c;
  }
  sO.P = "internal.getAllowAdPersonalization";
  function tO() {
    var a;
    return a;
  }
  tO.P = "internal.getAndResetEventUsage";
  function uO(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    return c;
  }
  uO.P = "internal.getAuid";
  function vO() {
    var a = [];
    return Ud(a);
  }
  vO.P = "internal.getContainerIds";
  function wO() {
    var a = new kb();
    return a;
  }
  wO.publicName = "getContainerVersion";
  function xO(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    return c;
  }
  xO.publicName = "getCookieValues";
  function yO() {
    var a = "";
    return a;
  }
  yO.P = "internal.getCorePlatformServicesParam";
  function zO() {
    return Im();
  }
  zO.P = "internal.getCountryCode";
  function AO() {
    var a = [];
    return Ud(a);
  }
  AO.P = "internal.getDestinationIds";
  function BO(a) {
    var b = new kb();
    return b;
  }
  BO.P = "internal.getDeveloperIds";
  function CO(a) {
    var b;
    return b;
  }
  CO.P = "internal.getEcsidCookieValue";
  function DO(a, b) {
    var c = null;
    return c;
  }
  DO.P = "internal.getElementAttribute";
  function EO(a) {
    var b = null;
    return b;
  }
  EO.P = "internal.getElementById";
  function FO(a) {
    var b = "";
    return b;
  }
  FO.P = "internal.getElementInnerText";
  function GO(a) {
    var b = null;
    return b;
  }
  GO.P = "internal.getElementParent";
  function HO(a) {
    var b = null;
    return b;
  }
  HO.P = "internal.getElementPreviousSibling";
  function IO(a, b) {
    var c = null;
    return Ud(c);
  }
  IO.P = "internal.getElementProperty";
  function JO(a) {
    var b;
    return b;
  }
  JO.P = "internal.getElementValue";
  function KO(a) {
    var b = 0;
    return b;
  }
  KO.P = "internal.getElementVisibilityRatio";
  function LO(a) {
    var b = null;
    return b;
  }
  LO.P = "internal.getElementsByCssSelector";
  function MO(a) {
    var b;
    if (!ch(a)) throw L(this.getName(), ["string"], arguments);
    M(this, "read_event_data", a);
    var c;
    a: {
      var d = a,
        e = $E(this).originalEventData;
      if (e) {
        for (
          var f = e, g = {}, h = {}, l = {}, m = [], p = d.split("\\\\"), q = 0;
          q < p.length;
          q++
        ) {
          for (var r = p[q].split("\\."), t = 0; t < r.length; t++) {
            for (var v = r[t].split("."), u = 0; u < v.length; u++)
              m.push(v[u]), u !== v.length - 1 && m.push(l);
            t !== r.length - 1 && m.push(h);
          }
          q !== p.length - 1 && m.push(g);
        }
        for (
          var x = [], y = "", A = n(m), C = A.next();
          !C.done;
          C = A.next()
        ) {
          var D = C.value;
          D === l
            ? (x.push(y), (y = ""))
            : (y = D === g ? y + "\\" : D === h ? y + "." : y + D);
        }
        y && x.push(y);
        for (var E = n(x), G = E.next(); !G.done; G = E.next()) {
          if (f == null) {
            c = void 0;
            break a;
          }
          f = f[G.value];
        }
        c = f;
      } else c = void 0;
    }
    b = Ud(c, this.T, 1);
    return b;
  }
  MO.P = "internal.getEventData";
  function NO(a) {
    var b = null;
    return b;
  }
  NO.P = "internal.getFirstElementByCssSelector";
  function OO() {
    var a;
    return a;
  }
  OO.P = "internal.getGsaExperimentId";
  function PO() {
    return new Rd(Ln);
  }
  PO.P = "internal.getHtmlId";
  function QO(a) {
    var b;
    return b;
  }
  QO.P = "internal.getIframingState";
  function RO(a, b) {
    var c = {};
    return Ud(c);
  }
  RO.P = "internal.getLinkerValueFromLocation";
  function SO() {
    var a = new kb();
    return a;
  }
  SO.P = "internal.getPrivacyStrings";
  function TO(a, b) {
    var c;
    return c;
  }
  TO.P = "internal.getProductSettingsParameter";
  function UO(a, b) {
    var c;
    return c;
  }
  UO.publicName = "getQueryParameters";
  function VO(a, b) {
    var c;
    return c;
  }
  VO.publicName = "getReferrerQueryParameters";
  function WO(a) {
    var b = "";
    if (!dh(a)) throw L(this.getName(), ["string|undefined"], arguments);
    M(this, "get_referrer", a);
    b = Kj(Oj(z.referrer), a);
    return b;
  }
  WO.publicName = "getReferrerUrl";
  function XO() {
    return Jm();
  }
  XO.P = "internal.getRegionCode";
  function YO(a, b) {
    var c;
    return c;
  }
  YO.P = "internal.getRemoteConfigParameter";
  function ZO(a, b) {
    var c = null;
    return c;
  }
  ZO.P = "internal.getScopedElementsByCssSelector";
  function $O() {
    var a = new kb();
    a.set("width", 0);
    a.set("height", 0);
    return a;
  }
  $O.P = "internal.getScreenDimensions";
  function aP() {
    var a = "";
    return a;
  }
  aP.P = "internal.getTopSameDomainUrl";
  function bP() {
    var a = "";
    return a;
  }
  bP.P = "internal.getTopWindowUrl";
  function cP(a) {
    var b = "";
    if (!dh(a)) throw L(this.getName(), ["string|undefined"], arguments);
    M(this, "get_url", a);
    b = Ij(Oj(w.location.href), a);
    return b;
  }
  cP.publicName = "getUrl";
  function dP() {
    M(this, "get_user_agent");
    return Mc.userAgent;
  }
  dP.publicName = "getUserAgent";
  dP.P = "internal.getUserAgent";
  function eP() {
    var a;
    return a ? Ud(mM(a)) : a;
  }
  eP.P = "internal.getUserAgentClientHints";
  function hP() {
    var a = w;
    return (a.gaGlobal = a.gaGlobal || {});
  }
  function iP(a, b) {
    var c = hP();
    if (c.vid === void 0 || (b && !c.from_cookie))
      (c.vid = a), (c.from_cookie = b);
  }
  function KP(a) {
    (KK(a) || Tj()) && W(a, H.D.Im, Jm() || Im());
    !KK(a) && Tj() && W(a, H.D.Bj, "::");
  }
  function LP(a) {
    Tj() && (KK(a) || Mm() || W(a, H.D.om, !0));
  }
  function VQ(a) {
    a.copyToHitData(H.D.Ua);
    var b = R(a.M, H.D.be);
    b && (Dp(b, function () {}), W(a, H.D.be, b));
  }
  function YQ(a) {
    var b = function (c) {
      return !!c && c.conversion;
    };
    U(a, J.J.Eg, b(IK(a)));
    P(a, J.J.Fg) && U(a, J.J.un, b(IK(a, "first_visit")));
    P(a, J.J.cf) && U(a, J.J.wn, b(IK(a, "session_start")));
  }
  var cR = function (a) {
    for (
      var b = {}, c = String(bR.cookie).split(";"), d = 0;
      d < c.length;
      d++
    ) {
      var e = c[d].split("="),
        f = e[0].trim();
      if (f && a(f)) {
        var g = e.slice(1).join("=").trim();
        g && (g = decodeURIComponent(g));
        var h = void 0,
          l = void 0;
        ((h = b)[(l = f)] || (h[l] = [])).push(g);
      }
    }
    return b;
  };
  var dR = window,
    bR = document,
    eR = function (a) {
      var b = dR._gaUserPrefs;
      if (
        (b && b.ioo && b.ioo()) ||
        bR.documentElement.hasAttribute("data-google-analytics-opt-out") ||
        (a && dR["ga-disable-" + a] === !0)
      )
        return !0;
      try {
        var c = dR.external;
        if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0;
      } catch (f) {}
      for (
        var d =
            cR(function (f) {
              return f === "AMP_TOKEN";
            }).AMP_TOKEN || [],
          e = 0;
        e < d.length;
        e++
      )
        if (d[e] == "$OPT_OUT") return !0;
      return bR.getElementById("__gaOptOutExtension") ? !0 : !1;
    };
  var oR =
    "gclid dclid gclsrc wbraid gbraid gad_source gad_campaignid utm_source utm_medium utm_campaign utm_term utm_content utm_id".split(
      " "
    );
  function pR() {
    var a = z.location,
      b,
      c =
        a == null
          ? void 0
          : (b = a.search) == null
          ? void 0
          : b.replace("?", ""),
      d;
    if (c) {
      for (
        var e = [], f = Gj(c, !0), g = n(oR), h = g.next();
        !h.done;
        h = g.next()
      ) {
        var l = h.value,
          m = f[l];
        if (m)
          for (var p = 0; p < m.length; p++) {
            var q = m[p];
            q !== void 0 && e.push({ name: l, value: q });
          }
      }
      d = e;
    } else d = [];
    return d;
  }
  var rR = [H.D.sa, H.D.da],
    sR = [H.D.sa, H.D.da, H.D.fa];
  function tR(a) {
    var b,
      c = N(506) && !yH(a, "ccd_ga_ads_ids_opt_out", !1),
      d = !!yH(a, "google_ng", !1),
      e = Ao(c ? (d ? sR : ix) : rR),
      f;
    f = yH(a, H.D.lg, R(a.M, H.D.lg)) || !!yH(a, "google_ng", !1);
    b = {
      qh: c,
      Xs: d,
      ap: e,
      ph: f,
      Ki: !!yH(a, "ga4_ads_linked", !1),
      Ji: Km(),
      ik: !GK(),
      Ys: KK(a),
      Ws: !!P(a, J.J.fe),
      Zs: !!P(a, J.J.cf),
      Ms: !!R(a.M, H.D.hm),
      ft: !!P(a, J.J.Gj),
      Sg: R(a.M, H.D.Xc),
      Ir: R(a.M, H.D.Xc, void 0, 4),
      bt: !!P(a, J.J.Rb),
    };
    U(a, J.J.Ej, b.ph);
    U(a, J.J.Dj, uR(b));
    uR(b) && b.ap && (b.qh ? b.Sg !== !1 || b.Ki : 1) && U(a, J.J.Kn, !0);
    b.Xs && !b.Ji && W(a, H.D.We, 1);
    (b.qh ? b.Sg : b.Ir) === !1 && W(a, "_&ngs", "1");
    U(a, J.J.me, vR(b) && (b.Zs || b.Ms));
    U(a, J.J.Lg, vR(b) && b.ft && !b.Ji);
  }
  function uR(a) {
    return a.qh
      ? (a.Ki || a.ph) && !a.Ji && !a.ik
      : a.ph && a.Sg !== !1 && !a.ik && !a.Ji;
  }
  function vR(a) {
    if (a.bt) return !1;
    if (a.qh) {
      if (!a.ph && !a.Ki) return !1;
    } else if (!a.ph) return !1;
    return a.Ys ||
      a.Ws ||
      a.ik ||
      (a.qh ? a.Sg === !1 && !a.Ki : a.Sg === !1) ||
      !a.ap
      ? !1
      : !0;
  }
  function IR(a) {}
  function JR(a) {
    var b = function () {};
    return b;
  }
  function KR(a, b) {}
  var LR = K.U.Jl,
    MR = K.U.Kl;
  function NR(a, b) {
    var c = rl();
    c && c.indexOf(b) > -1 && (a[J.J.Qb] = !0);
  }
  function PR(a, b, c) {
    var d = this;
  }
  PR.P = "internal.gtagConfig";
  function QR(a, b, c) {
    var d = this;
  }
  QR.P = "internal.gtagDestinationConfig";
  function SR(a, b) {}
  SR.publicName = "gtagSet";
  function TR() {
    var a = {};
    return a;
  }
  function UR(a) {}
  UR.P = "internal.initializeServiceWorker";
  function VR(a, b) {}
  VR.publicName = "injectHiddenIframe";
  function WR(a, b, c, d, e) {}
  WR.P = "internal.injectHtml";
  var bS = { dl: 1, id: 1 };
  function cS(a, b, c, d) {}
  cS.publicName = "injectScript";
  function dS() {
    var a = Fm,
      b = !1;
    return b;
  }
  dS.P = "internal.isAutoPiiEligible";
  function eS(a) {
    var b = !0;
    return b;
  }
  eS.publicName = "isConsentGranted";
  function fS(a) {
    var b = !1;
    return b;
  }
  fS.P = "internal.isDebugMode";
  function gS() {
    return Lm();
  }
  gS.P = "internal.isDmaRegion";
  function hS() {
    return FC();
  }
  hS.P = "internal.isDomReady";
  function iS(a) {
    var b = !1;
    return b;
  }
  iS.P = "internal.isEntityInfrastructure";
  function jS(a) {
    var b = !1;
    return b;
  }
  jS.P = "internal.isFeatureEnabled";
  function kS() {
    var a = !1;
    return a;
  }
  kS.P = "internal.isFpfe";
  function lS() {
    var a = !1;
    return a;
  }
  lS.P = "internal.isGcpConversion";
  function mS() {
    var a = !1;
    return a;
  }
  mS.P = "internal.isLandingPage";
  function nS() {
    var a = !1;
    return a;
  }
  nS.P = "internal.isOgt";
  function oS() {
    var a;
    return a;
  }
  oS.P = "internal.isSafariPcmEligibleBrowser";
  function pS() {
    var a = Gh(function (b) {
      $E(this).log("error", b);
    });
    a.publicName = "JSON";
    return a;
  }
  function qS(a) {
    var b = void 0;
    if (!ch(a)) throw L(this.getName(), ["string"], arguments);
    b = Oj(a);
    return Ud(b);
  }
  qS.P = "internal.legacyParseUrl";
  function rS() {
    return !1;
  }
  var sS = {
    getItem: function (a) {
      var b = null;
      return b;
    },
    setItem: function (a, b) {
      return !1;
    },
    removeItem: function (a) {},
  };
  function tS() {}
  tS.publicName = "logToConsole";
  function uS(a, b) {}
  uS.P = "internal.mergeRemoteConfig";
  function vS(a, b, c) {
    c = c === void 0 ? !0 : c;
    var d = [];
    return Ud(d);
  }
  vS.P = "internal.parseCookieValuesFromString";
  function wS(a) {
    var b = void 0;
    if (typeof a !== "string") return;
    a && Ub(a, "//") && (a = z.location.protocol + a);
    if (typeof URL === "function") {
      var c;
      a: {
        var d;
        try {
          d = new URL(a);
        } catch (x) {
          c = void 0;
          break a;
        }
        for (
          var e = {}, f = Array.from(d.searchParams), g = 0;
          g < f.length;
          g++
        ) {
          var h = f[g][0],
            l = f[g][1];
          e.hasOwnProperty(h)
            ? typeof e[h] === "string"
              ? (e[h] = [e[h], l])
              : e[h].push(l)
            : (e[h] = l);
        }
        c = Ud({
          href: d.href,
          origin: d.origin,
          protocol: d.protocol,
          username: d.username,
          password: d.password,
          host: d.host,
          hostname: d.hostname,
          port: d.port,
          pathname: d.pathname,
          search: d.search,
          searchParams: e,
          hash: d.hash,
        });
      }
      return c;
    }
    var m;
    try {
      m = Oj(a);
    } catch (x) {
      return;
    }
    if (!m.protocol || !m.host) return;
    var p = {};
    if (m.search)
      for (
        var q = m.search.replace("?", "").split("&"), r = 0;
        r < q.length;
        r++
      ) {
        var t = q[r].split("="),
          v = t[0],
          u = Hj(t.splice(1).join("=")) || "";
        u = u.replace(/\+/g, " ");
        p.hasOwnProperty(v)
          ? typeof p[v] === "string"
            ? (p[v] = [p[v], u])
            : p[v].push(u)
          : (p[v] = u);
      }
    m.searchParams = p;
    m.origin = m.protocol + "//" + m.host;
    m.username = "";
    m.password = "";
    b = Ud(m);
    return b;
  }
  wS.publicName = "parseUrl";
  function xS(a) {}
  xS.P = "internal.processAsNewEvent";
  function yS(a, b, c) {
    var d;
    return d;
  }
  yS.P = "internal.pushToDataLayer";
  function zS(a) {
    var b = Pa.apply(1, arguments),
      c = !1;
    return c;
  }
  zS.publicName = "queryPermission";
  function AS(a) {
    var b = this;
  }
  AS.P = "internal.queueAdsTransmission";
  function BS(a) {
    var b = void 0;
    return b;
  }
  BS.publicName = "readAnalyticsStorage";
  function CS() {
    var a = "";
    return a;
  }
  CS.publicName = "readCharacterSet";
  function DS() {
    return F(19);
  }
  DS.P = "internal.readDataLayerName";
  function ES() {
    var a = "";
    return a;
  }
  ES.publicName = "readTitle";
  function FS(a, b) {
    var c = this;
  }
  FS.P = "internal.registerCcdCallback";
  function GS(a, b) {
    return !0;
  }
  GS.P = "internal.registerDestination";
  var HS = ["event"];
  function IS(a, b, c) {}
  IS.P = "internal.registerGtagCommandListener";
  function JS(a, b) {
    var c = !1;
    return c;
  }
  JS.P = "internal.removeDataLayerEventListener";
  function KS(a, b) {}
  KS.P = "internal.removeFormData";
  function LS() {}
  LS.publicName = "resetDataLayer";
  function MS(a, b, c) {
    var d = void 0;
    return d;
  }
  MS.P = "internal.scrubUrlParams";
  function NS(a) {}
  NS.P = "internal.sendAdsHit";
  function OS(a, b, c, d) {}
  OS.P = "internal.sendGtagEvent";
  function PS(a, b, c) {}
  PS.publicName = "sendPixel";
  function QS(a, b) {}
  QS.P = "internal.setAnchorHref";
  function RS(a) {}
  RS.P = "internal.setContainerConsentDefaults";
  function SS(a, b, c, d) {
    var e = this;
    d = d === void 0 ? !0 : d;
    var f = !1;
    return f;
  }
  SS.publicName = "setCookie";
  function TS(a) {}
  TS.P = "internal.setCorePlatformServices";
  function US(a, b) {}
  US.P = "internal.setDataLayerValue";
  function VS(a) {}
  VS.publicName = "setDefaultConsentState";
  function WS(a, b) {}
  WS.P = "internal.setDelegatedConsentType";
  function XS(a, b) {}
  XS.P = "internal.setFormAction";
  function YS(a, b, c) {
    c = c === void 0 ? !1 : c;
  }
  YS.P = "internal.setInCrossContainerData";
  function ZS(a, b, c) {
    return !1;
  }
  ZS.publicName = "setInWindow";
  function $S(a, b, c) {}
  $S.P = "internal.setProductSettingsParameter";
  function aT(a, b, c) {}
  aT.P = "internal.setRemoteConfigParameter";
  function bT(a, b) {}
  bT.P = "internal.setTransmissionMode";
  function cT(a, b, c, d) {
    var e = this;
  }
  cT.publicName = "sha256";
  function dT(a, b, c) {}
  dT.P = "internal.sortRemoteConfigParameters";
  function eT(a) {}
  eT.P = "internal.storeAdsBraidLabels";
  function fT(a, b) {
    var c = void 0;
    return c;
  }
  fT.P = "internal.subscribeToCrossContainerData";
  function gT(a) {}
  gT.P = "internal.taskSendAdsHits";
  var hT = {
    getItem: function (a) {
      var b = null;
      return b;
    },
    setItem: function (a, b) {},
    removeItem: function (a) {},
    clear: function () {},
    publicName: "templateStorage",
  };
  function iT(a, b) {
    var c = !1;
    return c;
  }
  iT.P = "internal.testRegex";
  function jT(a) {
    var b;
    return b;
  }
  function kT(a, b) {}
  kT.P = "internal.trackUsage";
  function lT(a, b) {
    var c;
    return c;
  }
  lT.P = "internal.unsubscribeFromCrossContainerData";
  function mT(a) {}
  mT.publicName = "updateConsentState";
  function nT(a) {
    var b = !1;
    return b;
  }
  nT.P = "internal.userDataNeedsEncryption";
  var oT = function () {
      this.H = new Rh();
    },
    qT = function () {
      return function (a) {
        var b;
        var c = pT.H;
        if (c.contains(a)) b = c.get(a, this);
        else {
          var d;
          if ((d = c.H.hasOwnProperty(a))) {
            var e = this.T.Eb();
            if (e) {
              var f = !1,
                g = e.Sb();
              if (g) {
                rh(g) || (f = !0);
              }
              d = f;
            } else d = !0;
          }
          if (d) {
            var h = c.H.hasOwnProperty(a) ? c.H[a] : void 0;
            b = h;
          } else throw Error(a + " is not a valid API name.");
        }
        return b;
      };
    },
    pT;
  function rT(a, b, c) {
    pT || (pT = new oT());
    pT.H.add(a, b, c);
  }
  function sT(a, b) {
    pT || (pT = new oT());
    var c = pT.H;
    if (c.H.hasOwnProperty(a))
      throw Error(
        "Attempting to add a private function which already exists: " + a + "."
      );
    if (c.contains(a))
      throw Error(
        "Attempting to add a private function with an existing API name: " +
          a +
          "."
      );
    c.H[a] = yb(b) ? kh(a, b) : lh(a, b);
  }
  function tT() {
    function a(c) {
      if (!Wg(c)) throw L(this.getName(), ["Object"], arguments);
      var d = B(c, this.T, 1).wb();
      b(d);
    }
    var b = PE;
    a.P = "internal.taskSetUniversalParams";
    return a;
  }
  function uT() {
    var a = function (c) {
        return void sT(c.P, c);
      },
      b = function (c) {
        return void rT(c.publicName, c);
      };
    b(RE);
    b(aF);
    b(mG);
    b(oG);
    b(pG);
    b(zG);
    b(BG);
    b(DH);
    b(pS());
    b(FH);
    b(wO);
    b(xO);
    b(UO);
    b(VO);
    b(WO);
    b(cP);
    b(dP);
    b(SR);
    b(VR);
    b(cS);
    b(eS);
    b(tS);
    b(wS);
    b(zS);
    b(BS);
    b(CS);
    b(ES);
    b(PS);
    b(SS);
    b(VS);
    b(ZS);
    b(cT);
    b(hT);
    b(mT);
    rT("Math", ph());
    rT("Object", Ph);
    rT("TestHelper", Th());
    rT("assertApi", mh);
    rT("assertThat", nh);
    rT("decodeUri", sh);
    rT("decodeUriComponent", th);
    rT("encodeUri", uh);
    rT("encodeUriComponent", vh);
    rT("fail", Ah);
    rT("generateRandom", Dh);
    rT("getTimestamp", Eh);
    rT("getTimestampMillis", Eh);
    rT("getType", Fh);
    rT("makeInteger", Hh);
    rT("makeNumber", Ih);
    rT("makeString", Jh);
    rT("makeTableMap", Kh);
    rT("mock", Nh);
    rT("mockObject", Oh);
    rT("fromBase64", pO, !("atob" in w));
    rT("localStorage", sS, !rS());
    rT("toBase64", jT, !("btoa" in w));
    a(QE);
    a(XE);
    a(qF);
    a(CF);
    a(JF);
    a(OF);
    a(dG);
    a(kG);
    a(nG);
    a(qG);
    a(rG);
    a(uG);
    a(vG);
    a(wG);
    a(xG);
    a(yG);
    a(AG);
    a(CG);
    a(CH);
    a(EH);
    a(GH);
    a(HH);
    a(IH);
    a(JH);
    a(KH);
    a(QI);
    a(VI);
    a(bJ);
    a(cJ);
    a(iJ);
    a(nJ);
    a(sJ);
    a(zJ);
    a(EJ);
    a(PJ);
    a(RJ);
    a(dK);
    a(eK);
    a(fK);
    a(nO);
    a(oO);
    a(qO);
    a(rO);
    a(sO);
    a(tO);
    a(uO);
    a(vO);
    a(yO);
    a(zO);
    a(AO);
    a(BO);
    a(CO);
    a(DO);
    a(EO);
    a(FO);
    a(GO);
    a(HO);
    a(IO);
    a(JO);
    a(KO);
    a(LO);
    a(MO);
    a(NO);
    a(OO);
    a(PO);
    a(QO);
    a(RO);
    a(SO);
    a(TO);
    a(XO);
    a(YO);
    a(ZO);
    a($O);
    a(aP);
    a(bP);
    a(eP);
    a(PR);
    a(QR);
    a(UR);
    a(WR);
    a(dS);
    a(fS);
    a(gS);
    a(hS);
    a(iS);
    a(jS);
    a(kS);
    a(lS);
    a(mS);
    a(nS);
    a(oS);
    a(qS);
    a(bG);
    a(uS);
    a(vS);
    a(xS);
    a(yS);
    a(AS);
    a(DS);
    a(FS);
    a(GS);
    a(IS);
    a(JS);
    a(KS);
    a(MS);
    a(NS);
    a(OS);
    a(QS);
    a(RS);
    a(TS);
    a(US);
    a(WS);
    a(XS);
    a(YS);
    a($S);
    a(aT);
    a(bT);
    a(dT);
    a(eT);
    a(fT);
    a(gT);
    a(iT);
    a(kT);
    a(lT);
    a(nT);
    sT("internal.IframingStateSchema", TR());
    sT("internal.quickHash", Ch);
    pT || (pT = new oT());
    return qT();
  }
  var LE;
  function vT() {
    LE.zd(function (a, b, c) {
      Dn();
      var d = Bn;
      d.H.SANDBOXED_JS_SEMAPHORE = d.H.SANDBOXED_JS_SEMAPHORE || 0;
      d.H.SANDBOXED_JS_SEMAPHORE++;
      try {
        return a.apply(b, c);
      } finally {
        Dn(), Bn.H.SANDBOXED_JS_SEMAPHORE--;
      }
    });
  }
  function wT(a) {
    if (a && a.length)
      for (
        var b = uj(26, function () {
            return {};
          }),
          c = 0;
        c < a.length;
        c++
      ) {
        var d = a[c].replace(/^_*/, "");
        b[d] = ["sandboxedScripts"];
      }
  }
  function xT(a) {
    if (a) {
      var b = uj(26, function () {
        return {};
      });
      Gb(a, function (c, d) {
        for (var e = 0; e < d.length; e++) {
          var f = d[e].replace(/^_*/, "");
          b[f] = b[f] || [];
          b[f].push(c);
        }
      });
    }
  }
  function yT(a) {
    QC(jp("developer_id." + a, !0), 0, {});
  }
  function zT(a, b) {
    return Gd(a, b || null);
  }
  function X(a) {
    return window.encodeURIComponent(a);
  }
  function AT(a, b, c) {
    bd(a, b, c);
  }
  function BT(a) {
    var b = ["veinteractive.com", "ve-interactive.cn"];
    if (!a) return !1;
    var c = Ij(Oj(a), "host");
    if (!c) return !1;
    for (var d = 0; b && d < b.length; d++) {
      var e = b[d] && b[d].toLowerCase();
      if (e) {
        var f = c.length - e.length;
        f > 0 && e.charAt(0) !== "." && (f--, (e = "." + e));
        if (f >= 0 && c.indexOf(e, f) === f) return !0;
      }
    }
    return !1;
  }
  function CT(a, b, c) {
    for (var d = {}, e = !1, f = 0; a && f < a.length; f++)
      a[f] &&
        a[f].hasOwnProperty(b) &&
        a[f].hasOwnProperty(c) &&
        ((d[a[f][b]] = a[f][c]), (e = !0));
    return e ? d : null;
  }
  function DT(a, b) {
    var c = {};
    if (a) for (var d in a) a.hasOwnProperty(d) && (c[d] = a[d]);
    if (b) {
      var e = CT(b, "parameter", "parameterValue");
      e && (c = zT(e, c));
    }
    return c;
  }
  function ET(a, b, c) {
    return a === void 0 || a === c ? b : a;
  }
  function FT(a, b, c) {
    return Yc(a, b, c, void 0);
  }
  function GT(a, b) {
    w[a] = b;
  }
  function HT(a, b, c) {
    var d = w;
    b && (d[a] === void 0 || (c && !d[a])) && (d[a] = b);
    return d[a];
  }

  var IT = {},
    JT = O.R;
  var Y = { securityGroups: {} };

  (Y.securityGroups.get_referrer = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Y.__get_referrer = b;
        Y.__get_referrer.N = "get_referrer";
        Y.__get_referrer.isVendorTemplate = !0;
        Y.__get_referrer.priorityOverride = 0;
        Y.__get_referrer.isInfrastructure = !1;
        Y.__get_referrer["5"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!zb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified."
                  );
                if (!zb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified."
              );
          },
          aa: a,
        };
      });
    })();
  (Y.securityGroups.read_event_data = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Y.__read_event_data = b;
        Y.__read_event_data.N = "read_event_data";
        Y.__read_event_data.isVendorTemplate = !0;
        Y.__read_event_data.priorityOverride = 0;
        Y.__read_event_data.isInfrastructure = !1;
        Y.__read_event_data["5"] = !1;
      })(function (b) {
        var c = b.vtp_eventDataAccess,
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (g != null && !zb(g))
              throw e(f, { key: g }, "Key must be a string.");
            if (c !== "any") {
              try {
                if (c === "specific" && g != null && Ag(g, d)) return;
              } catch (h) {
                throw e(f, { key: g }, "Invalid key filter.");
              }
              throw e(f, { key: g }, "Prohibited read from event data.");
            }
          },
          aa: a,
        };
      });
    })();

  (Y.securityGroups.read_data_layer = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Y.__read_data_layer = b;
        Y.__read_data_layer.N = "read_data_layer";
        Y.__read_data_layer.isVendorTemplate = !0;
        Y.__read_data_layer.priorityOverride = 0;
        Y.__read_data_layer.isInfrastructure = !1;
        Y.__read_data_layer["5"] = !1;
      })(function (b) {
        var c = b.vtp_allowedKeys || "specific",
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (!zb(g)) throw e(f, {}, "Keys must be strings.");
            if (c !== "any") {
              try {
                if (Ag(g, d)) return;
              } catch (h) {
                throw e(f, {}, "Invalid key filter.");
              }
              throw e(
                f,
                {},
                "Prohibited read from data layer variable: " + g + "."
              );
            }
          },
          aa: a,
        };
      });
    })();

  (Y.securityGroups.get_url = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Y.__get_url = b;
        Y.__get_url.N = "get_url";
        Y.__get_url.isVendorTemplate = !0;
        Y.__get_url.priorityOverride = 0;
        Y.__get_url.isInfrastructure = !1;
        Y.__get_url["5"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"),
          b.vtp_fragment && c.push("fragment"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!zb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified."
                  );
                if (!zb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified."
              );
          },
          aa: a,
        };
      });
    })();

  function KT() {
    var a = {},
      b = {
        dataLayer: Jp,
        callback: function (c) {
          a.hasOwnProperty(c) && yb(a[c]) && a[c]();
          delete a[c];
        },
        bootstrap: 0,
      };
    return b;
  }
  function LT() {
    var a = KT();
    Gn(a);
    Al();
    fB();
    var b = uj(26, function () {
      return {};
    });
    Sb(b, Y.securityGroups);
    var c = wl(xl()),
      d,
      e = c == null ? void 0 : (d = c.context) == null ? void 0 : d.source;
    lo(e, c == null ? void 0 : c.parent);
    (e !== 2 && e !== 4 && e !== 3) || T(142);
    return a;
  }
  function MT() {
    var a = F(60);
    if (a)
      for (var b = a.split("."), c = 0; c < b.length; c++) {
        var d = b[c],
          e = EL;
        d && (e.H[d] = !0);
      }
  }
  function NT() {
    mj();
    Dn();
    for (
      var a = data.resource || {}, b = ZA, c = a.macros || [], d = 0;
      d < c.length;
      d++
    )
      b.macros.push(new QA(c[d], d, b.tags, b.macros));
    for (var e = a.tags || [], f = 0; f < e.length; f++)
      b.tags.push(new UA(e[f], f, b.tags, b.macros));
    for (var g = a.predicates || [], h = 0; h < g.length; h++)
      b.predicates.push(new RA(g[h], b.tags, b.macros));
    for (var l = a.rules || [], m = 0; m < l.length; m++)
      b.rules.push(new SA(l[m], m));
    OA = Y;
    var p = data.permissions || {},
      q = Y;
    bg = new eg(F(5), p, q);
    var r = data.sandboxed_scripts,
      t = data.security_groups,
      v = data.runtime || [],
      u = data.runtime_lines;
    LE = new pf();
    vT();
    NA = KE();
    var x = LE,
      y = uT(),
      A = new Nd("require", y);
    A.Ya();
    x.H.H.set("require", A);
    db.set("require", A);
    for (var C = 0; C < v.length; C++) {
      var D = v[C];
      if (!Array.isArray(D) || D.length < 3) {
        if (D.length === 0) continue;
        break;
      }
      u && u[C] && u[C].length && Of(D, u[C]);
      try {
        LE.execute(D);
      } catch (OT) {}
    }
    wT(r);
    xT(t);
    var E = LT();
    kE();
    Fm.bind();
    if (!Ri)
      for (
        var G = Lm() ? Io(Kf(5)) : Io(Kf(4)), I = n(uo), Q = I.next();
        !Q.done;
        Q = I.next()
      ) {
        var V = Q.value,
          S = V,
          ja = G[V] ? "granted" : "denied";
        Pl().implicit(S, ja);
      }
    jD.bind();
    EC();
    zC();
    mk.K &&
      ($p(),
      Zp(CE),
      cB(),
      (QB = new PB()),
      Zp(Nz),
      eq(),
      FE || (FE = new DE()),
      TB || (TB = new SB()),
      (HE = new GE()));
    if (mk.H) {
      JD.bind();
      Zo.bind();
      CD.bind();
      var fa = yl();
      if (fa) {
        var ka;
        a: {
          var Z,
            ia = (Z = fa.scriptElement) == null ? void 0 : Z.src;
          if (ia) {
            var ya;
            try {
              var ra;
              ya =
                (ra = ud()) == null ? void 0 : ra.getEntriesByType("resource");
            } catch (OT) {}
            if (ya) {
              for (
                var ua = -1, Oa = n(ya), fb = Oa.next();
                !fb.done;
                fb = Oa.next()
              ) {
                var Nb = fb.value;
                if (
                  Nb.initiatorType === "script" &&
                  ((ua += 1), Nb.name.replace(PD, "") === ia.replace(PD, ""))
                ) {
                  ka = ua;
                  break a;
                }
              }
              T(146);
            } else T(145);
          }
          ka = void 0;
        }
        var rc = ka;
        rc !== void 0 &&
          (fa.canonicalContainerId &&
            Bj("rtg", String(fa.canonicalContainerId)),
          Bj("slo", String(rc)),
          Bj("hlo", fa.htmlLoadOrder || "-1"),
          Bj("lst", String(fa.loadScriptType || "0")));
      } else T(144);
      var jc;
      var Qb = vl();
      if (Qb)
        if (Qb.canonicalContainerId) jc = Qb.canonicalContainerId;
        else {
          var wc,
            ve =
              Qb.scriptContainerId ||
              ((wc = Qb.destinations) == null ? void 0 : wc[0]);
          jc = ve ? "_" + ve : void 0;
        }
      else jc = void 0;
      var Fl = jc;
      Fl && Bj("pcid", Fl);
      Bj("bt", String(Hf(47) ? 2 : Hf(50) ? 1 : 0));
      Bj("ct", String(Hf(47) ? 0 : Hf(50) ? 1 : 3));
      GD.bind();
      for (
        var Vr = [], Wr = [], TE = n(Object.keys(MD)), Xr = TE.next();
        !Xr.done;
        Xr = TE.next()
      ) {
        var om = Xr.value;
        if (window.isSecureContext || !OD[om]) {
          var UE = MD[om]();
          if (yb(UE)) {
            var VE = Function.prototype.toString.call(UE);
            Vb(VE, "{ [native code] }") ||
              Vb(VE, "{\n    [native code]\n}") ||
              Wr.push(om);
          } else Vr.push(om);
        }
      }
      Vr.length > 0 && Bj("jsm", Vr.join("~"));
      Wr.length > 0 && Bj("jsp", Wr.join("~"));
      nz || (nz = new mz());
    }
    jE();
    Bm(1);
    $F();
    return E;
  }
  function Em() {
    try {
      if (Hf(47) || !Ml()) {
        Hf(64) && Ki.H.K.add(118517917);
        Ni();
        nk() && eA({ stage: Iz.W.Vi });
        Uf[5] = !0;
        var a = Cn("debugGroupId", function () {
          return String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
        });
        to(a);
        Lo();
        BE();
        br();
        AC();
        if (Bl()) {
          F(5);
          ZF();
          WB().removeExternalRestrictions(tl());
        } else {
          NT().bootstrap = Ob();
          Hf(51) && vD();
          nk() && iA();
          typeof w.name === "string" &&
          Ub(w.name, "web-pixel-sandbox-CUSTOM") &&
          vd()
            ? yT("dMDg0Yz")
            : w.Shopify && (yT("dN2ZkMj"), vd() && yT("dNTU0Yz"));
          MT();
        }
      }
    } catch (b) {
      Bm(5), aq();
    }
  }
  (function (a) {
    function b() {
      m = z.documentElement.getAttribute("data-tag-assistant-present");
      Yn(m) && (l = h.Pm);
    }
    function c() {
      l && Pc ? g(l) : a();
    }
    if (!w[F(37)]) {
      var d = !1;
      if (z.referrer) {
        var e = Oj(z.referrer);
        d = Kj(e, "host") === F(38);
      }
      if (!d) {
        var f = fs(F(39));
        d = !(!f.length || !f[0].length);
      }
      d && ((w[F(37)] = !0), Yc(F(40)));
    }
    var g = function (v) {
        var u = "GTM",
          x = "GTM";
        Hf(45) && ((u = "OGT"), (x = "GTAG"));
        var y = F(23),
          A = w[y];
        A ||
          ((A = []),
          (w[y] = A),
          Yc(
            "https://" +
              F(3) +
              "/debug/bootstrap?id=" +
              F(5) +
              "&src=" +
              x +
              "&cond=" +
              String(v) +
              "&gtm=" +
              Np()
          ));
        var C = {
          messageType: "CONTAINER_STARTING",
          data: {
            scriptSource: Pc,
            containerProduct: u,
            debug: !1,
            id: F(5),
            targetRef: { ctid: F(5), isDestination: ql(), canonicalId: F(6) },
            aliases: ul(),
            destinations: rl(),
          },
        };
        C.data.resume = function () {
          a();
        };
        Hf(2) && (C.data.initialPublish = !0);
        A.push(C);
      },
      h = { Yq: 1, ln: 2, Hn: 3, Dl: 4, Pm: 5 };
    h[h.Yq] = "GTM_DEBUG_LEGACY_PARAM";
    h[h.ln] = "GTM_DEBUG_PARAM";
    h[h.Hn] = "REFERRER";
    h[h.Dl] = "COOKIE";
    h[h.Pm] = "EXTENSION_PARAM";
    var l = void 0,
      m = void 0,
      p = Ij(w.location, "query", !1, void 0, "gtm_debug");
    Yn(p) && (l = h.ln);
    if (!l && z.referrer) {
      var q = Oj(z.referrer);
      Kj(q, "host") === F(24) && (l = h.Hn);
    }
    if (!l) {
      var r = fs("__TAG_ASSISTANT");
      r.length && r[0].length && (l = h.Dl);
    }
    l || b();
    if (!l && Xn(m)) {
      var t = !1;
      cd(
        z,
        "TADebugSignal",
        function () {
          t || ((t = !0), b(), c());
        },
        !1
      );
      w.setTimeout(function () {
        t || ((t = !0), b(), c());
      }, 200);
    } else c();
  })(function () {
    !Hf(47) || Dm()["0"] ? Em() : Hm();
  });
})();
