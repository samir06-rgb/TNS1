(function () {
  if (((window.jdgm = window.jdgm || {}), jdgm._loaderExecuted)) return;
  (jdgm._loaderExecuted = !0), (window.judgeme = jdgm);
  const l = window.jdgmSettings || {};
  (jdgm.WIDGET_REBRANDING_ENABLED = l.widget_version === "3.0"),
    (jdgm.isVersion3 = parseFloat(l.widget_version) >= 3),
    jdgm.CDN_HOST || (jdgm.CDN_HOST = "https://cdnwidget.judge.me/"),
    jdgm.CDN_HOST_ALT ||
      (jdgm.CDN_HOST_ALT = "https://cdn2.judge.me/cdn/widget_frontend/"),
    jdgm.API_HOST || (jdgm.API_HOST = "https://api.judge.me"),
    jdgm.docReady ||
      (jdgm.docReady = function (e) {
        (
          document.attachEvent
            ? document.readyState === "complete"
            : document.readyState !== "loading"
        )
          ? setTimeout(e, 0)
          : document.addEventListener("DOMContentLoaded", e);
      });
  function q() {
    return window.location.search.includes("jdgm_debug=true");
  }
  const F = q(),
    n = "[JM Loader]";
  function a(...e) {
    F && console.log(...e);
  }
  jdgm.debugLog = a;
  var _ = function (e) {
      return e.indexOf(jdgm.CDN_HOST) === 0 &&
        jdgm.CDN_HOST_ALT !== jdgm.CDN_HOST
        ? e.replace(jdgm.CDN_HOST, jdgm.CDN_HOST_ALT)
        : null;
    },
    M = {
      "widget/arp.js": !0,
      "widget/base.js": !0,
      "widget/common.js": !0,
      "widget/form.js": !0,
      "widget/main.js": !0,
      "widget/media.js": !0,
      "widget/others.js": !0,
      "video_carousel.js": !0,
      "widget/write_review_modal.js": !0,
      "shopify_v2.js": !0,
      "widget/base.css": !0,
      "widget/main.css": !0,
      "widget/form.css": !0,
      "widget/media.css": !0,
      "widget_v3/base.css": !0,
      "widget_v3/main.css": !0,
      "widget_v3/form.css": !0,
      "widget_v3/media.css": !0,
      "shopify_v2.css": !0,
    },
    S = function (e) {
      if (e.indexOf("//") === -1)
        return jdgm.CDN_BASE_URL
          ? jdgm.CDN_BASE_URL + e.replace(/\//g, "_")
          : jdgm.CDN_HOST + e;
      if (
        jdgm.CDN_BASE_URL &&
        jdgm.CDN_HOST &&
        e.indexOf(jdgm.CDN_HOST) === 0
      ) {
        var t = e.replace(jdgm.CDN_HOST, "");
        if (M[t]) return jdgm.CDN_BASE_URL + t.replace(/\//g, "_");
      }
      return e;
    };
  if (
    ((jdgm.prefetchResource = function (e, t) {
      var r = S(e),
        i = document.createElement("link");
      (i.className = "jdgm-prefetch"),
        (i.rel = "prefetch"),
        (i.crossOrigin = ""),
        t && (i.as = t),
        (i.href = r);
      var d = _(r);
      d &&
        (i.onerror = function () {
          jdgm.prefetchResource(d, t);
        }),
        document.body.appendChild(i);
    }),
    (jdgm.loadScript = function (e, t, r) {
      var i = S(e);
      if (!(!r && jdgm.loadScript.requestedUrls.indexOf(i) >= 0))
        if (
          (jdgm.loadScript.requestedUrls.push(i),
          e !== i && jdgm.loadScript.requestedUrls.push(e),
          jdgm.loadJS && l.widget_advanced_speed_features <= 10)
        )
          jdgm.loadJS(i, t);
        else if (jdgm.$ && jdgm.$.ajax)
          jdgm.$.ajax({ dataType: "script", cache: !0, url: i })
            .done(t)
            .fail(function () {
              var g = _(i);
              g && jdgm.loadScript(g, t, r);
            });
        else {
          var d = document.createElement("script");
          (d.className = "jdgm-script"),
            (d.type = "text/javascript"),
            (d.src = i),
            (d.async = !0),
            t && (d.onload = t);
          var o = _(i);
          o &&
            (d.onerror = function () {
              jdgm.loadScript(o, t, r);
            }),
            document.body.appendChild(d);
        }
    }),
    (jdgm.loadScript.requestedUrls = []),
    jdgm.loadCSS)
  ) {
    var L = jdgm.loadCSS;
    (jdgm.loadCSS = function (e, t, r) {
      var i = S(e);
      return (
        e !== i &&
          jdgm.loadCSS.requestedUrls.indexOf(e) === -1 &&
          jdgm.loadCSS.requestedUrls.push(e),
        L(i, t, r)
      );
    }),
      (jdgm.loadCSS.requestedUrls = L.requestedUrls);
  } else
    (jdgm.loadCSS = function (e, t, r) {
      var i = S(e);
      if (!(!r && jdgm.loadCSS.requestedUrls.indexOf(i) >= 0)) {
        jdgm.loadCSS.requestedUrls.push(i),
          e !== i && jdgm.loadCSS.requestedUrls.push(e);
        var d = document.createElement("link");
        (d.rel = "stylesheet"),
          (d.className = "jdgm-stylesheet"),
          (d.media = "nope!"),
          (d.href = i),
          (d.onload = function () {
            (this.media = "all"), t && setTimeout(t);
          });
        var o = _(i);
        o &&
          (d.onerror = function () {
            jdgm.loadCSS(o, t, r);
          }),
          document.body.appendChild(d);
      }
    }),
      (jdgm.loadCSS.requestedUrls = []);
  jdgm.widgetPath = function (e) {
    var t = jdgm.isVersion3 ? "widget_v3/" : "widget/";
    return jdgm.CDN_HOST + t + e;
  };
  var E = ".jdgm-all-reviews-page, .jdgm-all-reviews-widget",
    w = ".jdgm-review-widget, #judgeme_product_reviews",
    j = {
      "widget/arp.js": E,
      "widget/others.js":
        ".jdgm-carousel, .jdgm-revs-tab, .jdgm-all-reviews-rating, .jdgm-medals, .jdgm-all-reviews-text__text, .jdgm-ugc-media, .jdgm-verified-badge, .jdgm-popup-widget, .jdgm-review-snippet-widget, .jdgm-videos-carousel, .jdgm-cards-carousel",
      "widget/main.js": ".jdgm-preview-badge, .judgeme-preview-badge",
      "widget/write_review_modal.js":
        w + ', [data-widget="review"], [data-widget="all-reviews-v2025"]',
    },
    p = Object.assign({}, j, {
      "widget/media.js":
        ".jdgm-revs-tab, .jdgm-medal__image, .jdgm-ugc-media, " + E,
    });
  l.review_widget_revamp_enabled ||
    ((j["widget/main.js"] += ", " + w), (p["widget/media.js"] += ", " + w));
  var h = {
      "main.css": {
        selector: w + ", .jdgm-revs-tab, .jdgm-ugc-media, " + E,
        callback: function () {
          var e = document.createEvent("Event");
          e.initEvent("jdgm.doneLoadingCss", !0, !0), document.dispatchEvent(e);
        },
      },
    },
    T = { "media.css": ".jdgm-ugc-media" },
    x = [
      "judgeme_token",
      "judgeme_review_uuid",
      "judgeme_dynamic_form",
      "judgeme_follow_up_token",
      "judgeme_upload_pictures",
      "judgeme_pre_verified",
    ],
    D = !1,
    A = !1,
    O = [],
    N = function () {
      return document.querySelectorAll(Object.values(j).join(", ")).length > 0;
    },
    I = function () {
      (A = !0),
        O.forEach(function (e) {
          e();
        }),
        setTimeout(function () {
          jdgm.triggerVanillaEvent("finishLoadingCore");
        }, 0);
    },
    G = function (e) {
      D ||
        ((D = !0),
        jdgm.loadScript("widget/base.js", function () {
          jdgm.loadScript("widget/common.js", I);
        }),
        jdgm.prefetchResource("widget/common.js", "script")),
        A ? e() : O.push(e);
    },
    J = function () {
      var e = window.location,
        t = e.hash == "#judgeme" || e.hash == "#judgeme_product_reviews";
      return (
        x.forEach(function (r) {
          t = t || e.search.indexOf(r) >= 0;
        }),
        t
      );
    },
    B = function () {
      var e = J();
      G(function () {
        Object.keys(j).forEach(function (t) {
          document.querySelectorAll(j[t]).length > 0 &&
            jdgm.loadScript(jdgm.CDN_HOST + t);
        }),
          e &&
            (jdgm.loadScript(jdgm.CDN_HOST + "widget/form.js"),
            jdgm.loadScript(jdgm.CDN_HOST + "widget/write_review_modal.js"),
            jdgm.loadCSS(jdgm.widgetPath("form.css")));
      }),
        Object.keys(p).forEach(function (t) {
          document.querySelectorAll(p[t]).length > 0 &&
            jdgm.prefetchResource(jdgm.CDN_HOST + t, "script");
        }),
        e ||
          (jdgm.prefetchResource(jdgm.CDN_HOST + "widget/form.js", "script"),
          jdgm.prefetchResource(jdgm.widgetPath("form.css"), "style"));
    },
    Y = function () {
      jdgm.loadCSS(jdgm.widgetPath("base.css")),
        Object.keys(h).forEach(function (e) {
          if (document.querySelectorAll(h[e].selector).length > 0) {
            var t = jdgm.widgetPath(e);
            jdgm.loadCSS(t, h[e].callback);
          }
        }),
        Object.keys(T).forEach(function (e) {
          document.querySelectorAll(T[e]).length > 0 &&
            jdgm.prefetchResource(jdgm.widgetPath(e), "style");
        });
    };
  jdgm.docReady(function () {
    (window.jdgmLoadCSS || N()) &&
      (l.widget_load_with_code_splitting
        ? Y()
        : jdgm.loadCSS(jdgm.CDN_HOST + "shopify_v2.css"));
  }),
    jdgm.docReady(function () {
      (window.jdgmLoadJS || N()) &&
        (l.widget_load_with_code_splitting
          ? B()
          : jdgm.loadScript(jdgm.CDN_HOST + "shopify_v2.js", I));
    }),
    a(n, "Script loaded and executing...");
  const b = ".jdgm-widget[data-entry-point]",
    v = document.querySelectorAll(b);
  if (v.length === 0) {
    a(n, "No containers found with selector:", b);
    return;
  }
  a(n, "Found " + v.length + " container(s)");
  const W = new Set(),
    s = {
      REVIEW: "review",
      ALL_REVIEWS_V2025: "all-reviews-v2025",
      CAROUSEL: "carousel",
      TRUST_BADGE: "trust-badge",
      STORE_SUMMARY: "store-summary",
      REVIEWS_GRID: "reviews-grid",
    },
    K = {
      review: s.REVIEW,
      "all-reviews-v2025": s.ALL_REVIEWS_V2025,
      "testimonials-carousel": s.CAROUSEL,
      "cards-carousel": s.CAROUSEL,
      "videos-carousel": s.CAROUSEL,
      "trust-badge": s.TRUST_BADGE,
      "store-summary": s.STORE_SUMMARY,
      "reviews-grid": s.REVIEWS_GRID,
    };
  function $(e) {
    const t = e.dataset.widget;
    return K[t] || null;
  }
  function z(e) {
    const t = e.querySelector(".jdgm-legacy-widget-content");
    return t ? t.innerHTML.trim().length > 20 : !1;
  }
  function X(e, t) {
    if (t === s.ALL_REVIEWS_V2025) {
      const d = window.jdgm?.data?.allReviewsWidgetV2025;
      return !!(d && Object.keys(d).length > 0);
    }
    const r = e.dataset.productId,
      i = window.jdgm?.data?.reviewWidget?.[r];
    return !!(i && i.reviews !== void 0);
  }
  function H(e, t, r) {
    const i = l?.[t],
      d = z(e),
      o = X(e, r);
    return {
      shouldLoadRevamp: i ? o || !d : !d && o,
      productId: e.dataset.productId,
      revampEnabled: i,
      hasLegacy: d,
      hasRevamp: o,
    };
  }
  function P(e, t, r, i) {
    a(n, r, t);
    let d;
    i === s.ALL_REVIEWS_V2025
      ? (d = window.jdgm?.data?.allReviewsWidgetV2025)
      : (d = window.jdgm?.data?.reviewWidget?.[t.productId]);
    const o = !!d;
    t.hasRevamp !== o &&
      console.warn(
        n,
        "Data mismatch - Liquid hasRevamp:",
        t.hasRevamp,
        "JS sees:",
        o,
        d
      );
  }
  function V(e) {
    const t = e.querySelector(".jdgm-legacy-widget-content");
    t && (t.style.display = ""), a(n, "Legacy widget displayed");
  }
  function m(e) {
    const t = e.dataset.entryPoint,
      r = e.dataset.entryKey;
    if (!t || !r) {
      a(n, "Missing entryPoint or entryKey, skipping container");
      return;
    }
    const i = window.jdgm.CDN_BASE_URL;
    if (!i) {
      a(n, "CDN_BASE_URL not available, skipping revamp widget");
      return;
    }
    const d = i + t,
      o = e.querySelector(".jdgm-rev-widg");
    if (
      (o &&
        ((o.style.display = "none"),
        a(n, "Hidden legacy widget element (.jdgm-rev-widg)")),
      a(n, "Loading revamp widget:", t),
      W.has(d) || document.querySelector('script[src="' + d + '"]'))
    ) {
      a(n, "Script already loaded, skipping:", t);
      return;
    }
    W.add(d),
      Q(i, r, t).finally(() => {
        const g = document.createElement("script");
        (g.type = "module"),
          (g.src = d),
          (g.onload = () => {
            a(n, "Revamp widget loaded:", t);
          }),
          (g.onerror = () => {
            console.error(n, "Failed to load revamp widget:", t);
          }),
          document.head.appendChild(g);
      });
  }
  async function Q(e, t, r) {
    if (!(e + r).includes("localhost"))
      try {
        let R = function (y) {
          const c = k[y];
          c &&
            (c.css &&
              c.css.forEach((f) => {
                const U = e + f;
                if (!document.querySelector('link[href="' + U + '"]')) {
                  const C = document.createElement("link");
                  (C.rel = "stylesheet"),
                    (C.href = U),
                    document.head.appendChild(C);
                }
              }),
            c.imports && c.imports.forEach(R));
        };
        var d = R;
        const o = e + "manifest.json?v=" + Date.now(),
          k = await (await fetch(o)).json(),
          u = k[t];
        u &&
          u.css &&
          u.css.forEach((y) => {
            const c = e + y;
            if (!document.querySelector('link[href="' + c + '"]')) {
              const f = document.createElement("link");
              (f.rel = "stylesheet"),
                (f.href = c),
                document.head.appendChild(f);
            }
          }),
          u && u.imports && u.imports.forEach(R);
      } catch (o) {
        console.warn("Could not load manifest or CSS files:", o);
      }
  }
  v.forEach((e, t) => {
    const r = $(e),
      i = e.dataset.entryPoint;
    if (
      (a(
        n,
        "Container " +
          (t + 1) +
          "/" +
          v.length +
          " - Type: " +
          r +
          ", Entry: " +
          i
      ),
      !r)
    ) {
      a(n, "Unknown widget type, skipping");
      return;
    }
    switch (r) {
      case s.REVIEW: {
        const d = H(e, "review_widget_revamp_enabled", s.REVIEW);
        P(e, d, "Review Widget", s.REVIEW), d.shouldLoadRevamp ? m(e) : V(e);
        break;
      }
      case s.ALL_REVIEWS_V2025: {
        const d = H(e, "all_reviews_widget_v2025_enabled", s.ALL_REVIEWS_V2025);
        P(e, d, "All Reviews V2025 Widget", s.ALL_REVIEWS_V2025),
          d.shouldLoadRevamp ? m(e) : V(e);
        break;
      }
      case s.CAROUSEL:
        a(n, "Carousel widget - loading revamp"), m(e);
        break;
      case s.TRUST_BADGE: {
        a(n, "Trust Badge widget"), m(e);
        break;
      }
      case s.STORE_SUMMARY: {
        a(n, "Store Summary widget"), m(e);
        break;
      }
      case s.REVIEWS_GRID: {
        a(n, "Reviews Grid widget"), m(e);
        break;
      }
    }
  });
})();
